package com.louison.clikOcustomer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
