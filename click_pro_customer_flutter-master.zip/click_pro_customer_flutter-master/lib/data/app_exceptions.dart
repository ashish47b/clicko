
import 'package:get/get.dart';

class AppExceptions implements Exception{

  final _meesage;
  final _prefix;

  AppExceptions([this._meesage, this._prefix]);

  String toString(){
    return '$_prefix$_meesage';
  }
}


class InternetException extends AppExceptions{
  InternetException({String?message}) : super(message, 'No Internet'.tr);
}

class RequestTimeException extends AppExceptions{
  RequestTimeException({String?message}) : super(message, 'Request Time Out'.tr);
}

class ServerException extends AppExceptions{
  ServerException({String?message}) : super(message, 'Internel Server Error'.tr);
}

class InvalidRequestException extends AppExceptions{
  InvalidRequestException({String?message}) : super(message, 'Invalid Request'.tr);
}

class PageNotFoundException extends AppExceptions{
  PageNotFoundException({String?message}) : super(message, 'Page Not Found'.tr);
}

class FetchDataException extends AppExceptions{
  FetchDataException({String?message}) : super(message, 'Please try Again'.tr);
}