import 'package:click_pro_customer/data/network/network_service_api.dart';
import 'package:click_pro_customer/data/response/api_response.dart';
import 'package:click_pro_customer/model/BidsDataModel/bids_data_model.dart';
import 'package:click_pro_customer/model/DepositDataModel.dart';
import 'package:click_pro_customer/model/NegotiationMOdel/negotiation_list.dart';
import 'package:click_pro_customer/model/ProfessionalModel/prof_profile_model.dart';
import 'package:click_pro_customer/res/api/api.dart';

class BiddersRepo{
   
   final apiService = NetworkServiceApi();

   Future<BidsDataModel> getBiddersRepo(var data )async{
    final response = await apiService.postApi(API.BIDDERS_LIST, data);
    return BidsDataModel.fromJson(response);
   }

   Future<ApiResponse>  rejectBidRepo(var data)async{
    final response = await apiService.postApi(API.REJECT_BID, data);
    return ApiResponse.fromJson(response);
   }

   Future<ApiResponse>  approveBidRepo(var data)async{
    final response = await apiService.postApi(API.APPROVED_BID, data);
    return ApiResponse.fromJson(response);
   }

   Future<ProfessionalDataModel> profRepo(var data)async {
    final response = await apiService.postApi(API.PROFF_PROFILE, data);
    return ProfessionalDataModel.fromJson(response);
   }

  Future<ApiResponse>  getRatingRepo(var data)async{
    final response = await apiService.postApi(API.GET_PROF_RATINGS, data);
    return ApiResponse.fromJson(response);
   }

  Future<ApiResponse> nofTimeuHire(var data) async {
    final response = await apiService.postApi(API.NO_OF_TIME_YOU_HIRED, data);
    return ApiResponse.fromJson(response);
  }

  Future<NegotiationListDataModel> negotiationListRepo(var data) async {
    final response = await apiService.postApi(API.NEGOTIATION_LIST, data);
    return NegotiationListDataModel.fromJson(response);
  }

  Future<ApiResponse> saveNegoRepo(Map<String,String> data)async{
    final response = await apiService.postFormApi(API.SAVE_MILESTONE, data);
    return ApiResponse.fromJson(response);
  }

  Future<DepositDataModel> saveDepositRepo(var data)async{
    final response = await apiService.postApi(API.SAVE_DEPOSIT, data);
    return DepositDataModel.fromJson(response);
  }

    Future<ApiResponse> payDepositRepo(var data)async{
    final response = await apiService.postApi(API.PAY_DEPOSIT, data);
    return ApiResponse.fromJson(response);
  }


}