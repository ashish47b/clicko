import 'dart:io';

import 'package:click_pro_customer/data/network/network_service_api.dart';
import 'package:click_pro_customer/data/response/api_response.dart';
import 'package:click_pro_customer/model/CustomerProfile/cust_profile_model.dart';
import 'package:click_pro_customer/res/api/api.dart';

class ProfileRepo{

  final apiService = NetworkServiceApi();

  Future<ApiResponse> saveProfile(Map<String,String> data,String?attachFile)async {
    final response = await apiService.postFormApi(API.SAVE_PROFILE, data,singleFile: attachFile);
    return ApiResponse.fromJson(response);
  }

  Future<CustomerProfileDataModel> getProfile(var data)async {
    final response = await apiService.postApi(API.PROFILE, data);
    return CustomerProfileDataModel.fromJson(response);
  }
  
}