import 'package:click_pro_customer/data/network/network_service_api.dart';
import 'package:click_pro_customer/model/QuoteDataModel/quote_data_model.dart';
import 'package:click_pro_customer/model/QuoteDataModel/view_quotation.dart';
import 'package:click_pro_customer/res/api/api.dart';

class QuotationRepo{
  final apiService = NetworkServiceApi();

  Future<QuoteDataModel> pending_quoteRepo(var data) async {
   final response = await apiService.postApi(API.PENDING_QUOTE, data);
   return QuoteDataModel.fromJson(response);
  }

  Future<QuoteDataModel> active_quoteRepo(var data) async {
   final response = await apiService.postApi(API.ACTIVE_QUOTES, data);
   return QuoteDataModel.fromJson(response);
  }

  Future<QuoteDataModel> reject_quoteRepo(var data) async {
   final response = await apiService.postApi(API.REJECT_QUOTES, data);
   return QuoteDataModel.fromJson(response);
  }
  
  Future<ViewQuoteDataModel> view_quoteRepo(var data) async {
   final response = await apiService.postApi(API.VIEW_QUOTES, data);
   return ViewQuoteDataModel.fromJson(response);
  }

  

}