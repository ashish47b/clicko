import 'package:click_pro_customer/data/network/network_service_api.dart';
import 'package:click_pro_customer/model/CityModel/city_model.dart';
import 'package:click_pro_customer/res/api/api.dart';

class CityRepo{
  

  final apiServices = NetworkServiceApi();

  Future<CityDataModel> cityRepo()async {
    final response = await apiServices.postApi(API.GET_CITY, null);
    return CityDataModel.fromJson(response);
  }

}