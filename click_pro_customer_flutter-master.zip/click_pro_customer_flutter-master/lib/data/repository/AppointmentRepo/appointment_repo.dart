import 'package:click_pro_customer/data/network/network_service_api.dart';
import 'package:click_pro_customer/data/response/api_response.dart';
import 'package:click_pro_customer/model/AppoinmentDataModel/appointment_data_model.dart';
import 'package:click_pro_customer/model/AppoinmentDataModel/appointment_view_data_model.dart';
import 'package:click_pro_customer/res/api/api.dart';

class AppointmentRepo {

  final apiService = NetworkServiceApi();

  Future<AppointmentDataModel> allAppointmentRepo(var data) async{
    final response = await apiService.postApi(API.ALL_APPOINTMENTS, data);
    return AppointmentDataModel.fromJson(response);
  }

  //
  Future<AppointmentDataModel> todayAppointRepo(var data) async {
    final response = await apiService.postApi(API.TODAY_APPOINTMENT, data);
    return AppointmentDataModel.fromJson(response);
  }
  
    Future<AppointmentDataModel> previousAppointRepo(var data) async {
    final response = await apiService.postApi(API.PREVIOUS_APPOINTMENT, data);
    return AppointmentDataModel.fromJson(response);
  }

    Future<AppointmentViewDataModel> viewAppointRepo(var data) async {
    final response = await apiService.postApi(API.VIEW_APPOINTMENT, data);
    return AppointmentViewDataModel.fromJson(response);
  }

  Future<ApiResponse> saveAppointment(Map<String,String> data) async {
    final response = await apiService.postFormApi(API.RESCHEDULT_APPOINTMENT, data);
    return ApiResponse.fromJson(response);
  }
}

