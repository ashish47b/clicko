import 'package:click_pro_customer/data/network/network_service_api.dart';
import 'package:click_pro_customer/data/response/api_response.dart';
import 'package:click_pro_customer/model/ChatController/all_message_model.dart';
import 'package:click_pro_customer/model/ChatController/chat_users_model.dart';
import 'package:click_pro_customer/res/api/api.dart';

class ChatRepo{

  final apiService = NetworkServiceApi();

  Future<ChatUserListDataModel> chatUserRepo(var data) async {
    final respons = await apiService.postApi(API.CHAT_USER, data);
    return ChatUserListDataModel.fromJson(respons);
  }

  Future<AllMessageListDataModel> msgRepo(var data) async {
    final respons = await apiService.postApi(API.ALL_CHAT_MESSAGE, data);
    return AllMessageListDataModel.fromJson(respons);
  }

  Future<ApiResponse> addMsgRepo(var data) async {
    final respons = await apiService.postApi(API.ADD_CHAT_MESSAGE, data);
    return ApiResponse.fromJson(respons);
  }

}