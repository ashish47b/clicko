import 'package:click_pro_customer/data/network/network_service_api.dart';
import 'package:click_pro_customer/data/response/api_response.dart';
import 'package:click_pro_customer/model/AuthModel/RegisterModel.dart';
import 'package:click_pro_customer/model/AuthModel/verify_model.dart';
import 'package:click_pro_customer/res/api/api.dart';



class AuthRepo{
  final apiService = NetworkServiceApi();

  Future<RegisterDataModel> loginRepo(dynamic data) async {
    final response = await apiService.postApi(API.LOG_IN, data);
    return RegisterDataModel.fromJson(response);
  }

  Future<RegisterDataModel> registerRepo(var data) async{
   final response =  await apiService.postApi(API.REGISTER, data);
    return RegisterDataModel.fromJson(response);
  }

  Future<VerifyResponseModel> verifyAccount(var data) async{
   final response =  await apiService.postApi(API.VERIFY_ACCOUNT, data);
    return VerifyResponseModel.fromJson(response);
  }

 Future<VerifyResponseModel> generate_otp(var data) async{
   final response =  await apiService.postApi(API.GENERATE_OTP, data);
    return VerifyResponseModel.fromJson(response);
  }

   Future<ApiResponse> logOutRepo(var data) async{
   final response =  await apiService.postApi(API.LOG_OUT, data);
    return ApiResponse.fromJson(response);
  }

  Future<ApiResponse>  resendOtpRepo(var data) async {
    final response = await apiService.postApi(API.RESEND_OTP, data);
    return ApiResponse.fromJson(response);
  }



}