import 'package:click_pro_customer/data/network/network_service_api.dart';
import 'package:click_pro_customer/model/InvoiceModel/invoice_model.dart';
import 'package:click_pro_customer/model/InvoiceModel/view_invoice_model.dart';
import 'package:click_pro_customer/res/api/api.dart';

class InvoiceRepo{

  final apiService = NetworkServiceApi();

  Future<InvoiceDataListModel> invocieListRepo(var data)async {
    final response = await apiService.postApi(API.INVOICE_LIST, data);
    return InvoiceDataListModel.fromJson(response);
  }

  Future<ViewInvoiceDataModel>  invoDetailsRepo(var data) async {
    final response = await apiService.postApi(API.INVOICE_VIEW, data);
    return ViewInvoiceDataModel.fromJson(response);
  }
}