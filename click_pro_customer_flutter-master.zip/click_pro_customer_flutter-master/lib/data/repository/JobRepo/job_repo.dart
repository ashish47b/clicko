import 'dart:convert';
import 'dart:io';

import 'package:click_pro_customer/data/network/network_service_api.dart';
import 'package:click_pro_customer/data/response/api_response.dart';
import 'package:click_pro_customer/model/JobsDataModel/jobs_data_model.dart';
import 'package:click_pro_customer/model/JobsDataModel/single_job_model.dart';
import 'package:click_pro_customer/model/ViewJObDataModel/view_job_model.dart';
import 'package:click_pro_customer/res/api/api.dart';

class JobRepo{
  
  final apiService = NetworkServiceApi();

  Future<ApiResponse> savaJobRepo(Map<String,String> data,String? attachFiles)async{
    final response = await apiService.postFormApi(API.SAVE_JOB, data ,singleFile: attachFiles);
    return ApiResponse.fromJson(response);
  }


  Future<JobsDataModel> getPendinfJobRepo(var data) async {
    final response = await apiService.postApi(API.PENDING_JOBS, data);
    return JobsDataModel.fromJson(response);
  }

  Future<JobsDataModel> getActiveJobRepo(var data) async {
    final response = await apiService.postApi(API.ACTIVE_JOBS, data);
    return JobsDataModel.fromJson(response);
  }

  Future<JobsDataModel> getHiredJobRepo(var data) async {
    final response = await apiService.postApi(API.HIRED_JOBS, data);
    return JobsDataModel.fromJson(response);
  }

  Future<JobsDataModel> getCompleteJobRepo(var data) async {
    final response = await apiService.postApi(API.COMPLETE_JOBS, data);
    return JobsDataModel.fromJson(response);
  }

  Future<ApiResponse> activateJobRepo(var data) async {
    final response = await apiService.postApi(API.ACTIVATE_JOBS, data);
    return ApiResponse.fromJson(response);
  }
  

  Future<ViewJobDataModel> viewJobRepo(var data)async {
    final response = await apiService.postApi(API.VIEW_JOBS, data);
    return ViewJobDataModel.fromJson(response);
  }


  Future<ApiResponse> markCompleteRepo(var data)async {
    final response = await apiService.postApi(API.MARK_COMPLETE, data);
    return ApiResponse.fromJson(response);
  }

  Future<ApiResponse> chekPaymentRepo(var data)async {
    final response = await apiService.postApi(API.CHECK_PAYMENT, data);
    return ApiResponse.fromJson(response);
  }

  
  Future<SingleJobDataModel> getSingleJobRepo(var data) async {
    final response = await apiService.postApi(API.GET_SINGLE_JOB, data);
    return SingleJobDataModel.fromJson(response);
  }

  Future<ApiResponse> deactivateJobREpo(var data)async {
    final response = await apiService.postApi(API.DEACTIVATE_JOB, data);
    return ApiResponse.fromJson(response);
  }

    Future<ApiResponse> deleteJobRepo(var data)async {
    final response = await apiService.postApi(API.DELETE_JOB, data);
    return ApiResponse.fromJson(response);
  }




}