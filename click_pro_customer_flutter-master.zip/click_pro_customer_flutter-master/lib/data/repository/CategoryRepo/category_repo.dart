import 'package:click_pro_customer/data/network/network_service_api.dart';
import 'package:click_pro_customer/model/CategoryDataModel/category_data.dart';
import 'package:click_pro_customer/res/api/api.dart';

class CategoryRepo{
  final apiService = NetworkServiceApi();


Future<CategoryDataModel> categoryRepo()async {
    final response = await apiService.postApi(API.ALL_CATEGORIES, "");
    return CategoryDataModel.fromJson(response);
  }
}