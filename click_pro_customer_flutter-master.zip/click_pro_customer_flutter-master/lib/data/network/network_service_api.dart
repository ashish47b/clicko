
import 'dart:async';
import 'dart:convert';

import 'dart:io';

import 'package:click_pro_customer/data/app_exceptions.dart';
import 'package:click_pro_customer/data/network/base_service_api.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/utils/common.dart';

import 'package:http/http.dart' as http;

class NetworkServiceApi extends BaseApiServices{


  @override
  Future<dynamic> getApi(String url) async {
   String? token =await SharedMethods.getLocalStringData(key: SPKeys.USER_TOKEN);


   dynamic responseJson;

    try{
        final response = await http.get(Uri.parse(url),
        
        headers: token!=null?{
            "Content-Type":"application/json",
            "Authorization":'Bearer $token'
        }:null
        );
        responseJson = returnResponse(response);
    }on SocketException{
      throw InternetException(message: "No Internet");
    }on TimeoutException {
      throw RequestTimeException(message: "Time Out");
    }
    
    return responseJson;

  } 

  @override
  Future<dynamic> postApi(String url, var data) async {

    print("Hello");
   String? token = await SharedMethods.getLocalStringData(key: SPKeys.USER_TOKEN);
   print(token!=null?token:"");
   dynamic responseJson;
   print(url);
   print(data);
    try{
        final response = await http.post(Uri.parse(url), body: data!=null? jsonEncode(data) : null,
         headers:token!=null && token!=""? {
          "Content-Type":"application/json",
          "Authorization":'Bearer $token'
        }:null);
      if(response.statusCode==200){
        print("response >> "+ response.body);
      }
        responseJson = returnResponse(response);
        print(responseJson);
    }on SocketException{
      throw InternetException(message: "No Internet");
    }on TimeoutException {
      throw RequestTimeException(message: "Time Out");
    }
    
    return responseJson;

  }

  Future<dynamic> postFormApi(String url, Map<String,String> data,{List<File>? files, String? singleFile}) async {
     dynamic responseJson;
    try{

            
        String? token = await SharedMethods.getLocalStringData(key: SPKeys.USER_TOKEN);
        print(token!=null?token:"");

        print(url);
        print(data);

        var request = http.MultipartRequest('POST', Uri.parse(url));
        request.fields.addAll(data);
         request.headers
        .addAll({"Authorization": "Bearer $token"});

      if (files!=null &&  files.length > 0) {
        files.forEach((element) async {
          request.files.add(await http.MultipartFile(
              'attachment[]',
              await new http.ByteStream(File(element.path).openRead()),
              await File(element.path).length(),
              filename: element.path.split("/").last));
        });
      }

      if(singleFile!=null && singleFile!=""){
        request.files.add(await http.MultipartFile(
              'attachment',
              await new http.ByteStream(File(singleFile).openRead()),
              await File(singleFile).length(),
              filename: singleFile.split("/").last));
      }

      var sendRequest = await request.send();
      var response = await http.Response.fromStream(sendRequest);
      final responseData = jsonDecode(response.body);
      print("RSPONSE >> " + response.body);
      if (response.statusCode >= 400 ) {
         showToastMsg("Error Occured");
      }
      return responseData;
      
 

      }on SocketException{
        throw InternetException(message: "No Internet");
      }on TimeoutException {
        throw RequestTimeException(message: "Time Out");
      }
      
     

  } 


  dynamic returnResponse(http.Response response){
      switch(response.statusCode){
        case 200: 
         dynamic responseJson = jsonDecode(response.body);
         return responseJson; 
        
        case 400:
         throw InvalidRequestException();

        case 404:
         throw PageNotFoundException();
        
        default:
         throw FetchDataException();
      }


  }


}