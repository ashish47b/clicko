import 'package:flutter/material.dart';

class FadeImageWithError extends StatelessWidget {
  String? imgPath;
  BoxFit? fit;
  double?height;
  FadeImageWithError({this.imgPath,this.fit,this.height});
  @override
  Widget build(BuildContext context) {
    // return Image.network(imgPath,
    //     errorBuilder: (BuildContext context, Object exception, StackTrace stackTrace) {
    //       return Image.asset(
    //         'assets/images/no_image.png',
    //         height: 40.0,
    //         width: 40.0,
    //         fit: BoxFit.fitWidth,
    //       );
    //     });
    return FadeInImage.assetNetwork(
        placeholder: 'assets/images/no-photos.png',
        image: imgPath!,
        fit: fit!=null?fit:BoxFit.cover,
        imageErrorBuilder:
            (BuildContext ?context, Object ?exception, StackTrace ?stackTrace) {
          return Image.asset('assets/images/no-photos.png',
              fit: fit!=null?
              fit:BoxFit.contain);
        }
    );
  }
}
