import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LanguageDialogBox extends StatelessWidget {


    List<String> list = ["ENGLISH", "FRENCH(FRANÇAISE)"];
  int selectRadio = 0;

  @override
  Widget build(BuildContext context) {
    return StatefulBuilder(builder: (context,myState){
        return AlertDialog(
                    title: Text("Choose Language".tr, style: AppTextStyles.k18TextN,),
                    content: Wrap(
                      children: [
                        for(int i=0;i<list.length;i++)
                        Container(
                  child: RadioListTile(
                          title: Text(list[i], style: AppTextStyles.k14TextN,),
                          value: i,
                           groupValue: selectRadio,
                  onChanged: (val){
                           selectRadio = val!;
                    myState(() {
                      
                    });
              
                  }
                          ),
                          )
                      ],
                    ),
                    actions: [
                      InkWell(
                        onTap: (){
                          if(selectRadio==0){
                            Get.updateLocale(Locale('en', 'US'));
                              //context.locale = Locale('en', 'US');
                          Navigator.pop(context);
                          }else {
                            print("french");
                             Get.updateLocale(Locale('fr', 'BE'));
                            //  context.locale = Locale('fr', 'BE');
                          Navigator.pop(context);
                          }
                         
                         },
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColor.appThemeColorOlive,
                             borderRadius: BorderRadius.circular(12),
                          ),
                          child: Center(child: Text("Set".tr, style: AppTextStyles.k18TextN,),),
                        ),
                      )
                    ],
              
                  );
    });
  }
}