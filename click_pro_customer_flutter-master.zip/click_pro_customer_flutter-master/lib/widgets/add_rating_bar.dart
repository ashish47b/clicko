import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/JobController/job_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';

class AddRatingBar extends StatefulWidget {
String?job_id;

AddRatingBar({this.job_id});

  @override
  State<AddRatingBar> createState() => _AddRatingBarState();
}

class _AddRatingBarState extends State<AddRatingBar> {
   
  
  final JobController controller = Get.put(JobController());


  @override
  Widget build(BuildContext context) {
    return Wrap(
      children: [
        Container(
         // height: 100,
         padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
          decoration:const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(topLeft: Radius.circular(12), topRight: Radius.circular(12))
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  InkWell(
                    onTap: (){
                      Get.back();
                    },
                    child: Container(
                      padding: EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        border: Border.all(color: AppColor.appThemeColorOlive),
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.white,
                      ),
                      child:const Center(child: Icon(Icons.close,color: AppColor.appThemeColorOlive,)),
                    ),
                  ),
                /*  InkWell(
                    onTap: ()async{
                       await controller.markCompleteApi(rating: "0", feedback: "",jobId: widget.job_id);
                    },
                    child: Container(
                      padding: EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        border: Border.all(color: AppColor.appThemeColorOlive),
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.white,
                      ),
                      child: Center(child: Text("SKIP",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),)),
                    ),
                  ),*/
                ],
              ),
              const SizedBox(height: 20),
              Text("Add Ratings".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
               const SizedBox(height: 20),
               Center(
                 child: RatingBar.builder(
                 initialRating: 1,
                 minRating: 1,
                 direction: Axis.horizontal,
                 allowHalfRating: true,
                 itemCount: 5,
                 itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                 itemBuilder: (context, _) => Icon(
                 Icons.star,
                   color: AppColor.appThemeColorOrange,
                 ),
                 onRatingUpdate: (val) {
                  rating = val.toString();
                  print(rating);
                  },
                ),
               ),
              const SizedBox(height: 20),
              Text("Add Feedback".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
              const SizedBox(height: 20),

              getTextFromFieldTextType("", "", maxLines: 3,controller: feedbackController),
              const SizedBox(height: 20),
              InkWell(
                onTap: ()async{
                   if(![null,""].contains(rating)){
                     if(feedbackController.text.isNotEmpty){
                     await controller.markCompleteApi(rating: rating.toString(), feedback: feedbackController.text,jobId: widget.job_id);
                     }else{
                       showToastMsg("Please Add Feedback".tr);
                     }
                   }else{
                    showToastMsg("Please Add Rating".tr);
                   }
                },
                child: Container(
                  padding:const EdgeInsets.symmetric(vertical: 7),
                  decoration: BoxDecoration(
                    color: AppColor.appThemeColorOlive,
                    borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(child: Text("Submit".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

    String?rating;
    final TextEditingController feedbackController = TextEditingController(text: "");
}