import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/AuthController/gen_otp_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AccountVerifyDialog extends GetView<GenerateOtpController>{

  Widget build(BuildContext context){
   return AlertDialog(

                title: Text("Account Verification".tr),
                content: Text("Your Account is not Verify , First Verify your account for the further process".tr,style: AppTextStyles.k14TextN),
                actions: [
                         InkWell(
                          onTap: (){
                           controller.generateOtpRepo();
                          },
                           child: Container(
                                    height: 30,
                                    decoration: BoxDecoration(
                                    color: AppColor.appThemeColorOrange,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                              child: Center(
                            child: Text("Verify Account".tr),
                                                 ),
                                               ),
                         )
                ],
              );
  }
}