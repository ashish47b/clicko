import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class ReasonDialogBox extends StatelessWidget {
  const ReasonDialogBox({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text("Write Reason".tr(),style: AppTextStyles.k16TextN),
      content: Wrap(
        children: [
          getTextFieldTextType("Reason".tr(), "Reason".tr())
        ],
      ),
      actions: [
        Container(
                          padding: EdgeInsets.symmetric(vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColor.appThemeColorOlive,
                             borderRadius: BorderRadius.circular(12),
                          ),
                          child: Center(child: Text("Reject".tr(), style: AppTextStyles.k18TextN,),),
                        ),
      ],
    );
  }
}