import 'package:click_pro_customer/utils/app_color.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

class CustmerLoader extends StatelessWidget {
  const CustmerLoader({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: LoadingAnimationWidget.newtonCradle(color: AppColor.appThemeColorOlive, size: 100),
    );
  }
}