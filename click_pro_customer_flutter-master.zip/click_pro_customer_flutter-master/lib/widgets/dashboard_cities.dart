import 'package:click_pro_customer/model/CategoryDataModel/category_data.dart';
import 'package:click_pro_customer/model/CityModel/city_model.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/CategoryController/category_controller.dart';
import 'package:click_pro_customer/view_model/CityController/city_controller.dart';
import 'package:click_pro_customer/views/Postjobs/post_jobs_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DashBoardCities extends StatefulWidget {
  const DashBoardCities({super.key});

  @override
  State<DashBoardCities> createState() => _DashBoardCitiesState();
}

class _DashBoardCitiesState extends State<DashBoardCities> {
  
  final CityController controller = Get.put(CityController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }

  getData()async{
    await controller.getCity();
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=> Container(
            height:_size!.height>900?_size!.height*0.2: _size!.height*0.15,
            child: ListView.builder(
              itemCount: controller.citiesList!.length,
            
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context,index){
                CityData obj = controller.citiesList![index];
                return  categoryItem( title: obj.cityName,id: obj.id,image: obj.city_image);
            }),
    ));
  }
    categoryItem({String?image,String?title, String?id}){
    return InkWell(
      onTap: (){
        navigateWithPageTransition(context, PostJobs(cityID: id,));
      },
      child: Stack(
        children: [
          Container(
            width: _size!.width*0.6,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.black.withOpacity(0.7),Colors.black.withOpacity(0.7)])
            ),
          ),
          Container(
                 width: _size!.width*0.6,
                margin: EdgeInsets.only(right: 10),
                decoration:BoxDecoration(
                  //shape: BoxShape.circle,
                 color: Colors.black12,
                 borderRadius: BorderRadius.circular(6),
                 image: DecorationImage(image: NetworkImage(image!),fit: BoxFit.fill,opacity: 0.8)
                ),
                child: Center(
                  child: Text(title!,style: AppTextStyles.k20TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)),
                ),
            ),
        ],
      ),
    );
  }
}