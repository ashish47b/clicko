import 'package:flutter/material.dart';


class NoDataWidget extends StatefulWidget {
  bool?isloading;

  NoDataWidget({this.isloading});

  @override
  State<NoDataWidget> createState() => _NoDataWidgetState();
}

class _NoDataWidgetState extends State<NoDataWidget> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return widget.isloading!?Container(): Center(child: Container(
       height: _size!.height*0.6,
      // width: _size!.width*0.6,
      decoration:const BoxDecoration(
        //color: Colors.red,
        image: DecorationImage(image: AssetImage("assets/images/no_data1.png"),fit: BoxFit.fill,)
      ),
    ));
  }
}