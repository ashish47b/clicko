import 'package:click_pro_customer/utils/app_color.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class ChatMessagesField extends StatefulWidget {
  const ChatMessagesField({Key? key}) : super(key: key);

  @override
  State<ChatMessagesField> createState() => _ChatMessagesFieldState();
}

class _ChatMessagesFieldState extends State<ChatMessagesField> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(
        left: size.width / 18,
        right: size.width / 18,
        bottom: size.height / 40,
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.only(left: size.width / 30),
              height: 50,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(100),
              //  color: a.bgColor,
                border: Border.all(color: AppColor.appThemeColorOlive, width: 1),
              ),
              child: Row(
                children: [
                 // SvgPicture.asset("images/icons/smile.svg"),
                  SizedBox(
                    width: size.width / 36,
                  ),
                  const Expanded(
                    child: TextField(
                      cursorColor: AppColor.appThemeColorOlive,
                      decoration: InputDecoration(
                          border: InputBorder.none, hintText: "Type Message.."),
                    ),
                  )
                ],
              ),
            ),
          ),
          SizedBox(
            width: size.width / 36,
          ),
          Container(
            height: 42,
            width: 42,
            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColor.appThemeColorOlive,
            ),
            child: Image.asset(
              "images/icons/send.png",
              height: 10,
              width: 6,
            ),
          )
        ],
      ),
    );
  }
}