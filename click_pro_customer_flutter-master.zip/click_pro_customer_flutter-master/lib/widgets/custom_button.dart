import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  String text;
  Color?textColor;
  Color?buttonColor;
  VoidCallback? onTap;

  CustomButton({this.buttonColor,this.onTap,required this.text,this.textColor});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: MediaQuery.of(context).size.height*0.04,
          padding: const EdgeInsets.symmetric(horizontal: 5,vertical: 4),
          decoration: BoxDecoration(
            color: buttonColor!=null?buttonColor!:AppColor.appThemeColorOlive,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Center(child: Text(text,style: AppTextStyles.k16TextN.copyWith(color:textColor!=null?textColor!:Colors.white),)),
       ),
    );
  }
}