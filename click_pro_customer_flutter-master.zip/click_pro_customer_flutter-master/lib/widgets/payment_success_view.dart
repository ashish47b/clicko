import 'package:click_pro_customer/model/DepositDataModel.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/widgets/RowWithText.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

class PaymentSuccessView extends StatefulWidget {
  @override
  State<PaymentSuccessView> createState() => _PaymentSuccessViewState();
}

class _PaymentSuccessViewState extends State<PaymentSuccessView> {
  DepositDataModel?obj;
  
  getData()async {
    if(Get.arguments!=null){
      obj = Get.arguments[0];
    }
    setState(() {
      
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    Future.delayed(Duration(milliseconds: 100),()=> getData());
    super.initState();
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: Text("Payment".tr,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive,fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        centerTitle: true,
        automaticallyImplyLeading: false,
        elevation: 0.0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextButton(onPressed: (){
              Get.toNamed(RoutesName.dashboardView);
            },style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all(AppColor.appThemeColorOlive)
            ), child: Text("Go Home",
            style: AppTextStyles.k14TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold))),
          )
        ],
      ),
      body: Container(
        height: _size!.height,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            AppColor.appThemeColorOrange,
            AppColor.appThemeColorGreen,
            AppColor.appThemeColorOlive,
          ],begin: Alignment.topCenter,end: Alignment.bottomRight),
          
        ),
        child: Container(
          margin:const EdgeInsets.symmetric(horizontal: 20,vertical: 40),
          decoration: BoxDecoration(
            color: Colors.white
          ),
          child: obj!=null && obj!.msg!=null && obj!.msg![0]!=null?  Stack(
            children: [
              Column(
                children: [
                  Container(
                  height: 200,
                    child: Lottie.asset("assets/lottie/pay_success.json",repeat: false),
                  ),
                
                  Text("Thank you for your transfer".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange,fontWeight: FontWeight.bold)),
                  SizedBox(height: _size!.height*0.02),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Customer User".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                          Expanded(child: Text(obj!.msg![0].customerName!=null? obj!.msg![0].customerName!:"", style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),))
                        ],
                    ),
                  ),
                   SizedBox(height: _size!.height*0.01),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Professional User".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                          Expanded(child: Text(obj!.msg![0].proName!=null? obj!.msg![0].proName!:"", style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),))
                        ],
                    ),
                  ),
                   SizedBox(height: _size!.height*0.02),
                   Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Invoice No.".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                          Text(obj!.invId!=null? "COC-" + obj!.invId!.toString():"", style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                        ],
                    ),
                  ),
                  SizedBox(height: _size!.height*0.02),
                    Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child:Column(
                    
                        children: [
                          Text("Transaction ID".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                          Text(obj!.msg![0].paymentId!=null? obj!.msg![0].paymentId!:"",textAlign: TextAlign.center, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                        ],
                    ),
                  ),
                  SizedBox(height: _size!.height*0.02),
                    Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Invoice".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                          Text(obj!.msg![0].amount!=null? obj!.msg![0].amount!:"", style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                        ],
                    ),
                  ),
                  SizedBox(height: _size!.height*0.005),
                    Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Commission".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                          Text(obj!.msg![0].adminCusCommission!=null? obj!.msg![0].adminCusCommission!:"", style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                        ],
                    ),
                  ),
                  SizedBox(height: _size!.height*0.01),
                    Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Total Amount".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                          Text(obj!.msg![0].amount!=null && obj!.msg![0].adminCusCommission!=null? (double.parse(obj!.msg![0].amount!) +  double.parse(obj!.msg![0].adminCusCommission!)).toString():"", style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                        ],
                    ),
                  ),
                  SizedBox(height: _size!.height*0.02),
                    Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child:Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Payment Date".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                          Text(obj!.msg![0].customerPaymentDate!=null? obj!.msg![0].customerPaymentDate!:"", style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                        ],
                    ),
                  ),
                  Container(
                        margin: EdgeInsets.only(top: _size!.height*0.05),
                        width: _size!.width*0.4,
                        height: _size!.height*0.1,
                      
                        child: Image.asset("assets/logos/logo1.png"),
                   ),
                  
                ],
              ),
               Positioned(child:  Align(
              alignment: Alignment.bottomCenter,
              child: Text("You can take the Screenshot".tr,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOrange,fontStyle: FontStyle.italic),),
            ))
            ],
          ) : Container(),
        ),
      ),
    );
  }
}