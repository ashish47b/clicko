import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/views/Profile/edit_profile.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

import '../view_model/ProfileController.dart/profile_controller.dart';

class VerifySuccessWidget extends StatefulWidget {
  const VerifySuccessWidget({super.key});

  @override
  State<VerifySuccessWidget> createState() => _VerifySuccessWidgetState();
}

class _VerifySuccessWidgetState extends State<VerifySuccessWidget> {

  final ProfileController profileController = Get.put(ProfileController());

  @override
  void initState() {
    // TODO: implement initState
    Future.delayed(Duration(milliseconds: 200),()=> getData());
    super.initState();
  }

  getData()async {
    await profileController.getProfile();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        margin: EdgeInsets.symmetric(horizontal: 20),
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
           Container(
            height: 200,
            child: Lottie.asset("assets/lottie/success.json"),
           ),
           SizedBox(height: 40),
           InkWell(
            onTap: (){
              navigateWithPageTransition(context, EditProfile(profileData: profileController.profileData,from: "start"));
              // Get.toNamed(RoutesName.dashboardView);
            },
             child: Container(
              height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: AppColor.appThemeColorOrange
              ),
              child: Center(
                child: Text("Continue".tr,style: TextStyle(color: Colors.white, fontSize: 18,fontWeight: FontWeight.w600),),
              ),
             ),
           )
        ]),
      ),
    );
  }
}