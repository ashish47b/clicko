
import 'package:click_pro_customer/res/languages/languages.dart';
import 'package:click_pro_customer/res/route/app_routes.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/views/Auth/verify_otp.dart';
import 'package:click_pro_customer/views/OnBoardPage/onboard_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

void main() async{
   WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();
  runApp(
     MyApp()
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      translations: Languages(),
      fallbackLocale: Locale('fr', 'BE'),
      locale: Locale('fr','BE'),
      theme: ThemeData(
        primaryColor: AppColor.appThemeColorOlive,
        
      ),
     getPages: AppRoutes.appRoutes(),
    );
  }
}



