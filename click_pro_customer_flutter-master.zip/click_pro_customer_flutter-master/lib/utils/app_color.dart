import 'package:flutter/animation.dart';
import 'package:flutter/material.dart';

class AppColor{

  static const appThemeColorSky = Color(0xFF0097B2);
  static const appThemeColorGreen = Color(0xFF7ED957);
  static const appThemeColorOlive = Color(0xFF0b8f93);
  static const appThemeColorOrange = Color(0xFFf29e26);
  static const appRedColor = Colors.red;

}