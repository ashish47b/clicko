

import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:multi_select_flutter/util/multi_select_item.dart';

import 'package:page_transition/page_transition.dart';
import 'package:url_launcher/url_launcher.dart';


  class Jobs {
  final int? id;
  final String? name;

  Jobs({
    this.id,
    this.name,
  });
}

  List<Jobs> jobs = [
    Jobs(id: 1, name: "Plumber"),
    Jobs(id: 1, name: "Electrician"),
    Jobs(id: 1, name: "Painter"),
    Jobs(id: 1, name: "Gardner"),
    Jobs(id: 1, name: "Cleaner"),
    Jobs(id: 1, name: "Mason"),
    Jobs(id: 1, name: "Roofer"),
  
  ];

    final items = jobs
      .map((jobs) => MultiSelectItem<Jobs>(jobs, jobs.name!))
      .toList();

navigateWithPageTransition(BuildContext context, var obj, {PageTransitionType?type}){
   Navigator.push(context, PageTransition(child: obj, type: type!=null?type:PageTransitionType.rightToLeft, duration: Duration(milliseconds: 300)));
}

  List<dynamic> categoriesImage= [
    {
      "image":"assets/images/plumber.png",
      "title":"Plumber",
     
    },
     {
      "image":"assets/images/electrician.png",
      "title":"Electrician",
      
    },
     {
      "image":"assets/images/painter.png",
      "title":"Painter",
      
    },
        {
      "image":"assets/images/gardening.png",
      "title":"Gardner",
     
    },
     {
      "image":"assets/images/household.png",
      "title":"Cleaner",
      
    },
     {
      "image":"assets/images/builder.png",
      "title":"Mason",
      
    },
       {
      "image":"assets/images/roofer.png",
      "title":"Roofer",
      
    },
  ];


//import 'package:http/http.dart' as http;

  // launchWhatsApp() async {
  //   final link = WhatsAppUnilink(
  //     phoneNumber: '+919896666326',
  //     text: "Hey! I'm inquiring about your products",
  //   );
  //   // Convert the WhatsAppUnilink instance to a string.
  //   // Use either Dart's string interpolation or the toString() method.
  //   // The "launch" method is part of "url_launcher".
  //   await launch('$link');
  // }

  // launchMail() async {
  //   const url = 'mailto:vishaljindal113@gmail.com';
  //   if (await canLaunch(url)) {
  //     await launch(url);
  //   } else {
  //     throw 'Could not launch $url';
  //   }
  // }

  // launchPhoneCall() async {
  //   const url = 'tel:+919896666326';
  //   if (await canLaunch(url)) {
  //     await launch(url);
  //   } else {
  //     throw 'Could not launch $url';
  //   }
  // }

  navigateWithTransition(BuildContext context,dynamic object){
   Navigator.push(context,PageTransition(child: object, type: PageTransitionType.leftToRight));
}
var buttonShape=RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(24)
);



var buttonTextStyle = new TextStyle(
    fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white
);

var headingNameWithWhiteStyle = new TextStyle(
    fontSize: 20,fontWeight: FontWeight.w500,color: Colors.white
);

var normalTextTyle= TextStyle(
    fontWeight: FontWeight.w800,fontSize: 20,color: Colors.black38
);
var normalTextFieldText= TextStyle(
    fontWeight: FontWeight.w800,fontSize: 20,color: Colors.black54
);
var hintTextTyle= TextStyle(
    fontWeight: FontWeight.w500,fontSize: 16,color: Colors.black26
);
// var formatter = new DateFormat('dd-MM-yyyy HH:mm');
// var onlyDateFormatter = new DateFormat('dd-MM-yyyy');
// var yyMMddDateFormatter = new DateFormat('yyyy-MM-dd');
var textStyle = new TextStyle(fontSize: 16,fontWeight: FontWeight.w700,);

TextStyle getTitleBlackText({Color?color,FontWeight?weight}){
  return TextStyle(
      color: color!=null?color:Colors.black.withOpacity(.8),
      fontWeight:weight!=null?weight: FontWeight.w500,
      fontSize: 16
  );
}

getComplainStatus(String?val){
  switch(val){
    case "0":return "Pending";
    case "1":return "Assigned";
    case "2":return "Resolved";
    case "3":return "Completed";
    case "4":return "Re-Open";
    default:
      return "";
  }
}
// var formatter = DateFormat('dd-MM-yyyy HH:mm');
// var onlyDateFormatter = new DateFormat('dd-MM-yyyy');
// var yyMMddDateFormatter = new DateFormat('yyyy-MM-dd');
final picker = ImagePicker();
pickedImage(BuildContext context,{ImageSource? cameraOnly}) async{
  ImageSource? source;
  if(cameraOnly!=null){
    source = ImageSource.camera;
  } else {
    await showDialog<ImageSource>(
      context: context,
      builder: (context) =>
          AlertDialog(
              content: Text("Choose image source".tr),
              actions: [
                ElevatedButton(
                  child: Text("Camera".tr),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColor.appThemeColorOlive
                  ),
                  onPressed: () {
                    source = ImageSource.camera;
                    Navigator.pop(context);
                  },
                ),
                ElevatedButton(
                  child: Text("Gallery".tr),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColor.appThemeColorOlive
                  ),
                  onPressed: () {
                    source = ImageSource.gallery;
                    Navigator.pop(context);
                  },
                ),
              ]
          ),
    );
  }
  if (source!= null) {
    //final pickedFile = await ImagePicker.pickImage(source: source);
    final pickedFile = await picker.getImage(source: source!,imageQuality: 25);
    //print(pickedFile.path);
    print(pickedFile!.path);
    //print(new Directory(pickedFile.path).absolute.path);
    return pickedFile.path;
  }
  // });
}

getTextFieldTextType(String label,String msg, {TextEditingController? controller,int?maxLines,TextInputType?textInputType,bool?isEnabled
,Function? callbackFunction,Color?fillColor,Widget?suffix, List<TextInputFormatter>? textInputFormatter,double?radius, bool obscureText=false}){

  return Column(
    children: [
      SizedBox(height: 8,),
      SizedBox(
        //height: 60,
        child:  TextFormField(
          obscureText: obscureText,
          obscuringCharacter: "*",
          controller: controller,
           enabled: isEnabled!=null?isEnabled:null,
           decoration: InputDecoration(
            suffix: suffix!=null?suffix:null,
            contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 3),
            disabledBorder: new OutlineInputBorder(
                borderSide: new BorderSide(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(radius!=null?radius:20)),
            enabledBorder: new OutlineInputBorder(
                borderSide: new BorderSide(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(radius!=null?radius:20)),
            focusedBorder: OutlineInputBorder(
                borderSide: new BorderSide(color: AppColor.appThemeColorOrange),
                borderRadius: BorderRadius.circular(radius!=null?radius:20)
            ),
            labelText: label,labelStyle: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),
            floatingLabelBehavior: FloatingLabelBehavior.always,
            alignLabelWithHint: false,
             fillColor: fillColor!=null?fillColor:null
          ),
          keyboardType: textInputType!=null?textInputType:TextInputType.text,

          onSaved: (value){

          },
          inputFormatters: textInputFormatter!=null?textInputFormatter:null,
          //maxLines: maxLines!=null?maxLines:null,
          validator: (value) {
            if (value!.isEmpty) {
              return msg;
            }
            return null;
          },
          onChanged:(str)=>callbackFunction!=null?callbackFunction():null,
          //textInputAction: ,
        ) ,
      ),
    ],
  );
}
getTextFromFieldTextType(String label,String msg, {TextEditingController? controller,int?maxLines,TextInputType?textInputType,bool?isEnabled
,Function? callbackFunction,Color?fillColor,List<TextInputFormatter>? list,double?radius}){

  return Column(
    children: [
      SizedBox(height: 8,),
      SizedBox(
        //height: 60,
        child:  TextFormField(
          controller: controller,
           enabled: isEnabled!=null?isEnabled:null,
         decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 3),
            enabledBorder: new OutlineInputBorder(
                borderSide: new BorderSide(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(radius!=null?radius:20)),
            focusedBorder: OutlineInputBorder(
                borderSide: new BorderSide(color: AppColor.appThemeColorOrange),
                borderRadius: BorderRadius.circular(radius!=null?radius:20)
            ),
            labelText: label,labelStyle: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),
            floatingLabelBehavior: FloatingLabelBehavior.always,
            alignLabelWithHint: false,
             fillColor: fillColor!=null?fillColor:null
          ),
          keyboardType: textInputType!=null?textInputType:TextInputType.text,

          onSaved: (value){

          },
          inputFormatters: list!=null?list:null,
          maxLines: maxLines!=null?maxLines:null,
          validator: (value) {
            if (value!.isEmpty) {
              return msg;
            }
            return null;
          },
          onChanged:(str)=>callbackFunction!=null?callbackFunction():null,
          //textInputAction: ,
        ) ,
      ),
    ],
  );
}



showToastMsg(String str) {
  Fluttertoast.showToast(
      msg: str,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.SNACKBAR,
      timeInSecForIosWeb: 1,
      backgroundColor: AppColor.appThemeColorOrange,
      //FlowrimColors.baseColor.withOpacity(.8),
      textColor: Colors.white,
      fontSize: 16.0
  );
}

pushReplace(BuildContext context, object){
  Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => object));

}


// bool?downloading=false;
// String?path;
// final Random random = Random();

/*Future<void> downloadFile({String? url,String? name,MyProvider?model,String?from,String?productId}) async {
  Dio dio = Dio();
  var status = await Permission.storage.status;
  bool allowed = status.isGranted;

  if (!allowed) {
    print("Permission ${status.isGranted}");
    Permission.storage.request();
    EasyLoading.dismiss(animation: true);
    model!.notifyListeners();
  }else{
    if (status.isGranted) {
      String dirloc = "";
      if (io.Platform.isAndroid) {
        dirloc = "/sdcard/download/";
      } else {
        dirloc = (await getApplicationDocumentsDirectory()).path;
      }

      var randid = random.nextInt(10000);
      name = name!.replaceAll(" ", "_").replaceAll("\"", '');

      try {
        //FileUtils.mkdir([dirloc]);
        await dio.download(url!, dirloc + "${name}_"+randid.toString() + ".pdf",
            onReceiveProgress: (receivedBytes, totalBytes) {

              downloading = true;
              //progress = ((receivedBytes / totalBytes) * 100).toStringAsFixed(0) + "%";
              EasyLoading.show(status: "Please wait...");

            });
        print("downloaded");
      } catch (e) {
        print(e);
      }finally{
        EasyLoading.dismiss(animation: true);
        model!.notifyListeners();
      }

      //setState(() {
      downloading = false;
      EasyLoading.dismiss(animation: true);

      //progress = "Download Completed.";*/
    /*  path = dirloc + "${name.replaceAll(" ", "_").replaceAll("\"", '')}_"+ randid.toString() + ".pdf";
      // EasyLoading.showSuccess("Downloaded");
      //_launchURL(path!);

      if(from!=null && from.compareTo("purchase")==0){
        model.delete_assets(fileName: url);
      } else {
        model.deletePdfFileFromServer(productId,url!.split("/").last);
      }

        await  _launchURL(path!);


      //   shareFile(path!,model,name);

      print("path $path");
      // });

    } else {
      print("sorry bhai");
    }
  }

}*/

/*_launchURL(String url) async {
  // print(url);
  var url = 'file://' + path!;
  print("url launch "+url);
  try {
    await OpenFile.open(path, type: "application/pdf");
  } catch(ex){
    print(ex);
  }

}*/

/*launchURL(url) async {
  Uri uri = Uri.parse(url);
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri);
  } else {
    throw 'Could not launch $url';
  }
}*/

snackBarWidget(String?title, String?message){
  Get.snackbar(title!, message!,margin: EdgeInsets.all(10), colorText: Colors.white, duration: Duration(seconds: 3),snackPosition: SnackPosition.BOTTOM, borderRadius: 12, backgroundColor:AppColor.appThemeColorOlive);
}

  var genders = [
    "MALE".tr,
    "FEMALE".tr,
    "OTHER".tr,
  ];

  var days = [
    "Monday".tr,
    "Tuesday".tr,
    "Wednesday".tr,
    "Thursday".tr,
    "Friday".tr,
    "Saturday".tr,
    "Sunday".tr,
  ];

  var times = [
    "Morning".tr,
    "Afternoon".tr,
    "Evening".tr,
    "Night".tr,
  ];



  launchURL(url) async {
  Uri uri = Uri.parse(url);
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri);
  } else {
    throw 'Could not launch $url';
  }
}