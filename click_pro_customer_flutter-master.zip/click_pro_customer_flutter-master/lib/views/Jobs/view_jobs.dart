import 'package:click_pro_customer/model/ViewJObDataModel/view_job_model.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/CategoryController/category_controller.dart';
import 'package:click_pro_customer/view_model/CityController/city_controller.dart';
import 'package:click_pro_customer/view_model/JobController/job_controller.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';
import 'package:click_pro_customer/widgets/fade_img_with_error.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ViewJobs extends StatefulWidget {
  const ViewJobs({super.key});

  @override
  State<ViewJobs> createState() => _ViewJobsState();
}

class _ViewJobsState extends State<ViewJobs> {
   
   final JobController controller = Get.put(JobController());
   final CityController cityController = Get.put(CityController());
   final CategoryController categoryController = Get.put(CategoryController());
   @override
  void initState() {
    // TODO: implement initState
    super.initState();
     Future.delayed(Duration(milliseconds: 200),()=> getData());
  }

  getData()async{
      await categoryController.getCategoryApi();
      await cityController.getCity();
      await controller.viewJobApi(job_id: Get.arguments[0]);

      

  }

  String?categoryName="";
  String?cityName="";




  Size?_size;
  @override
  Widget build(BuildContext context) {


    _size = MediaQuery.of(context).size;
    return Obx((){ 
      
      if(categoryController.categoryData!=null && categoryController.categoryData!.length>0){
        if(controller.viewJobData!=null && ![null,""].contains(controller.viewJobData!.category!)){
           print("cat hai");
          categoryController.categoryData!.forEach((element) {
            if(element.id!.compareTo(controller.viewJobData!.category!)==0){
               categoryName = element.categoryName;
            }
          });
        }
      }

      if(cityController.citiesList!=null && cityController.citiesList!.length>0){
        if(controller.viewJobData!=null && ![null,""].contains(controller.viewJobData!.location!)){
          cityController.citiesList!.forEach((element) {
            if(element.id!.compareTo(controller.viewJobData!.location!)==0){
               cityName = element.cityName;
            }
          });
        }
      }
      return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          centerTitle: true,
          title: Text("Job Details".tr,style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
          iconTheme: IconThemeData(color: Colors.black),
        ),
      body: Stack(
        children: [
          controller.viewJobData==null?NoDataWidget(isloading: controller.isLoading.value,):ListView(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        children: [
             Divider(color: Colors.grey),
             Text(controller.viewJobData!.jobTitle!.toUpperCase(), style: AppTextStyles.k18TextH.copyWith(color: AppColor.appThemeColorOlive)),
             SizedBox(height: _size!.height*0.01),
             Text("Category".tr +"  " + categoryName!,style: AppTextStyles.k16TextN,), 
              SizedBox(height: _size!.height*0.01),
             Text("Posted on" + " : "+ controller.viewJobData!.startDate!, style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive)),
             SizedBox(height: _size!.height*0.01),
             const Divider(color: Colors.grey),
             Text("Description".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
             SizedBox(height: _size!.height*0.01),
             Text(controller.viewJobData!.description!,style: AppTextStyles.k16TextN),
             //const Divider(color: Colors.grey),

             // 
             SizedBox(height: _size!.height*0.01),
             const Divider(color: Colors.grey),
             Text("Price".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
             SizedBox(height: _size!.height*0.01),
             Text("€" +" "+ controller.viewJobData!.price!,style: AppTextStyles.k16TextN),
            // const Divider(color: Colors.grey),

             //    //
             SizedBox(height: _size!.height*0.01),
             const Divider(color: Colors.grey),
             Text("Location".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
             SizedBox(height: _size!.height*0.01),
             Text(cityName!,style: AppTextStyles.k16TextN),
            

             // 
             SizedBox(height: _size!.height*0.02),
             const Divider(color: Colors.grey),
             Text("Attachments".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
             controller.viewJobData!.attachmentsList!=null && controller.viewJobData!.attachmentsList.length>0? Container(
                height: 100,
                child: ListView.builder(
                  itemCount: controller.viewJobData!.attachmentsList.length,
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context,index){
                  return Container(
                            height: 80,
                            width: 80,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: FadeImageWithError(imgPath: controller.viewJobData!.attachmentsList[index])));
                })
              ): Container(),
        ],
      ),
      
                controller.isLoading.value?CustomLoader(): Container(),

        ],
      )
    );}
    );
  }
}