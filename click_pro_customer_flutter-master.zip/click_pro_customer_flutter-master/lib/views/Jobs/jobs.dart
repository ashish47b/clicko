
import 'package:click_pro_customer/model/JobsDataModel/jobs_data_model.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';

import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/JobController/job_controller.dart';
import 'package:click_pro_customer/views/Jobs/job_items.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';
import 'package:contained_tab_bar_view/contained_tab_bar_view.dart';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class AllJobsScreen extends StatefulWidget {
 String?from;

 AllJobsScreen({this.from});

  @override
  State<AllJobsScreen> createState() => _AllJobsScreenState();
}

class _AllJobsScreenState extends State<AllJobsScreen> {

        var scController=ScrollController();
  
  final JobController controller = Get.put(JobController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    scController.addListener(listener);
    Future.delayed(Duration(milliseconds: 300),(() => getData()));
  }

  getData()async{
   if(currentIndex==0){
       controller.getPendingJobs(limit: skipValue);
   }else if(currentIndex==1){
       controller.getActiveJobs(limit: skipValue);
   }else if(currentIndex==2){
       controller.getHiredJobs(limit: skipValue);
   }else if(currentIndex==3){
       controller.getCompleteJobs(limit: skipValue);
   }
  }

  int skipValue=1;
  listener(){
    if(scController.position.pixels == scController.position.maxScrollExtent){
      skipValue=skipValue+1;
      getData();
      print("called");
    }else{
      print("sorry");
    }
  }

  int currentIndex = 0;

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=>SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            DefaultTabController(
                 length: 4,
                 child: Column(
                  children: [
              Container(
                margin: EdgeInsets.only(top: 20),
                decoration: BoxDecoration(
                  //color: AppColor.appThemeColorOrange
                ),
                child: Container(
                  //height: 50,
                 
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12)
                  ),
                  child: TabBar(
                    unselectedLabelColor: AppColor.appThemeColorOlive,
                    labelColor: AppColor.appThemeColorOrange,
                    labelStyle: AppTextStyles.k16TextN.copyWith(
                        fontSize: 16.0,
                        color: AppColor.appThemeColorOlive,
                        fontWeight: FontWeight.w700),
                    tabs: [
                    Tab(
                      child: Container(width: _size!.width*0.3, child: Center(child: Text("Job Pending".tr))),
                    ),Tab(
                      child: Container(width: _size!.width*0.3, child: Center(child: Text("Online Job".tr))),
                    ),Tab(
                      child: Container(width: _size!.width*0.3, child: Center(child: Text("Active Employment".tr))),
                    ),Tab(
                      child:Container(width: _size!.width*0.3, child: Center(child: Text("Job Ended".tr))),
                    ),
                  ],indicatorColor: AppColor.appThemeColorOrange,
                    isScrollable: true,
                    automaticIndicatorColorAdjustment: true,
                    //physics: NeverScrollableScrollPhysics(),
                  onTap: (val){
                    print(val);
                    currentIndex = val;
                     skipValue = 1;
                     getData();

                    },
                  ),
                ),
              ),
               
              Expanded(
                child: TabBarView(
                  physics: NeverScrollableScrollPhysics(),
                children: [
                  // current index = 0
                 controller.pendingJobsList!=null && controller.pendingJobsList!.length>0?  ListView.builder(
                    itemCount: controller.pendingJobsList!.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                    JobsData obj = controller.pendingJobsList![index];
                    return JobItem(obj: obj,tabIndex: "0",);
                   }) : NoDataWidget(isloading: controller.isLoading.value,),
                    
                    //current Index =1
                    controller.activeJobsList!=null && controller.activeJobsList!.length>0?  ListView.builder(
                    itemCount: controller.activeJobsList!.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                    JobsData obj = controller.activeJobsList![index];
                    return JobItem(obj: obj,tabIndex: "1",);
                   }) : NoDataWidget(isloading: controller.isLoading.value,),

                   // currentIndex=2
                    controller.hiredJobsList!=null && controller.hiredJobsList!.length>0?  ListView.builder(
                    itemCount: controller.hiredJobsList!.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                    JobsData obj = controller.hiredJobsList![index];
                    return JobItem(obj: obj,tabIndex: "2",);
                   }) : NoDataWidget(isloading: controller.isLoading.value,),

                   // currentIndex = 3
                    controller.completeJobsList!=null && controller.completeJobsList!.length>0?  ListView.builder(
                    itemCount: controller.completeJobsList!.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                    JobsData obj = controller.completeJobsList![index];
                    return JobItem(obj: obj,tabIndex: "3",);
                   }) :NoDataWidget(isloading: controller.isLoading.value,),

                ],
              ))

                  ],
                 )
                 ),

                  controller.isLoading.value?CustomLoader(): Container(),
          ],
        )
         
      ),
    ));
  }
}