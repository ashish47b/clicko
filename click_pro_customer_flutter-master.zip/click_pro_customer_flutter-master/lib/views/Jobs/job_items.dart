import 'package:click_pro_customer/model/JobsDataModel/jobs_data_model.dart';
import 'package:click_pro_customer/res/formats/date_formats.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/CategoryController/category_controller.dart';
import 'package:click_pro_customer/view_model/CityController/city_controller.dart';
import 'package:click_pro_customer/view_model/JobController/job_controller.dart';
import 'package:click_pro_customer/views/Bidders/bidders_list.dart';
import 'package:click_pro_customer/views/Bidders/negotiation_page.dart';
import 'package:click_pro_customer/views/ChatScreen/chat_scrreen.dart';
import 'package:click_pro_customer/views/Jobs/view_jobs.dart';
import 'package:click_pro_customer/widgets/RowWithText.dart';
import 'package:click_pro_customer/widgets/add_rating_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';

class JobItem extends StatefulWidget {
  JobsData?obj;
  final tabIndex;
  JobItem({this.obj,this.tabIndex});

  @override
  State<JobItem> createState() => _JobItemState();
}

class _JobItemState extends State<JobItem> {
   
   final JobController controller = Get.put(JobController());

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Container(
      child: Column(
            //padding: const EdgeInsets.symmetric(horizontal: 16),
          children: [

                SizedBox(height: _size!.height*0.01),

               SizedBox(height: _size!.height*0.02),
               InkWell(
                onTap: (){
                     // Get.toNamed(RoutesName.joDetailsView);
                },
                 child: Container(
                   //height: 150,
                   margin:const EdgeInsets.symmetric(horizontal: 12),
                   padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                   decoration: BoxDecoration(
                      border: Border.all(color: AppColor.appThemeColorGreen,width: 2)
                   ),
                   child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(child: Text(widget.obj!.jobTitle!,style: AppTextStyles.k18TextH.copyWith(color: AppColor.appThemeColorSky))),
                            Container(
                              padding:const EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                color: AppColor.appThemeColorGreen,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text("€"+" " + widget.obj!.price! ,style: AppTextStyles.k16TextH.copyWith(color: Colors.white))),
                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const Icon(Icons.calendar_today,color: AppColor.appThemeColorOlive),
                            const SizedBox(width: 5),
                            Text("Posted on".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            //Text(ddMMMyyyy.format(DateTime.parse(widget.obj!.startDate!)).toString(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorGreen),)
                            Text(widget.obj!.startDate!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appRedColor),)
                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const Icon(Icons.calendar_today,color: AppColor.appThemeColorOlive),
                            const SizedBox(width: 5),
                            Text("Expires on".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            //Text(ddMMMyyyy.format(DateTime.parse(widget.obj!.dueDate!)).toString(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appRedColor))
                            Text(widget.obj!.dueDate!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appRedColor),)
                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/auction.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Total Bid".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(widget.obj!.bidCount!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                        SizedBox(height: _size!.height*0.015),
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/medal.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Category".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(widget.obj!.category_name!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                        SizedBox(height: _size!.height*0.015),
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/medal.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Location".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(widget.obj!.city_name!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                        SizedBox(height: _size!.height*0.015),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                          Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/medal.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Client ID".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text("COC-"+ widget.obj!.custId!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                          ],
                        ),
                        SizedBox(height: _size!.height*0.015),
                        if(widget.tabIndex=="2")
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/medal.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Hired Professional ID".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(widget.obj!.professionalId!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                        if(widget.tabIndex=="2")
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                        SizedBox(height: _size!.height*0.01),
                        RowWtihText(title: "Start Date",value: widget.obj!.startDate!),
                        SizedBox(height: _size!.height*0.01),
                        RowWtihText(title: "End Date",value: widget.obj!.dueDate!),
                          ],
                        ),
                        Divider(color: Colors.grey,),
                        SizedBox(height: _size!.height*0.01),
                        Text(widget.obj!.description!,style: AppTextStyles.k14TextN, maxLines: 4,overflow: TextOverflow.ellipsis,),
                        SizedBox(height: _size!.height*0.01),

                        Divider(color: Colors.grey,),

                        // pending jobs case 
                        if(widget.tabIndex=="0")
                        Column(
                          children: [
                            Row(
                              children: [
                              Expanded(
                                child: InkWell(
                                onTap: (){
                                  Get.toNamed(RoutesName.view_job,arguments: [widget.obj!.id]);
                                },
                                 child: Container(
                                  margin:const EdgeInsets.symmetric(horizontal: 5),
                                  padding:const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    color: AppColor.appThemeColorOrange,
                                   borderRadius: BorderRadius.circular(6)
                                  ),
                                  child:Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                       Text("View".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                                       const SizedBox(width: 10),
                                      const Icon(Icons.remove_red_eye,color: Colors.white,),
                                    ],
                                  ),
                                 ),
                                 ),
                              ),

                              Expanded(
                                child: InkWell(
                                onTap: (){
                                  Get.toNamed(RoutesName.postJobsView, arguments: [widget.obj!.id]);
                                },
                                child: Container(
                                  margin:const EdgeInsets.symmetric(horizontal: 5),
                                  padding:const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    color: AppColor.appThemeColorSky,
                                   borderRadius: BorderRadius.circular(6)
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("Edit".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                                      const SizedBox(width: 10),
                                      const Icon(Icons.edit,color: Colors.white,),
                                    ],
                                  ),
                                 ),
                                                          ),
                              ),
                            
                              ],
                            ),

                            const SizedBox(height: 10),

                            Row(
                              children: [
                              Expanded(
                                child: InkWell(
                                onTap: (){
                                  controller.activatePendingJobs(job_id: widget.obj!.id!);
                                },
                                 child: Container(
                                  margin:const EdgeInsets.symmetric(horizontal: 5),
                                  padding:const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: AppColor.appThemeColorOlive,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("Enable".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                                      const SizedBox(width: 10),
                                      const Icon(Icons.check,color: Colors.white,)
                                    ],
                                  ),
                                 ),
                                                           ),
                              ),
                             Expanded(
                               child: InkWell(
                                onTap: (){
                                  controller.deleteJobs(job_id: widget.obj!.id);
                                },
                                 child: Container(
                                  margin:const EdgeInsets.symmetric(horizontal: 5),
                                  padding:const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: AppColor.appRedColor,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("Delete".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                                      const SizedBox(width: 10),
                                      const Icon(Icons.delete,color: Colors.white,)
                                    ],
                                  ),
                                 ),
                               ),
                             ),
                              ],
                            ),
                          ],
                        ),


                        // active jobs 
                        if(widget.tabIndex=="1")
                        Column(
                          children: [
                            Row(
                              children: [
                              Expanded(
                                child: InkWell(
                                onTap: (){
                                  Get.toNamed(RoutesName.bidderView, arguments: [widget.obj!.id]);
                                },
                                 child: Container(
                                  margin:const EdgeInsets.symmetric(horizontal: 5),
                                  padding:const EdgeInsets.all(6),
                                
                                  decoration: BoxDecoration(
                                    color: AppColor.appThemeColorOrange,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Center(child: Text("See Offers".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),)),
                                 ),
                                                           ),
                              ),
                              ],
                            ),
                            SizedBox(height: 10),
                            Row(
                              children: [
                              Expanded(
                               child: InkWell(
                                onTap: (){
                                  controller.deActivateJobs(job_id: widget.obj!.id);
                                },
                                 child: Container(
                                  margin:const EdgeInsets.symmetric(horizontal: 5),
                                  padding:const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: AppColor.appThemeColorOlive,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("Disable".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                                      const SizedBox(width: 10),
                                      const Icon(Icons.close,color: Colors.white,)
                                    ],
                                  ),
                                 ),
                               ),
                             ),
                             Expanded(
                               child: InkWell(
                                onTap: (){
                                  controller.deleteJobs(job_id: widget.obj!.id);
                                },
                                 child: Container(
                                  margin:const EdgeInsets.symmetric(horizontal: 5),
                                  padding:const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: AppColor.appRedColor,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("Delete".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                                      const SizedBox(width: 10),
                                      const Icon(Icons.delete,color: Colors.white,)
                                    ],
                                  ),
                                 ),
                               ),
                             ),
                              ],
                            )
                          ],
                        ),


                        // hired jobs
                        if(widget.tabIndex=="2")
                        Column(
                          children: [
                            Row(
                              children: [
                              Expanded(
                               child: InkWell(
                                  onTap: (){
                                    navigateWithPageTransition(context, NegotiationPage(
                                    quote_id: widget.obj!.quot_id,user_ID: widget.obj!.professionalId!,

                                  ));
                                  },
                                  child: Container(
                                    margin:const EdgeInsets.symmetric(horizontal: 5),
                                    padding:const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      color: AppColor.appThemeColorOlive,
                                     borderRadius: BorderRadius.circular(6)
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text("Pay Payment".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                                      ],
                                    ),
                                   ),
                                ),
                            ),
                               Expanded(
                                 child: InkWell(
                                  onTap: (){
                                    Get.toNamed(RoutesName.quote_page, arguments: [widget.obj!.id]);
                                  },
                                  child: Container(
                                    margin:const EdgeInsets.symmetric(horizontal: 5),
                                    padding:const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: AppColor.appThemeColorOrange,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child:Center(child: Text("Quotes".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),)),
                                   ),
                                ),
                               ),

                            
                              ],
                            ),
                            SizedBox(height: 10),

                            Row(
                              children: [
                              /* Expanded(
                                 child: InkWell(
                                  onTap: (){
                                    Get.toNamed(RoutesName.quote_page, arguments: [widget.obj!.id]);
                                  },
                                  child: Container(
                                    margin:const EdgeInsets.symmetric(horizontal: 5),
                                    padding:const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: AppColor.appThemeColorOlive,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child:Text("Quotes".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                                   ),
                                ),
                               ),*/
                               Expanded(
                              child: InkWell(
                                  onTap: (){
                                   // Get.toNamed(RoutesName.chat_users_view, arguments: [widget.obj!.professionalId]);
                                   navigateWithPageTransition(context, ChatScreen(prof_Id: widget.obj!.professionalId, name: widget.obj!.pro_Name));
                                  },
                                  child: Container(
                                    margin:const EdgeInsets.symmetric(horizontal: 5),
                                    padding:const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      color: AppColor.appThemeColorOlive,
                                     borderRadius: BorderRadius.circular(6)
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text("Chat".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                                        const SizedBox(width: 10),
                                        const Icon(Icons.chat,color: Colors.white,),
                                      ],
                                    ),
                                   ),
                                ),
                            ),

                               Expanded(
                                 child: InkWell(
                                  onTap: ()async{
                                   await controller.chkPaymnetApi(jobId: widget.obj!.id);
                                  if(controller.pay_status=="1"){
                                     Get.bottomSheet(AddRatingBar(job_id: widget.obj!.id,));
                                  }else{
                                    showToastMsg("Do Payment First".tr);
                                  }
                                  
                                  },
                                  child: Container(
                                    margin:const EdgeInsets.symmetric(horizontal: 5),
                                    padding:const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      color: AppColor.appThemeColorGreen,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child:Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text("Mark Done".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                                        const SizedBox(width: 10),
                                        const Icon(Icons.check,color: Colors.white,),
                                      ],
                                    ),
                                   ),
                                                             ),
                               ),

                              /* Expanded(
                               child: InkWell(
                                onTap: (){
                                  controller.deleteJobs(job_id: widget.obj!.id);
                                },
                                 child: Container(
                                  margin:const EdgeInsets.symmetric(horizontal: 5),
                                  padding:const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: AppColor.appRedColor,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("Delete".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                                      const SizedBox(width: 10),
                                      const Icon(Icons.delete,color: Colors.white,)
                                    ],
                                  ),
                                 ),
                               ),
                             ),*/

                              ],
                            ),

                          ],
                        ),

                        // complete jobs
                        if(widget.tabIndex=="3")
                         Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                child: InkWell(
                                onTap: (){
                                  Get.toNamed(RoutesName.view_job,arguments: [widget.obj!.id]);
                                },
                                 child: Container(
                                  margin:const EdgeInsets.symmetric(horizontal: 5),
                                  padding:const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    color: AppColor.appThemeColorOrange,
                                   borderRadius: BorderRadius.circular(6)
                                  ),
                                  child:Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                       Text("View".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                                       const SizedBox(width: 10),
                                      const Icon(Icons.remove_red_eye,color: Colors.white,),
                                    ],
                                  ),
                                 ),
                                 ),
                              ),
                              Expanded(
                               child: InkWell(
                                onTap: (){
                                  controller.deleteJobs(job_id: widget.obj!.id);
                                },
                                 child: Container(
                                  margin:const EdgeInsets.symmetric(horizontal: 5),
                                  padding:const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: AppColor.appRedColor,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("Delete".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                                      const SizedBox(width: 10),
                                      const Icon(Icons.delete,color: Colors.white,)
                                    ],
                                  ),
                                 ),
                               ),
                             ),
                              ],
                            )
                          ],
                         )

                       
                    ],
                   ),
                   ),
               ),
          ],
        ),
    );
  }
}