import 'dart:async';

import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/view_model/SplashController/splash_controller.dart';
import 'package:click_pro_customer/widgets/custome_loader.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  Size?_size;
  final SplashController controller = Get.put(SplashController());

  @override
  void initState() {
    // TODO: implement initState
   
    Future.delayed(Duration(seconds: 3)).whenComplete(() => controller.naviagteOnScreen());
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
      
    _size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        children: [
          SizedBox(height: _size!.height*0.02),
            Container(
              margin: EdgeInsets.only(top: _size!.height*0.05),
              width: _size!.width*0.7,
              height:_size!.height*0.1,           
              child: Image.asset("assets/logos/logo1.png"),
          ),
         
          SizedBox(height: _size!.height*0.04),
            InkWell(
              onTap: (){
                //Get.toNamed(RoutesName.onBoardView);
              },
              child: Container(
              padding: EdgeInsets.all(10),
              height: _size!.height*0.4,
              child: Lottie.asset("assets/lottie/splash.json")
              ),
            ),
            SizedBox(height: _size!.height*0.05),
            CustmerLoader(),
        ],
      ),
    );
  }
}