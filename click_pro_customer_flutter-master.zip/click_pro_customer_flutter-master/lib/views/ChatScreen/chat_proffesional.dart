import 'package:click_pro_customer/model/ChatController/chat_users_model.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/ChatController/chat_scotroller.dart';
import 'package:click_pro_customer/views/ChatScreen/chat_scrreen.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ChatWithProfessional extends StatefulWidget {
  String?from;
  ChatWithProfessional({this.from});

  @override
  State<ChatWithProfessional> createState() => _ChatWithProfessionalState();
}

class _ChatWithProfessionalState extends State<ChatWithProfessional> {
  
  final ChatController chatController = Get.put(ChatController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }

  getData()async {
    chatController.getChatUsers();
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=> Scaffold(
      appBar:widget.from==null? AppBar(
        title: Text("CHATS".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.black)),
        centerTitle: true,
        iconTheme:const IconThemeData(color: Colors.black),
        elevation: 0.0,
        backgroundColor: Colors.white,
      ):null,
      body: Stack(
        children: [
          ListView(
            children: [
               SizedBox(height: _size!.height*0.02),
               ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                itemCount: chatController.chatUserList.length,
                shrinkWrap: true,
                itemBuilder: (context,index){
                  ChatUser obj = chatController.chatUserList[index];
                return InkWell(
                  onTap: (){
                    Get.toNamed(RoutesName.chatView, arguments: [
                      obj.id,obj.first_name , obj.last_name
                    ]);
                  },
                  child: Container(
                padding:const EdgeInsets.symmetric(vertical: 5,horizontal: 10),
                margin:const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  //border: Border.all(color: Colors.black),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: AppColor.appThemeColorOlive.withOpacity(0.2),
                      
                      spreadRadius: 3,blurRadius: 3
                    )
                  ]
                ),
                child: Row(
                  children: [
                    obj.profilePic!=null && obj.profilePic!=""?
                   Container(
                    height: 60,
                    width: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                       image: DecorationImage(image: NetworkImage(obj.profilePicPath! + obj.profilePic!),fit: BoxFit.fill)
                    ),
                   ) :Container(
                    height: 60,
                    width: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                       image: DecorationImage(image: AssetImage("assets/images/avatar.png"), fit: BoxFit.fill)
                    ),
                   ) ,
                    SizedBox(width: 10,),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(obj.first_name! + obj.last_name!,style: AppTextStyles.k18TextN,),
                        //Text("Plumber",style: AppTextStyles.k16TextN,),
                        
                      ],
                    )
                  ],
                ),
              ),
                );
               })
            ],
          ),
          
          chatController.isLoading.value?CustomLoader():Container()
        ],
      ),
    ));
  }
}