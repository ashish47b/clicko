import 'package:click_pro_customer/model/ChatController/all_message_model.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/ChatController/chat_scotroller.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:grouped_list/grouped_list.dart';

class ChatScreen extends StatefulWidget {
  String?name;
  String?prof_Id;

  ChatScreen({this.name,this.prof_Id});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {

  final ChatController controller = Get.put(ChatController());

   @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 100),()=> getData());
  }


  getData()async {
    controller.getMessages(profId: widget.prof_Id);
    getAfterData();
  }

 getAfterData() async{  
   await Future.delayed(Duration(seconds: 5));
  getData();
}


  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=>Scaffold(
      appBar: AppBar(
            backgroundColor: AppColor.appThemeColorOlive,
            elevation: 0,
           // automaticallyImplyLeading: false,
            title: Text(widget.name!=null ? widget.name!:(widget.prof_Id!=null ? widget.prof_Id!:""),style: AppTextStyles.k18TextN),

      ),
      body: Stack(
        children: [
          Column(
            children: [
               
               Expanded(
                  child: GroupedListView<ChatMessage, DateTime>(
                    padding: const EdgeInsets.all(8),
                    reverse: true,
                    order: GroupedListOrder.DESC,
                    useStickyGroupSeparators: true,
                    floatingHeader: true,
                    elements: controller.messageList,
                    groupBy: (message) => DateTime(
                    DateTime.now().year
                    ),
                    groupHeaderBuilder: (ChatMessage message) => SizedBox(
                      // height: 40,
                      // child: Center(
                      //   child: Card(
                      //     //color: Color(0xff4169E1),
                      //     child: Padding(
                      //       padding: const EdgeInsets.all(8),
                      //       // child: Text(
                      //       //   DateFormat.yMMMd().format(message.date),
                      //       //   style: const TextStyle(color: Colors.white),
                      //       // ),
                      //     ),
                      //   ),
                      // ),
                    ),
                    itemBuilder: (context, ChatMessage message) => Align(
                      alignment: message.createdBy == message.customerId
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Card(
                        elevation: 8,
                        color: message.createdBy == message.userId? AppColor.appThemeColorOlive.withOpacity(0.3) : AppColor.appThemeColorOlive.withOpacity(0.5),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(message.message!),
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                
                  margin: EdgeInsets.only(
                    left: _size!.width / 18,
                    right: _size!.width / 18,
                    bottom: _size!.height / 40,
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.only(left: _size!.width / 30),
                          height: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            // color: Colours.bgColor,
                            border: Border.all(color: Colors.black, width: 1),
                          ),
                          child: Row(
                            children: [
                              // SvgPicture.asset("images/icons/smile.svg"),
                              SizedBox(
                                width: _size!.width / 36,
                              ),
                              Expanded(
                                child: TextField(
                                  onChanged: (value) {
                                    setState(() {});
                                  },
                                  controller: _textController,
                                  cursorColor: Colors.deepPurple,
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    hintText: "Type Message..",
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        width: _size!.width / 36,
                      ),
                      Visibility(
                        visible: _textController.text
                            .isNotEmpty, // If message is not empty then send button will visible
                        child: GestureDetector(
                          onTap: () {
                           // addMessage(model);
                            
                            // final message = MessageModel(
                            //   text: _textController.text,
                            //   date: DateTime.now(),
                            //   isSentByMe: true,
                            // );
                            setState(() {
                              // messages.add(message);
                              controller.addMessage(Get.arguments[0], _textController.text);
                              _textController.clear();
                            });
                          },
                          child: Container(
                            padding: EdgeInsets.all(8),
                            height: 42,
                            width: 42,
                            decoration: BoxDecoration(
                                color: AppColor.appThemeColorOlive.withOpacity(0.2),
                                shape: BoxShape.circle,
                                border: Border.all(color: AppColor.appThemeColorOlive)),
                            child: Image.asset(
                              "assets/images/send.png",
                              height: 20,
                            ),
                            // child: SvgPicture.asset(
                            //   "images/icons/send.svg",
                            //   height: 17,
                            //   width: 11,
                            // ),
                          ),
                        ),
                        replacement: Container(),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          controller.isLoading.value?CustomLoader():Container()
        ],
      ),
    ));
  }
  TextEditingController _textController = TextEditingController();
}


class MessageModel {
  final String text;
  final DateTime date;
  final bool isSentByMe;

  MessageModel({required this.text, required this.date, required this.isSentByMe});
}

