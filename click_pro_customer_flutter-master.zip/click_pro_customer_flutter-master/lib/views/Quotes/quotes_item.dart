import 'package:click_pro_customer/model/QuoteDataModel/quote_data_model.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/views/Bidders/negotiation_page.dart';
import 'package:click_pro_customer/views/ChatScreen/chat_scrreen.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:intl/intl.dart';

class QuotesItem extends StatefulWidget {
QuoteData?obj;
final tabIndex;

QuotesItem({this.obj,this.tabIndex});

  @override
  State<QuotesItem> createState() => _QuotesItemState();
}

class _QuotesItemState extends State<QuotesItem> {


  
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Container(
       child: Column(
            //padding: const EdgeInsets.symmetric(horizontal: 16),
          children: [

                SizedBox(height: _size!.height*0.01),

               SizedBox(height: _size!.height*0.02),
               InkWell(
                onTap: (){
                     // Get.toNamed(RoutesName.joDetailsView);
                },
                 child: Container(
                   //height: 150,
                   margin:const EdgeInsets.symmetric(horizontal: 12),
                   padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                   decoration: BoxDecoration(
                      border: Border.all(color: AppColor.appThemeColorGreen)
                   ),
                   child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(child: Text(widget.obj!.jobTitle!,style: AppTextStyles.k18TextH.copyWith(color: AppColor.appThemeColorSky))),
                            Container(
                              padding:const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                              color: AppColor.appThemeColorGreen,
                              borderRadius: BorderRadius.circular(10)
                              ),
                              child: Text("€ " + widget.obj!.estimatePrice!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                            )
                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const Icon(Icons.calendar_today,color: AppColor.appThemeColorOlive),
                            const SizedBox(width: 5),
                            Text("Posted on".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(widget.obj!.createdDate!.toString().substring(0,10),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorGreen),)
                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const Icon(Icons.calendar_today,color: AppColor.appThemeColorOlive),
                            const SizedBox(width: 5),
                            Text("Expires on".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(![null,""].contains(widget.obj!.dueDate!)? widget.obj!.dueDate!:"",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appRedColor),)
                          ],
                        ),
                          SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/auction.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Category".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(widget.obj!.cat_name!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/auction.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Number of Payout".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(widget.obj!.instalmentPlan!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                          SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/auction.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Professional ID".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(widget.obj!.userId!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/auction.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Installment Amount".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            
                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        SizedBox(
                          height: 25,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              if(widget.obj!.versement_amount1!="0.00")
                              installPayBox(amount: widget.obj!.versement_amount1!,type:widget.obj!.pay_count!=null && (widget.obj!.pay_count=="1" || int.parse(widget.obj!.pay_count!)>1) ? "yes":""),
                              if(widget.obj!.versement_amount2!="0.00")
                              installPayBox(amount: widget.obj!.versement_amount2!,type:widget.obj!.pay_count!=null &&(widget.obj!.pay_count=="2" || int.parse(widget.obj!.pay_count!)>2)? "yes":""),
                              if(widget.obj!.versement_amount3!="0.00")
                              installPayBox(amount: widget.obj!.versement_amount3!,type:widget.obj!.pay_count!=null && (widget.obj!.pay_count=="3" || int.parse(widget.obj!.pay_count!)>3)? "yes":""),
                              if(widget.obj!.versement_amount4!="0.00")
                              installPayBox(amount: widget.obj!.versement_amount4!,type:widget.obj!.pay_count!=null && (widget.obj!.pay_count=="4" || int.parse(widget.obj!.pay_count!)>4)? "yes":""),
                              if(widget.obj!.versement_amount5!="0.00")
                              installPayBox(amount: widget.obj!.versement_amount5!,type:widget.obj!.pay_count!=null && (widget.obj!.pay_count=="5" || int.parse(widget.obj!.pay_count!)>5)? "yes":""),
                            ],
                          ),
                        ),
                        Divider(color: Colors.grey,),
                        SizedBox(height: _size!.height*0.01),
                        Text(widget.obj!.coverDescription!,style: AppTextStyles.k14TextN,maxLines: 4,overflow: TextOverflow.ellipsis,),
                        SizedBox(height: _size!.height*0.01),
                        Divider(color: Colors.grey,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            if(widget.tabIndex=="0" || widget.tabIndex=="1")
                             InkWell(
                              onTap: (){
                                // Get.toNamed(RoutesName.chatView,arguments: [widget.obj!.userId]);
                                navigateWithPageTransition(context, ChatScreen(prof_Id: widget.obj!.userId,name: widget.obj!.pro_name,));
                              },
                               child: Container(
                                padding:const EdgeInsets.all(7),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColor.appThemeColorOrange,
                                 
                                ),
                                child:Icon(Icons.chat,color: Colors.white, size: 20,)),
                             ),
                             const SizedBox(width: 6),
                             if(widget.tabIndex=="0" || widget.tabIndex=="1" || widget.tabIndex=="2")
                             InkWell(
                              onTap: (){
                                Get.toNamed(RoutesName.view_quotes,arguments: [widget.obj!.id]);
                              },
                               child: Container(
                                padding:const EdgeInsets.all(4),
                                decoration: BoxDecoration(
                                  color: AppColor.appThemeColorOrange,
                                  borderRadius: BorderRadius.circular(8)
                                ),
                                child:Text("See Quote".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)),
                             ),
                            const SizedBox(width: 10),
                            if(widget.tabIndex=="0" || widget.tabIndex=="1")
                            InkWell(
                              onTap: (){
                                navigateWithPageTransition(context, NegotiationPage(
                              quote_id: widget.obj!.id,user_ID: widget.obj!.userId,

                            ));
                              },
                               child: Container(
                                padding:const EdgeInsets.all(4),
                                decoration: BoxDecoration(
                                  color: AppColor.appThemeColorOrange,
                                  borderRadius: BorderRadius.circular(8)
                                ),
                                child:Text(widget.tabIndex=="1"? "Payment" : "Negotiation".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)                               ),
                             ),
                            

                             
                          ],
                        ),

                        SizedBox(height: _size!.height*0.01),
                       /* Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              padding:const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: AppColor.appThemeColorOrange,
                                borderRadius: BorderRadius.circular(8)
                              ),
                              child:Wrap(
                                children: [
                                  // for 1 payment 
                                  if((widget.obj!.pay_count==null || widget.obj!.pay_count=="0") && widget.obj!.versement_date1!="")
                                  Text("Payment Due".tr + " : " + widget.obj!.versement_date1!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
                                  
                                   // for 2 payment 
                                   if((widget.obj!.pay_count!=null && widget.obj!.pay_count=="1") && widget.obj!.versement_date2!="")
                                  Text("Payment Due".tr + " : " + widget.obj!.versement_date2!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
                                  
                                  // for 3 payment 
                                   if((widget.obj!.pay_count!=null && widget.obj!.pay_count=="2") && widget.obj!.versement_date3!="")
                                  Text("Payment Due".tr + " : " + widget.obj!.versement_date3!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
                                   
                                   // for 4 payment 
                                   if((widget.obj!.pay_count!=null && widget.obj!.pay_count=="3") && widget.obj!.versement_date4!="")
                                  Text("Payment Due".tr + " : " + widget.obj!.versement_date4!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
                                  
                                  // for 5 payment 
                                   if((widget.obj!.pay_count!=null && widget.obj!.pay_count=="4") && widget.obj!.versement_date5!="")
                                  Text("Payment Due".tr + " : " + widget.obj!.versement_date5!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
                                ],
                              ),
                            ),
                          ],
                        ),*/
                    ],
                   ),
                             ),
               ),
          ],
        ),
    );
  }
  installPayBox({String?amount, String?type}){
    return Container(
    padding:const EdgeInsets.symmetric(horizontal: 5),
    margin:const EdgeInsets.only(right: 4),
    decoration: BoxDecoration(
    color:![null,""].contains(type)?AppColor.appThemeColorGreen: AppColor.appRedColor,
    borderRadius: BorderRadius.circular(10),
    ),
    child: Center(
      child: Text("€ " + amount!,
      style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
    ));
  }
}