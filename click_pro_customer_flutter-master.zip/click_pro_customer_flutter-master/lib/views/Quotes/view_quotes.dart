import 'package:click_pro_customer/model/QuoteDataModel/view_quotation.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';
import 'package:click_pro_customer/widgets/RowWithText.dart';
import 'package:click_pro_customer/widgets/fade_img_with_error.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../view_model/QuotationController/quotation_controller.dart';

class ViewQuotes extends StatefulWidget {
  const ViewQuotes({super.key});

  @override
  State<ViewQuotes> createState() => _ViewQuotesState();
}

class _ViewQuotesState extends State<ViewQuotes> {

  final QuotationController controller = Get.put(QuotationController());
   
   getData()async{
    await controller.viewQuotes(quote_id: Get.arguments[0]);
   }


   @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }
  Size?_size;

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=>Scaffold(
    appBar:  AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          centerTitle: true,
          title: Text("Quote Details".tr,style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
          iconTheme: IconThemeData(color: Colors.black),
        ),
        body: Stack(
          children: [
            controller.viewQuoteData==null? NoDataWidget(isloading: controller.isLoading.value):
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            margin: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            width: double.infinity,
           decoration: BoxDecoration(
             borderRadius: BorderRadius.circular(6),
             border: Border.all(color: AppColor.appThemeColorGreen)
           ),
           child: ListView(
           
            children: [
              SizedBox(height: _size!.height*0.01),
              Text(controller.viewQuoteData!.jobTitle!,style: AppTextStyles.k20TextN.copyWith(color: AppColor.appThemeColorOrange)),
               SizedBox(height: _size!.height*0.01),
               Text(controller.viewQuoteData!.companyDetailsDtaList!=null && controller.viewQuoteData!.companyDetailsDtaList.length>0? controller.viewQuoteData!.companyDetailsDtaList[0].location!:"",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
              SizedBox(height: _size!.height*0.01),
              Row(
                children: [
                  Text("Enterprise".tr + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                  Text(controller.viewQuoteData!.companyDetailsDtaList!=null && controller.viewQuoteData!.companyDetailsDtaList.length>0? controller.viewQuoteData!.companyDetailsDtaList[0].companyName!:"", style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                ],
              ),
               SizedBox(height: _size!.height*0.01),
               Row(
                children: [
                  Text("SIREN Ou SIRET No".tr + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                  Text(controller.viewQuoteData!.sirenOrSiretNo!, style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                ],
              ),
              SizedBox(height: _size!.height*0.01),
               Row(
                children: [
                  Text("RCS Non".tr + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                  Text(controller.viewQuoteData!.rcsNo!, style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                ],
              ),
              SizedBox(height: _size!.height*0.01),
               Row(
                children: [
                  Text("TVA(%)".tr + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                  Text(controller.viewQuoteData!.vat!, style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                ],
              ),
              SizedBox(height: _size!.height*0.01),
               Row(
                children: [
                  Text("Start Date".tr + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                  Text(controller.viewQuoteData!.workStartDate!, style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                ],
              ),
              SizedBox(height: _size!.height*0.01),
               Row(
                children: [
                  Text("End Date".tr + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                  Text(controller.viewQuoteData!.workEndDate!, style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                ],
              ),
               const Divider(color: AppColor.appThemeColorOlive),
              Container(
                margin: EdgeInsets.all(10),
                padding:const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColor.appThemeColorOrange),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [
                    SizedBox(height: _size!.height*0.005),
                    RowWtihText(title: "Price".tr, value:"€ " +  controller.viewQuoteData!.estimate!),
                    SizedBox(height: _size!.height*0.01),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        RowWtihText(title: "TVA(%)".tr, value:controller.viewQuoteData!.vat!),
                        RowWtihText(title: "Total Vat".tr, value:"€ " +  controller.viewQuoteData!.totalVat!),
                      ],
                    ),
                    SizedBox(height: _size!.height*0.01),
                    RowWtihText(title: "Total Price".tr, value:"€ " +  controller.viewQuoteData!.estimatePrice!),
                  ],
                ),
              ),
              const Divider(color: AppColor.appThemeColorOlive),
              SizedBox(height: _size!.height*0.02),
              controller.viewQuoteData!.quoteMaterialDetailsList!=null && controller.viewQuoteData!.quoteMaterialDetailsList!.length>0? Column(
                children: [
                   Text("Material Details".tr ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                   SizedBox(height: _size!.height*0.015),
                  Container(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child:  DataTable(headingRowColor: MaterialStateProperty.all(AppColor.appThemeColorOlive),
                          columnSpacing: 16,
                          columns: [
                            DataColumn(label: Center(child: Text('Name'.tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                            DataColumn(label: Center(child: Text('Qty'.tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                            DataColumn(label: Center(child: Text('Unit'.tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                            DataColumn(label: Center(child: Text('Price(Unit)'.tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                            DataColumn(label: Center(child: Text('Vat(%)'.tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                            DataColumn(label: Center(child: Text('Total Vat'.tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                            DataColumn(label: Center(child: Text('Total Price'.tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                            ],
                          rows: getDataCells(),
                          //:CircularProgressIndicator(),
                          showCheckboxColumn: true,
                          decoration: BoxDecoration(),dataRowHeight: 22,headingRowHeight: 28,

                      ),
                    ),
                  ),
                ],
              ): Container(),

              SizedBox(height: _size!.height*0.01),
              const Divider(color: AppColor.appThemeColorOlive),
              SizedBox(height: _size!.height*0.01),
              Text("Description".tr + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
              SizedBox(height: _size!.height*0.007),
              Text(controller.viewQuoteData!.coverDescription!, style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOrange)),
              SizedBox(height: _size!.height*0.01),
              const Divider(color: AppColor.appThemeColorOlive),
              Text("Attachments".tr,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
              SizedBox(height: _size!.height*0.01),

             controller.viewQuoteData!.attachmentsList!=null && controller.viewQuoteData!.attachmentsList.length>0? Container(
                height: 100,
                child: ListView.builder(
                  itemCount: controller.viewQuoteData!.attachmentsList.length,
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context,index){
                  return Container(
                            height: 80,
                            width: 80,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: FadeImageWithError(imgPath: controller.viewQuoteData!.attachmentsList[index])));
                })
              ): Container(),
            ],

            ),
          ),

           controller.isLoading.value?CustomLoader(): Container(),
          ],
        )
    ));
  }
  
  getDataCells(){
        List<DataRow> dataRows=[];
        for(int i=0;i<controller.viewQuoteData!.quoteMaterialDetailsList!.length;i++){
          QuoteMaterialDetailsDataModel product= controller.viewQuoteData!.quoteMaterialDetailsList![i];

          dataRows.add(DataRow(cells: [
            DataCell(Text(product.materialName!,textAlign: TextAlign.center,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),),),
            DataCell(Center(child: Text(product.materialQty!,textAlign: TextAlign.left,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),
          
            DataCell(Center(child: Text(product.unit!,textAlign: TextAlign.center,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),
            DataCell(Center(child: Text(product.unitPrice!,textAlign: TextAlign.left,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),
            DataCell(Center(child: Text( product.tax!,textAlign: TextAlign.center,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),
            DataCell(Center(child: Text(product.taxAmount!,textAlign: TextAlign.center,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),
            DataCell(Center(child: Text(product.totalAmount!,textAlign: TextAlign.center,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),
            
          
          ],color: i.isOdd?MaterialStateProperty.all(AppColor.appThemeColorOlive.withOpacity(.4)):MaterialStateProperty.all(Colors.white)));
        }
        return dataRows;
  }

}

