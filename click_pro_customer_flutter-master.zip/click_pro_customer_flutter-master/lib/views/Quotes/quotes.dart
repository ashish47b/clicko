import 'package:click_pro_customer/model/BidsDataModel/bids_data_model.dart';
import 'package:click_pro_customer/model/QuoteDataModel/quote_data_model.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/QuotationController/quotation_controller.dart';
import 'package:click_pro_customer/views/Quotes/quotes_item.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Quotes extends StatefulWidget {
  String?from;
  Quotes({this.from});

  @override
  State<Quotes> createState() => _QuotesState();
}

class _QuotesState extends State<Quotes> {
  var scController=ScrollController();

  final QuotationController controller = Get.put(QuotationController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    scController.addListener(listener);
    Future.delayed(Duration(milliseconds: 300),(() => getData()));
    if(Get.arguments!=null){
      job_id = Get.arguments[0];
    }
  }

  String?job_id;

  getData()async{
   if(controller.currentIndex.value==0){
       controller.getPendingQuotes(limit: skipValue,job_id: job_id!=null?job_id!:"" );
   }else if(controller.currentIndex.value==1){
       controller.getActiveQuotes(limit: skipValue,job_id: job_id!=null?job_id!:"");
   }else if(controller.currentIndex.value==2){
       controller.getRejectQuotes(limit: skipValue,job_id: job_id!=null?job_id!:"");
   }
  }
    //int currentIndex = 0;
  int skipValue=1;
  listener(){
    if(scController.position.pixels == scController.position.maxScrollExtent){
      skipValue=skipValue+1;
      getData();
      print("called");
    }else{
      print("sorry");
    }
  }

   Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=> SafeArea(
      
      child: Scaffold(
        appBar: widget.from==null? AppBar(
          elevation: 0.0,
          backgroundColor: Colors.transparent,
          title: Text("Quotes".tr,style: AppTextStyles.k18TextN.copyWith(color: Colors.black),),
          centerTitle: true,
          iconTheme: IconThemeData(color: Colors.black),
        ):null,
        body: Stack(
          children: [
          DefaultTabController(
                 length: 3,
                 child: Column(
                  children: [
              Container(
               // margin: EdgeInsets.only(top: 20),
                decoration: BoxDecoration(
                  //color: AppColor.appThemeColorOrange
                ),
                child: Container(
                  //height: 50,
                 
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12)
                  ),
                  child: TabBar(
                    unselectedLabelColor: AppColor.appThemeColorOlive,
                    labelColor: AppColor.appThemeColorOrange,
                    labelStyle: AppTextStyles.k16TextN.copyWith(
                        fontSize: 16.0,
                        color: AppColor.appThemeColorOlive,
                        fontWeight: FontWeight.w700),
                    tabs: [
                    Tab(
                      child: Container(width: _size!.width*0.23, child: Center(child: Text("Pending".tr))),
                    ),Tab(
                      child: Container(width: _size!.width*0.2, child: Center(child: Text("Active".tr))),
                    ),Tab(
                      child: Container(width: _size!.width*0.2, child: Center(child: Text("Reject".tr))),
                    ),
                  ],indicatorColor: AppColor.appThemeColorOrange,
                    isScrollable: true,
                    automaticIndicatorColorAdjustment: true,
                   // physics: NeverScrollableScrollPhysics(),
                  onTap: (val){
                    print(val);
                    controller.setCurrentIndex(val);
                     
                     skipValue = 1;
                     getData();
                    },
                  ),
                ),
              ),
               
              Expanded(
                child: TabBarView(
                  physics: NeverScrollableScrollPhysics(),
                children: [
                  // current index = 0
                  controller.pendingQuotesList!=null && controller.pendingQuotesList!.isNotEmpty && 
                  !controller.isLoading.value?  ListView.builder(
                    itemCount: controller.pendingQuotesList!.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                      print("isime aa rha h");
                    QuoteData obj = controller.pendingQuotesList![index];
                    return QuotesItem(obj: obj,tabIndex: "0",);
                   }) : NoDataWidget(isloading: controller.isLoading.value),
                    
                    //current Index =1
                    controller.activeQuotesList!=null && controller.activeQuotesList!.length>0?  ListView.builder(
                    itemCount: controller.activeQuotesList!.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                    QuoteData obj = controller.activeQuotesList![index];
                    return QuotesItem(obj: obj,tabIndex: "1",);
                   }) : NoDataWidget(isloading: controller.isLoading.value),

                   // currentIndex=2
                    controller.rejectQuotesList!=null && controller.rejectQuotesList!.length>0?  ListView.builder(
                    itemCount: controller.rejectQuotesList!.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                    QuoteData obj = controller.rejectQuotesList![index];
                    return QuotesItem(obj: obj,tabIndex: "2",);
                   }) : NoDataWidget(isloading: controller.isLoading.value),

                ],
              ),
             ),

            ],
          )
        ), 
          controller.isLoading.value?CustomLoader(): Container(),
       
        ],
          
        ) ,
      ),
    ));
  }
}