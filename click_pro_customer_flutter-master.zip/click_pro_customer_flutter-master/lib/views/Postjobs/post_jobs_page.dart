
import 'dart:convert';
import 'dart:io';

import 'package:click_pro_customer/model/CategoryDataModel/category_data.dart';
import 'package:click_pro_customer/model/CityModel/city_model.dart';
import 'package:click_pro_customer/model/JobsDataModel/jobs_data_model.dart';
import 'package:click_pro_customer/res/formats/date_formats.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/CategoryController/category_controller.dart';
import 'package:click_pro_customer/view_model/CityController/city_controller.dart';
import 'package:click_pro_customer/view_model/JobController/job_controller.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:dropdown_search/dropdown_search.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class PostJobs extends StatefulWidget {
  String? categoryID;
  String? cityID;
  PostJobs({this.categoryID,this.cityID});

  @override
  State<PostJobs> createState() => _PostJobsState();
}

class _PostJobsState extends State<PostJobs> {

  final JobController controller = Get.put(JobController());
  final CityController cityController = Get.put(CityController());
  final CategoryController categoryController = Get.put(CategoryController());
   

  CityData?selectedCity;
  CategoryData?selectCategory;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 300),()=> getData());
    //Future.delayed(Duration(milliseconds: 300),()=> getJobData());

  }

  getData()async {
    await cityController.getCity();
    await categoryController.getCategoryApi();
    if(categoryController.categoryData!=null && categoryController.categoryData!.length>0){
     if(![null,""].contains(widget.categoryID)){
     print("enter12");
       categoryController.categoryData!.forEach((element) {
        if(element.id!.compareTo(widget.categoryID!)==0){
           selectCategory = element;
        }
       });
     } 
    }
     if(cityController.citiesList!=null && cityController.citiesList!.length>0){
     if(![null,""].contains(widget.cityID)){
     print("enter12");
       cityController.citiesList!.forEach((element) {
        if(element.id!.compareTo(widget.cityID!)==0){
           selectedCity = element;
        }
       });
     } 
    }
     
    if(Get.arguments!=null){
      print("from here");
     await controller.getSingleJob(jobId: Get.arguments[0]);
    }

  }

  




  Size?_size;

  final titleController = TextEditingController(text: "");
   final descController = TextEditingController(text: "");
    final amountController = TextEditingController(text: "");

  @override
  Widget build(BuildContext context) {
    print(Get.arguments);
   _size = MediaQuery.of(context).size;
    return Obx((){
      if(controller.singleJobDtaa!=null){
        print("data toh hai");
        titleController.text = controller.singleJobDtaa!.jobTitle!;
        descController.text = controller.singleJobDtaa!.description!;
        amountController.text = controller.singleJobDtaa!.price!;
        currentTime = DateTime.parse(controller.singleJobDtaa!.dueDate!);
        if(categoryController.categoryData!=null && categoryController.categoryData!.length>0){
          if(![null,""].contains(controller.singleJobDtaa!.category!)){
            categoryController.categoryData!.forEach((element) {
              if(element.id!.compareTo(controller.singleJobDtaa!.category!)==0){
                selectCategory = element;
              }
            });
          }
        }
        
        if(cityController.citiesList!=null && cityController.citiesList!.length>0){
          if(![null,""].contains(controller.singleJobDtaa!.location!)){
            cityController.citiesList!.forEach((element) {
              if(element.id!.compareTo(controller.singleJobDtaa!.location!)==0){
                selectedCity = element;
              }
            });
          }
        }
      }
      return SafeArea(
      child: Stack(
        children: [
          Scaffold(
            appBar: AppBar(
              centerTitle: true,
              iconTheme:const IconThemeData(color: Colors.black),
              elevation: 0.0,
              backgroundColor: Colors.transparent,
              title: Text("Post A Job".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.black)),
            ),
            body: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                   SizedBox(height: _size!.height*0.0),                 
                  Center(child: Text("Enter Work Details".tr,style: AppTextStyles.k18TextH)),
                  SizedBox(height: _size!.height*0.02),
                  getTextFieldTextType("Enter Title".tr, "Enter Title".tr, controller: titleController,radius: 10),
                   SizedBox(height: _size!.height*0.02),

                  getTextFromFieldTextType("Enter Description".tr, "Enter Description".tr,
                  radius: 10,
                  controller: descController,
                  maxLines: 5),
                   SizedBox(height: _size!.height*0.02),
                    Container(
                  padding: const EdgeInsets.all(1),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
                      borderRadius: BorderRadius.circular(16)
                  ),
                
                  child:  DropdownSearch<CategoryData>(
                                //asyncItems: (String filter) => getData(filter),
                itemAsString: (CategoryData? u) => u!.categoryName!,
                items: categoryController.categoryData!,
                dropdownButtonProps: const DropdownButtonProps(

                ),
                dropdownDecoratorProps: const DropDownDecoratorProps(
                  dropdownSearchDecoration: InputDecoration(hintText: "Select Category", border: InputBorder.none)
                ),
                popupProps: const PopupProps.dialog(
                showSearchBox: true,
              //  showSelectedItems: true,
                  title: Text("Select Category"),
              ),selectedItem:selectCategory ,

                  onChanged: (CategoryData? data) async {
                  setState(() {
                    selectCategory = data!;
                  });
                },
                onSaved: (data){
                  print("hi");
                },
              ),
                ),
                  SizedBox(height: _size!.height*0.02),
                  Container(
                  padding: const EdgeInsets.all(1),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
                      borderRadius: BorderRadius.circular(16)
                  ),
                
                  child:  DropdownSearch<CityData>(
                                //asyncItems: (String filter) => getData(filter),
                itemAsString: (CityData? u) => u!.cityName!,
                items: cityController.citiesList!,
                dropdownButtonProps: const DropdownButtonProps(

                ),
                dropdownDecoratorProps: const DropDownDecoratorProps(
                  dropdownSearchDecoration: InputDecoration(hintText: "Select City", border: InputBorder.none)
                ),
                popupProps: const PopupProps.dialog(
                showSearchBox: true,
              //  showSelectedItems: true,
                  title: Text("Select City"),
              ),selectedItem:selectedCity ,

                  onChanged: (CityData? data) async {
                  setState(() {
                    selectedCity = data!;
                  });
                },
                onSaved: (data){
                  print("hi");
                },
              ),
                ),
              SizedBox(height: _size!.height*0.02),

              Center(child: Text("Enter Budget Details".tr,style: AppTextStyles.k18TextH)),
              SizedBox(height: _size!.height*0.02),
              getTextFieldTextType("Amount".tr, "Amount".tr,
              radius: 10,
              controller: amountController,
              textInputType: TextInputType.number,
              textInputFormatter: [
                FilteringTextInputFormatter.digitsOnly,
              ]
              ),
              SizedBox(height: _size!.height*0.02),
              InkWell(
                onTap: (){
                  selectDate();
                },
                child: Container(
                  height: 50,
                  padding:const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                   borderRadius: BorderRadius.circular(10),
                   border: Border.all(color: AppColor.appThemeColorOlive)
                  ),
                  child: Row(
                    children: [
                     const Icon(Icons.calendar_today, color: AppColor.appThemeColorOlive,),
                     const SizedBox(width: 10),
                      Text(currentTime!=null && dateSet!?currentTime!.toString().substring(0,10) :(controller.singleJobDtaa!=null && controller.singleJobDtaa!.dueDate!=null?controller.singleJobDtaa!.dueDate!: "Select Due Date").tr, style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),)
                    ],
                  ),
                ),
              ),
              SizedBox(height: _size!.height*0.03),
              InkWell(
                onTap: ()async{
                 String?str= await pickedImage(context);
                 if(![null,""].contains(str)){
                   selectedImage = str;
                 }
                 setState(() {
                   
                 });
                },
                child: Container(
                  padding:const EdgeInsets.symmetric(vertical: 3),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColor.appThemeColorOlive),
                    borderRadius: BorderRadius.circular(12),
                    color: AppColor.appThemeColorOlive
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.add,color: Colors.white),
                      const SizedBox(width: 6),
                      Text("Attach Files",style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
                    ],
                  ),
                ),
              ),
             
             SizedBox(height: _size!.height*0.01),
             selectedImage!=null? Wrap(
               children: [
                 Container(
                  height: 80,width: 80,
                  decoration: BoxDecoration(
                    border: Border.all(color:AppColor.appThemeColorOlive),
                    borderRadius: BorderRadius.circular(10),
                    image: DecorationImage(image: FileImage(File(selectedImage!)),fit: BoxFit.fill)
                  ),
                 ),
               ],
             ):Container()

                 

              ],
            ),
            bottomNavigationBar: InkWell(
              onTap: (){
                print("Chk");
                saveData();
              },
              child: Container(
                height: 40,
                margin:const EdgeInsets.symmetric(horizontal: 12,vertical: 10),
                decoration: BoxDecoration(
                  color: AppColor.appThemeColorOlive,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(child: Text("SUBMIT".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),)),
              ),
            ),
          ),
          cityController.isLoading.value || categoryController.isLoading.value ||controller.isLoading.value ? CustomLoader() : Container()
        ],
      ),

    );});
  }
  
   String? selectedImage;
  saveData()async{
   
    if(titleController.text.isEmpty && titleController.text.isEmpty){
      return showToastMsg("Please Enter Post Details".tr);
    }

    if(selectCategory==null){
     return showToastMsg("Please Select Category".tr);
    }

    if(selectedCity==null){
     return showToastMsg("Please Select City".tr);
    }
   
    if(amountController.text.isEmpty){
      return showToastMsg("Please Enter Job Amount".tr);
    }

    if(currentTime==null){
      return showToastMsg("Please Select Date Time".tr);
    }
    print(currentTime);

    controller.saveJobApi(context,
      job_id: controller.singleJobDtaa!=null?controller.singleJobDtaa!.id!:"",
      title: titleController.text,
      desc: descController.text,
      amount: amountController.text,
      catId: selectCategory!=null?selectCategory!.id:"",
      date:currentTime!=null?  yyMMddDateFormatter.format(currentTime!) : yyMMddDateFormatter.format(DateTime.now()),
      city_id: selectedCity!=null?selectedCity!.id:"",
      attachFiles: selectedImage!=null? selectedImage:"",
    );
  }
  //
 


  bool?dateSet = false;
  DateTime? currentTime;
  selectDate() async{
    DateTime? date = DateTime.now();
    var newDate = new DateTime(date.year, date.month - 11, date.day);
    DateTime? newDateFrom=await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: newDate,
        lastDate: DateTime(2100));
    if (newDateFrom !=null) {
      setState(() {
        
      });
      currentTime = newDateFrom;
      dateSet = true;
      //getData();
    }
   }
}