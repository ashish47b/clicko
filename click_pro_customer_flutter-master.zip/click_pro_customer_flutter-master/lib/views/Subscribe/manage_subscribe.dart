import 'package:carousel_slider/carousel_slider.dart';
import 'package:click_pro_customer/utils/app_color.dart';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../../utils/text_styles.dart';

class ManageSubscribe extends StatefulWidget {
  const ManageSubscribe({super.key});

  @override
  State<ManageSubscribe> createState() => _ManageSubscribeState();
}

class _ManageSubscribeState extends State<ManageSubscribe> {
  
  bool isMonth=false;
  bool isYear=false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isMonth = true;
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return StatefulBuilder(builder: (context,myState){
      return ListView(
      children: [
         SizedBox(height: _size!.height*0.02,),
        // Center(child: Text("Manage Subscription",style: AppTextStyles.k18TextH)),
         SizedBox(height: _size!.height*0.02),
         Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            InkWell(
              onTap: (){
                isMonth = true;
                isYear = false;
                myState(() {
                  
                });
              },
              child: Container(
                width: 100,
                padding: EdgeInsets.symmetric(vertical: 3),
                decoration: BoxDecoration(color:isMonth? AppColor.appThemeColorOrange:Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColor.appThemeColorOrange)
                ),
              child:  Center(child: Text("Monthly".tr(), style: AppTextStyles.k16TextN.copyWith(color:isMonth? Colors.white:AppColor.appThemeColorOrange),)),
              ),
            ),
           const SizedBox(width: 20),
               InkWell(
                onTap: (){
                     isMonth = false;
                isYear = true;
                myState(() {
                  
                });
                },
                 child: Container(
                             width: 100,
                             padding: EdgeInsets.symmetric(vertical: 3),
                             decoration: BoxDecoration(color:isYear? AppColor.appThemeColorOrange :Colors.white,
                             borderRadius: BorderRadius.circular(12),
                             border:Border.all(color: AppColor.appThemeColorOrange)
                             ),
                           child:  Center(child: Text("Yearly".tr(), style: AppTextStyles.k16TextN.copyWith(color:isYear? Colors.white :AppColor.appThemeColorOrange),)),
                           ),
               ),
          ],
         ),

         SizedBox(height: _size!.height*0.05),

        monthlyWidget(myState)
      ],
    );
    });
  }
  monthlyWidget(myState){
    return Container(
      
      child: CarouselSlider(
  options: CarouselOptions(
    height: _size!.height*0.5,
    viewportFraction: 0.65,
     enlargeFactor: 0.2,
   enlargeCenterPage: true,
 enableInfiniteScroll :false,
 initialPage: 1
 ),
  
  items: subscriptionData.map((i) {
    return Builder(
      builder: (BuildContext context) {
        return subscriptionBox(
          myState,
          name: i['name'],
          amount: i['amount'],
          quote: i['quotes'],
          bills: i['bills'],
          whapss: i['whatsApp'],
          commission: i['commission'],
          isSubscrib:i['isSubscribe'],
          i:i

        );
      },
    );
  }).toList(),
)
 );
  }

  subscriptionBox(myState,{String?name,amount,quote,bills,whapss,commission, bool?isSubscrib,dynamic i} ){
    return InkWell(
      onTap: (){
        myState(() {
          print(isSubscrib);
          i['isSubscribe']=!isSubscrib!;
           print(isSubscrib);
        });
      },
      child: Container(
            width: MediaQuery.of(context).size.width,
           
            decoration: BoxDecoration(
             // color: Colors.amber,
             borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColor.appThemeColorOrange,width: i['isSubscribe']?3:1),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: AppColor.appThemeColorOrange.withOpacity(0.2),
                  blurRadius: 3, spreadRadius: 3,
                )
              ]
            ),
           child: Column(
            children: [
              Image.asset("assets/logos/logo1.png", height: 100, width: 150),
              SizedBox(height: _size!.height*0.01),
              Text(name!,style: AppTextStyles.k25TextN.copyWith(color: AppColor.appThemeColorOrange)),
               SizedBox(height: _size!.height*0.01),
               amount=="0"
               ?Text("FREE",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorGreen))
               :Row(
                mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   Text( "\$ " + amount!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                   Text("/ per month",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                 ],
               ),
                SizedBox(height: _size!.height*0.02),
              
             quote=="all"? Text("No Limit",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorGreen)) : Text("${quote} Quotes",style: AppTextStyles.k16TextN),
              SizedBox(height: _size!.height*0.01),
                  bills=="all"? Text("No Limit",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorGreen)) : Text("${bills} Bills",style: AppTextStyles.k16TextN),
              SizedBox(height: _size!.height*0.01),
              // Text("Appointment Management",style: AppTextStyles.k16TextN),
               Row(
                mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   Text("WhatsApp Reminder",style: AppTextStyles.k16TextN),
                  whapss=="no"? Icon(Icons.close, color: Colors.red,):Icon(Icons.check, color: Colors.green,) 
                 ],
               ),
               SizedBox(height: _size!.height*0.01),
            commission=="no"? Text("No Commission ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorGreen)) :   Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Commission ",style: AppTextStyles.k16TextN),
                  Text("(${commission}%)",style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange))
                ],
              ),
            ],
           ),
          ),
    );
  }

  List<dynamic> subscriptionData=[
    {
      "name":"Discovery",
      "amount":"0",
      "quotes":"5",
      "bills":"5",
      "whatsApp":"no",
      "commission":"10",
      "isSubscribe":false
    },
        {
      "name":"Standard",
      "amount":"99",
      "quotes":"50",
      "bills":"50",
      "whatsApp":"yes",
      "commission":"5",
      "isSubscribe":false
    },
        {
      "name":"Prime",
      "amount":"199",
      "quotes":"100",
      "bills":"100",
      "whatsApp":"yes",
      "commission":"2",
      "isSubscribe":false
    },
        {
      "name":"Privilege",
      "amount":"1199",
      "quotes":"all",
      "bills":"all",
      "whatsApp":"yes",
      "commission":"no",
      "isSubscribe":false
    }
  ];
}