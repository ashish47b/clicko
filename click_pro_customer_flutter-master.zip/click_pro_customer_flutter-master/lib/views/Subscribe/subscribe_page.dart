import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/views/Subscribe/manage_subscribe.dart';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class SubscriberPage extends StatefulWidget {
  const SubscriberPage({super.key});

  @override
  State<SubscriberPage> createState() => _SubscriberPageState();
}

class _SubscriberPageState extends State<SubscriberPage> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0.0,
            centerTitle: true,
            title: Text("SUBSCRIBE".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
            iconTheme: IconThemeData(color: Colors.black),
          ),
          body: Column(
            children: [
              SizedBox(height: _size!.height*0.06),
             Expanded(child:  ManageSubscribe(),)
            ],
          ),
          bottomNavigationBar: Wrap(
            children: [
              Container(
                padding:const EdgeInsets.symmetric(vertical: 6),
                margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 10),
                decoration: BoxDecoration(
                  color: AppColor.appThemeColorOlive,
                  borderRadius: BorderRadius.circular(12),

                ),
                child: Center(child: Text("APPLY".tr(),style: AppTextStyles.k18TextN.copyWith(color: Colors.white),),),
              ),
            ],
          ),
      ),
    );
  }
}