
import 'package:click_pro_customer/model/CategoryDataModel/category_data.dart';
import 'package:click_pro_customer/model/CityModel/city_model.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/CategoryController/category_controller.dart';
import 'package:click_pro_customer/view_model/ChatController/chat_scotroller.dart';
import 'package:click_pro_customer/view_model/CityController/city_controller.dart';
import 'package:click_pro_customer/views/DashBoard/search_professionals.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/dashboard_category.dart';
import 'package:click_pro_customer/widgets/dashboard_cities.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';




class DashBoardScreen extends StatefulWidget {
  const DashBoardScreen({super.key});

  @override
  State<DashBoardScreen> createState() => _DashBoardScreenState();
}

class _DashBoardScreenState extends State<DashBoardScreen> {
  
  final CategoryController categoryController = Get.put(CategoryController());
  final ChatController chatController = Get.put(ChatController());
  final CityController cityController = Get.put(CityController());



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }
  String?userName="";
  String?userEmail = "";
  getData()async{
    await categoryController.getCategoryApi();
    await chatController.getChatUsers();
    await cityController.getCity();

    userName = await SharedMethods.getLocalStringData(key: SPKeys.USER_NAME);
    userEmail = await SharedMethods.getLocalStringData(key: SPKeys.USER_EMAIL);
  }



  Size?_size;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
     print(_size!.height);
    print(_size!.width);
    return Obx(()=>SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        key: scaffoldKey,
        //drawer: NavDrawer(userName: userName,userEmail: userEmail,),
        body: Stack(
          children: [
            categoryController.categoryData!=null && categoryController.categoryData!.length>0?
            ListView(
              
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                  SizedBox(height: _size!.height*0.03),
                  Text("Hii"+ ", " + userName! ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                  SizedBox(height: _size!.height*0.01),
                  GestureDetector(
                    onTap: (){
                      navigateWithPageTransition(context, SearchProfessionals());
                    },
                    child: Container(
                      padding:const EdgeInsets.symmetric(vertical: 10,horizontal: 10),
                      decoration: BoxDecoration(
                        border: Border.all(color: AppColor.appThemeColorOlive),
                        borderRadius: BorderRadius.circular(50),
                        //color: AppColor.appThemeColorOlive
                      ),
                     child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                       children: [
                         Text("Search Professionals".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.grey)),
                         Icon(Icons.search,color: Colors.grey),
                       ],
                     )
                    ),
                  ),
                  // Text("Popular Categories".tr,style: AppTextStyles.k20TextH),
                  // SizedBox(height: _size!.height*0.02),
              
                 /* Container(
                      height : _size!.height>900?_size!.height*0.3: _size!.height*0.2,
                      child: PageView.builder(
                        scrollDirection: Axis.horizontal,
                        scrollBehavior: ScrollConfiguration.of(context).copyWith(
                        dragDevices: {
                          PointerDeviceKind.touch,
                          PointerDeviceKind.mouse,
                        },
                      ),
                      itemCount: 5,
                      itemBuilder: (context,index){
                      return Container(
                      
                      height: _size!.height*0.18,
                      margin: EdgeInsets.symmetric(horizontal: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        //border: Border.all(color: AppColor.appThemeColorOlive),
                        color: Colors.white,
                         image: DecorationImage(image: AssetImage("assets/images/home_ser1.jpg"), fit: BoxFit.fill)
                      ),
                   //  child: Image.asset("assets/images/home_ser1.jpg", fit: BoxFit.fill,),
                    );
                    }),
                  ),*/
                  SizedBox(height: _size!.height*0.03),
                  Text("All Categories".tr,style: AppTextStyles.k20TextH),
                  SizedBox(height: _size!.height*0.02),
                  DashBoardCategory(),
                  SizedBox(height: _size!.height*0.02),
                  Text("All Cities".tr,style: AppTextStyles.k20TextH),
                  SizedBox(height: _size!.height*0.02),
                  DashBoardCities(),
                  SizedBox(height: _size!.height*0.02),
                  Text("Recommended".tr,style: AppTextStyles.k20TextH),
                  SizedBox(height: _size!.height*0.02),
                  chatController.chatUserList!=null && chatController.chatUserList.length>0?
                  ListView.builder(
                    itemCount: chatController.chatUserList.length,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (context,index){
                      return InkWell(
                    onTap: (){
                      Get.toNamed(RoutesName.professionalView, arguments: [chatController.chatUserList[index].id]);
                    },
                    child: Container(
                      margin:const EdgeInsets.symmetric(vertical: 5),
                      padding:const EdgeInsets.symmetric(vertical: 5,horizontal: 5),
                 // height: _size!.height*0.1,
                  decoration: BoxDecoration(
                    //color: AppColor.appThemeColorOlive,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.black)
                  ),
                  child: Row(
                    children: [
                      chatController.chatUserList[index].profilePic!=null && chatController.chatUserList[index].profilePic!=""?
                   Container(
                    height: 60,
                    width: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                       image: DecorationImage(image: NetworkImage(chatController.chatUserList[index].profilePicPath! + chatController.chatUserList[index].profilePic!),fit: BoxFit.fill)
                    ),
                   ) :Container(
                    height: 60,
                    width: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                       image: DecorationImage(image: AssetImage("assets/images/avatar.png"), fit: BoxFit.fill)
                    ),
                   ) ,
                     const SizedBox(width: 10),
                     Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(chatController.chatUserList[index].first_name! + chatController.chatUserList[index].last_name! ,style: AppTextStyles.k18TextN),
                         const SizedBox(height: 2),
                      //   Text("James Bond",style: AppTextStyles.k14TextN),
                      //  const SizedBox(height: 3),
                        Row(
                          children: [
                            //Text("${"12/hr"} ",style: AppTextStyles.k16TextH),
                            // SizedBox(width: _size!.width*0.3),
                               Row(
                           children: [
                                    Icon(Icons.star,color: Colors.yellow[700],size: 20,),
                                    Icon(Icons.star,color: Colors.yellow[700],size: 20),
                                    Icon(Icons.star,color: Colors.yellow[700],size: 20),
                                    Icon(Icons.star_half_outlined,color: Colors.yellow[700],size: 20),
                                  ],
                                ),
                          ],
                        ),
                         const SizedBox(height: 3),
                     
    
                      ],
                     )
                    ],
                  ),
                ),
                );
                  })
                  : Container()
              ],
            ) : CustomLoader(),
            
            categoryController.isLoading.value || chatController.isLoading.value? CustomLoader(): Container()

          ],
        ),
      ),
    ));
  }




}