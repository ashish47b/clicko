import 'package:click_pro_customer/model/CategoryDataModel/category_data.dart';
import 'package:click_pro_customer/model/CityModel/city_model.dart';
import 'package:click_pro_customer/model/CustomerSearchDataModel.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/CityController/city_controller.dart';
import 'package:click_pro_customer/view_model/CustomerSearchController/customer_search_Controller.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../view_model/CategoryController/category_controller.dart';

class SearchProfessionals extends StatefulWidget {
  const SearchProfessionals({super.key});

  @override
  State<SearchProfessionals> createState() => _SearchProfessionalsState();
}

class _SearchProfessionalsState extends State<SearchProfessionals> {
    final CategoryController categoryController = Get.put(CategoryController());

  final CityController cityController = Get.put(CityController());
  final CustomerSeachController customerSeachController = Get.put(CustomerSeachController());

    @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }
  String?userName="";
  String?userEmail = "";
  getData()async{
    await categoryController.getCategoryApi();
    await cityController.getCity();
  }

  Size?_size;
 String? cityName="";

    CityData?selectedCity;
  CategoryData?selectCategory;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx((){
      if(cityController.citiesList!=null && cityController.citiesList!.length>0){
        if(customerSeachController.customerSearchProList!=null && customerSeachController.customerSearchProList.length>0){
          customerSeachController.customerSearchProList.forEach((element) {
            if(![null,""].contains(element.cityId)){
              cityController.citiesList!.forEach((city) { 
                if(city.id!.compareTo(element.cityId!)==0){
                      cityName = city.cityName!;
                }
              });
            }
          });
        } 
      }
      return  Scaffold(
      appBar: AppBar(
        title: Text("Search".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.black),),
        elevation: 0.0,
        iconTheme: IconThemeData(color: Colors.black),
        centerTitle: true,
        backgroundColor: Colors.transparent,
      ),
      body: Stack(
        children: [
        ListView(
          padding:const EdgeInsets.symmetric(horizontal: 16,vertical: 10),
          children: [
          Text("Select Category",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
          SizedBox(height: _size!.height*0.01),
          Container(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(
                border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
                  borderRadius: BorderRadius.circular(10),
                  
              ),
                
              child:  DropdownSearch<CategoryData>(
                            //asyncItems: (String filter) => getData(filter),
            itemAsString: (CategoryData? u) => u!.categoryName!,
            items: categoryController.categoryData!,
            dropdownButtonProps: const DropdownButtonProps(
      
            ),
            dropdownDecoratorProps:  DropDownDecoratorProps(
              dropdownSearchDecoration: InputDecoration(hintText: "Select Category".tr, border: InputBorder.none)
            ),
            popupProps:  PopupProps.dialog(
            showSearchBox: true,
          //  showSelectedItems: true,
              title: Text("Select Category".tr),
          ),selectedItem:selectCategory ,
      
              onChanged: (CategoryData? data) async {
              setState(() {
                selectCategory = data!;
              });
            },
            onSaved: (data){
              print("hi");
            },
            ),
          ),
      
          SizedBox(height: _size!.height*0.01),
          Text("Select City",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
          SizedBox(height: _size!.height*0.01),
          Container(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
                    borderRadius: BorderRadius.circular(10),
                    
                ),
                  
                child:  DropdownSearch<CityData>(
                              //asyncItems: (String filter) => getData(filter),
              itemAsString: (CityData? u) => u!.cityName!,
              items: cityController.citiesList!,
              dropdownButtonProps: const DropdownButtonProps(
        
              ),
              dropdownDecoratorProps:  DropDownDecoratorProps(
                dropdownSearchDecoration: InputDecoration(hintText: "Select City".tr, border: InputBorder.none)
              ),
              popupProps:  PopupProps.dialog(
              showSearchBox: true,
            //  showSelectedItems: true,
                title: Text("Select Category".tr),
            ),selectedItem:selectedCity ,
        
                onChanged: (CityData? data) async {
                setState(() {
                  selectedCity = data!;
                });
              },
              onSaved: (data){
                print("hi");
              },
              ),
            ),
          
          SizedBox(height: _size!.height*0.04),
          InkWell(
            onTap: (){
              if(selectCategory==null && selectedCity==null){
                return showToastMsg("Please Select".tr);
              }
              customerSeachController.getSearchData(catId: selectCategory!=null? selectCategory!.id:"", cityID: selectedCity!=null?selectedCity!.id:"");
            },
            child: Container(
              padding:const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: AppColor.appThemeColorOrange,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Center(
                child: Text("Search Professionals".tr,style: AppTextStyles.k14TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)),
              ),
            ),
          ),
          SizedBox(height: _size!.height*0.03),
          Text("Professionals",style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive)),
          SizedBox(height: _size!.height*0.01),
          customerSeachController.customerSearchProList!=null && customerSeachController.customerSearchProList.length>0?
           ListView.builder(
            itemCount: customerSeachController.customerSearchProList.length,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: (context,index){
              CustomerSearchProfessionals obj = customerSeachController.customerSearchProList[index];
            return Container(
              margin:const EdgeInsets.symmetric(vertical: 8),
              padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 8),
              decoration: BoxDecoration(
                border: Border.all(color:AppColor.appThemeColorGreen),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ![null,""].contains(obj.profilePic) && ![null,""].contains(obj.profilePicPath!)?
                  Container(
                    height: 80,width: 80,
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColor.appThemeColorGreen),
                      shape: BoxShape.circle,
                      image: DecorationImage(image: NetworkImage(obj.profilePicPath! + obj.profilePic!),fit: BoxFit.fill)
                    ),
                  ) :Container(
                    height: 80,width: 80,
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColor.appThemeColorGreen),
                      shape: BoxShape.circle,
                      image: DecorationImage(image: AssetImage("assets/images/avatar.png"),fit: BoxFit.fill)
                    ),
                  ) ,
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Image.asset("assets/images/medal.png",height: 30),
                          const SizedBox(width: 4),
                          Text(obj.firstName! + obj.lastName!,style: AppTextStyles.k16TextN),
                        ],
                      ),
                      const SizedBox(height: 7),
                      Row(
                        children: [
                          const Icon(Icons.location_on,color: AppColor.appRedColor,),
                          const SizedBox(width: 4),
                          Text(cityName!,style: AppTextStyles.k14TextN),
                        ],
                      ),
            
                      const SizedBox(height: 7),
              
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Text("Total Work Done".tr + " : ".tr,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive)),
                              Text(obj.jobDone!,style: AppTextStyles.k14TextN,)
                            ],
                          ),
                          const SizedBox(width: 15),
                          // Row(
                          //   children: [
                          //     Text("You Hired".tr  + " : ".tr,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive)),
                          //     Text("0",style: AppTextStyles.k14TextN,)
                          //   ],
                          // )
                        ],
                      ),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColor.appThemeColorOlive
                        ),
                        onPressed: (){
                           Get.toNamed(RoutesName.professionalView, arguments: [obj.userId]);
                        },
                        child: Text("See Profile".tr,style: AppTextStyles.k16TextN,)
                      )
                    ],
                  )
                ],
              )
            );
          }):Container()
          ],
        ),
        customerSeachController.isLoading.value?CustomLoader():Container()
      ]),
    );
    }
   );
  }
}