
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/AuthController/login_controller.dart';
import 'package:click_pro_customer/view_model/loader.dart';
import 'package:click_pro_customer/views/BottomNavBar/bottomNavbar.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';

import 'package:flutter/material.dart';

import 'package:get/get.dart';
import '../../res/route/routes_name.dart';

class UserLogin extends StatefulWidget {
  const UserLogin({super.key});

  @override
  State<UserLogin> createState() => _UserLoginState();
}

class _UserLoginState extends State<UserLogin> {

  final LoginController loginController = Get.put(LoginController());

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=> Scaffold(
      body: Stack(
        children: [
          ListView(
             children: [
              SizedBox(height: _size!.height*0.05),
                Container(
                    margin: EdgeInsets.only(top: _size!.height*0.05),
                    width: _size!.width*0.7,
                    height: _size!.height*0.1,
                  
                    child: Image.asset("assets/logos/logo1.png"),
               ),
                 SizedBox(height: _size!.height*0.03),
              Center(child: Text("LOGIN".tr,style: AppTextStyles.k20TextH.copyWith(color: AppColor.appThemeColorOlive))),
               SizedBox(height: _size!.height*0.03),

               Container(
                //height: 300,
                margin:const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                decoration: BoxDecoration(
                 //s border: Border.all(color: AppColor.appThemeColorOrange),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [

                  
                    getTextFieldTextType("Enter Email".tr, "Enter Email".tr,controller: loginController.emailController.value,textInputType: TextInputType.emailAddress ),
                    SizedBox(height: _size!.height*0.02),
                    getTextFieldTextType("Enter Password".tr, "Enter Password".tr,
                    suffix: InkWell(
                      onTap: (){
                        loginController.isShow.value = !loginController.isShow.value;
                      },
                      child: Icon(Icons.remove_red_eye),
                    ),
                    controller: loginController.passController.value,obscureText: loginController.isShow.value),
                    // SizedBox(height: _size!.height*0.01),
                   
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.end,
                    //   children: [
                    //     Text("Forgot Password".tr,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorGreen)),
                    //   ],
                    // ),
                    SizedBox(height: _size!.height*0.04),
                    InkWell(
                        onTap: ()async{
                            if(loginController.emailController.value.text.isNotEmpty && loginController.passController.value.text.isNotEmpty){
                               
                               loginController.loginApi(context);
                            }else{
                              showToastMsg("Please Enter Details".tr);
                            }
                        },
                         child: Container(
                          height: _size!.height*0.05,
                          decoration: BoxDecoration(
                            color: AppColor.appThemeColorOrange,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(child: Text("Log In".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),),
                         ),
                       ) ,
                    /*  SizedBox(height: _size!.height*0.03),
                      Center(child: Text("OR".tr,style: AppTextStyles.k12TextN,),),
                       SizedBox(height: _size!.height*0.03),

                    InkWell(
                        onTap: (){
                          //  Get.toNamed(RoutesName.dashboardView);
                        },
                         child: Container(
                          height: _size!.height*0.05,
                          decoration: BoxDecoration(
                            //color: AppColor.appThemeColorOlive,
                            border: Border.all(color: AppColor.appThemeColorOlive),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                               Image.asset("assets/images/google.png", height: 25,),
                              const SizedBox(width: 10,),
                              Text("Log In With Google".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.black,fontWeight: FontWeight.w600),),
                            ],
                          ),
                         ),
                       ) , 
                         SizedBox(height: _size!.height*0.03),*/

                   /* InkWell(
                        onTap: (){
                           // Get.toNamed(RoutesName.dashboardView);
                        },
                         child: Container(
                          height: _size!.height*0.05,
                          decoration: BoxDecoration(
                            //color: AppColor.appThemeColorOlive,
                            border: Border.all(color: AppColor.appThemeColorOlive),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                               Image.asset("assets/images/facebook.png", height: 25,),
                              const SizedBox(width: 10,),
                              Text("Log In With Facebook".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.black,fontWeight: FontWeight.w600),),
                            ],
                          ),
                         ),
                       ) , */
                  ],
                ),
               ),
             ],
          ),
          
          loginController.isLoading.value?CustomLoader():Container()
        ],
      ),
    ));
  }
}