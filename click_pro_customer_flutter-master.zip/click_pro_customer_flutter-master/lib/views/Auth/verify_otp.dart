import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/AuthController/verifyAccount_controller.dart';
import 'package:click_pro_customer/view_model/loader.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pin_put/pin_put.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../view_model/AuthController/gen_otp_controller.dart';

class VerifyOTP extends StatefulWidget {
  const VerifyOTP({super.key});

  @override
  State<VerifyOTP> createState() => _VerifyOTPState();
}

class _VerifyOTPState extends State<VerifyOTP> {
  final VerifyAccountController verifyAccountController = Get.put(VerifyAccountController());
  final GenerateOtpController generateOtpController = Get.put(GenerateOtpController());
  final LoaderController loaderController = Get.put(LoaderController());

   Size?_size;
  final _pinPutFocusNode = FocusNode();
  final _pinPutController = TextEditingController();

  String?email="";

  getData()async {
    email =await SharedMethods.getLocalStringData(key: SPKeys.USER_EMAIL);
  }

  @override
  void initState() {
    // TODO: implement initState
    Future.delayed(Duration(milliseconds: 100),()=> getData());
    super.initState();
  }

  @override
  Widget build(BuildContext context){
    _size = MediaQuery.of(context).size;
    return Obx((){
      return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          ListView(
            children: [
                 SizedBox(height: _size!.height*0.05),
                  Container(
                    margin: EdgeInsets.only(top: _size!.height*0.05),
                    width: _size!.width*0.7,
                    height: _size!.height*0.1,
                  
                    child: Image.asset("assets/logos/logo1.png"),
               ),
              SizedBox(height: _size!.height*0.05), 
                         // SizedBox(height: _size!.height*0.02),
              Center(child: Text("VERIFY".tr,style: AppTextStyles.k20TextH.copyWith(color: AppColor.appThemeColorOlive))),
               SizedBox(height: _size!.height*0.02),
               Padding(
                 padding: const EdgeInsets.symmetric(horizontal: 40),
                 child: Text("We have sent an Security Code on your register email".tr, textAlign: TextAlign.center, style: AppTextStyles.k14TextN),
               ),
               Text(email!, textAlign: TextAlign.center,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorGreen,fontWeight: FontWeight.w600,fontStyle: FontStyle.italic),),
              SizedBox(height: _size!.height*0.05), 
               Padding(padding: EdgeInsets.all(8),
                child: Container(
                  child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 8.0, horizontal: 30),
                      child: otpPinWidget()),
                ),),
               SizedBox(height: _size!.height*0.05), 
                InkWell(
                        onTap: ()async{
                          print("fine");
                          
                           if(verifyAccountController.otpController.value.text.isNotEmpty){
                            loaderController.setIsLoading(true);
                            await Future.delayed(Duration(seconds: 2));
                            loaderController.setIsLoading(false);
                            verifyAccountController.verifyApi();
                           }else{
                            showToastMsg("Please ENter OTP first".tr);
                           }
                           // navigateWithPageTransition(context, BottomNavBar(0),);
                        },
                         child: Container(
                          height: _size!.height*0.05,
                          margin:const EdgeInsets.symmetric(horizontal: 20),
                          decoration: BoxDecoration(
                            color: AppColor.appThemeColorOrange,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(child: Text("Verify Account".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),),
                         ),
              ),
                SizedBox(height: _size!.height*0.01), 
                Center(child: InkWell(
                  onTap: (){
                    generateOtpController.resendOTPApi();
                  },
                  child: Text("Resend Security Code",style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorGreen,fontWeight: FontWeight.w700),)))

            ],
          ),
          generateOtpController.isLoading.value? CustomLoader():Container()
        ],
      ),
    );
    });
  }

    Widget otpPinWidget() {

    final BoxDecoration pinPutDecoration = BoxDecoration(
      color:  Colors.white,
      boxShadow: [
        BoxShadow(
            color: AppColor.appThemeColorOlive,
            blurRadius: 2,spreadRadius: 2
        )
      ],
      borderRadius: BorderRadius.circular(12.0),
      border: Border.all(
        color: Colors.white,
      ),
    );

        final BoxDecoration selectedpinPutDecoration = BoxDecoration(
      color:  Colors.white,
      boxShadow: [
        BoxShadow(
            color: AppColor.appThemeColorOrange,
            blurRadius: 2,spreadRadius: 2
        )
      ],
      borderRadius: BorderRadius.circular(12.0),
      border: Border.all(
        color: Colors.white,
      ),
    );

    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: PinPut(
        fieldsCount: 4,
        withCursor: true,
        enabled: true,
        separator: SizedBox(width: 8,),
        textStyle: const TextStyle(fontSize: 25.0, color: AppColor.appThemeColorGreen,fontWeight: FontWeight.w700),
        eachFieldWidth: 45.0,
        eachFieldHeight: 50.0,eachFieldPadding: EdgeInsets.all(8),
        onSubmit: (String pin) async {
            if(pin.length==4){
              verifyAccountController.verifyApi();
            }
        },
        focusNode: _pinPutFocusNode,
        controller: verifyAccountController.otpController.value,onTap: (){},keyboardType: TextInputType.number,
        submittedFieldDecoration: selectedpinPutDecoration,
        selectedFieldDecoration: pinPutDecoration,
        followingFieldDecoration: pinPutDecoration,
        pinAnimationType: PinAnimationType.fade,

      ),
    );

  }

}

