
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/view_model/AuthController/register_controller.dart';
import 'package:click_pro_customer/view_model/loader.dart';
import 'package:click_pro_customer/views/BottomNavBar/bottomNavbar.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../utils/common.dart';
import '../../utils/text_styles.dart';

class UserRegister extends StatefulWidget {
  const UserRegister({super.key});

  @override
  State<UserRegister> createState() => _UserRegisterState();
}

class _UserRegisterState extends State<UserRegister> {
 final RegisterController registerController = Get.put(RegisterController());
 final LoaderController loaderController = Get.put(LoaderController());

 Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(() =>Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          ListView(
         children: [
          SizedBox(height: _size!.height*0.01),
            Container(
                margin: EdgeInsets.only(top: _size!.height*0.05),
                width: _size!.width*0.7,
                height: _size!.height*0.07,
              
                child: Image.asset("assets/logos/logo1.png"),
           ),
             SizedBox(height: _size!.height*0.02),
          Center(child: Text("REGISTER".tr,style: AppTextStyles.k20TextH.copyWith(color: AppColor.appThemeColorOlive))),
           SizedBox(height: _size!.height*0.02),

           Container(
            //height: 300,
            margin:const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
            padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
            decoration: BoxDecoration(
             //s border: Border.all(color: AppColor.appThemeColorOrange),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              children: [

                getTextFieldTextType("Enter Name".tr, "Enter Name".tr, controller: registerController.nameController.value),
                SizedBox(height: _size!.height*0.02),
                getTextFieldTextType("Enter Email".tr, "Enter Email".tr, controller: registerController.emailController.value,textInputType: TextInputType.emailAddress),
                SizedBox(height: _size!.height*0.02),
                 getTextFieldTextType("Enter Phone Number".tr, "Enter Phone NUmber".tr,
                  controller: registerController.phoneController.value,
                   textInputType: TextInputType.number,
                   textInputFormatter: [
                    LengthLimitingTextInputFormatter(10),
                    FilteringTextInputFormatter.digitsOnly
                   ]
                   ),
                  SizedBox(height: _size!.height*0.02),
                getTextFieldTextType("Enter Password".tr, "Enter Password".tr,
                suffix: InkWell(
                      onTap: (){
                        registerController.isObsecure.value = !registerController.isObsecure.value;
                      },
                      child: Icon(Icons.remove_red_eye),
                    ),
                 controller: registerController.passwordController.value,
                 obscureText: registerController.isObsecure.value
                 ),
                SizedBox(height: _size!.height*0.02),
                  getTextFieldTextType("Enter Password".tr, "Enter Password".tr,
                  suffix: InkWell(
                      onTap: (){
                        registerController.isObsecure.value = !registerController.isObsecure.value;
                      },
                      child: Icon(Icons.remove_red_eye),
                    ),
                   controller: registerController.confirmPassController.value,
                   obscureText: registerController.isObsecure.value
                   ),
                SizedBox(height: _size!.height*0.04),
                InkWell(
                    onTap: (){
                      print("fine");
                       
                       validateMethods();
                       // navigateWithPageTransition(context, BottomNavBar(0),);
                    },
                     child: Container(
                      height: _size!.height*0.05,
                      decoration: BoxDecoration(
                        color: AppColor.appThemeColorOrange,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Center(child: Text("Create Account".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),),
                     ),
                  ),
                /*  SizedBox(height: _size!.height*0.02),
                  Center(child: Text("OR".tr,style: AppTextStyles.k12TextN,),),
                   SizedBox(height: _size!.height*0.02),
                InkWell(
                    onTap: (){
                      //  navigateWithPageTransition(context, BottomNavBar(0),);
                    },
                     child: Container(
                      height: _size!.height*0.05,
                      decoration: BoxDecoration(
                        color: AppColor.appThemeColorOlive,
                        border: Border.all(color: AppColor.appThemeColorOlive),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,                   
                        children: [
                           Image.asset("assets/images/google.png", height: 25,),
                          const SizedBox(width: 10,),
                          Text("Sign Up With Google".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),
                        ],
                      ),
                     ),
                ) , 
                SizedBox(height: _size!.height*0.02),
                InkWell(
                    onTap: (){
                       // navigateWithPageTransition(context, BottomNavBar(0),);
                    },
                     child: Container(
                      height: _size!.height*0.05,
                      decoration: BoxDecoration(
                        color: AppColor.appThemeColorOlive,
                        border: Border.all(color: AppColor.appThemeColorOlive),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                           Image.asset("assets/images/facebook.png", height: 25,),
                          const SizedBox(width: 10,),
                          Text("Sign Up With Facebook".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),
                        ],
                    ),
                  ),
                ) ,*/
              ],
            ),
           ),
         ],
      ),

         loaderController.isLoading.value?CustomLoader():Container()
        ],
      )
      
   ));
  }
  validateMethods()async{
    if(registerController.nameController.value.text.isNotEmpty){
      if(registerController.emailController.value.text.isNotEmpty){
        if(registerController.phoneController.value.text.isNotEmpty && registerController.phoneController.value.text.length==10){
          if(registerController.passwordController.value.text.isNotEmpty && registerController.passwordController.value.text.length>7){
             if(registerController.confirmPassController.value.text.isNotEmpty ){
               if(registerController.confirmPassController.value.text == registerController.passwordController.value.text){
                     registerController.register();
               }
               else{
                showToastMsg("Both Password should be same".tr);
               }
             }else{
             }

          }else{
            showToastMsg("Please Enter Password and and enter a strong password(choose min 8 characters)".tr);
          }

        }else{
           showToastMsg("Please Enter Phone Number".tr);
        }

      }else{
         showToastMsg("Please Enter Email".tr);
      }
    }else{
      showToastMsg("Please Enter Name".tr);
    }
  }
}
  
 