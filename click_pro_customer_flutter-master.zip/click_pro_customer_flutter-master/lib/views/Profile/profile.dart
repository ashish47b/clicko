import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/ProfileController.dart/profile_controller.dart';
import 'package:click_pro_customer/views/Jobs/jobs.dart';
import 'package:click_pro_customer/views/Profile/edit_profile.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';
import 'package:click_pro_customer/widgets/custom_button.dart';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ProfileScreen extends StatefulWidget {
  final from;

  ProfileScreen({this.from});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  
  final ProfileController controller = Get.put(ProfileController());


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 300),()=> getData());
  }

  getData()async{
    await controller.getProfile();
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
     _size = MediaQuery.of(context).size;
    return Obx(()=> SafeArea(
      child: Stack(
        children: [
          Scaffold(
            body:controller.profileData==null?NoDataWidget(isloading: controller.isLoading.value,) : ListView(
              padding:const EdgeInsets.symmetric(horizontal: 10),
              children: [
            SizedBox(height: _size!.height*0.02),
             Padding(
               padding: const EdgeInsets.symmetric(horizontal: 16),
               child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                 widget.from!=null ? Container(): InkWell(
                    onTap: (){
                      Navigator.pop(context);
                    },
                    child: Icon(Icons.close)),
                ],
               ),
             ),
             SizedBox(height: _size!.height*0.05),
            
               ![null,""].contains(controller.profileData!.profilePic!) && ![null,""].contains(controller.profileData!.profilePicPath)?
                  Container(
                    height: _size!.height*0.15,
                    width: _size!.width*0.25,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColor.appThemeColorOlive,
                        border: Border.all(color: AppColor.appThemeColorOrange,width: 2),
                        image: DecorationImage(image: NetworkImage(controller.profileData!.profilePicPath! + controller.profileData!.profilePic!)) 
                      ),
                  ): Container(
                    height: _size!.height*0.15,
                    width: _size!.width*0.25,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColor.appThemeColorOlive,
                        border: Border.all(color: AppColor.appThemeColorOrange,width: 2),
                        image: DecorationImage(image: AssetImage("assets/images/avatar.png"))
                      ),
                  ),
             SizedBox(height: _size!.height*0.02),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
               children: [
                 Text(controller.profileData!.name!,style: AppTextStyles.k20TextN),
              
               ],
             ),
              SizedBox(height: _size!.height*0.01),
              
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(controller.profileData!.email!,style: AppTextStyles.k16TextN,)
              ],
             ),
              SizedBox(height: _size!.height*0.01),
              
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(controller.profileData!.phone!,style: AppTextStyles.k16TextN,)
              ],
             ),
               SizedBox(height: _size!.height*0.01),
               const Divider(color: AppColor.appThemeColorOlive),
               SizedBox(height: _size!.height*0.01),
               CustomContainerWithRowText(title: "Location".tr,value: controller.profileData!.cityName!),
               CustomContainerWithRowText(title: "Gender".tr,value: controller.profileData!.gender!.toUpperCase()),
               CustomContainerWithRowText(title: "Total Job Posted".tr,value: controller.profileData!.jobPosting!),
               CustomContainerWithRowText(title: "Professional Hires".tr,value: controller.profileData!.professionalHired!),
               
             
              
              ],
            ),
            bottomNavigationBar: InkWell(
              onTap: (){
                navigateWithPageTransition(context, EditProfile(profileData: controller.profileData));
              },
              child: Container(
                padding:const EdgeInsets.symmetric(horizontal: 12,vertical: 12),
                child: CustomButton(text: "EDIT".tr,)),
            ),
          ),
           controller.isLoading.value?CustomLoader(): Container(),
        ],
      ),
    )
    );
  }
  textWithIcon({String?img,String?title}){
    return Container(
      decoration: BoxDecoration(
       
      ),
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Image.asset(img!,height: 20,),
          SizedBox(width: 6),
          Text(title!,style: AppTextStyles.k16TextN)
        ],
      ),
    );
  }



}

class CustomContainerWithRowText extends StatelessWidget {
 String?title, value;
 CustomContainerWithRowText({this.title, this.value});

  @override
  Widget build(BuildContext context) {
    return    Container(
      margin:const EdgeInsets.symmetric(vertical: 10,horizontal: 10),
              padding:const EdgeInsets.symmetric(horizontal: 8,vertical: 5),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: AppColor.appThemeColorOlive.withOpacity(0.2),
                    blurRadius: 2,spreadRadius: 2
                  )
                ]
              ),
               child: Row(
                  children: [
                    Text(title! + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                    Text(value!, style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                  ],
                ),
             );
  }
}