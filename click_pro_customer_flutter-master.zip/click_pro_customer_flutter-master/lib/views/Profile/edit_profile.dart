
import 'dart:async';
import 'dart:io';

import 'package:click_pro_customer/model/CategoryDataModel/category_data.dart';
import 'package:click_pro_customer/model/CityModel/city_model.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/CityController/city_controller.dart';
import 'package:click_pro_customer/view_model/ProfileController.dart/profile_controller.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/custom_button.dart';
import 'package:click_pro_customer/widgets/show_dialog.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../../model/CustomerProfile/cust_profile_model.dart';

class EditProfile extends StatefulWidget {
  CustomerProfileData?profileData;
  String?from;
  EditProfile({this.profileData,this.from});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {

final CityController cityController = Get.put(CityController());
final ProfileController profileController = Get.put(ProfileController());

@override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 300),()=> getData());

  }
  
  getData()async {
    await cityController.getCity();
    Future.delayed(Duration(milliseconds: 200));
    getProfileData();
  }
  getProfileData()async {
        if(widget.profileData!=null) {
             nameController.text = widget.profileData!.name!; 
            emailController.text = widget.profileData!.email!;
            phoneController.text = widget.profileData!.phone!;
          addressController.text = widget.profileData!.address!;
          descrController.text = widget.profileData!.description!;
          print(widget.profileData!.profilePicPath! + widget.profileData!.profilePic!);
          //selectedImage = obj!.profilePicPath! + obj!.profilePic!;
          
          for(int i=0;i<genders.length;i++){
            if(widget.profileData!.gender!.compareTo(genders[i])==0){
                 selectGender = genders[i];
            }
          }
          if(cityController.citiesList!=null && cityController.citiesList!.length>0){
             if(widget.profileData!=null && ![null,""].contains(widget.profileData!.cityId)){
              cityController.citiesList!.forEach((element) {
                 if(element.id!.compareTo(widget.profileData!.cityId!)==0){
                   selectedCity = element;
                 }
              });
             }
          }
          // print("cityController.citiesList!.length" + cityController.citiesList!.length.toString());
          // for(int i=0;i<cityController.citiesList!.length;i++){
          //   print("CITY ID " + obj!.cityId!);
          //   if(obj!.cityId!.compareTo(cityController.citiesList![i].id!)==0){
          //     print("ENTER CITY");
          //        selectedCity = cityController.citiesList![i];
          //   }
          // }
        }

  }

  final nameController = TextEditingController(text: "");
  final emailController = TextEditingController(text: "");
  final phoneController = TextEditingController(text: "");
  final addressController = TextEditingController(text: "");
  final descrController = TextEditingController(text: "");
  
      Future<bool> _onBackButtonPressed() async {
    bool request = await showDialog(
        context: context,
        builder: ((context) {
          return ShowDialogsss().exitDialog(context);
        }));

    return request;
  }

  String?selectGender;
  CityData?selectedCity;
  Size?_size;
  String? selectedImage;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=> WillPopScope(
      onWillPop: _onBackButtonPressed,
      child: Scaffold(
        appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0.0,
            centerTitle: true,
            automaticallyImplyLeading: false,
            leading:widget.from!=null? null: IconButton(icon: Icon(Icons.arrow_back), onPressed: (){
              Get.back();
            }),
            title: Text("Edit Profile".tr,style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
            iconTheme: IconThemeData(color: Colors.black),
          ),
          body: Stack(
            children: [
            StatefulBuilder(builder: (context,myState){
              return ListView(
                padding:const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  SizedBox(height: _size!.height*0.005),
                  Wrap(
                    children: [
                      Center(
                        child: InkWell(
                          onTap: ()async{
                            //if([null,""].contains(selectedImage)){
                              String? str=  await pickedImage(context);
                              if(![null,""].contains(str)){
                                selectedImage = str;
                             }
                             myState(() {
                               
                             });
                            //}
                          },
                          child: Container(
                            height: 90,
                            width: 90,
                            decoration:const BoxDecoration(
                              color: Colors.grey,
                              shape: BoxShape.circle, 
                            ),
                            child:  ![null,""].contains(selectedImage) ? Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(image: FileImage(File(selectedImage!)), fit: BoxFit.fill)
                              ),
                              
                            ): (widget.profileData!=null && ![null,""].contains(widget.profileData!.profilePic!) && ![null,""].contains(widget.profileData!.profilePicPath)?
                            Container(
                              height: _size!.height*0.15,
                              width: _size!.width*0.25,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColor.appThemeColorOlive,
                                  border: Border.all(color: AppColor.appThemeColorOrange,width: 2),
                                  image: DecorationImage(image: NetworkImage(widget.profileData!.profilePicPath! + widget.profileData!.profilePic!)) 
                                ),
                            ) :Center(child: Icon(Icons.camera_alt),))
                                    
                          ),
                        ),
                      ),
                    ],
                  ),
                   SizedBox(height: _size!.height*0.01),
    
    
                  SizedBox(height: _size!.height*0.02),
                  getTextFieldTextType("Name".tr, "Name".tr,controller: nameController,radius: 10),
                  SizedBox(height: _size!.height*0.01),
                  getTextFieldTextType("Email".tr, "Email".tr,controller: emailController, 
                  radius: 10,textInputType: TextInputType.emailAddress),
                  SizedBox(height: _size!.height*0.01),
                  getTextFieldTextType("Phone Number".tr, "Phone Number".tr,
                  textInputType: TextInputType.number,
                  textInputFormatter: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(10)
                  ],
                  controller: phoneController,radius: 10),
                  SizedBox(height: _size!.height*0.01),
                  Container(
                      decoration: BoxDecoration(
                        //border: Border.all(color: AppColor.appThemeColor,width: 1),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.all(1),
                      child:  DropdownButtonFormField(
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: const BorderRadius.all(
                                const Radius.circular(10.0),
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                color: AppColor.appThemeColorOlive,
                                width: 1.0,
                              ),
                            ),
                            filled: true,
                            //hintStyle: TextStyle(color: ),
                            hintText:"Select Gender".tr,
                            hintStyle: new TextStyle(color: Colors.grey,fontSize: 14),
                            contentPadding: EdgeInsets.all(8.0),
                            fillColor: Colors.grey.shade50),
                        value: selectGender,
                        onTap: (){
                          FocusScope.of(context).requestFocus(new FocusNode());
                        },
                        onChanged: (value) async{
                          setState(() {
                            selectGender = value!;
                          });
                        },
                        items: genders
                            .map((val) => DropdownMenuItem<String>(
                            value: val,
                            child: Padding(
                              padding:  EdgeInsets.all(2.0),
                              child: Text(val,style: new TextStyle(fontSize: 16),),
                            )))
                            .toList(),
                      ),
                    ),
                 SizedBox(height: _size!.height*0.013),
                 getTextFieldTextType("Enter Address".tr, "Enter Address".tr,radius: 10,controller: addressController),
                 SizedBox(height: _size!.height*0.013),
                 Container(
                    padding: const EdgeInsets.all(1),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
                        borderRadius: BorderRadius.circular(16)
                    ),
                  
                    child:  DropdownSearch<CityData>(
                                  //asyncItems: (String filter) => getData(filter),
                  itemAsString: (CityData? u) => u!.cityName!,
                  items: cityController.citiesList!,
                  dropdownButtonProps: const DropdownButtonProps(
    
                  ),
                  dropdownDecoratorProps: const DropDownDecoratorProps(
                    dropdownSearchDecoration: InputDecoration(hintText: "Select City", border: InputBorder.none)
                  ),
                  popupProps: const PopupProps.dialog(
                  showSearchBox: true,
                //  showSelectedItems: true,
                    title: Text("Select City"),
                ),selectedItem:selectedCity ,
    
                    onChanged: (CityData? data) async {
                    setState(() {
                      selectedCity = data!;
                    });
                  },
                  onSaved: (data){
                    print("hi");
                  },
                ),
                  ),
                  SizedBox(height: _size!.height*0.01),
                  getTextFromFieldTextType("Description".tr, "Description".tr,maxLines: 4,radius: 10,controller: descrController),
                  
                ],
              );
             }),
              
              cityController.isLoading.value?CustomLoader():Container()
            ],
          ),
          bottomNavigationBar: InkWell(
            onTap: ()async{
              if(nameController.text.isNotEmpty && emailController.text.isNotEmpty && phoneController.text.isNotEmpty){
               await profileController.savePorfile(
                name: nameController.text.isNotEmpty?nameController.text:"",
                email: emailController.text.isNotEmpty?emailController.text:"",
                phone: phoneController.text.isNotEmpty?phoneController.text:"",
                address: addressController.text.isNotEmpty?addressController.text:"",
                desx: descrController.text.isNotEmpty?descrController.text:"",
                gender: selectGender!=null?selectGender:"",
                city_id: selectedCity!=null?selectedCity!.id:null,
                attachFile:![null,""].contains(selectedImage)? selectedImage:null,
                from: widget.from!=null? "start":""
               );
              }else{
                showToastMsg("Enter Details".tr);
              }
            },
            child: Container(
                  padding:const EdgeInsets.symmetric(horizontal: 12,vertical: 12),
                  child: CustomButton(text: "EDIT".tr,)),
          ),
            
      ),
    ));
  }
}