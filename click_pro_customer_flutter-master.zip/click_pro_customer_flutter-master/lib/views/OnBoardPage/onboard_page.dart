
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/loader.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class OnBoardPage extends StatefulWidget {
  const OnBoardPage({super.key});

  @override
  State<OnBoardPage> createState() => _OnBoardPageState();
}

class _OnBoardPageState extends State<OnBoardPage> {
   List<dynamic> slides= [
    {
      "image":"assets/images/onboard1.png",
      "title":"POST A JOB",
      "desc":"This is the platform where you can post a job for services like Electrician, Gardner, Plumber."
    },
     {
      "image":"assets/images/onboard1.png",
      "title":"GET PROFESSIONAL",
      "desc":"This is the platform where you can post a job for services like Electrician, Gardner, Plumber."
    },
     {
      "image":"assets/images/onboard.png",
      "title":"ALL SERVICES",
      "desc":"This is the platform where you can post a job for services like Electrician, Gardner, Plumber."
    },
  ];
  
  int currentIndex= 0;
  PageController _pageController = PageController();

  @override
  void initState() {
    // TODO: implement initState
    _pageController = PageController(initialPage: 0);
    //super.initState();
  }

  final LoaderController controller = Get.put(LoaderController());
   

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=>SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            Column(
                children: [
                 
                  Container(
                    margin: EdgeInsets.only(top: _size!.height*0.05),
                    width: _size!.width*0.7,
                    height:_size!.height*0.1,
                  
                    child: Image.asset("assets/logos/logo1.png"),
                  ),
               Expanded(
                 child: PageView.builder(
                 scrollDirection: Axis.horizontal,
                 controller: _pageController,
                 itemCount: slides.length,
                 onPageChanged: (value){
                      currentIndex = value;
                     },
                 itemBuilder: (context,index){
                 return Slider(
                    image: slides[index]['image'],
                    title: slides[index]['title'],
                    description: slides[index]['desc'],
                 );
                        }),
               )
                
                ],
            ),
            controller.isLoading.value?CustomLoader():Container()
          ],
        ),
        bottomNavigationBar:  Wrap(
                    children: [
                      Center(
                        child: InkWell(
                          onTap: ()async{
                            controller.setIsLoading(true);
                            await Future.delayed(Duration(seconds: 2));
                            controller.setIsLoading(false);
                            Get.toNamed(RoutesName.loginView);
                          },
                          child: Container(
                            height: _size!.height*0.05,
                            width: _size!.width*0.9,
                            margin: EdgeInsets.symmetric(vertical: _size!.height*0.04),
                            decoration: BoxDecoration(
                              color: AppColor.appThemeColorOrange,
                              borderRadius: BorderRadius.circular(20)
                            ),
                            child: Center(child: Text("Log In".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: ()async{
                        controller.setIsLoading(true);
                        await Future.delayed(Duration(seconds: 2));
                        controller.setIsLoading(false);
                        Get.toNamed(RoutesName.signUpView);
                        },
                        child: Center(child: Text("Don't have an Account? Sign Up".tr,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),))),
                        SizedBox(height: _size!.height*0.06,)                   
                       ],
                  ),
      ),
    ));
  }
}



class Slider extends StatelessWidget {
  String?image,title,description;

  Slider({this.description,this.image,this.title});

  @override
  Widget build(BuildContext context) {
    Size _size = MediaQuery.of(context).size;
    return Container(
      child: Column(

        children: [
          Container(
            padding: EdgeInsets.all(10),
           
            child: Image.asset(image!,fit: BoxFit.fill,height: _size.height*0.4,width: _size.width*0.8,),
            ),
       
          Text(title!.tr, style: AppTextStyles.k20TextH),
          //SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(description!.tr,style: AppTextStyles.k14TextN,textAlign:TextAlign.center,),
          ),
         
        ],
      ),
    );
  }
}