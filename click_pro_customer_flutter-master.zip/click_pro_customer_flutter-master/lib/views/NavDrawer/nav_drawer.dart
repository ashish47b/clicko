
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/view_model/loader.dart';

import 'package:click_pro_customer/views/AppointmentPage/appointment_page.dart';
import 'package:click_pro_customer/views/Invoices/invoices.dart';
import 'package:click_pro_customer/views/Sponsership/add-sponsership.dart';
import 'package:click_pro_customer/views/Sponsership/sponsorship.dart';
import 'package:click_pro_customer/views/Subscribe/subscribe_page.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/languageBox.dart';


import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../view_model/AuthController/gen_otp_controller.dart';

class NavDrawer extends StatefulWidget {
 String?userName,userEmail;
 NavDrawer({this.userEmail,this.userName});

  @override
  State<NavDrawer> createState() => _NavDrawerState();
}

class _NavDrawerState extends State<NavDrawer> {

 final LoaderController loaderController = Get.put(LoaderController());
 final GenerateOtpController logOutController = Get.put(GenerateOtpController());





  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
   // print("User Name : " + userMobile!);

    return  Obx(() =>Stack(
      children: [

        Container(
          width: _size!.width * 0.7,
          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
          decoration: BoxDecoration(
              color: AppColor.appThemeColorOlive,
              borderRadius: BorderRadius.only(topRight: Radius.circular(50), bottomRight: Radius.circular(50)),
              gradient: LinearGradient(colors: [AppColor.appThemeColorOlive, AppColor.appThemeColorOlive ], begin: Alignment.topCenter, end: Alignment.bottomCenter)
            ),
          child: ListView(
            children: [
             SizedBox(height: _size!.height * 0.02,),
              Container(
               child: Row(
                children: [
                  Container(
                    child: CircleAvatar(
                      backgroundColor: AppColor.appThemeColorOrange,
                      maxRadius: 32,
                      child: CircleAvatar(
                       backgroundColor: Colors.white,
                       maxRadius: 30,
                        child:  Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset("assets/images/avatar.png",
                            ),
                        ),
                     ),
                   ),
                 ),
                 SizedBox(width: 20,),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.userName!=null?widget.userName!:"",style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600,color: Colors.white),),
                      SizedBox(height: 3,),
                      Text(widget.userEmail!=null?widget.userEmail!:"",style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400,color: Colors.white),)
                    ],
                  )

               ],
              ),
             ),
              SizedBox(height: _size!.height*0.02),
              Divider(color:Colors.white,),
              
              SizedBox(height: _size!.height*0.02),
              ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/posting.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      Get.toNamed(RoutesName.postJobsView);
                    },
                  title: Text("Post A Job".tr,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
            Divider(color:Colors.white60,),
            ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/invoice.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      Get.toNamed(RoutesName.invoiceListView);
                    },
                  title: Text("Invoices".tr,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
            Divider(color:Colors.white60,),
                ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/time.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      Get.toNamed(RoutesName.appointmentPage);
                    },
                  title: Text("Appointment".tr,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
        
              Divider(color:Colors.white60,),
              ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/chat.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      Get.toNamed(RoutesName.chat_users_view);
                    },
                  title: Text("Chat".tr,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
             Divider(color:Colors.white60,),
              /*  ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/gallery.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      Get.toNamed(RoutesName.sponsorshipListView);
                    },
                  title: Text("Sponsorship".tr,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
             Divider(color:Colors.white60,),*/
                ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/translation.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      showDialog(context: context, builder:(context){
                        return LanguageDialogBox();
                      });
                     // navigateWithTransition(context,SubscriberPage() );
                    },
                  title: Text("Language".tr,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
             Divider(color:Colors.white60,),
                ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/logout.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: ()async{
                      logOutController.logOutApi();
                      // loaderController.setIsLoading(true);
                      // await Future.delayed(Duration(seconds: 2));
                      // loaderController.setIsLoading(false);
                     
                      
                    },
                  title: Text("Log Out".tr,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
             Divider(color:Colors.white60,),
      

            ],
          ),
        ),
      
       loaderController.isLoading.value?CustomLoader():Container(),
      ],
    ));
  }
}