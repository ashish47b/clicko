
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/InvoiceController/invoice_controller.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/RowWithText.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class InvoiceDetails extends StatefulWidget {
 String?invocie_id;
 InvoiceDetails({this.invocie_id});

  @override
  State<InvoiceDetails> createState() => _InvoiceDetailsState();
}

class _InvoiceDetailsState extends State<InvoiceDetails> {

  final InvoiceController controller = Get.put(InvoiceController());

  getData()async {
    controller.getInvoiceDetails(invc_id :widget.invocie_id);
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=> Stack(
        children: [
          Scaffold(
            appBar: AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0.0,
                centerTitle: true,
                title: Text("Invoice Details".tr,style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
                iconTheme:const IconThemeData(color: Colors.black),
              ),
              body: ListView(
            padding:const EdgeInsets.symmetric(horizontal: 14),
            children: [         
              SizedBox(height: _size!.height*0.05),
              //RowWtihText(title: "Payment ID",value:model.viewInvoiceData!=null && model.viewInvoiceData!.paymentId!=null ? model.viewInvoiceData!.paymentId!:""),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Payment ID".tr + (" : " ),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                  Expanded(child: Text(controller.viewInvoiceData!=null && controller.viewInvoiceData!.paymentId!=null ? controller.viewInvoiceData!.paymentId!:"", style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),))
                ],
              ),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Status".tr,value:controller.viewInvoiceData!=null && controller.viewInvoiceData!.paymentStatus!=null?controller.viewInvoiceData!.paymentStatus! :""),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Payment Date".tr,value:controller.viewInvoiceData!=null && controller.viewInvoiceData!.customerPaymentDate!=null?controller.viewInvoiceData!.customerPaymentDate! :""),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Total Amount".tr,value:controller.viewInvoiceData!=null && controller.viewInvoiceData!.amount!=null?("€ "+ controller.viewInvoiceData!.amount!) :""),
             // SizedBox(height: _size!.height*0.01),
             // RowWtihText(title: "Professional Amount".tr,value:controller.viewInvoiceData!=null && controller.viewInvoiceData!.professionalPaidAmount!=null?("€ "+ controller.viewInvoiceData!.professionalPaidAmount!) :""),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Commission Amount".tr,value:controller.viewInvoiceData!=null && controller.viewInvoiceData!.adminCommission!=null?("€ "+ controller.viewInvoiceData!.adminCommission!) :""),
              SizedBox(height: _size!.height*0.02),
              const Divider(color: AppColor.appThemeColorOlive),
              Text("Job Details".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Title".tr,value:controller.viewInvoiceJobData!=null && controller.viewInvoiceJobData!.jobTitle!=null?controller.viewInvoiceJobData!.jobTitle! :""),
              SizedBox(height: _size!.height*0.01),
              Text(controller.viewInvoiceJobData!=null && controller.viewInvoiceJobData!.description!=null?controller.viewInvoiceJobData!.description!:"",style: AppTextStyles.k14TextN,),
              SizedBox(height: _size!.height*0.02),
              const Divider(color: AppColor.appThemeColorOlive),
              Text("Professional Details".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title:"Name".tr,value:controller.viewInvoiceProData!=null && controller.viewInvoiceProData!.firstName!=null?(controller.viewInvoiceProData!.firstName!+" " + controller.viewInvoiceProData!.lastName!):""),
              SizedBox(height: _size!.height*0.02),
              const Divider(color: AppColor.appThemeColorOlive),
              Text("Customer Details".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title:"Name".tr,value:controller.viewInvoiceCusData!=null && controller.viewInvoiceCusData!.name!=null?controller.viewInvoiceCusData!.name!:""),
              SizedBox(height: _size!.height*0.01),
               RowWtihText(title:"Customer ID".tr,value:controller.viewInvoiceCusData!=null && controller.viewInvoiceCusData!.userId!=null?("COC-" + controller.viewInvoiceCusData!.userId!):""),
           
            ],
           ),
          /* bottomNavigationBar: Container(
            height: 45,
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColor.appThemeColorOlive,
              borderRadius: BorderRadius.circular(10)
            ),
            child: Center(
              child: Text("PRINT",style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)),
            ),
           ),*/

    ),
         controller.isLoading.value?const CustomLoader():Container()
        ],
      ));
  }
}