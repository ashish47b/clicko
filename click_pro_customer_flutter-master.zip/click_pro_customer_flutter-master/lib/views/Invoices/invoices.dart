import 'package:click_pro_customer/model/InvoiceModel/invoice_model.dart';
import 'package:click_pro_customer/res/formats/date_formats.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/InvoiceController/invoice_controller.dart';
import 'package:click_pro_customer/views/Invoices/invoice_details.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';


import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Invoices extends StatefulWidget {
 String?from;
 Invoices({this.from});

  @override
  State<Invoices> createState() => _InvoicesState();
}

class _InvoicesState extends State<Invoices> {

   final InvoiceController controller = Get.put(InvoiceController());
    var scController=ScrollController();

   @override
  void initState() {
    // TODO: implement initState
    super.initState();
     scController.addListener(listener);
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }

  getData()async {
    controller.getInvoices(date: currentTime!=null?currentTime.toString().substring(0,10):"", limit: skipValue);
  }

  int skipValue=1;
  listener(){
    if(scController.position.pixels == scController.position.maxScrollExtent){
      skipValue=skipValue+1;
      getData();
      print("called");
    }else{
      print("sorry");
    }
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=> SafeArea(

      child: Scaffold(
        appBar:widget.from!=null?null:  AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          centerTitle: true,
          title: Text("INVOICES".tr,style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
          iconTheme:const IconThemeData(color: Colors.black),
        ),
        body:  Stack(
          children: [
            ListView(children: [
              SizedBox(height: _size!.height*0.013,),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 6),
                  margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    //border: Border.all(color:AppColor.appThemeColorOlive),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: AppColor.appThemeColorOrange.withOpacity(0.2),
                        blurRadius: 3,spreadRadius: 3
                    )
                  ]
                ),
                child: Row(
                  children: [
                    Text("Total Transaction".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                    Text(controller.invoiceDataListModel!=null&& controller.invoiceDataListModel!.totalTransactions!=null? controller.invoiceDataListModel!.totalTransactions!:"",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 6),
                  margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    //border: Border.all(color:AppColor.appThemeColorOlive),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: AppColor.appThemeColorOrange.withOpacity(0.2),
                        blurRadius: 3,spreadRadius: 3
                    )
                  ]
                ),
                child: Row(
                  children: [
                    Text("Total Amount".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                    Text("€ " + (controller.invoiceDataListModel!=null&& controller.invoiceDataListModel!.totalTransAmount!=null? controller.invoiceDataListModel!.totalTransAmount!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                  ],
                ),
              ),
             controller.invoiceList!=null && controller.invoiceList.length>0? ListView.builder(
                itemCount: controller.invoiceList.length,
                shrinkWrap: true,
                physics:const NeverScrollableScrollPhysics(),
                itemBuilder: (context,index){
                  InvoiceDataList obj = controller.invoiceList[index];
                return InkWell(
                  onTap: (){
                      navigateWithPageTransition(context, InvoiceDetails(invocie_id: obj.id));             
                    },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 6),
                        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color:AppColor.appThemeColorOlive),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: AppColor.appThemeColorOlive.withOpacity(0.2),
                              blurRadius: 3,spreadRadius: 3
                            )
                          ]
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Customer Name".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Expanded(child: Text((obj.cus_name!=null? obj.cus_name!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange))),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            
                            Row(
                              children: [
                                Text("Professional Name".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Expanded(child: Text((obj.pro_name!=null? obj.pro_name!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange))),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            
                            Row(
                              children: [
                                Text("Category".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Expanded(child: Text((obj.category_name!=null? obj.category_name!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange))),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            
                            Row(
                              children: [
                                Text("Location".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Expanded(child: Text((obj.location!=null? obj.location!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange))),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            Row(
                              children: [
                                Text("Amount".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Text(" € "+  (obj.amount!=null? obj.amount!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            Row(
                              children: [
                                Text("Service Fee".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Text(" € "+ (obj.admin_commission!=null? obj.admin_commission!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            Row(
                              children: [
                                Text("Total Amount".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Text(" € "+ (obj.amount!=null && obj.admin_commission!=null? (double.parse(obj.amount!) + double.parse(obj.admin_commission!)).toString() :""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            
                           /* Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(child: Text("Created Date : " + obj.professionalPaidDate!.toString().substring(0,10),style: AppTextStyles.k14TextN)),
                                Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.black12)
                                  ),
                                 //child: Icon(Icons.picture_as_pdf, color: Colors.red,size: 20,),
                                ),
                              const SizedBox(width: 10),
                            
                              ],
                            ),*/
                    
                          ],
                        ),
                      ),
                    );
              }) : NoDataWidget(isloading: controller.isLoading.value,)
            ],),
            controller.isLoading.value?const CustomLoader():Container()
          ],
        ),
      ),
    ));
  }




    bool?dateSet = false;
  DateTime? currentTime;
  selectDate() async{
    DateTime? date = DateTime.now();
    var newDate = new DateTime(date.year, date.month - 11, date.day);
    DateTime? newDateFrom=await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: newDate,
        lastDate: DateTime(2100));
    if (newDateFrom !=null) {
      setState(() {
        
      });
      currentTime = newDateFrom;
      dateSet = true;
      getData();
    }
   }
}