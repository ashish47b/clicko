import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/widgets/fade_img_with_error.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';

class ManageProfessionals extends StatefulWidget {
  const ManageProfessionals({super.key});

  @override
  State<ManageProfessionals> createState() => _ManageProfessionalsState();
}

class _ManageProfessionalsState extends State<ManageProfessionals> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 10),
        children: [
          
          ListView.builder(
            itemCount: 3,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: (context,index){
            return Container(
              margin:const EdgeInsets.symmetric(vertical: 8),
              padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 8),
              decoration: BoxDecoration(
                border: Border.all(color:AppColor.appThemeColorGreen),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 80,width: 80,
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColor.appThemeColorGreen),
                      shape: BoxShape.circle,
                      image: DecorationImage(image: AssetImage("assets/images/avatar.png"),fit: BoxFit.fill)
                    ),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Image.asset("assets/images/medal.png",height: 30),
                          const SizedBox(width: 4),
                          Text("Professional Name" + " ",style: AppTextStyles.k16TextN),
                        ],
                      ),
                      const SizedBox(height: 7),
                      Row(
                        children: [
                          const Icon(Icons.location_on,color: AppColor.appRedColor,),
                          const SizedBox(width: 4),
                          Text("Location",style: AppTextStyles.k14TextN),
                        ],
                      ),
                      const SizedBox(height: 7),
                      Row(
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 5,vertical: 2),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(3),
                              color: AppColor.appThemeColorOrange
                            ),
                            child: Text("5",style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                          ),
                            RatingBar.builder(
                                initialRating: 4.5,
                                minRating: 1,
                                direction: Axis.horizontal,
                                allowHalfRating: true,
                                itemCount: 5,
                                  itemSize: 18,
                                itemBuilder: (context, _) => Icon(
                                      Icons.star,
                                      color: AppColor.appThemeColorOrange,
                                    
                                      
                                ),
                                onRatingUpdate: (rating) {
                                    print(rating);
                                },
                          ),
                        ],
                      ),

                      const SizedBox(height: 7),
              
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Text("Total Work Done".tr + " : ".tr,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive)),
                              Text("2",style: AppTextStyles.k14TextN,)
                            ],
                          ),
                          const SizedBox(width: 15),
                          // Row(
                          //   children: [
                          //     Text("You Hired".tr  + " : ".tr,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive)),
                          //     Text("0",style: AppTextStyles.k14TextN,)
                          //   ],
                          // )
                        ],
                      ),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColor.appThemeColorOlive
                        ),
                        onPressed: (){},
                        child: Text("View Profile",style: AppTextStyles.k16TextN,)
                      )
                    ],
                  )
                ],
              )
            );
          })

        ],
      ),
    );
  }
}