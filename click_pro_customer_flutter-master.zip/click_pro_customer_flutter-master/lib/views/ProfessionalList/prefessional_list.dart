import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/views/ProfessionalList/professional_details.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ProfessionalList extends StatefulWidget {
  const ProfessionalList({super.key});

  @override
  State<ProfessionalList> createState() => _ProfessionalListState();
}

class _ProfessionalListState extends State<ProfessionalList> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        body: ScrollConfiguration(
          behavior: ScrollConfiguration.of(context).copyWith(
                dragDevices: {
                  PointerDeviceKind.touch,
                  PointerDeviceKind.mouse,
                },
              ),
          child: ListView(
            children: [
            
              Divider(color: Colors.grey),
             SizedBox(height: _size!.height*0.01),
             Container(
              margin:const EdgeInsets.symmetric(horizontal: 12),
              padding: EdgeInsets.symmetric(horizontal: 7, vertical: 6),
              decoration: BoxDecoration(
                border: Border.all(color: AppColor.appThemeColorOlive),
                borderRadius: BorderRadius.circular(12),
        
              ),
              child: Row(
                children: [
                  Icon(Icons.search, color: AppColor.appThemeColorOlive,), 
                  Text("Search Professionals", style: AppTextStyles.k14TextN,)
                ],
              ),
             ),
             SizedBox(height: _size!.height*0.01),
             ListView.builder(
              itemCount: categoriesImage.length,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemBuilder: (context,index){
              return professionalList(
                image: categoriesImage[index]['image'],
                title: categoriesImage[index]['title'],
              );
             })
            ],
          ),
        ),
      ),
    );
  }
  professionalList({String?image,String?title}){
    return InkWell(
      onTap: (){
         Get.toNamed(RoutesName.professionalView);
      },
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 10, horizontal: 14),
                 // height: _size!.height*0.1,
                  decoration: BoxDecoration(
                    //color: AppColor.appThemeColorOlive,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.black)
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(10),
                         width: 80,
                        decoration: BoxDecoration(
                          // /color: Colors.red,
                          borderRadius: BorderRadius.circular(12)
                        ),
                        child: Image.asset(image!),
                      ),
                     const SizedBox(width: 10),
                     Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title!,style: AppTextStyles.k18TextN),
                         const SizedBox(height: 2),
                        Text("James Bond",style: AppTextStyles.k14TextN),
                       const SizedBox(height: 3),
                        Row(
                          children: [
                            Text("${"12/hr"} ",style: AppTextStyles.k16TextH),
                            SizedBox(width: _size!.width*0.3),
                               Row(
                           children: [
                                    Icon(Icons.star,color: Colors.yellow[700],size: 20,),
                                    Icon(Icons.star,color: Colors.yellow[700],size: 20),
                                    Icon(Icons.star,color: Colors.yellow[700],size: 20),
                                    Icon(Icons.star_half_outlined,color: Colors.yellow[700],size: 20),
                                  ],
                                ),
                          ],
                        ),
                         const SizedBox(height: 3),
                     
    
                      ],
                     )
                    ],
                  ),
                ),
    );
  }
}