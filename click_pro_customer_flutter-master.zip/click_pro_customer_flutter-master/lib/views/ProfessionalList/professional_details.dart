import 'package:click_pro_customer/model/ProfessionalModel/prof_profile_model.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/BiddersController/bidders_controller.dart';
import 'package:click_pro_customer/view_model/CategoryController/category_controller.dart';
import 'package:click_pro_customer/view_model/CityController/city_controller.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';
import 'package:click_pro_customer/widgets/RowWithText.dart';
import 'package:click_pro_customer/widgets/fade_img_with_error.dart';
import 'package:click_pro_customer/widgets/image_preview.dart';
import 'package:flutter/gestures.dart';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import 'package:get/get.dart';

class ProfessionalProfilePage extends StatefulWidget {
  const ProfessionalProfilePage({super.key});

  @override
  State<ProfessionalProfilePage> createState() => _ProfessionalProfilePageState();
}

class _ProfessionalProfilePageState extends State<ProfessionalProfilePage> {
   

  final BidderController controller = Get.put(BidderController());
  final CityController cityController = Get.put(CityController());
  final CategoryController categoryController = Get.put(CategoryController());

  getData()async{
    await controller.getProfDetails(prof_id: Get.arguments[0]);
    await controller.getProfratings(prof_id: Get.arguments[0]);
    await categoryController.getCategoryApi();
    await cityController.getCity();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 100),()=> getData());
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx((){
      return SafeArea(
      child: Scaffold(
        appBar: AppBar(
               backgroundColor: Colors.transparent,
               elevation: 0.0,
               title: Text("PROFILE",style: AppTextStyles.k18TextH.copyWith(color: Colors.black)),
               centerTitle: true,
               iconTheme: IconThemeData(color: Colors.black),
            ),
        body:Stack(
          children: [
            controller.obj==null?
        NoDataWidget(isloading: controller.isLoading.value,)
        : ListView(
          children: [
           
            Container(
              color: Colors.grey[200],
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              child: Column(
                //crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ![null,""].contains(controller.obj!.profilePic) && ![null,""].contains(controller.obj!.profilePicPath)?
                  InkWell(
                    onTap: (){
                      print(controller.obj!.profilePicPath! + controller.obj!.profilePic!);
                      //navigateWithPageTransition(context, ImagePreviewScreen(path: controller.obj!.profilePicPath! + controller.obj!.profilePic!));
                      Get.toNamed(RoutesName.image_previewView, arguments: [controller.obj!.profilePicPath! + controller.obj!.profilePic!],);
                    },
                    child: Container(
                      height: _size!.height*0.15,
                      width: _size!.width*0.25,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColor.appThemeColorOlive,
                          border: Border.all(color: AppColor.appThemeColorOrange,width: 2),
                          image: DecorationImage(image: NetworkImage(controller.obj!.profilePicPath! + controller.obj!.profilePic!),fit: BoxFit.fill) 
                        ),
                    ),
                  ):Container(
                    height: _size!.height*0.15,
                    width: _size!.width*0.25,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColor.appThemeColorOlive,
                        border: Border.all(color: AppColor.appThemeColorOrange,width: 2),
                        image:const DecorationImage(image: AssetImage("assets/images/avatar.png"))
                      ),
                  ),
                  Center(child: Text(controller.obj!.name!.toUpperCase(),textAlign: TextAlign.center, style: AppTextStyles.k20TextH.copyWith(color: AppColor.appThemeColorOlive))),
                 /* Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.phone,color:AppColor.appThemeColorGreen,size: 20),
                      const SizedBox(width: 7),
                      Text(controller.profileData!.phone!.toUpperCase(),style: AppTextStyles.k20TextH.copyWith(color: AppColor.appThemeColorOlive)),
                    ],
                  ),*/
                  SizedBox(height: _size!.height*0.005),
                  if(![null,""].contains(controller.obj!.cityName!))
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.location_city,color: AppColor.appThemeColorOrange,size: 25),
                      SizedBox(width: _size!.width*0.02),
                      Text(controller.obj!.cityName!,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive)),
                    ],
                  ),
                  SizedBox(height: _size!.height*0.01),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: AppColor.appThemeColorOrange,
                          borderRadius: BorderRadius.circular(6),
                  
                        ),
                       child: Text(controller.ratingBar!,style: AppTextStyles.k14TextN.copyWith(color: Colors.white),),
                      ),
                      const SizedBox(width: 5),
                     RatingBar.builder(
                          initialRating: controller.ratingBar!=null?double.parse(controller.ratingBar!):1,
                          minRating: 1,
                          direction: Axis.horizontal,
                          allowHalfRating: true,
                          itemCount: 5,
                           itemSize: 18,
                         itemBuilder: (context, _) =>const Icon(
                               Icons.star,
                               color: AppColor.appThemeColorOrange,       
                         ),
                         onRatingUpdate: (rating) {
                             print(rating);
                          },
                      )
                    ],
                  ),
                  SizedBox(height: _size!.height*0.01),
                  if(![null,""].contains(controller.obj!.jobDone!))
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Total Job Done".tr + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                      Text(controller.obj!.jobDone!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),)
                    ],
                  ),
                ],
              ),
            ),
           /* SizedBox(height: _size!.height*0.02),
             controller.obj!=null && controller.obj!.categoryDetailsList!=null && controller.obj!.categoryDetailsList!.length>0?
             Container(
              padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              margin:const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: AppColor.appThemeColorOlive.withOpacity(0.2),
                    blurRadius: 2,spreadRadius: 2
                  )
                ]
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Category".tr,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive,fontWeight: FontWeight.w600)),
                  for(int i=0;i<controller.obj!.categoryDetailsList!.length;i++)
                  Text(controller.obj!.categoryDetailsList![i].categoryId!,style: AppTextStyles.k16TextN,)
                ],
              ),
             ):Container(),*/
            
             //
             SizedBox(height: _size!.height*0.02),
             controller.obj!=null && (![null,""].contains(controller.obj!.companyName) || ![null,""].contains(controller.obj!.companyLogo))?
             Container(
              padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              margin:const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: AppColor.appThemeColorOlive.withOpacity(0.2),
                    blurRadius: 2,spreadRadius: 2
                  )
                ]
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text("Company Name".tr + " : ",style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive,fontWeight: FontWeight.w600)),
                      Expanded(child: Text(controller.obj!.companyName!=null ? controller.obj!.companyName!:"",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange,fontWeight: FontWeight.bold))),
                    ],
                  ),
                  SizedBox(height: _size!.height*0.01),
                  Row(
                    children: [
                      Text("Company Logo",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive,fontWeight: FontWeight.w600)),
                      const SizedBox(width: 20),
                      InkWell(
                        onTap:(){
                          navigateWithPageTransition(context, ImagePreviewScreen(path: controller.obj!.companyLogoPath! + controller.obj!.companyLogo!));
                        },
                        child: Container(
                          height: 70,width: 100,
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColor.appThemeColorOlive.withOpacity(0.1)),
                            borderRadius: BorderRadius.circular(10),
                            image: DecorationImage(image: NetworkImage(controller.obj!.companyLogoPath! + controller.obj!.companyLogo!),fit: BoxFit.fill)
                          ),
                        ),
                      )
                    ],
                  )
                ],
              ),
             ):Container(),
            //  about 

            controller.obj!=null && controller.obj!.diplomaDataList!=null && controller.obj!.diplomaDataList.length>0?
             Container(
              margin:const EdgeInsets.symmetric(horizontal: 12,vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow:[
                  BoxShadow(
                    color: AppColor.appThemeColorOlive.withOpacity(0.2),
                    blurRadius: 2,spreadRadius: 2,
                  ),
                ],
              ),
              padding: const EdgeInsets.symmetric(horizontal: 7,vertical: 7),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Diploma & Qualifications",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive,fontWeight: FontWeight.bold)),
                  SizedBox(height: _size!.height*0.01),
                  ListView.builder(
                    itemCount: controller.obj!.diplomaDataList.length,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (context,index){
                      DiplomaData obj = controller.obj!.diplomaDataList[index];
                    return Container(
                      padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 8),
                      margin:const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: AppColor.appThemeColorOlive.withOpacity(0.1),blurRadius: 1,spreadRadius: 1
                          )
                        ]
                      ),
                       child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                         Row(
                            children: [
                              Text("Certificate Name" + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text(obj.nameOfCertificat!=null?obj.nameOfCertificat!:'',style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600))),
                            ],
                          ),
                          SizedBox(height: _size!.height*0.01),
                          Row(
                            children: [
                              Text("University Name" + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text(obj.nameOfUniver!=null?obj.nameOfUniver!:'',style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600))),
                            ],
                          ),
                          SizedBox(height: _size!.height*0.01),
                          Row(
                            children: [
                              Text("Passing Year" + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text(obj.passingYear!=null?obj.passingYear!:'',style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600))),
                            ],
                          ),
                          SizedBox(height: _size!.height*0.01),
                          Row(
                            children: [
                              Text("Attachment" + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text("link",style: AppTextStyles.k14TextN.copyWith(color: Colors.blue,fontWeight: FontWeight.w600))),
                            ],
                          ),
                        ],
                       ),
                    );
                  }),
                ],
              ),
             ):Container(),
        
            SizedBox(height: _size!.height*0.02),
            if(![null,""].contains(controller.obj!.sirenOrSiretNo))
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: RowWtihText(title: "SIRET or SIREN NO".tr,value: controller.obj!.sirenOrSiretNo!,),
            ),

            SizedBox(height: _size!.height*0.01),
            if(![null,""].contains(controller.obj!.sirenOrSiretNo))
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: RowWtihText(title: "RCS NO".tr,value: controller.obj!.rcsNo!,),
            ),

            SizedBox(height: _size!.height*0.01),
            if(![null,""].contains(controller.obj!.sirenOrSiretNo))
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: RowWtihText(title: "TVA(%)".tr,value: controller.obj!.vat!,),
            ),


            if(![null,""," "].contains(controller.obj!.description!))
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: _size!.height*0.02),
              Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("About".tr,style: AppTextStyles.k18TextH),
              
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Text(controller.obj!.description!,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),),
            ),
              ],
            ),
        
            //
            SizedBox(height: _size!.height*0.03),
        
            // jobs categories
            if(controller.obj!.category!=null && controller.obj!.category!.length>0)
             Container(
                height: _size!.height*0.15,
                width: _size!.width*0.6,
                padding: const EdgeInsets.symmetric(vertical: 5,horizontal: 8),
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: AppColor.appThemeColorSky.withOpacity(0.2),
                ),
                child: Column(
                 mainAxisAlignment: MainAxisAlignment.center,
                 crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Job Categoriers".tr,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorSky)),
                    Divider(color: Colors.white),
                    Expanded(child: ListView.builder(
                      itemCount: controller.obj!.category!.length,
                      itemBuilder: (context,index){
                        return                     Row(
                            children: [
                              Icon(Icons.star,color: AppColor.appThemeColorSky),
                              SizedBox(width: 5),
                              Text(controller.obj!.category![index],style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorSky)),
              
                            ],
                          );
                      }
                      ))

                  ],
                ),
              ),

           if(![null,""].contains(controller.obj!.workHistory!))
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Text("Work Knowledge".tr,style: AppTextStyles.k18TextH),
            ),
             Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Text(controller.obj!.workHistory!,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),),
            ),
              ],
            ),

            // work knowledge
           if(controller.obj!.workImageList!=null && controller.obj!.workImageList!.length>0)
           Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
             Container(
              height: _size!.height*.15,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ListView.builder(
                itemCount: controller.obj!.workImageList!.length,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context,index){
                 return InkWell(
                   onTap: (){
                    Get.toNamed(RoutesName.image_previewView, arguments: [controller.obj!.workImageList![index],]);
                    
                   },
                   child: Container(
                                 height: _size!.height*0.15,
                                 width: _size!.width*0.3,
                         
                                 margin: const EdgeInsets.only(right: 10),
                                 decoration: BoxDecoration(
                                  border: Border.all(color: AppColor.appThemeColorGreen,width: 2),
                                  borderRadius: BorderRadius.circular(10),
                                 
                  
                                 ),
                                 child: ClipRRect(
                                     borderRadius: BorderRadius.circular(10),
                                  child: FadeImageWithError(imgPath: controller.obj!.workImageList![index],)),
                               ),
                 );
              }),
            ),
            ],
           ),



             // work knowledge
            if(controller.obj!.certificateImageList!=null && controller.obj!.certificateImageList!.length>0)
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                  SizedBox(height: _size!.height*0.03),
              Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Text("Certificates".tr,style: AppTextStyles.k18TextH),
            ),
            SizedBox(height: _size!.height*0.01),
             Container(
              height: _size!.height*.15,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ListView.builder(
                itemCount: controller.obj!.certificateImageList!.length,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context,index){
                 return InkWell(
                   onTap: (){
                     Get.toNamed(RoutesName.image_previewView, arguments: [controller.obj!.certificateImageList![index]],);
                   
                   },
                   child: Container(
                                 height: _size!.height*0.15,
                                 width: _size!.width*0.3,
                         
                                 margin: const EdgeInsets.only(right: 10),
                                 decoration: BoxDecoration(
                                  border: Border.all(color: AppColor.appThemeColorGreen,width: 2),
                                  borderRadius: BorderRadius.circular(10),
                                 
                  
                                 ),
                                 child: ClipRRect(
                                     borderRadius: BorderRadius.circular(10),
                                  child: FadeImageWithError(imgPath: controller.obj!.certificateImageList![index],)),
                               ),
                 );
              }),
            ),
              ],
            ),
            
        
            //\ reviews
            /*  SizedBox(height: _size!.height*0.03),
              Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Text("REVIEWS ",style: AppTextStyles.k18TextH),
            ),
            SizedBox(height: _size!.height*0.01),
             Container(
              height: _size!.height*.2,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ListView.builder(
                itemCount: 3,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context,index){
                 return Container( 
                width: _size!.width*0.6,
                margin: const EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: AppColor.appThemeColorOrange,
                ),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    children: [
                      Row(
                                children: [
                                  CircleAvatar(
                                    radius: 24,
                                    backgroundColor: Colors.white,
                                    backgroundImage: AssetImage("assets/images/person.jpg"),
                                  ),
                                 const SizedBox(width: 20),
                                 Expanded(
                                   child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                     children: [
                                       Text("Courtney Henry",style: AppTextStyles.k14TextN,),
                                       Text("2 days ago",style: AppTextStyles.k12TextN,),
                                     ],
                                   ),
                                 ),
                                ],
                      ),
                         SizedBox(height: _size!.height*0.01),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                                 color: Colors.white,
                              borderRadius: BorderRadius.circular(6),
        
                            ),
                            child: Text("4.5",style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOrange),),
                          ),
                          SizedBox(width: 5),
                          RatingBar.builder(
                              initialRating:3,
                              minRating: 1,
                              direction: Axis.horizontal,
                              allowHalfRating: true,
                              itemCount: 5,
                               itemSize: 18,
                             itemBuilder: (context, _) => Icon(
                                   Icons.star,
                                   color: Colors.white,
                                  
                                   
                             ),
                             onRatingUpdate: (rating) {
                                 print(rating);
                              },
                          )
                        ],
                      ),
                      Divider(color: Colors.white),
                       Text("Very professional and knowledgeable. They were quick to schedule and showed up on time. ",
                             style: AppTextStyles.k12TextN.copyWith(color: Colors.white),
                             maxLines: 3,
                             ),
                    ],
                  ),
                ),
              );
              
              }),
            ),*/
            controller.obj!=null && (![null,""].contains(controller.obj!.instagramLink) || ![null,""].contains(controller.obj!.facebookLink) || ![null,""].contains(controller.obj!.linkedinLink) || ![null,""].contains(controller.obj!.twittrLink) )?
            Container(
                  margin: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                  padding: EdgeInsets.symmetric(vertical: 10,horizontal: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: AppColor.appThemeColorOrange,
                    boxShadow: [
                      BoxShadow(
                        color: AppColor.appThemeColorOlive.withOpacity(0.2),spreadRadius: 2,blurRadius: 2,
                      )
                    ]
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      if(controller.obj!=null && ![null,""].contains(controller.obj!.instagramLink))
                      InkWell(
                        onTap: ()async{
                          print(controller.obj!.instagramLink);
                         await launchURL(controller.obj!.instagramLink);
                        },
                        child: Container(
                          height: 40,width: 40,
                          child: Image.asset("assets/icons/instagram.png"),
                        ),
                      ),
                      if(controller.obj!=null && ![null,""].contains(controller.obj!.facebookLink))
                      InkWell(
                        onTap: ()async{
                          print(controller.obj!.facebookLink);
                         await launchURL(controller.obj!.facebookLink);
                        },
                        child: Container(
                          height: 40,width: 40,
                          child: Image.asset("assets/icons/facebook.png"),
                        ),
                      ),
                      if(controller.obj!=null && ![null,""].contains(controller.obj!.linkedinLink))
                      InkWell(
                        onTap: ()async{
                          print(controller.obj!.linkedinLink);
                         await launchURL(controller.obj!.linkedinLink);
                        },
                        child: Container(
                          height: 40,width: 40,
                          child: Image.asset("assets/icons/linkedin.png"),
                        ),
                      ),
                      if(controller.obj!=null && ![null,""].contains(controller.obj!.twittrLink))
                      InkWell(
                        onTap: ()async{
                          print(controller.obj!.twittrLink);
                         await launchURL(controller.obj!.twittrLink);
                        },
                        child: Container(
                          height: 40,width: 40,
                          child: Image.asset("assets/icons/twitter.png"),
                        ),
                      ),
                    ],
                  ),
                ):Container(),
                SizedBox(height: _size!.height*0.05),
          ],
        ),

         controller.isLoading.value?CustomLoader(): Container(),
          ],
        )
      ),
    );
    });
  }
  


}