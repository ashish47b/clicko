import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class ShowAdds extends StatefulWidget {
  const ShowAdds({super.key});

  @override
  State<ShowAdds> createState() => _ShowAddsState();
}

class _ShowAddsState extends State<ShowAdds> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          centerTitle: true,
          title: Text("Fill Details".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
          iconTheme: IconThemeData(color: Colors.black),
        ),
        body: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          children: [
            SizedBox(height: _size!.height*0.02),
                Text("Show your add for the better engagement.Show your add for the better engagement. ",
                style: AppTextStyles.k14TextN),

            SizedBox(height: _size!.height*0.02), 
            getTextFieldTextType("Add Content", "Add Content", maxLines: 4),

            SizedBox(height: _size!.height*0.02),
            Container(
              height: 150,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: AppColor.appThemeColorOlive.withOpacity(0.2),
                    blurRadius: 3,spreadRadius: 3
                  ),
                ]
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                 Icon(Icons.add_a_photo_outlined,size: 30),
                 const SizedBox(height: 10),
                  Text("Add Image",style: AppTextStyles.k16TextN,)
                ],
              ),
            ),
          ],
        ),
        bottomNavigationBar: Container(
          margin: const EdgeInsets.symmetric(horizontal: 16,vertical: 12),
                      height: _size!.height*0.05,
                      decoration: BoxDecoration(
                        color: AppColor.appThemeColorOlive,
                       // border: Border.all(color: AppColor.appThemeColorOlive),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                         
                          Text("ADD".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),
                        ],
                      ),
                     ),
    );
  }
}