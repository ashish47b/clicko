import 'dart:convert';

import 'package:click_pro_customer/model/BidsDataModel/bids_data_model.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/BiddersController/bidders_controller.dart';
import 'package:click_pro_customer/views/Bidders/negotiation_page.dart';
import 'package:click_pro_customer/views/ChatScreen/chat_scrreen.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';
import 'package:click_pro_customer/widgets/RowWithText.dart';
import 'package:click_pro_customer/widgets/custom_button.dart';

import 'package:flutter/material.dart';
import 'package:flutter_paypal/flutter_paypal.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';

class BiddersList extends StatefulWidget {
  const BiddersList({super.key});

  @override
  State<BiddersList> createState() => _BiddersListState();
}

class _BiddersListState extends State<BiddersList> {
  
  final BidderController controller = Get.put(BidderController());


  

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 300),()=>getData());
  }

  String? jobid="";

  getData()async {
    controller.getBidders(job_id: Get.arguments[0]);
    jobid= Get.arguments[0];
  }

  Size?_size;
  String?totalAmount;

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx((){
      return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          centerTitle: true,
          title: Text("OFFERS".tr,style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
          iconTheme: IconThemeData(color: Colors.black),
        ),
        body: Stack(
          children: [
            ListView(
              padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              children: [
                 controller.biddersList!=null && controller.biddersList!.length>0? ListView.builder(
                    itemCount: controller.biddersList!.length,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (context,index){
                      Bidders obj = controller.biddersList![index];
                      totalAmount = obj.quot!=null ? obj.quot!.estimatePrice!:"";
                    return Container(
                      margin:const EdgeInsets.symmetric(vertical: 6),
                   padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 10),
                   decoration: BoxDecoration(
                     border: Border.all(color: AppColor.appThemeColorOrange,width: 2),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ![null,""].contains(obj.profilePic)
                          ? Container(
                            height: 80,
                            width: 80,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white,
                              border: Border.all(color:AppColor.appThemeColorOrange),
                              image: DecorationImage(image: NetworkImage(obj.profilePicPath!+ obj.profilePic!),fit: BoxFit.fill)
                            ),
                          )
                          :Container(
                            height: 80,
                            width: 80,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white,
                              border: Border.all(color:AppColor.appThemeColorOrange),
                              image: DecorationImage(image: AssetImage("assets/images/avatar.png"),fit: BoxFit.fill)
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                   Row(
                                    children: [
                                       Image.asset("assets/images/medal.png",height: 30),
                                    const SizedBox(width: 4),
                                    Text(obj.firstName! + " ",style: AppTextStyles.k16TextN),
                                    ],
                                   ),
                                    
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Row(
                                  children: [
                                    Container(
                                      padding: EdgeInsets.symmetric(horizontal: 5,vertical: 3),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(3),
                                        color: AppColor.appThemeColorOrange
                                      ),
                                      child: Text("5",style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                                    ),
                                     RatingBar.builder(
                                          initialRating: 4.5,
                                          minRating: 1,
                                          direction: Axis.horizontal,
                                          allowHalfRating: true,
                                          itemCount: 5,
                                           itemSize: 18,
                                         itemBuilder: (context, _) => Icon(
                                               Icons.star,
                                               color: AppColor.appThemeColorOrange,
                                              
                                               
                                         ),
                                         onRatingUpdate: (rating) {
                                             print(rating);
                                          },
                                    ),
                                  ],
                                ),
                                SizedBox(height: _size!.height*0.01),
                                Row(
                                  children: [
                                    Text("Total Work Done".tr + " : ".tr,style: AppTextStyles.k14TextN),
                                    Text(obj.jobDone!,style: AppTextStyles.k14TextN,)
                                  ],
                                ),
                                SizedBox(height: _size!.height*0.01),
                                Row(
                                      children: [
                                        Text("You Hired".tr  + " : ".tr,style: AppTextStyles.k14TextN),
                                        Text("0",style: AppTextStyles.k14TextN,)
                                      ],
                                    )
                          
                              ],
                            ),
                          )
                        ],
                      ),

                      //
                      Divider(),
                      const SizedBox(height: 10),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Total No. Of Payments : " + (obj.quot!=null && ![null,""].contains(obj.quot!.instalment_plan) ? obj.quot!.instalment_plan!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                          Container(
                            padding:const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: AppColor.appThemeColorGreen,
                              borderRadius: BorderRadius.circular(6)
                            ),
                            child: Text("€"+ " "+(obj.quot!=null ? obj.quot!.estimatePrice!:""),style: AppTextStyles.k16TextH.copyWith(color: Colors.white))),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RowWtihText(title: "Start Date",value: obj.quot!=null && ![null,""].contains(obj.quot!.work_start_date) ? obj.quot!.work_start_date!:"",),
                              const SizedBox(height: 5),
                              RowWtihText(title: "End Date",value: obj.quot!=null && ![null,""].contains(obj.quot!.work_end_date) ? obj.quot!.work_end_date!:"",),
                            ],
                          ),
                          InkWell(
                            onTap: (){
                              // Get.toNamed(RoutesName.chatView, arguments: [
                              //   obj.userId,obj.firstName , obj.lastName
                              // ]);
                              navigateWithPageTransition(context, ChatScreen(prof_Id: obj.userId!, name: obj.user!.name));
                            },
                            child: Container(
                              padding:const EdgeInsets.all(8),
                              decoration:const BoxDecoration(
                                shape: BoxShape.circle,
                                color: AppColor.appThemeColorOrange,
                              ),
                              child:const Icon(Icons.chat,size: 20,color: Colors.white,),
                            ),
                          )
                        ],
                      ),
                      const SizedBox(height: 20),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                           Expanded(child: CustomButton(text: "Negotiation".tr,buttonColor: AppColor.appThemeColorOrange,
                           onTap: (){
                            navigateWithPageTransition(context, NegotiationPage(
                              quote_id: obj.quot!.id!,user_ID: obj.userId,

                            ));
                            // Get.toNamed(RoutesName.negotiation_view, arguments: [obj.quot!.id]);
                           },
                           )),
                           SizedBox(width: _size!.width*0.04),
                            Expanded(
                               child: CustomButton(text: "Approve".tr,buttonColor: AppColor.appThemeColorGreen,
                              /* onTap: ()async{
                                Get.dialog(
                                  Center(
                                  child: Container(
                                    margin:const EdgeInsets.symmetric(horizontal: 20),
                                    padding:const EdgeInsets.symmetric(vertical: 20),
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(12)
                                    ),
                                    child: Wrap(
                                      children: [
                                        Center(
                                          child: Container(
                                            height: 100,
                                            child: Image.asset("assets/images/paypal.png"),
                                          ),
                                        ),
                                        SizedBox(height: _size!.height*0.15,),
                                        Center(
                                          child: ElevatedButton(onPressed: (){
                                            double? toalAmount = double.parse(obj.quot!.estimatePrice!);
                                            Navigator.push(context, MaterialPageRoute(builder: (context)=> UsePaypal(
                                                            sandboxMode: true,
                                                            clientId:
                                                                "AW1TdvpSGbIM5iP4HJNI5TyTmwpY9Gv9dYw8_8yW5lYIbCqf326vrkrp0ce9TAqjEGMHiV3OqJM_aRT0",
                                                            secretKey:
                                                                "EHHtTDjnmTZATYBPiGzZC_AZUfMpMAzj2VZUeqlFUrRJA_C0pQNCxDccB5qoRQSEdcOnnKQhycuOWdP9",
                                                            returnURL: "https://samplesite.com/return",
                                                            cancelURL: "https://samplesite.com/cancel",
                                                            transactions: [
                                                              {
                                                                "amount": {
                                                                  "total": totalAmount!,
                                                                  "currency": "USD",
                                                                  "details": {
                                                                    "subtotal": totalAmount!,
                                                                    "shipping": '0',
                                                                    "shipping_discount": 0
                                                                  }
                                                                },


                                                              }
                                                            ],
                                                            note: "Contact us for any questions on your order.",
                                                            onSuccess: (Map params) async {
                                                              var data = params["paymentId"];
                                                              print("PAYMENT ID" +  data);
                                                              print("onSuccess: $params");
                                                              
                                                              await controller.approveBidApi(job_id: jobid,bid_id: obj.id,pay_id: data);
                                                            },
                                                            onError: (error) {
                                                            
                                                              showToastMsg("Payment Not Successful, Try Again".tr);
                                                                print('error: $error');
                                                            },
                                                            onCancel: (params) {
                                                                showToastMsg("Payment Cancelled, Try Again".tr);
                                                              print('cancelled: $params');
                                                            }),
                                            ));
                                          },
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: AppColor.appThemeColorGreen
                                          ),
                                           child: Text("Pay".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)),
                                        )
                                      ],
                                    ),
                                  ),
                                ));
                               // getData();
                               },*/
                               ),
                             ),
                        ],
                      ),
                      SizedBox(height: _size!.height*0.01),
                      Row(
                        children: [
                          Expanded(
                            child: CustomButton(text: "See Profile".tr,buttonColor: AppColor.appThemeColorOlive,
                              onTap: ()async{
                                Get.toNamed(RoutesName.professionalView, arguments: [obj.id]);
                              },
                              ),
                          ),
                          SizedBox(width: _size!.width*0.04),
                          Expanded(
                            child: CustomButton(text: "Reject".tr,buttonColor: AppColor.appRedColor,onTap: ()async{
                                await controller.rejectBidApi(job_id: Get.arguments[0],bid_id: obj.id);
                                getData();
                            },),
                          ),
                        ],
                      )
                    ],
                  ),
                );
                  }): NoDataWidget(isloading: controller.isLoading.value,)
                
              ],
            ),
              controller.isLoading.value?CustomLoader(): Container(),
          ],
        ),
    );});
  }

  
}