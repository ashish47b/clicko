
import 'dart:convert';

import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/payment.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../view_model/BiddersController/bidders_controller.dart';

class NegotiationPage extends StatefulWidget {
  String?quote_id;
  String?user_ID;
  String?pay_count;
  String?job_id;
  NegotiationPage({this.quote_id,this.user_ID});
  @override
  State<NegotiationPage> createState() => _NegotiationPageState();
}

class _NegotiationPageState extends State<NegotiationPage> {
  
  final BidderController controller = Get.put(BidderController());

  getData()async {
    controller.negotiationListApi(quot_id: widget.quote_id);
  }
  String?installPLanValue="0";
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 300),()=> getData());
  }


  final installmentController = TextEditingController(text: "");

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx((){
          if(controller.negoObj!=null && controller.negoObj!.quot!=null){
          installmentController.text = controller.negoObj!.quot!.instalmentPlan!;
          installPLanValue = controller.negoObj!.quot!.instalmentPlan!;
          // print("install plan value" + installPLanValue.toString());
          for(int i=0;i<int.parse(installPLanValue!);i++){
            planDateList!.add(null);
          }
          for(int i=0;i<int.parse(installPLanValue!);i++){
            installPriceController!.add(null);
          }
          for(int i=0;i<int.parse(installPLanValue!);i++){
            selectPercentageValue!.add("0");
          }
        }
      return Scaffold(
      
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        centerTitle: true,
        iconTheme:const IconThemeData(color: Colors.black),
        title: Text("Negotiation".tr, style: AppTextStyles.k18TextN.copyWith(color: Colors.black)),
      ),
      body: Stack(
        children: [
          controller.negoObj!=null ?
          ListView(
            padding:const EdgeInsets.symmetric(horizontal: 12),
            children: [
              SizedBox(height: _size!.height*0.01),
              Text("Price Proposed By the Professional",style: AppTextStyles.k16TextN),
              SizedBox(height: _size!.height*0.01),
              Text(("€ ") + (controller.negoObj!=null &&controller.negoObj!.quot!=null ? controller.negoObj!.quot!.estimatePrice!:""),
              style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange)),
              SizedBox(height: _size!.height*0.01),
              getTextFieldTextType("Milestone", "Milestone",radius: 8,controller: installmentController),

              SizedBox(height: _size!.height*0.01),
              controller.negoObj!.negotiation!=null && controller.negoObj!.negotiation!.length>0
              ? Container(
                child: Column(
                  children: [
                    for(int i=0;i<controller.negoObj!.negotiation!.length;i++)
                    Container(
                      decoration: BoxDecoration(
                       
                      ),
                      child: Column(
                        children: [
                          Container(
                            margin:const EdgeInsets.symmetric(vertical: 5),
                            child: Row(
                              children: [
                                Expanded(child: Container(height: 45,decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: AppColor.appThemeColorOlive)
                                ),child: Center(child: Text(controller.negoObj!.negotiation![i].amount!),),)),
                                const SizedBox(width: 7),
                                Expanded(child: Container(height: 45,decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: AppColor.appThemeColorOlive)
                                ),child: Center(child: Text(controller.negoObj!.negotiation![i].deffDays! + (" %")),),)),
                                const SizedBox(width: 7),
                                Expanded(child: Container(height: 45,decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: AppColor.appThemeColorOlive)
                                ),child: Center(child: Text(controller.negoObj!.negotiation![i].paymentDueDate!),),)),
                              ],
                            ),
                          ),
                          SizedBox(height: _size!.height*0.01),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              ![null,""].contains(controller.negoObj!.negotiation![i].paymentStatus) && controller.negoObj!.negotiation![i].paymentStatus=="Complete"
                              ? TextButton(onPressed: (){
                                  showToastMsg("Already Deposit");
                              },style: ButtonStyle(
                                backgroundColor: MaterialStateProperty.all(AppColor.appThemeColorGreen)
                              ), child: Text("Complete",style: AppTextStyles.k14TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)),
                            )
                              :
                              TextButton(onPressed: (){
                                   if(controller.negoObj!.quot!.professionalNegotiationCount=="1"){
                                  // controller.saveDepositApi(
                                  //   payment_id: "12345653",
                                  //   paymentStatus: "Complete",
                                  //   paymentDate: DateTime.now().toString(),
                                  //   negoID:controller.negoObj!.negotiation![i].id,
                                  //   job_id: controller.negoObj!.quot!.jobId,
                                  //   quote_id: widget.quote_id,
                                  //   pay_count: controller.negoObj!.quot!.pay_count,
                                  // );
                                    showDialog(context: context, builder: (context){
                                      return PayPal(from: "deposit",
                                      prof_id: widget.user_ID,
                                      negoID: controller.negoObj!.negotiation![i].id,
                                      quoteID: widget.quote_id,
                                      jobID: controller.negoObj!.quot!.jobId,
                                      payCount: controller.negoObj!.quot!.pay_count,
                                      amount: (double.parse(controller.negoObj!.negotiation![i].amount!) + double.parse(controller.negoObj!.negotiation![i].admin_cus_commission!)).toStringAsFixed(2),);
                                    });
                                }else{
                                  showToastMsg("Professional Not Submitted yet");
                                }
                                
                                
                              },style: ButtonStyle(
                                backgroundColor: MaterialStateProperty.all(AppColor.appRedColor)
                              ), child: Text("Deposit",style: AppTextStyles.k14TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold))),
                              SizedBox(width: 8),
                             ![null,""].contains(controller.negoObj!.negotiation![i].paymentStatus) && controller.negoObj!.negotiation![i].paymentStatus=="Complete"
                             ?  TextButton(onPressed: (){
                                 if(![null,""].contains(controller.negoObj!.negotiation![i].approve_status_pro!) && controller.negoObj!.negotiation![i].approve_status_pro=="1"){
                                   showToastMsg("Already Done");
                                 }else{
                                  controller.payDepositApi(negoID:controller.negoObj!.negotiation![i].id);
                                 }
                                  
                              },style: ButtonStyle(
                                backgroundColor: MaterialStateProperty.all(![null,""].contains(controller.negoObj!.negotiation![i].approve_status_pro!) && controller.negoObj!.negotiation![i].approve_status_pro=="1"? AppColor.appThemeColorGreen: AppColor.appRedColor)
                              ), child: Text("Pay",style: AppTextStyles.k14TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)),
                            )
                             : Container()
                            ],
                          )
                        ],
                      ),
                    )
                  ],
                )
              )
              : installPayBox(),
              SizedBox(height: _size!.height*0.04),
              controller.negoObj!.negotiation!=null && controller.negoObj!.negotiation!.length>0?Container():
              TextButton(onPressed: (){
                saveData();
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(AppColor.appThemeColorOrange)
              ),
              child: Text("Submit",style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
            )
            ],
          ): NoDataWidget(isloading: controller.isLoading.value,),
          controller.isLoading.value?CustomLoader(): Container(),
        ],
      ),
    );
    });
  }
  List<String?>? installPriceController = [];
  List<String?>? selectPercentageValue = [];
  installPayBox(){
    if(controller.negoObj!=null && controller.negoObj!.quot!=null &&![null,""].contains(controller.negoObj!.quot!.grandTotalEstimatePrice!)  &&![null,""].contains(controller.negoObj!.quot!.instalmentPlan!)){
      String installmentAmount = (double.parse(controller.negoObj!.quot!.grandTotalEstimatePrice!)/double.parse(controller.negoObj!.quot!.instalmentPlan!)).toStringAsFixed(2);

       for(int i=0;i<int.parse(installPLanValue!);i++){
         installPriceController![i] = installmentAmount;
       }

     return Column(
      children: [
        for(int i=0;i<int.parse(installPLanValue!);i++)
        Container(
          margin: EdgeInsets.symmetric(vertical: 5),
          decoration: BoxDecoration(
          //   border: Border.all(color: AppColor.appThemeColorOrange)
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
                Expanded(child: Container(height: 45,decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColor.appThemeColorOlive)
                ),child: Center(child: Text(installPriceController![i]!),),)),
                const SizedBox(width: 7),
                Expanded(child: Container(
                padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColor.appThemeColorOlive),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: DropdownButton(
                  isDense: true,
                  isExpanded: true,
                  value: selectPercentageValue![i],
                  
                  items: ["0","10","30","50","75","100"].map((e){
                    return DropdownMenuItem(child: Text(e), value: e);
                  }).toList(),
                  onChanged: (val){
                      selectPercentageValue![i] = val;
                      setState(() {});
                  }
                    ),
                )),
                const SizedBox(width: 7),
                Expanded(child:InkWell(
                        onTap: (){
                          print(i);
                            selectPlanDates(context,i);
                        },
                        child: Container(
                            margin: EdgeInsets.only(bottom: 5),
                          padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 12),
                          decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: AppColor.appThemeColorOlive)
                          ),
                          child: Row(
                            children: [
                            const Icon(Icons.calendar_today, color: AppColor.appThemeColorOlive,size: 20,),
                            const SizedBox(width: 5),
                              Text(planDateList!=null && planDateList![i]!=null ?DateFormat("dd MMM yy").format(planDateList![i]!): "Select", style: AppTextStyles.k12TextN,)
                            ],
                          ),
                        ),
                      ),)
            ],
          ),
        ),
      ],
    );
    }else{
      return Container();
    }
   

  }

     // select plan date 
   List<DateTime?>? planDateList=[];
   selectPlanDates(BuildContext context, int index) async{
    DateTime? date = DateTime.now();
    var newDate = DateTime(date.year, date.month - 11, date.day);
     DateTime? newDateFrom=await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: newDate,
        lastDate: DateTime(2100));
        if(newDateFrom !=null) {
          setState(() {
            
          });
          planDateList![index] = newDateFrom;
          print(index);
          print(planDateList![index]);
          
          
          //getData();
        }
  }

  // payment methods



  String?cust_id="";
  saveData()async{

    cust_id = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    if(installPLanValue==null){
      showToastMsg("No Data");
    }
    List<NegotiationData> list =[];
    for(int i=0;i<int.parse(installPLanValue!);i++){
      NegotiationData obj1 = NegotiationData(
        negeditId: "0",
        amount: installPriceController![i],
        deffDays: selectPercentageValue![i],
        paymentDueDate: planDateList![i].toString()
      );
      list.add(obj1);
    }
    print(jsonEncode(list));



    SaveNegotiationData obj = SaveNegotiationData(
      quote_id: controller.negoObj!=null && controller.negoObj!.quot!=null ? controller.negoObj!.quot!.id:"",
      jobId: controller.negoObj!=null && controller.negoObj!.quot!=null ? controller.negoObj!.quot!.jobId:"",
      negotiationData: list,
      userId: widget.user_ID,
      milestone: installPLanValue,
      cust_id: cust_id,
      estimate_price: controller.negoObj!=null && controller.negoObj!.quot!=null ? controller.negoObj!.quot!.grandTotalEstimatePrice:"",
    );

    print(jsonEncode(obj));
    controller.saveNegotiation(context,obj);
  }
}

class SaveNegotiationData {
  String? quote_id;
  String?cust_id;
  String? jobId;
  List<NegotiationData>? negotiationData;
  String? userId;
  String? milestone;
  String?estimate_price;

  SaveNegotiationData(
      {this.quote_id,
      this.jobId,
      this.negotiationData,
      this.userId,
      this.milestone,this.cust_id,
      this.estimate_price,
      });

  SaveNegotiationData.fromJson(Map<String, dynamic> json) {
    quote_id = json['quote_id'];
    jobId = json['job_id'];
    if (json['negotiation_data'] != null) {
      negotiationData = <NegotiationData>[];
      json['negotiation_data'].forEach((v) {
        negotiationData!.add(new NegotiationData.fromJson(v));
      });
    }
    userId = json['userId'];
    milestone = json['milestone'];
    cust_id = json['cust_id'];
    estimate_price=  json['estimate_price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['quote_id'] = this.quote_id;
    data['job_id'] = this.jobId;
    if (this.negotiationData != null) {
      data['negotiation_data'] =
          this.negotiationData!.map((v) => v.toJson()).toList();
    }
    data['userId'] = this.userId;
    data['milestone'] = this.milestone;
    data['cust_id'] = this.cust_id;
    data['estimate_price'] = this.estimate_price;
    return data;
  }
}

class NegotiationData {
  String? negeditId;
  String? amount;
  String? deffDays;
  String? paymentDueDate;

  NegotiationData(
      {this.negeditId, this.amount, this.deffDays, this.paymentDueDate});

  NegotiationData.fromJson(Map<String, dynamic> json) {
    negeditId = json['negedit_id']!=null?json['negedit_id'].toString():"";
    amount = json['amount']!=null?json['amount'].toString():"";
    deffDays = json['deff_days']!=null?json['deff_days'].toString():"";
    paymentDueDate = json['payment_due_date']!=null?json['payment_due_date'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['negedit_id'] = this.negeditId;
    data['amount'] = this.amount;
    data['deff_days'] = this.deffDays;
    data['payment_due_date'] = this.paymentDueDate;
    return data;
  }
}



    


