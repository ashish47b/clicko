import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class SponsorshipItem extends StatefulWidget {
final tabIndex;
SponsorshipItem({this.tabIndex});

  @override
  State<SponsorshipItem> createState() => _SponsorshipItemState();
}

class _SponsorshipItemState extends State<SponsorshipItem> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12,vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: AppColor.appThemeColorOlive.withOpacity(0.2),
            blurRadius: 3,spreadRadius: 3,
          ),
        ]
      ),
      child: Column(
        children: [
          Row(
            children: [
              Text("Name : ",style: AppTextStyles.k16TextN,),
              Text("Henry Marton",style: AppTextStyles.k16TextN,),
            ],
          ),
          SizedBox(height: _size!.height*0.01),
            Row(
            children: [
              Text("Phone Number : ",style: AppTextStyles.k16TextN,),
              Text("90898767556",style: AppTextStyles.k16TextN,),
            ],
          ),
          SizedBox(height: _size!.height*0.01),
            Row(
            children: [
              Text("Business Type : ",style: AppTextStyles.k16TextN,),
              Text("type",style: AppTextStyles.k18TextN,),
            ],
          ),
          SizedBox(height: _size!.height*0.01),
            Row(
            children: [
              Text("Amount : ",style: AppTextStyles.k16TextN,),
              Text("\$99",style: AppTextStyles.k18TextN,),
            ],
          ),
          SizedBox(height: _size!.height*0.02),

        widget.tabIndex=="1"?Container():  Row(
            children: [
              Expanded(child: Container(
                padding: const EdgeInsets.symmetric(vertical: 3),
                decoration: BoxDecoration(
                  color: AppColor.appThemeColorOlive,
                  borderRadius: BorderRadius.circular(12),
                 
                ),
                child: Center(
                  child: Text("Accept".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                ),
              )),
              SizedBox(width: 10),
              Expanded(child: Container(
                padding: const EdgeInsets.symmetric(vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.redAccent,
                  borderRadius: BorderRadius.circular(12),
                 
                ),
                child: Center(
                  child: Text("Reject".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                ),
              ))
            ],
          )
        ],
      ),
    );
  }
}