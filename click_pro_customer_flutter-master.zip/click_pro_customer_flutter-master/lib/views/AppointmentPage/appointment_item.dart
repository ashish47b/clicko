import 'package:click_pro_customer/model/AppoinmentDataModel/appointment_data_model.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../utils/text_styles.dart';

class AppointmentItem extends StatefulWidget {
  AppointmentData?obj;
  final tabIndex;
  AppointmentItem({this.obj, this.tabIndex});

  @override
  State<AppointmentItem> createState() => _AppointmentItemState();
}

class _AppointmentItemState extends State<AppointmentItem> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Container(
      margin:const EdgeInsets.symmetric(horizontal: 8,vertical: 10),
      padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 7),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: AppColor.appThemeColorOlive.withOpacity(0.2),
            blurRadius: 3,spreadRadius: 3
          ),
        ]
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
           Text(widget.obj!.title!,style: AppTextStyles.k18TextH.copyWith(color: AppColor.appThemeColorSky)),
           SizedBox(height: _size!.height*0.01),
           Row(
              children: [
                Text("Job Title".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                Text(widget.obj!.jobTitle!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
              ],
            ),
             SizedBox(height: _size!.height*0.01),
            Row(
              children: [
                Text("Name".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                Text(widget.obj!.firstName!+ " " + widget.obj!.lastName!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
              ],
            ),
            SizedBox(height: _size!.height*0.015),
          Row(
            children: [
            Text("Appointment Days".tr + " : "  ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
            Text(widget.obj!.date!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
            //SizedBox(width: _size!.height*0.03),
           /* for(int i=0; i<widget.obj!.appointmentDaysList.length;i++)
             Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: AppColor.appThemeColorOrange.withOpacity(0.4),
                    blurRadius: 2,spreadRadius: 2
                  )
                ]
              ),
              child: Text(widget.obj!.appointmentDaysList[i]),
             ),*/
            ],
          ),
            SizedBox(height: _size!.height*0.01),
          Row(
            children: [
              Text("Prefer Time".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
              Expanded(child: Text(widget.obj!.time!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange))),
            //SizedBox(width: _size!.height*0.03),
           /* for(int i=0; i<widget.obj!.preferTimeList.length;i++)
             Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: AppColor.appThemeColorOrange.withOpacity(0.4),
                    blurRadius: 2,spreadRadius: 2
                  )
                ]
              ),
              child: Text(widget.obj!.preferTimeList[i]),
             ),*/

            ],
          ),

          SizedBox(height:_size!.height*0.01),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              InkWell(
              onTap: (){
                Get.toNamed(RoutesName.reschedule_View,arguments: [widget.obj!.id, widget.obj!.quotId, widget.obj!.jobId]  );
              },
               child: Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: AppColor.appThemeColorOlive,
                  borderRadius: BorderRadius.circular(8),             
                ),
                child: Text("Reschedule".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
               ),
             ),
            const SizedBox(width: 10),
             InkWell(
              onTap: (){
                Get.toNamed(RoutesName.appointment_view, arguments: [widget.obj!.id]);
              },
               child: Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: AppColor.appThemeColorOlive,
                  borderRadius: BorderRadius.circular(8),             
                ),
                child: Text("Details".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
               ),
             )
            ],
          )
 
        ],
      ),
    );
  }
}