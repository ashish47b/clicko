import 'package:click_pro_customer/model/AppoinmentDataModel/appointment_view_data_model.dart';
import 'package:click_pro_customer/model/QuoteDataModel/view_quotation.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/AppointmentController/appointMent_controller.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';
import 'package:click_pro_customer/widgets/RowWithText.dart';
import 'package:click_pro_customer/widgets/fade_img_with_error.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AppointmentViewPage extends StatefulWidget {
  const AppointmentViewPage({super.key});

  @override
  State<AppointmentViewPage> createState() => _AppointmentViewPageState();
}

class _AppointmentViewPageState extends State<AppointmentViewPage> {
  
  final AppointmentController controller = Get.put(AppointmentController());

  getData()async{
    await controller.appointViewDataApi(appointmnet_id: Get.arguments[0]);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size  = MediaQuery.of(context).size;
    return Obx(()=> Scaffold(
       appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0.0,
              centerTitle: true,
              title: Text("APPOINTMENT".tr,style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
              iconTheme: IconThemeData(color: Colors.black),
            ),
         body: Stack(
           children: [
            controller.appointViewData==null?NoDataWidget(isloading: controller.isLoading.value) : ListView(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 10),
              children: [
                             Text(controller.appointViewData!.title!,style: AppTextStyles.k18TextH.copyWith(color: AppColor.appThemeColorSky)),
               SizedBox(height: _size!.height*0.01),
               Row(
                  children: [
                    Text("Job Title".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                    Text(controller.appointViewData!.jobTitle!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                  ],
                ),
                 SizedBox(height: _size!.height*0.01),
                Row(
                  children: [
                    Text("Name".tr + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                    Text(controller.appointViewData!.firstName!+ " " + controller.appointViewData!.lastName!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                  ],
                ),
                SizedBox(height: _size!.height*0.01),
                Row(
                    children: [
                    Text("Appointment Days".tr + " : "  ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                    Text(controller.appointViewData!.date!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                  ],
                ),
                SizedBox(height: _size!.height*0.01),
                Row(
                    children: [
                    Text("Prefer Time".tr + " : "  ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                    Text(controller.appointViewData!.time!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                  ],
                ),
                SizedBox(height: _size!.height*0.01),
               const Divider(color: AppColor.appThemeColorOlive),
                SizedBox(height: _size!.height*0.01),
                  Text("Description".tr + " : "  ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                 SizedBox(height: _size!.height*0.01),
                 Text(controller.appointViewData!.description!, style: AppTextStyles.k14TextN.copyWith(color: Colors.grey)),
                SizedBox(height: _size!.height*0.01),
               const Divider(color: AppColor.appThemeColorOlive),
                SizedBox(height: _size!.height*0.01),
                Text("Attachments".tr ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                controller.appointViewData!.attachmentList!=null && controller.appointViewData!.attachmentList.length>0?
                Container(
                  height: 100,
                  child: ListView.builder(
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    itemCount: controller.appointViewData!.attachmentList.length,
                    itemBuilder: (context,index){
                    return  InkWell(
                      onTap: (){
                        Get.toNamed(RoutesName.image_previewView, arguments: [controller.appointViewData!.attachmentList[index]]);
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColor.appThemeColorGreen)
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: FadeImageWithError(imgPath: controller.appointViewData!.attachmentList[index],),
                        ),
                      ),
                    );
                  }),
                ) : Container(),
                 SizedBox(height: _size!.height*0.02),
               const Divider(color: AppColor.appThemeColorOlive),
                SizedBox(height: _size!.height*0.01),
                Text("Company Details".tr ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                SizedBox(height: _size!.height*0.01),
                ListView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: controller.appointViewData!.companyDetailsDtaList.length,
                  itemBuilder: (context,index){
                  CompanyDetailsData obj = controller.appointViewData!.companyDetailsDtaList[index];
                  return Container(
                    padding: EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: AppColor.appThemeColorGreen),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                        children: [
                          RowWtihText(title: "Company Name".tr, value: obj.companyName!,),
                          RowWtihText(title: "Company Location".tr, value: obj.location!,),
                         
                        ],
                    ),
                  );
                })
              ],
             ),

             controller.isLoading.value?CustomLoader():Container()
           ],
         ),   
    ));
  }
}