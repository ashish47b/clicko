import 'package:click_pro_customer/model/AppoinmentDataModel/appointment_data_model.dart';

import 'package:click_pro_customer/utils/app_color.dart';

import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/AppointmentController/appointMent_controller.dart';

import 'package:click_pro_customer/views/AppointmentPage/appointment_item.dart';

import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/NoData.dart';


import 'package:flutter/material.dart';
import 'package:get/get.dart';


class AppointmentPage extends StatefulWidget {
  const AppointmentPage({super.key});

  @override
  State<AppointmentPage> createState() => _AppointmentPageState();
}

class _AppointmentPageState extends State<AppointmentPage> {

  final AppointmentController controller = Get.put(AppointmentController());
          var scController=ScrollController();

 @override
  void initState() {
    // TODO: implement initState
    super.initState();
    scController.addListener(listener);
    Future.delayed(Duration(seconds: 2),(() => getData()));
  }


  getData()async{
    Future.delayed(Duration(seconds: 2));
    if(currentIndex==0){
      await controller.todayAppointments(limit: skipValue);
    }else if(currentIndex==1){
      await controller.allAppointments(limit: skipValue);
    }else if(currentIndex==2){
      await controller.previousAppointment(limit: skipValue);
    }

    setState(() {
      
    });

  }

    int skipValue=1;
  listener(){
    if(scController.position.pixels == scController.position.maxScrollExtent){
      skipValue=skipValue+1;
      getData();
      print("called");
    }else{
      print("sorry");
    }
  }

  int currentIndex = 0;

  Size?_size;


  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=> Stack(
      children: [
        Scaffold(
           appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0.0,
              centerTitle: true,
              title: Text("APPOINTMENT".tr,style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
              iconTheme: IconThemeData(color: Colors.black),
            ),
            body: DefaultTabController(
              length: 3,
              child: Column(
                children: [
                  Container(
                    //height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12)
                    ),
                    child: TabBar(
                      unselectedLabelColor: AppColor.appThemeColorOlive,
                      labelColor: AppColor.appThemeColorOrange,
                      labelStyle: AppTextStyles.k16TextN.copyWith(
                          fontSize: 16.0,
                          color: AppColor.appThemeColorOlive,
                          fontWeight: FontWeight.w700),
                      tabs: [
                        Tab(child: Container(width: _size!.width*0.25, child: Center(child: Text("Today")))),
                         Tab(child: Container(width: _size!.width*0.25, child: Center(child: Text("All")))),
                          Tab(child: Container(width: _size!.width*0.25, child: Center(child: Text("Previous")))),
                    ],indicatorColor: AppColor.appThemeColorOrange,
                      isScrollable: true,
                      automaticIndicatorColorAdjustment: true,
                      //physics: NeverScrollableScrollPhysics(),
                    onTap: (val){
                      print(val);
                      currentIndex = val;
                      setState(() {              
                      });
                       skipValue = 1;
                       getData();

                      },
                    ),
                  ),
              Expanded(child: TabBarView(children: [
                // current index = 0
                  controller.todayAppointmentList!=null && controller.todayAppointmentList!.isNotEmpty && 
                  !controller.isLoading.value?  ListView.builder(
                    itemCount: controller.todayAppointmentList!.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                      print("isime aa rha h");
                    AppointmentData obj = controller.todayAppointmentList![index];
                    return AppointmentItem(obj: obj,tabIndex: "0",);
                   }) : NoDataWidget(isloading: controller.isLoading.value),
                    
                    //current Index =1
                    controller.allAppointmentList!=null && controller.allAppointmentList!.length>0?  ListView.builder(
                    itemCount: controller.allAppointmentList!.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                    AppointmentData obj = controller.allAppointmentList![index];
                    return AppointmentItem(obj: obj,tabIndex: "1",);
                   }) : NoDataWidget(isloading: controller.isLoading.value),

                    //current Index = 2
                    controller.previousAppointmentList!=null && controller.previousAppointmentList!.length>0?  ListView.builder(
                    itemCount: controller.previousAppointmentList!.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                    AppointmentData obj = controller.previousAppointmentList![index];
                    return AppointmentItem(obj: obj,tabIndex: "1",);
                   }) : NoDataWidget(isloading: controller.isLoading.value),
         
              ]))
                ],
              )
              ),
            
            /*floatingActionButton: FloatingActionButton(
              onPressed: (){
                 Get.toNamed(RoutesName.appointmentUserView);
              },
              backgroundColor: AppColor.appThemeColorSky,
              child: Icon(Icons.add),
            ),*/
        ),
        controller.isLoading.value?CustomLoader():Container()
      ],
    ));
  }
}