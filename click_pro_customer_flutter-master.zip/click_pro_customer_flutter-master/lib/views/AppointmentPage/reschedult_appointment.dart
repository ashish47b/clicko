import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/AppointmentController/appointMent_controller.dart';
import 'package:click_pro_customer/widgets/CustomeLoader.dart';
import 'package:click_pro_customer/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ReschedultAppointment extends StatefulWidget {
  const ReschedultAppointment({super.key});

  @override
  State<ReschedultAppointment> createState() => _ReschedultAppointmentState();
}

class _ReschedultAppointmentState extends State<ReschedultAppointment> {

  final AppointmentController appointmentController = Get.put(AppointmentController());

  
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 100),()=> timeWidget(0));
  }

  final titleController = TextEditingController(text: "");
  final meetingCotroller = TextEditingController(text: "");
  final descController  = TextEditingController(text: "");
  
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Obx(()=>Stack(
      children: [
        Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0.0,
            title: Text("Reschedule Appointment".tr,style: AppTextStyles.k18TextN.copyWith(color: Colors.black)),
            centerTitle: true,
            iconTheme:const IconThemeData(color: Colors.black),
          ),
          body: StatefulBuilder(builder: (context,myState){
            return ListView(
            padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 10),
            children: [
              getTextFieldTextType("Title".tr, "Title".tr,radius: 10,controller: titleController),
              SizedBox(height: _size!.height*0.01),
              ListView.builder(
                itemCount: widgets.length,
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: (context,index){
                return widgets[index];
              }),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                  ElevatedButton(onPressed: (){
                    for(int i=0;i<widgets.length;i++){
                      if(daysList![i]==null && timeList![i] == null){
                        showToastMsg("Please Fill Details".tr);
                        return;
                      }
                    }
                   myState(() {
                     timeWidget(cardIndexValue);
                     cardIndexValue++;
                   });
                    
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColor.appThemeColorOlive
                  ),
                  child: Text("ADD".tr)
                  )
              ],),
              SizedBox(height: _size!.height*0.01),
              getTextFieldTextType("Meeting Url".tr, "Meeting Url".tr,radius: 10, controller: meetingCotroller),
               SizedBox(height: _size!.height*0.01),
              getTextFieldTextType("Description".tr, "Description".tr,radius: 10, controller: descController,maxLines: 4)
            ],
          );
          }),
          bottomNavigationBar: InkWell(
            onTap: ()async{
             
             if(titleController.text.isEmpty){
              return showToastMsg("Enter Title".tr);
             }

              List<String> time = [];
              List<String> days = [];
             if(widgets!=null && widgets.length>0){
              for(int i=0;i<widgets.length;i++){
                time.add(timeList![i]!);
                days.add(daysList![i]!);
              }
             }

             appointmentController.rscheduleAppointment(
              appointment_id: Get.arguments[0],
              quot_id: Get.arguments[1],
              job_id: Get.arguments[2],
              title: titleController.text.isNotEmpty?titleController.text:"",
              desc: descController.text.isNotEmpty?descController.text:"",
              url: meetingCotroller.text.isNotEmpty?meetingCotroller.text:"",
              preferTimeList: time,
              daysList: days,
             );
            },
            child: Container(
              padding:const EdgeInsets.all(12),
              child: CustomButton(text: "Save".tr),
            ),
          ),
        ),
       appointmentController.isLoading.value?CustomLoader():Container()
      ],
    ));
  }
List<Widget> widgets = [];
List<String?>? daysList=[];
List<String?>? timeList=[];
int cardIndexValue=1;

  timeWidget(int index){
   List<Widget> list=[];
   daysList!.add(null);
   timeList!.add(null);
   list.add(
         Container(
          padding: EdgeInsets.all(5),
          decoration: BoxDecoration(
            border: Border.all(color: AppColor.appThemeColorOlive.withOpacity(0.3))
          ),
           child: Column(
      children: [
        Container(
            decoration: BoxDecoration(
              //border: Border.all(color: AppColor.appThemeColor,width: 1),
                borderRadius: BorderRadius.circular(10)
            ),
            padding: EdgeInsets.all(1),
            child:  DropdownButtonFormField(
              decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: const BorderRadius.all(
                      const Radius.circular(10.0),
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    borderSide: BorderSide(
                      color: AppColor.appThemeColorOlive,
                      width: 1.0,
                    ),
                  ),
                  filled: true,
                  //hintStyle: TextStyle(color: ),
                  hintText:"Select Day".tr,
                  hintStyle: new TextStyle(color: Colors.grey,fontSize: 14),
                  contentPadding: EdgeInsets.all(8.0),
                  fillColor: Colors.grey.shade50),
              value: daysList![index],
              onTap: (){
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              onChanged: (value) async{
                setState(() {
                  daysList![index] = value!;
                });
              },
              items: days
                  .map((val) => DropdownMenuItem<String>(
                  value: val,
                  child: Padding(
                    padding:  EdgeInsets.all(2.0),
                    child: Text(val,style: new TextStyle(fontSize: 16),),
                  )))
                  .toList(),
            ),
        ),

        SizedBox(height: _size!.height*0.01),
        Container(
            decoration: BoxDecoration(
              //border: Border.all(color: AppColor.appThemeColor,width: 1),
                borderRadius: BorderRadius.circular(10)
            ),
            padding: EdgeInsets.all(1),
            child:  DropdownButtonFormField(
              decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: const BorderRadius.all(
                      const Radius.circular(10.0),
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    borderSide: BorderSide(
                      color: AppColor.appThemeColorOlive,
                      width: 1.0,
                    ),
                  ),
                  filled: true,
                  //hintStyle: TextStyle(color: ),
                  hintText:"Select Time".tr,
                  hintStyle: new TextStyle(color: Colors.grey,fontSize: 14),
                  contentPadding: EdgeInsets.all(8.0),
                  fillColor: Colors.grey.shade50),
              value: timeList![index],
              onTap: (){
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              onChanged: (value) async{
                setState(() {
                  timeList![index] = value!;
                });
              },
              items: times
                  .map((val) => DropdownMenuItem<String>(
                  value: val,
                  child: Padding(
                    padding:  EdgeInsets.all(2.0),
                    child: Text(val,style: new TextStyle(fontSize: 16),),
                  )))
                  .toList(),
            ),
        ),
      ],
    ),
         )
   );
   widgets.addAll(list);
   setState(() {
     
   });
  }

}