
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/views/ChatScreen/chat_proffesional.dart';
import 'package:click_pro_customer/views/ChatScreen/chat_scrreen.dart';
import 'package:click_pro_customer/views/DashBoard/dashboard_View.dart';
import 'package:click_pro_customer/views/Invoices/invoices.dart';
import 'package:click_pro_customer/views/Jobs/jobs.dart';
import 'package:click_pro_customer/views/ManageProfessionals/manage_professionals.dart';
import 'package:click_pro_customer/views/NavDrawer/nav_drawer.dart';
import 'package:click_pro_customer/views/ProfessionalList/prefessional_list.dart';
import 'package:click_pro_customer/views/Profile/edit_profile.dart';
import 'package:click_pro_customer/views/Profile/profile.dart';
import 'package:click_pro_customer/views/Quotes/quotes.dart';
import 'package:click_pro_customer/widgets/show_dialog.dart';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../res/LocalStoreage/shared)key_name.dart';
import '../../res/LocalStoreage/shared_methods.dart';
import '../../view_model/ProfileController.dart/profile_controller.dart';

class BottomNavBar extends StatefulWidget {
  int currentIndex = 0;
  BottomNavBar(this.currentIndex);
  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {

  final ProfileController profileController = Get.put(ProfileController());
  
  // String?userName;
  // String?userEmail;
  getData()async{
     await profileController.getProfile();
    // userName = await SharedMethods.getLocalStringData(key: SPKeys.USER_NAME);
    // userEmail = await SharedMethods.getLocalStringData(key: SPKeys.USER_EMAIL);

  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(seconds: 2),()=> getData());
  }

    final List<Widget> _childrens = [
        DashBoardScreen(),      
        AllJobsScreen(),
        Quotes(from: "bottom",),
        // ChatWithProfessional(from:"bottom",),
        Invoices(from: "bottom",),
        ProfileScreen(from:"bottom"),
        // CustomerScreen(),
  ];
    final scaffoldKey = GlobalKey<ScaffoldState>();
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return RefreshIndicator(
      displacement: 250,
      backgroundColor: AppColor.appThemeColorGreen,
      color: Colors.white,
      strokeWidth: 3,
      triggerMode: RefreshIndicatorTriggerMode.onEdge,
      onRefresh: () async {
          
      },
      child: SafeArea(
        child: Scaffold(
           key: scaffoldKey,
        drawer: NavDrawer(userEmail: profileController.profileData!=null && ![null,""].contains(profileController.profileData!.email!)?profileController.profileData!.email!:"" ,userName: profileController.profileData!=null && ![null,""].contains(profileController.profileData!.name!)?profileController.profileData!.name!:"",),
          body: Column(
            children: [
              SizedBox(height: _size!.height*0.02),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                   if(widget.currentIndex==0 || widget.currentIndex==1 ||  widget.currentIndex==2 || widget.currentIndex==3)
                    InkWell(
                       onTap: (){
                     scaffoldKey.currentState!.openDrawer();
                     setState(() {
                       
                     });
                      },
                      child: Image.asset("assets/icons/menu.png", height: 25)
                    ),
                   


                    /// for current index 0
                    if(widget.currentIndex==0)
                    profileController.profileData!=null && ![null,""].contains(profileController.profileData!.cityName!)?
                    Expanded(
                      child: GestureDetector(
                        onTap: (){
                         navigateWithPageTransition(context, EditProfile(profileData: profileController.profileData));
                        },
                        child: Row(
                        children: [
                        const SizedBox(width: 15,),
                        Text(profileController.profileData!.cityName!,style: AppTextStyles.k14TextN),
                        Icon(Icons.keyboard_arrow_down, color: Colors.grey,),
                         ],
                       ),
                      ),
                    ):Container(),

                      // for currentIndex 1
                    if(widget.currentIndex==1)
                    Text("POSTED JOBS".tr,style: AppTextStyles.k16TextN,),
                    
                     // for current Index 2
                     if(widget.currentIndex==2)
                    Text("QUOTES".tr,style: AppTextStyles.k16TextN,),

                    // for current Index 3
                     if(widget.currentIndex==3)
                    Text("INVOICES".tr,style: AppTextStyles.k16TextN,),
                      if(widget.currentIndex==0 || widget.currentIndex==1 || widget.currentIndex==2 || widget.currentIndex==3 )
                    InkWell(
                      onTap: (){
                           navigateWithPageTransition(context, ProfileScreen());
                      },
                      child: Container(
                        height: 30,
                        padding:const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          //border: Border.all(color: AppColor.appThemeColorOlive)
                          color: AppColor.appThemeColorOlive
                        ),
                        child:const Icon(Icons.person, color:Colors.white),
                       ),
                      ),

                    //  if(widget.currentIndex==1 || widget.currentIndex==2 || widget.currentIndex==3)
                    //  const Icon(Icons.more_vert),

                  ],
                ),
              ),
              Expanded(child: _childrens[widget.currentIndex]),
            ],
          ),
          bottomNavigationBar: Theme(
            data: Theme.of(context).copyWith(
              canvasColor:   Colors.white,  //AppColor.appThemeColor
            ),
            child: WillPopScope(
              onWillPop: _onBackButtonPressed,
              child: Container(
                height: 60.0,
                child: BottomNavigationBar(
                    showSelectedLabels: true,
                    showUnselectedLabels: false,
                    selectedItemColor: AppColor.appThemeColorOrange,
                    unselectedItemColor: Colors.black45,
                  
                    onTap: onTabTapped,
                    currentIndex: widget.currentIndex,
                    items: const [
                      BottomNavigationBarItem(
                        icon: Padding(
                          padding: EdgeInsets.only(bottom: 3),
                          child: ImageIcon(
                           AssetImage("assets/icons/home.png"),
                           size:20,
                           ),
                        ),
                        label:'Maison', //'Home',
                      ),
                      BottomNavigationBarItem(
                        icon: Padding(
                          padding: EdgeInsets.only(bottom: 3),
                          child: ImageIcon(
                           AssetImage("assets/icons/job.png"),
                           size:20,
                           ),
                        ),
                        label: 'Emplois',//'Jobs',
                      ),
                      BottomNavigationBarItem(
                        icon: Padding(
                          padding: EdgeInsets.only(bottom: 3),
                          child: ImageIcon(
                           AssetImage("assets/icons/bag.png"),
                           size:20,
                           ),
                        ),
                        label:'Citations',// 'Quotes',
                      ),
                      BottomNavigationBarItem(
                        icon: Padding(
                          padding: EdgeInsets.only(bottom: 3),
                          child: ImageIcon(
                           AssetImage("assets/icons/medal.png"),
                           size:20,
                           ),
                        ),
                        label:'Factures',// 'Professionals',
                      ),
                      // BottomNavigationBarItem(
                      //   icon: Icon(Icons.shopping_bag),
                      //   label: 'Orders',
                      // ),
                      
                      
                      BottomNavigationBarItem(
                        icon: Padding(
                          padding: EdgeInsets.only(bottom: 3),
                          child: ImageIcon(
                           AssetImage("assets/icons/user.png"),
                           size:20,
                           ),
                        ),
                        label:'Profil',// 'Profile',
                      ),
                    ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
    Future<bool> _onBackButtonPressed() async {
    bool request = await showDialog(
        context: context,
        builder: ((context) {
          return ShowDialogsss().exitDialog(context);
        }));

    return request;
  }

  void onTabTapped(int index) {
    setState(() {
      widget.currentIndex = index;
    });
  }
}