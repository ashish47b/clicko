import 'package:easy_localization/easy_localization.dart';

var formatter = new DateFormat('dd-MM-yyyy HH:mm');
var formatterWithSeconds = new DateFormat('dd-MM-yyyy HH:mm:aa');
var onlyDateFormatter = new DateFormat('dd-MM-yyyy');
var dateMotnhFormatter = new DateFormat('dd-MMM-yyyy');
var yyMMddDateFormatter = new DateFormat('yyyy-MM-dd');
var ddMMMyyyy = new DateFormat('dd-MMM-yyyy');