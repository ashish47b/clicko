import 'package:shared_preferences/shared_preferences.dart';

class SharedMethods {
 
   // save methods 

   static saveLocalStringData({String?key, String?value})async {
     SharedPreferences sp = await SharedPreferences.getInstance();
     var saveValue = sp.setString(key!, value!);
   }



   // get methods 
    static getLocalStringData({String?key,})async {
     SharedPreferences sp = await SharedPreferences.getInstance();
     if(sp.getString(key!)!=null)
       return sp.getString(key);
      else 
      return null;
    }

    // remove methods
    static removeSharedData({String?key})async{
      SharedPreferences sp = await SharedPreferences.getInstance();
      var removeValue = await sp.remove(key!);
      
    }

}