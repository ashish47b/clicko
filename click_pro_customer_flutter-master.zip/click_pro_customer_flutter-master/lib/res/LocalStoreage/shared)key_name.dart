class SPKeys{
  

  static const String USER_ID = "user_id";
  static const String USER_TOKEN = "user_token";
  static const String USER_EMAIL = "user_email";
  static const String USER_PHONE = "user_phone";
  static const String USER_VERIFY = "user_verify";
  static const String USER_NAME = "user_name";

}