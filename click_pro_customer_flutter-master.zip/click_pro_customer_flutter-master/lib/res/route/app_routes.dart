import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/view_model/AuthController/gen_otp_controller.dart';
import 'package:click_pro_customer/view_model/AuthController/login_controller.dart';
import 'package:click_pro_customer/view_model/AuthController/register_controller.dart';
import 'package:click_pro_customer/view_model/AuthController/verifyAccount_controller.dart';
import 'package:click_pro_customer/view_model/BiddersController/bidders_controller.dart';
import 'package:click_pro_customer/view_model/SplashController/splash_controller.dart';

import 'package:click_pro_customer/views/AppointmentPage/appointment_page.dart';

import 'package:click_pro_customer/views/AppointmentPage/appointment_view.dart';
import 'package:click_pro_customer/views/AppointmentPage/reschedult_appointment.dart';
import 'package:click_pro_customer/views/Auth/login.dart';
import 'package:click_pro_customer/views/Auth/register.dart';
import 'package:click_pro_customer/views/Auth/verify_otp.dart';
import 'package:click_pro_customer/views/Bidders/bidders_list.dart';
import 'package:click_pro_customer/views/Bidders/negotiation_page.dart';
import 'package:click_pro_customer/views/BottomNavBar/bottomNavbar.dart';
import 'package:click_pro_customer/views/ChatScreen/chat_proffesional.dart';
import 'package:click_pro_customer/views/ChatScreen/chat_scrreen.dart';
import 'package:click_pro_customer/views/Invoices/invoice_details.dart';
import 'package:click_pro_customer/views/Invoices/invoices.dart';
import 'package:click_pro_customer/views/Jobs/jobs.dart';

import 'package:click_pro_customer/views/Jobs/view_jobs.dart';
import 'package:click_pro_customer/views/OnBoardPage/onboard_page.dart';
import 'package:click_pro_customer/views/Postjobs/post_jobs_page.dart';
import 'package:click_pro_customer/views/ProfessionalList/professional_details.dart';
import 'package:click_pro_customer/views/Profile/edit_profile.dart';
import 'package:click_pro_customer/views/Profile/profile.dart';
import 'package:click_pro_customer/views/Quotes/quotes.dart';
import 'package:click_pro_customer/views/Quotes/view_quotes.dart';
import 'package:click_pro_customer/views/Splash/splash_screen.dart';
import 'package:click_pro_customer/views/Sponsership/add-sponsership.dart';
import 'package:click_pro_customer/views/Sponsership/list_sponsorship.dart';
import 'package:click_pro_customer/views/Sponsership/sponsorship.dart';
import 'package:click_pro_customer/widgets/Account_verify_dialog.dart';
import 'package:click_pro_customer/widgets/image_preview.dart';
import 'package:click_pro_customer/widgets/payment_success_view.dart';
import 'package:click_pro_customer/widgets/verify_success.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:page_transition/page_transition.dart';

class AppRoutes {

   static appRoutes () => [
    GetPage(name: RoutesName.splashView, page: (() => SplashScreen())),
    GetPage(name: RoutesName.onBoardView, page: (() => OnBoardPage()),),
    GetPage(name: RoutesName.loginView, page: (() => UserLogin()),binding: RootBinding()),
    GetPage(name: RoutesName.signUpView, page: (() => UserRegister()),binding: RootBinding()),
    GetPage(name: RoutesName.dashboardView, page: (() => BottomNavBar(0))),
    GetPage(name: RoutesName.postJobsView, page: (() => PostJobs()), transition: Transition.rightToLeftWithFade,transitionDuration: Duration(milliseconds: 500)),
    GetPage(name: RoutesName.professionalView, page: (() => ProfessionalProfilePage()), transition: Transition.rightToLeftWithFade,transitionDuration: Duration(milliseconds: 300)),
    GetPage(name: RoutesName.chatView, page: (() => ChatScreen()), transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.allJobsView, page: (() => AllJobsScreen()), transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.invoiceListView, page: (() => Invoices()), transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.invoiceDetails, page: (() => InvoiceDetails()), transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.appointmentPage, page: (() => AppointmentPage()), transition: Transition.rightToLeftWithFade),

    GetPage(name: RoutesName.sponsorshipListView, page: (() => Sponsorship()), transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.addSponsorshipView, page: (() => AddSponsership()), transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.profileView, page: (() => ProfileScreen()), transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.verifyAccount, page: (() => VerifyOTP()), transition: Transition.rightToLeftWithFade,binding: RootBinding()),
    GetPage(name: RoutesName.successVerifyView, page: (() => VerifySuccessWidget())),
    GetPage(name: RoutesName.verifyDialog, page: (() => AccountVerifyDialog()), binding:RootBinding()),
    GetPage(name: RoutesName.bidderView, page: (()=> BiddersList()),transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.view_job, page: (()=> ViewJobs()),transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.image_previewView, page: (() => ImagePreviewScreen())),
    GetPage(name: RoutesName.view_quotes, page: (()=> ViewQuotes()),transition: Transition.rightToLeftWithFade),
     GetPage(name: RoutesName.appointment_view, page: (()=> AppointmentViewPage()),transition: Transition.rightToLeftWithFade),
   GetPage(name: RoutesName.edit_view, page: (()=> EditProfile()),transition: Transition.rightToLeftWithFade),
   GetPage(name: RoutesName.reschedule_View, page: (()=> ReschedultAppointment()),transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.negotiation_view, page: (()=> NegotiationPage()),transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.quote_page, page: (()=> Quotes()),transition: Transition.rightToLeftWithFade),
    GetPage(name: RoutesName.chat_users_view, page: (()=> ChatWithProfessional())),
    GetPage(name: RoutesName.payment_success_view, page: (()=> PaymentSuccessView())),

   ];

}

class RootBinding extends Bindings{
 @override
 void dependencies() {
  //Get.lazyPut(() => SplashController());
  Get.lazyPut(() => RegisterController());
  Get.lazyPut(() => VerifyAccountController());
  Get.lazyPut(() => LoginController());
  Get.lazyPut(() => GenerateOtpController());
 // Get.lazyPut(() => BidderController());

 
 }
}