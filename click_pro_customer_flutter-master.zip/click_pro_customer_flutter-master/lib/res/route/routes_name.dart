class RoutesName{
   
   static const String splashView = "/";
   static const String onBoardView = "/onBoard_view";
   static const String loginView = "/login_view";
   static const String signUpView = "/sign_view";
   static const String dashboardView = "/dashboard_view";
   static const String postJobsView = "/post_jobs_view";
   static const String professionalView="/professional_view";
   static const String joDetailsView = "/jobdetails_view";
   static const String chatView = "/chatView";
   static const String totalSpentView = "/totalSpent_view";
   static const String allJobsView = "/allJobs_view";
   static const String invoiceListView = "/invoiceList_view";
   static const String invoiceDetails = "/invoiceDetails_view";
   static const String appointmentPage = "/appointment_view";
   static const String appointmentUserView = "/appointmentUser_view";

   static const String sponsorshipListView = "/sponsorshipList_view";
   static const String addSponsorshipView = "/addSponsorship_view";
   static const String profileView = "/profile_view";
   static const String verifyAccount = "/verify_account";
   static const String successVerifyView = "/success_verify";
   static const String verifyDialog = "/verify_dialog";
   static const String bidderView = "/jobbidder_view";
   static const String view_job = "/view_job";
   static const String image_previewView = "/image_preview";
   static const String view_quotes = "/view_quotes";
   static const String appointment_view = "/appoint_view";
   static const String edit_view = "/edit_view";
   static const String reschedule_View = "/reschedule_view";
  static const String negotiation_view = "/negotiation_view";
  static const String quote_page = "/quote_page";
  static const String chat_users_view = "/chat_users_view";
  static const String payment_success_view = "/payment_success_view";




}