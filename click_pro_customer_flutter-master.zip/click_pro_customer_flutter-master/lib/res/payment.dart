import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/view_model/BiddersController/bidders_controller.dart';

import 'package:flutter/material.dart';

import 'package:flutter_paypal/flutter_paypal.dart';
import 'package:get/get.dart';

import '../utils/app_color.dart';

class PayPal extends StatefulWidget {
  String?from;
  String?amount;
  String?quoteID;String?jobID;String?negoID;
  String?payCount;
  String?prof_id;
  PayPal({this.from,this.amount,this.quoteID,this.jobID,this.negoID,this.payCount,this.prof_id});

  @override
  State<PayPal> createState() => _PayPalState();
}

class _PayPalState extends State<PayPal> {
  
  final BidderController controller = Get.put(BidderController());


  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Center(
      child: Container(
      margin:const EdgeInsets.symmetric(horizontal: 20),
      padding:const EdgeInsets.symmetric(vertical: 20),
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12)
      ),
      child: Wrap(
        children: [
          Center(
            child: Container(
              height: 100,
              child: Image.asset("assets/images/paypal.png"),
            ),
          ),
          SizedBox(height: _size!.height*0.015),
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
               Padding(
                 padding: const EdgeInsets.all(8.0),
                 child: Center(child: Text("Total Amount (Including Taxes)",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive,fontWeight: FontWeight.bold))),
               ),
          SizedBox(height: _size!.height*0.01),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(child: Text(widget.amount!,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange,fontWeight: FontWeight.bold))),
          ),
            ],
          ),
         
         // SizedBox(height: _size!.height*0.15,),
          Center(
            child: ElevatedButton(onPressed: (){
             // double? toalAmount = double.parse(obj.quot!.estimatePrice!);
              Navigator.push(context, MaterialPageRoute(builder: (context)=> UsePaypal(
                              sandboxMode: true,
                              
                              // for normal test
                              //clientId:"AW1TdvpSGbIM5iP4HJNI5TyTmwpY9Gv9dYw8_8yW5lYIbCqf326vrkrp0ce9TAqjEGMHiV3OqJM_aRT0",
                              //secretKey:"EHHtTDjnmTZATYBPiGzZC_AZUfMpMAzj2VZUeqlFUrRJA_C0pQNCxDccB5qoRQSEdcOnnKQhycuOWdP9",

                              // click o pro test account
                              clientId:"Af8zmf679WHG81fwuTZtX28NonuLEjeggRS9-INtLl-0ha8F-TolzVc-HDyDRHj6rQJLNh8wx4FGHOTJ",
                              secretKey:"EDn7f9xwmRwnlWKu5GF8-GgMKgwkHqHSE8NoXkcQ1EYuDX4WJQzpa7P-SZUQoqaTwAC7K_zZNlnnQyRO",

                              // // click o pro live account
                              // clientId:"Ab7waqXwdsqZ3m6JnFdrWGYu98ZNXHphyRz7vWikhYeee2jqCFCN6wcElPqv99uDCwWSiHYutdgM1g-5",
                              // secretKey:"EMlsoovW8J96aqKoz9VBYZ64UNUzvs2VUVHF1k5NMggRvV9d2iGPdbozB_aYyNju6gjmatpzlhxzsJGX",

                              returnURL: "https://samplesite.com/return",
                              cancelURL: "https://samplesite.com/cancel",
                              transactions:  [
                                {
                                  "amount": {
                                    "total":widget.amount,
                                    "currency": "USD",
                                    "details": {
                                      "subtotal": widget.amount,
                                      "shipping": '0',
                                      "shipping_discount": 0
                                    }
                                  },
                                }
                              ],
                              note: "Contact us for any questions on your order.",
                              onSuccess: (Map params) async {
                                var data = params["paymentId"];
                                print("PAYMENT ID" +  data);
                                print("onSuccess: $params");
                                controller.saveDepositApi(
                                  context,
                                    payment_id: data,
                                    paymentStatus: "Complete",
                                    paymentDate: DateTime.now().toString(),
                                    negoID:widget.negoID,
                                    job_id: widget.jobID,
                                    quote_id: widget.quoteID,
                                    pay_count: widget.payCount,
                                    amount: widget.amount,
                                    prof_id: widget.prof_id,
                                  );
                              },
                              onError: (error) {
                                showToastMsg("Payment Not Successful, Try Again".tr);
                                  print('error: $error');
                              },
                              onCancel: (params) {
                                  showToastMsg("Payment Cancelled, Try Again".tr);
                                print('cancelled: $params');
                              }),
              ));
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColor.appThemeColorGreen
            ),
              child: Text("Pay".tr,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)),
          )
        ],
      ),
    ),
  );
  }
}