class API{

   static const String BASE_URL = "https://clikopro.fr/api/";

   static const String LOG_IN =BASE_URL + "auth/login";
   static const String REGISTER = BASE_URL + "auth/register";
   static const String VERIFY_ACCOUNT = BASE_URL + "auth/verify_account";
   static const String GENERATE_OTP  = BASE_URL + "auth/generate_otp";
   static const String ALL_CATEGORIES = BASE_URL + "home/get_active_cat";
   static const String GET_CITY = BASE_URL + "home/get_active_city";
   static const String PROFILE = BASE_URL + "home/profile";
   static const String SAVE_PROFILE = BASE_URL + "home/updateprofile";
   static const String SAVE_JOB = BASE_URL + "jobs/save_jobs";
   static const String PENDING_JOBS = BASE_URL + "jobs/pending_jobs";
   static const String ACTIVE_JOBS = BASE_URL +"jobs/active_jobs";
   static const String COMPLETE_JOBS = BASE_URL + "jobs/complete_jobs";
   static const String HIRED_JOBS = BASE_URL + "jobs/hiring_jobs";
   static const String ACTIVATE_JOBS = BASE_URL + "jobs/pendingtoactivejob";
   static const String BIDDERS_LIST = BASE_URL + "jobs/manage_bids";
   static const String VIEW_JOBS = BASE_URL + "jobs/view_jobs";
   static const String REJECT_BID = BASE_URL + "jobs/rejected_bid";
   static const String APPROVED_BID = BASE_URL + "jobs/approved_bid";
   static const String PROFF_PROFILE = BASE_URL + "jobs/view_professional_profile";
   static const String GET_PROF_RATINGS = BASE_URL + "jobs/getProfRating";
   static const String MARK_COMPLETE = BASE_URL + "jobs/markascomplete";
   static const String CHECK_PAYMENT = BASE_URL + "jobs/checkpayment";
   static const String PENDING_QUOTE = BASE_URL + "quotation/pending_quote";
   static const String ACTIVE_QUOTES = BASE_URL + "quotation/active_quote";
   static const String REJECT_QUOTES = BASE_URL + "quotation/rejected_quote";
   static const String VIEW_QUOTES = BASE_URL + "quotation/view_quote";
   static const String TODAY_APPOINTMENT = BASE_URL + "home/today_appointment";
   static const String ALL_APPOINTMENTS = BASE_URL + "home/all_appointment";
   static const String PREVIOUS_APPOINTMENT = BASE_URL +"home/previous_appointment";
   static const String VIEW_APPOINTMENT = BASE_URL + "home/view_appointment";
   static const String ADD_CHAT_MESSAGE = BASE_URL + "home/addmessage";
   static const String ALL_CHAT_MESSAGE = BASE_URL + "home/allmessages";
   static const String CHAT_USER = BASE_URL + "home/userlist";
   static const String INVOICE_LIST = BASE_URL + "home/invoicelistCus";
   static const String INVOICE_VIEW = BASE_URL + "home/viewinvoice";
   static const String GET_SINGLE_JOB = BASE_URL + "jobs/edit_jobs";
   static const String RESCHEDULT_APPOINTMENT = BASE_URL + "home/reseduleappointment";
   static const String NO_OF_TIME_YOU_HIRED = BASE_URL  + "jobs/numberOfTimeYouAreHired";
   static const String NEGOTIATION_LIST = BASE_URL + "jobs/negotiation";
   static const String DEACTIVATE_JOB = BASE_URL + "home/deactivatejob";
   static const String DELETE_JOB = BASE_URL + "home/deletejobs";
   static const String SAVE_MILESTONE = BASE_URL + "Jobs/save_milestone";
   static const String SAVE_DEPOSIT = BASE_URL + "Jobs/customer_paid_status";
   static const String PAY_DEPOSIT = BASE_URL + "Jobs/approve_status_pro";
   static const String LOG_OUT = BASE_URL + "auth/logout";
   static const String RESEND_OTP = BASE_URL + "auth/resend_otp";
   static const String CUS_SEARCH_PRO = BASE_URL + "home/cus_search_pro";

}