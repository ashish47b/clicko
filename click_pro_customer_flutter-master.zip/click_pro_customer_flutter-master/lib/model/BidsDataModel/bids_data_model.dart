class BidsDataModel {
  String? status;
  int? totalbid;
  List<Bidders>? bidders;

  BidsDataModel({this.status, this.totalbid, this.bidders});

  BidsDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    totalbid = json['totalbid'];
    if (json['bidders'] != null) {
      bidders = <Bidders>[];
      json['bidders'].forEach((v) {
        bidders!.add(new Bidders.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['totalbid'] = this.totalbid;
    if (this.bidders != null) {
      data['bidders'] = this.bidders!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Bidders {
  String? id;
  String? showHomePage;
  String? userId;
  String? firstName;
  String? lastName;
  String? email;
  String? password;
  String? gender;
  String? profDeviceToken;
  String? idProofAttachment;
  String? contactNumber;
  String? profilePic;
  String? profilePicPath;
  String? description;
  String? cityId;
  String? address;
  String? proofAcceptTravelCity;
  String? website;
  String? categoryDetails;
  String? workHistory;
  String? previousWorkAttachment;
  String? previousWorkAttachmentPath;
  String? subscriptionPlanId;
  String? certificate;
  String? certificatePath;
  String? companyDetails;
  String? sirenOrSiretNo;
  String? rcsNo;
  String? vat;
  String? jobDone;
  String? status;
  String? approvedBy;
  String? createdDate;
  String? updatedDate;
  User? user;
  Quot? quot;

  Bidders(
      {this.id,
      this.showHomePage,
      this.userId,
      this.firstName,
      this.lastName,
      this.email,
      this.password,
      this.gender,
      this.profDeviceToken,
      this.idProofAttachment,
      this.contactNumber,
      this.profilePic,
      this.profilePicPath,
      this.description,
      this.cityId,
      this.address,
      this.proofAcceptTravelCity,
      this.website,
      this.categoryDetails,
      this.workHistory,
      this.previousWorkAttachment,
      this.previousWorkAttachmentPath,
      this.subscriptionPlanId,
      this.certificate,
      this.certificatePath,
      this.companyDetails,
      this.sirenOrSiretNo,
      this.rcsNo,
      this.vat,
      this.jobDone,
      this.status,
      this.approvedBy,
      this.createdDate,
      this.updatedDate,
      this.user,
      this.quot});

  Bidders.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    showHomePage = json['show_home_page'];
    userId = json['user_id'];
    firstName = json['first_name']!=null?json['first_name'].toString():"";
    lastName = json['last_name']!=null?json['last_name'].toString():"";
    email = json['email']!=null?json['email'].toString():"";
    password = json['password'];
    gender = json['gender']!=null?json['first_name'].toString():"";
    profDeviceToken = json['prof_device_token'];
    idProofAttachment = json['id_proof_attachment'];
    contactNumber = json['contact_number']!=null?json['contact_number'].toString():"";
    profilePic = json['profile_pic']!=null?json['profile_pic'].toString():"";
    profilePicPath = json['profile_pic_path']!=null?json['profile_pic_path'].toString():"";
    description = json['description']!=null?json['description'].toString():"";
    cityId = json['city_id']!=null?json['city_id'].toString():"";
    address = json['address']!=null?json['address'].toString():"";
    proofAcceptTravelCity = json['proof_accept_travel_city']!=null?json['proof_accept_travel_city'].toString():"";
    website = json['website']!=null?json['website'].toString():"";
    categoryDetails = json['category_details']!=null?json['category_details'].toString():"";
    workHistory = json['work_history']!=null?json['work_history'].toString():"";
    previousWorkAttachment = json['previous_work_attachment']!=null?json['previous_work_attachment'].toString():"";
    previousWorkAttachmentPath = json['previous_work_attachment_path']!=null?json['previous_work_attachment_path'].toString():"";
    subscriptionPlanId = json['subscription_plan_id']!=null?json['subscription_plan_id'].toString():"";
    certificate = json['certificate']!=null?json['certificate'].toString():"";
    certificatePath = json['certificate_path']!=null?json['certificate_path'].toString():"";
    companyDetails = json['company_details']!=null?json['company_details'].toString():"";
    sirenOrSiretNo = json['siren_or_siret_no'];
    rcsNo = json['rcs_no'];
    vat = json['vat'];
    jobDone = json['job_done']!=null?json['job_done'].toString():"";
    status = json['status'];
    approvedBy = json['approved_by'];
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
    quot = json['quot'] != null ? new Quot.fromJson(json['quot']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['show_home_page'] = this.showHomePage;
    data['user_id'] = this.userId;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['email'] = this.email;
    data['password'] = this.password;
    data['gender'] = this.gender;
    data['prof_device_token'] = this.profDeviceToken;
    data['id_proof_attachment'] = this.idProofAttachment;
    data['contact_number'] = this.contactNumber;
    data['profile_pic'] = this.profilePic;
    data['profile_pic_path'] = this.profilePicPath;
    data['description'] = this.description;
    data['city_id'] = this.cityId;
    data['address'] = this.address;
    data['proof_accept_travel_city'] = this.proofAcceptTravelCity;
    data['website'] = this.website;
    data['category_details'] = this.categoryDetails;
    data['work_history'] = this.workHistory;
    data['previous_work_attachment'] = this.previousWorkAttachment;
    data['previous_work_attachment_path'] = this.previousWorkAttachmentPath;
    data['subscription_plan_id'] = this.subscriptionPlanId;
    data['certificate'] = this.certificate;
    data['certificate_path'] = this.certificatePath;
    data['company_details'] = this.companyDetails;
    data['siren_or_siret_no'] = this.sirenOrSiretNo;
    data['rcs_no'] = this.rcsNo;
    data['vat'] = this.vat;
    data['job_done'] = this.jobDone;
    data['status'] = this.status;
    data['approved_by'] = this.approvedBy;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    if (this.user != null) {
      data['user'] = this.user!.toJson();
    }
    if (this.quot != null) {
      data['quot'] = this.quot!.toJson();
    }
    return data;
  }
}

class User {
  String? name;
  String? email;
  String? phone;

  User({this.name, this.email, this.phone});

  User.fromJson(Map<String, dynamic> json) {
    name = json['name']!=null?json['name'].toString():"";
    email = json['email']!=null?json['email'].toString():"";
    phone = json['phone']!=null?json['phone'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['email'] = this.email;
    data['phone'] = this.phone;
    return data;
  }
}

class Quot {
  String? estimatePrice;
  String? grandTotal;
  String? grandTotalEstimatePrice;
  String? id;
  String?instalment_plan;
  String?work_start_date;
  String?work_end_date;
  Quot(
      {this.estimatePrice,
      this.grandTotal,
      this.grandTotalEstimatePrice,
      this.id,
      this.instalment_plan,this.work_end_date,this.work_start_date
      });

  Quot.fromJson(Map<String, dynamic> json) {
    estimatePrice = json['estimate_price']!=null?json['estimate_price'].toString():"";
    grandTotal = json['grand_total']!=null?json['grand_total'].toString():"";
    grandTotalEstimatePrice = json['grand_total_estimate_price']!=null?json['grand_total_estimate_price'].toString():"";
    id = json['id'];
    work_end_date = json['work_end_date']!=null?json['work_end_date'].toString():"";
    work_start_date = json['work_start_date']!=null?json['work_start_date'].toString():"";
    instalment_plan = json['instalment_plan']!=null?json['instalment_plan'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['estimate_price'] = this.estimatePrice;
    data['grand_total'] = this.grandTotal;
    data['grand_total_estimate_price'] = this.grandTotalEstimatePrice;
    data['id'] = this.id;
    data['instalment_plan'] = this.instalment_plan;
    data['work_start_date'] = this.work_start_date;
    data['work_end_date'] = this.work_end_date;
    return data;
  }
}