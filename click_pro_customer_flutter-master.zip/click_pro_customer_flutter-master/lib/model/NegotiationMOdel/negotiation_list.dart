class NegotiationListDataModel {
  String? status;
  Quot? quot;
  Job? job;
  List<Negotiation>? negotiation;

  NegotiationListDataModel(
      {this.status, this.quot, this.job, this.negotiation});

  NegotiationListDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    quot = json['quot'] != null ? new Quot.fromJson(json['quot']) : null;
    job = json['job'] != null ? new Job.fromJson(json['job']) : null;
    if (json['negotiation'] != null) {
      negotiation = <Negotiation>[];
      json['negotiation'].forEach((v) {
        negotiation!.add(new Negotiation.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.quot != null) {
      data['quot'] = this.quot!.toJson();
    }
    if (this.job != null) {
      data['job'] = this.job!.toJson();
    }
    if (this.negotiation != null) {
      data['negotiation'] = this.negotiation!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Quot {
  String? id;
  String? estimatePrice;
  String? grandTotalEstimatePrice;
  String? customerNegotiationCount;
  String? professionalNegotiationCount;
  String? instalmentPlan;
  String? jobId;
  String?pay_count;

  Quot(
      {this.id,
      this.estimatePrice,
      this.grandTotalEstimatePrice,
      this.customerNegotiationCount,
      this.professionalNegotiationCount,
      this.instalmentPlan,
      this.jobId,
      this.pay_count,
      });

  Quot.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    estimatePrice = json['estimate_price']!=null?json['estimate_price'].toString():"";
    grandTotalEstimatePrice = json['grand_total_estimate_price']!=null?json['grand_total_estimate_price'].toString():"0";
    customerNegotiationCount = json['customer_negotiation_count']!=null?json['customer_negotiation_count'].toString():"";
    professionalNegotiationCount = json['professional_negotiation_count']!=null?json['professional_negotiation_count'].toString():"";
    instalmentPlan = json['instalment_plan']!=null?json['instalment_plan'].toString():"";
    jobId = json['job_id'];
    pay_count = json['pay_count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['estimate_price'] = this.estimatePrice;
    data['grand_total_estimate_price'] = this.grandTotalEstimatePrice;
    data['customer_negotiation_count'] = this.customerNegotiationCount;
    data['professional_negotiation_count'] = this.professionalNegotiationCount;
    data['instalment_plan'] = this.instalmentPlan;
    data['job_id'] = this.jobId;
    data['pay_count'] = this.pay_count;
    return data;
  }
}

class Job {
  String? id;
  String? jobTitle;

  Job({this.id, this.jobTitle});

  Job.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    jobTitle = json['job_title']!=null?json['job_title'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['job_title'] = this.jobTitle;
    return data;
  }
}

class Negotiation {
  String? id;
  String? paymentId;
  String? deffDays;
  String? paymentDueDate;
  String? amount;
  String? paymentStatus;
  String? paymentApprovedStatus;
  String? quotId;
  String? jobId;
  String? custId;
  String? profId;
  String? customerPaymentDate;
  String? professionalPadStatus;
  String? professionalPaidAmount;
  String? professionalPadId;
  String? createdDate;
  String? professionalPaidDate;
  String? updatedDate;
  String?admin_cus_commission;
  String?admin_cus_per;
  String?approve_status_pro;

  Negotiation(
      {this.id,
      this.paymentId,
      this.deffDays,
      this.paymentDueDate,
      this.amount,
      this.paymentStatus,
      this.paymentApprovedStatus,
      this.quotId,
      this.jobId,
      this.custId,
      this.profId,
      this.customerPaymentDate,
      this.professionalPadStatus,
      this.professionalPaidAmount,
      this.professionalPadId,
      this.createdDate,
      this.professionalPaidDate,
      this.admin_cus_commission,
      this.admin_cus_per,
      this.approve_status_pro,
      this.updatedDate});

  Negotiation.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    paymentId = json['payment_id']!=null?json['payment_id'].toString():"";
    deffDays = json['deff_days']!=null?json['deff_days'].toString():"0";
    paymentDueDate = json['payment_due_date']!=null?json['payment_due_date'].toString():"";
    amount = json['amount']!=null?json['amount'].toString():"";
    paymentStatus = json['payment_status']!=null?json['payment_status'].toString():"";
    paymentApprovedStatus = json['payment_approved_status']!=null?json['payment_approved_status'].toString():"";
    quotId = json['quot_id']!=null?json['quot_id'].toString():"";
    jobId = json['job_id']!=null?json['job_id'].toString():"";
    custId = json['cust_id']!=null?json['cust_id'].toString():"";
    profId = json['prof_id']!=null?json['prof_id'].toString():"";
    customerPaymentDate = json['customer_payment_date']!=null?json['customer_payment_date'].toString():"";
    professionalPadStatus = json['professional_pad_status']!=null?json['professional_pad_status'].toString():"";
    professionalPaidAmount = json['professional_paid_amount']!=null?json['professional_paid_amount'].toString():"";
    professionalPadId = json['professional_pad_id']!=null?json['professional_pad_id'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    professionalPaidDate = json['professional_paid_date']!=null?json['professional_paid_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
    admin_cus_commission = json['admin_cus_commission']!=null?json['admin_cus_commission'].toString():"0";
    admin_cus_per = json['admin_cus_per']!=null?json['admin_cus_per'].toString():"";
    approve_status_pro = json['approve_status_pro']!=null?json['approve_status_pro'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['payment_id'] = this.paymentId;
    data['deff_days'] = this.deffDays;
    data['payment_due_date'] = this.paymentDueDate;
    data['amount'] = this.amount;
    data['payment_status'] = this.paymentStatus;
    data['payment_approved_status'] = this.paymentApprovedStatus;
    data['quot_id'] = this.quotId;
    data['job_id'] = this.jobId;
    data['cust_id'] = this.custId;
    data['prof_id'] = this.profId;
    data['customer_payment_date'] = this.customerPaymentDate;
    data['professional_pad_status'] = this.professionalPadStatus;
    data['professional_paid_amount'] = this.professionalPaidAmount;
    data['professional_pad_id'] = this.professionalPadId;
    data['created_date'] = this.createdDate;
    data['professional_paid_date'] = this.professionalPaidDate;
    data['updated_date'] = this.updatedDate;
    data['admin_cus_commission'] = this.admin_cus_commission;
    data['admin_cus_per'] = this.admin_cus_per;
    data['approve_status_pro'] = this.approve_status_pro;
    return data;
  }
}