import 'dart:convert';

class ViewJobDataModel {
  String? status;
  String? message;
  ViewJobData? data;

  ViewJobDataModel({this.status, this.message, this.data});

  ViewJobDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new ViewJobData.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class ViewJobData {
  String? id;
  String? showHomePage;
  String? custId;
  String? jobTitle;
  String? category;
  String? subcategory;
  String? tags;
  String? location;
  String? description;
  String? price;
  String? attachment;
  String? attachmentPath;
  String? status;
  String? bidCount;
  String? bidAppliedPropfessional;
  String? bidRejectedPropfessional;
  String? rejectedBid;
  String? remarksByProf;
  String? markedDone;
  String? startDate;
  String? dueDate;
  String? hiredDate;
  String? completionDate;
  String? professionalFeedback;
  String? professionalRating;
  String? professionalId;
  String? payAmount;
  String? paymentStatus;
  String? createdDate;
  String? updatedDate;
  List<String> attachmentsList=[];

  ViewJobData(
      {this.id,
      this.showHomePage,
      this.custId,
      this.jobTitle,
      this.category,
      this.subcategory,
      this.tags,
      this.location,
      this.description,
      this.price,
      this.attachment,
      this.attachmentPath,
      this.status,
      this.bidCount,
      this.bidAppliedPropfessional,
      this.bidRejectedPropfessional,
      this.rejectedBid,
      this.remarksByProf,
      this.markedDone,
      this.startDate,
      this.dueDate,
      this.hiredDate,
      this.completionDate,
      this.professionalFeedback,
      this.professionalRating,
      this.professionalId,
      this.payAmount,
      this.paymentStatus,
      this.createdDate,
      this.updatedDate});

  ViewJobData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    showHomePage = json['show_home_page'];
    custId = json['cust_id'];
    jobTitle = json['job_title']!=null?json['job_title'].toString():"";
    category = json['category']!=null?json['category'].toString():"";
    subcategory = json['subcategory']!=null?json['subcategory'].toString():"";
    tags = json['tags']!=null?json['tags'].toString():"";
    location = json['location']!=null?json['location'].toString():"";
    description = json['description']!=null?json['description'].toString():"";
    price = json['price']!=null?json['price'].toString():"";
    attachment = json['attachment']!=null?json['attachment'].toString():"";
    attachmentPath = json['attachment_path']!=null?json['attachment_path'].toString():"";
    status = json['status']!=null?json['status'].toString():"";
    bidCount = json['bid_count']!=null?json['bid_count'].toString():"";
    bidAppliedPropfessional = json['bid_applied_propfessional']!=null?json['bid_applied_propfessional'].toString():"";
    bidRejectedPropfessional = json['bid_rejected_propfessional']!=null?json['bid_rejected_propfessional'].toString():"";
    rejectedBid = json['rejected_bid']!=null?json['rejected_bid'].toString():"";
    remarksByProf = json['remarks_by_prof']!=null?json['remarks_by_prof'].toString():"";
    markedDone = json['marked_done']!=null?json['marked_done'].toString():"";
    startDate = json['start_date']!=null?json['start_date'].toString():"";
    dueDate = json['due_date']!=null?json['due_date'].toString():"";
    hiredDate = json['hired_date']!=null?json['hired_date'].toString():"";
    completionDate = json['completion_date'];
    professionalFeedback = json['professional_feedback']!=null?json['professional_feedback'].toString():"";
    professionalRating = json['professional_rating']!=null?json['professional_rating'].toString():"";
    professionalId = json['professional_id']!=null?json['professional_id'].toString():"";
    payAmount = json['pay_amount']!=null?json['pay_amount'].toString():"";
    paymentStatus = json['payment_status']!=null?json['payment_status'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";


    if(![null,"","[]",[]].contains(json['attachment']) && ![null,""].contains(json['attachment_path'])){
      List<dynamic> list = jsonDecode(json['attachment']);
        if(list!=null&& list.length>0){
        list.forEach((element) {
          attachmentsList.add(attachmentPath! + element);
        });
        }
    }

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['show_home_page'] = this.showHomePage;
    data['cust_id'] = this.custId;
    data['job_title'] = this.jobTitle;
    data['category'] = this.category;
    data['subcategory'] = this.subcategory;
    data['tags'] = this.tags;
    data['location'] = this.location;
    data['description'] = this.description;
    data['price'] = this.price;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['status'] = this.status;
    data['bid_count'] = this.bidCount;
    data['bid_applied_propfessional'] = this.bidAppliedPropfessional;
    data['bid_rejected_propfessional'] = this.bidRejectedPropfessional;
    data['rejected_bid'] = this.rejectedBid;
    data['remarks_by_prof'] = this.remarksByProf;
    data['marked_done'] = this.markedDone;
    data['start_date'] = this.startDate;
    data['due_date'] = this.dueDate;
    data['hired_date'] = this.hiredDate;
    data['completion_date'] = this.completionDate;
    data['professional_feedback'] = this.professionalFeedback;
    data['professional_rating'] = this.professionalRating;
    data['professional_id'] = this.professionalId;
    data['pay_amount'] = this.payAmount;
    data['payment_status'] = this.paymentStatus;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    return data;
  }
}