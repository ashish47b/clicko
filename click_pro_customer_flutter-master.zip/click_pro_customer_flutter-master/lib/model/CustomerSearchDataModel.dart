class CustomerSearchDataModel {
  String? status;
  String? message;
  Data? data;

  CustomerSearchDataModel({this.status, this.message, this.data});

  CustomerSearchDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new Data.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<CustomerSearchProfessionals>? professionalsa;

  Data({this.professionalsa});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['professionalsa'] != null) {
      professionalsa = <CustomerSearchProfessionals>[];
      json['professionalsa'].forEach((v) {
        professionalsa!.add(new CustomerSearchProfessionals.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.professionalsa != null) {
      data['professionalsa'] =
          this.professionalsa!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CustomerSearchProfessionals {
  String? id;
  String? showHomePage;
  String? userId;
  String? firstName;
  String? lastName;
  String? email;
  String? password;
  String? gender;
  String? profDeviceToken;
  String? idProofAttachment;
  String? contactNumber;
  String? profileStatus;
  String? educationData;
  String? profilePic;
  String? profilePicPath;
  String? proofPic;
  String? proofPicPath;
  String? description;
  String? cityId;
  String? address;
  String? proofAcceptTravelCity;
  String? website;
  String? linkedin;
  String? facebook;
  String? instagram;
  String? twitter;
  String? categoryDetails;
  String? workHistory;
  String? companyName;
  String? companyLogo;
  String? companyLogoPath;
  String? previousWorkAttachment;
  String? previousWorkAttachmentPath;
  String? subscriptionPlanId;
  String? totalQuotPending;
  String? totalInvoicePending;
  String? certificate;
  String? certificatePath;
  String? companyDetails;
  String? sirenOrSiretNo;
  String? rcsNo;
  String? vat;
  String? rib;
  String? jobDone;
  String? status;
  String? approvedBy;
  String? createdDate;
  String? updatedDate;

  CustomerSearchProfessionals(
      {this.id,
      this.showHomePage,
      this.userId,
      this.firstName,
      this.lastName,
      this.email,
      this.password,
      this.gender,
      this.profDeviceToken,
      this.idProofAttachment,
      this.contactNumber,
      this.profileStatus,
      this.educationData,
      this.profilePic,
      this.profilePicPath,
      this.proofPic,
      this.proofPicPath,
      this.description,
      this.cityId,
      this.address,
      this.proofAcceptTravelCity,
      this.website,
      this.linkedin,
      this.facebook,
      this.instagram,
      this.twitter,
      this.categoryDetails,
      this.workHistory,
      this.companyName,
      this.companyLogo,
      this.companyLogoPath,
      this.previousWorkAttachment,
      this.previousWorkAttachmentPath,
      this.subscriptionPlanId,
      this.totalQuotPending,
      this.totalInvoicePending,
      this.certificate,
      this.certificatePath,
      this.companyDetails,
      this.sirenOrSiretNo,
      this.rcsNo,
      this.vat,
      this.rib,
      this.jobDone,
      this.status,
      this.approvedBy,
      this.createdDate,
      this.updatedDate});

  CustomerSearchProfessionals.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    showHomePage = json['show_home_page']!=null?json['show_home_page'].toString():"";
    userId = json['user_id']!=null?json['user_id'].toString():"";
    firstName = json['first_name']!=null?json['first_name'].toString():"";
    lastName = json['last_name']!=null?json['last_name'].toString():"";
    email = json['email']!=null?json['email'].toString():"";
    password = json['password']!=null?json['password'].toString():"";
    gender = json['gender']!=null?json['gender'].toString():"";
    profDeviceToken = json['prof_device_token']!=null?json['prof_device_token'].toString():"";
    idProofAttachment = json['id_proof_attachment']!=null?json['id_proof_attachment'].toString():"";
    contactNumber = json['contact_number']!=null?json['contact_number'].toString():"";
    profileStatus = json['profile_status']!=null?json['profile_status'].toString():"";
    educationData = json['education_data']!=null?json['education_data'].toString():"";
    profilePic = json['profile_pic']!=null?json['profile_pic'].toString():"";
    profilePicPath = json['profile_pic_path']!=null?json['profile_pic_path'].toString():"";
    proofPic = json['proof_pic']!=null?json['proof_pic'].toString():"";
    proofPicPath = json['proof_pic_path']!=null?json['proof_pic_path'].toString():"";
    description = json['description']!=null?json['description'].toString():"";
    cityId = json['city_id']!=null?json['city_id'].toString():"";
    address = json['address']!=null?json['address'].toString():"";
    proofAcceptTravelCity = json['proof_accept_travel_city']!=null?json['proof_accept_travel_city'].toString():"";
    website = json['website']!=null?json['website'].toString():"";
    linkedin = json['linkedin']!=null?json['linkedin'].toString():"";
    facebook = json['facebook']!=null?json['facebook'].toString():"";
    instagram = json['instagram']!=null?json['instagram'].toString():"";
    twitter = json['twitter']!=null?json['twitter'].toString():"";
    categoryDetails = json['category_details']!=null?json['category_details'].toString():"";
    workHistory = json['work_history']!=null?json['work_history'].toString():"";
    companyName = json['company_name']!=null?json['company_name'].toString():"";
    companyLogo = json['company_logo']!=null?json['company_logo'].toString():"";
    companyLogoPath = json['company_logo_path']!=null?json['company_logo_path'].toString():"";
    previousWorkAttachment = json['previous_work_attachment']!=null?json['previous_work_attachment'].toString():"";
    previousWorkAttachmentPath = json['previous_work_attachment_path']!=null?json['previous_work_attachment_path'].toString():"";
    subscriptionPlanId = json['subscription_plan_id']!=null?json['subscription_plan_id'].toString():"";
    totalQuotPending = json['total_quot_pending']!=null?json['total_quot_pending'].toString():"";
    totalInvoicePending = json['total_invoice_pending']!=null?json['total_invoice_pending'].toString():"";
    certificate = json['certificate']!=null?json['certificate'].toString():"";
    certificatePath = json['certificate_path']!=null?json['certificate_path'].toString():"";
    companyDetails = json['company_details']!=null?json['company_details'].toString():"";
    sirenOrSiretNo = json['siren_or_siret_no']!=null?json['siren_or_siret_no'].toString():"";
    rcsNo = json['rcs_no']!=null?json['rcs_no'].toString():"";
    vat = json['vat']!=null?json['vat'].toString():"";
    rib = json['rib']!=null?json['rib'].toString():"";
    jobDone = json['job_done']!=null?json['job_done'].toString():"";
    status = json['status']!=null?json['status'].toString():"";
    approvedBy = json['approved_by']!=null?json['approved_by'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['show_home_page'] = this.showHomePage;
    data['user_id'] = this.userId;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['email'] = this.email;
    data['password'] = this.password;
    data['gender'] = this.gender;
    data['prof_device_token'] = this.profDeviceToken;
    data['id_proof_attachment'] = this.idProofAttachment;
    data['contact_number'] = this.contactNumber;
    data['profile_status'] = this.profileStatus;
    data['education_data'] = this.educationData;
    data['profile_pic'] = this.profilePic;
    data['profile_pic_path'] = this.profilePicPath;
    data['proof_pic'] = this.proofPic;
    data['proof_pic_path'] = this.proofPicPath;
    data['description'] = this.description;
    data['city_id'] = this.cityId;
    data['address'] = this.address;
    data['proof_accept_travel_city'] = this.proofAcceptTravelCity;
    data['website'] = this.website;
    data['linkedin'] = this.linkedin;
    data['facebook'] = this.facebook;
    data['instagram'] = this.instagram;
    data['twitter'] = this.twitter;
    data['category_details'] = this.categoryDetails;
    data['work_history'] = this.workHistory;
    data['company_name'] = this.companyName;
    data['company_logo'] = this.companyLogo;
    data['company_logo_path'] = this.companyLogoPath;
    data['previous_work_attachment'] = this.previousWorkAttachment;
    data['previous_work_attachment_path'] = this.previousWorkAttachmentPath;
    data['subscription_plan_id'] = this.subscriptionPlanId;
    data['total_quot_pending'] = this.totalQuotPending;
    data['total_invoice_pending'] = this.totalInvoicePending;
    data['certificate'] = this.certificate;
    data['certificate_path'] = this.certificatePath;
    data['company_details'] = this.companyDetails;
    data['siren_or_siret_no'] = this.sirenOrSiretNo;
    data['rcs_no'] = this.rcsNo;
    data['vat'] = this.vat;
    data['rib'] = this.rib;
    data['job_done'] = this.jobDone;
    data['status'] = this.status;
    data['approved_by'] = this.approvedBy;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    return data;
  }
}