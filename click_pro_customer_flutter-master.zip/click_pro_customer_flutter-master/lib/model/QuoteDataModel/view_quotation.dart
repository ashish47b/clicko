import 'dart:convert';

class ViewQuoteDataModel {
  String? status;
  String? message;
  ViewQuoteData? data;

  ViewQuoteDataModel({this.status, this.message, this.data});

  ViewQuoteDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new ViewQuoteData.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class ViewQuoteData {
  String? id;
  String? userId;
  String? jobId;
  String? clientrefId;
  String? estimate;
  String? totalVat;
  String? estimatePrice;
  String? estimateProjectTime;
  String? coverDescription;
  String? sendQuot;
  String? instalmentPlan;
  String? attachment;
  String? attachmentPath;
  String? priceDownload;
  String? workStartDate;
  String? workEndDate;
  String? comment;
  String? necessaryMaterial;
  String? materialDetails;
  String? milestone;
  String? customerNegotiationCount;
  String? professionalNegotiationCount;
  String? total;
  String? totalTax;
  String? grandTotal;
  String? grandTotalEstimatePrice;
  String? status;
  String? createdDate;
  String? updatedDate;
  String? firstName;
  String? lastName;
  String? email;
  String? contactNumber;
  String? companyDetails;
  String? sirenOrSiretNo;
  String? rcsNo;
  String? vat;
  String? custId;
  String? jobTitle;
  String? category;
  String? location;
  List<CompanyDetailsData> companyDetailsDtaList=[];
  List<String> attachmentsList=[];
  List<QuoteMaterialDetailsDataModel>? quoteMaterialDetailsList = [];

  ViewQuoteData(
      {this.id,
      this.userId,
      this.jobId,
      this.clientrefId,
      this.estimate,
      this.totalVat,
      this.estimatePrice,
      this.estimateProjectTime,
      this.coverDescription,
      this.sendQuot,
      this.instalmentPlan,
      this.attachment,
      this.attachmentPath,
      this.priceDownload,
      this.workStartDate,
      this.workEndDate,
      this.comment,
      this.necessaryMaterial,
      this.materialDetails,
      this.milestone,
      this.customerNegotiationCount,
      this.professionalNegotiationCount,
      this.total,
      this.totalTax,
      this.grandTotal,
      this.grandTotalEstimatePrice,
      this.status,
      this.createdDate,
      this.updatedDate,
      this.firstName,
      this.lastName,
      this.email,
      this.contactNumber,
      this.companyDetails,
      this.sirenOrSiretNo,
      this.rcsNo,
      this.vat,
      this.custId,
      this.jobTitle,
      this.category,
      this.location});

  ViewQuoteData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    jobId = json['job_id'];
    clientrefId = json['clientref_id'];
    estimate = json['estimate']!=null?json['estimate'].toString():"";
    totalVat = json['total_vat']!=null?json['total_vat'].toString():"";
    estimatePrice = json['estimate_price']!=null?json['estimate_price'].toString():"";
    estimateProjectTime = json['estimate_project_time']!=null?json['estimate_project_time'].toString():"";
    coverDescription = json['cover_description']!=null?json['cover_description'].toString():"";
    sendQuot = json['send_quot']!=null?json['send_quot'].toString():"";
    instalmentPlan = json['instalment_plan']!=null?json['instalment_plan'].toString():"";
    attachment = json['attachment']!=null?json['attachment'].toString():"";
    attachmentPath = json['attachment_path']!=null?json['attachment_path'].toString():"";
    priceDownload = json['price_download']!=null?json['price_download'].toString():"";
    workStartDate = json['work_start_date']!=null?json['work_start_date'].toString():"";
    workEndDate = json['work_end_date']!=null?json['work_end_date'].toString():"";
    comment = json['comment']!=null?json['comment'].toString():"";
    necessaryMaterial = json['necessary_material']!=null?json['necessary_material'].toString():"";
    materialDetails = json['material_details']!=null?json['material_details'].toString():"";
    milestone = json['milestone']!=null?json['milestone'].toString():"";
    customerNegotiationCount = json['customer_negotiation_count']!=null?json['customer_negotiation_count'].toString():"";
    professionalNegotiationCount = json['professional_negotiation_count']!=null?json['professional_negotiation_count'].toString():"";
    total = json['total']!=null?json['total'].toString():"";
    totalTax = json['total_tax']!=null?json['total_tax'].toString():"";
    grandTotal = json['grand_total']!=null?json['grand_total'].toString():"";
    grandTotalEstimatePrice = json['grand_total_estimate_price'!=null?json['grand_total_estimate_price'].toString():""];
    status = json['status']!=null?json['status'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
    firstName = json['first_name']!=null?json['first_name'].toString():"";
    lastName = json['last_name']!=null?json['last_name'].toString():"";
    email = json['email']!=null?json['email'].toString():"";
    contactNumber = json['contact_number']!=null?json['contact_number'].toString():"";
    companyDetails = json['company_details']!=null?json['company_details'].toString():"";
    sirenOrSiretNo = json['siren_or_siret_no']!=null?json['siren_or_siret_no'].toString():"";
    rcsNo = json['rcs_no']!=null?json['rcs_no'].toString():"";
    vat = json['vat']!=null?json['vat'].toString():"";
    custId = json['cust_id']!=null?json['cust_id'].toString():"";
    jobTitle = json['job_title']!=null?json['job_title'].toString():"";
    category = json['category']!=null?json['category'].toString():"";
    location = json['location']!=null?json['location'].toString():"";

    if(![null,""].contains(json['company_details'])){
      List<dynamic> list = jsonDecode(json['company_details']);
      if(list!=null ){
        list.forEach((element) {
          companyDetailsDtaList.add(CompanyDetailsData.fromJson((element)));
        });
      }
    }

    if(![null,"","[]",[]].contains(json['attachment']) && ![null,""].contains(json['attachment_path'])){
      List<dynamic> list = jsonDecode(json['attachment']);
        if(list!=null&& list.length>0){
        list.forEach((element) {
          attachmentsList.add(attachmentPath! + element);
        });
        }
    }

    if(![null,"","[]",[]].contains(json['material_details'])){
      List<dynamic> list = jsonDecode(json['material_details']);
      if(list!=null && list.length>0){
        list.forEach((element) {
          quoteMaterialDetailsList!.add(QuoteMaterialDetailsDataModel.fromJson(element));
        });
      }
    }

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['job_id'] = this.jobId;
    data['clientref_id'] = this.clientrefId;
    data['estimate'] = this.estimate;
    data['total_vat'] = this.totalVat;
    data['estimate_price'] = this.estimatePrice;
    data['estimate_project_time'] = this.estimateProjectTime;
    data['cover_description'] = this.coverDescription;
    data['send_quot'] = this.sendQuot;
    data['instalment_plan'] = this.instalmentPlan;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['price_download'] = this.priceDownload;
    data['work_start_date'] = this.workStartDate;
    data['work_end_date'] = this.workEndDate;
    data['comment'] = this.comment;
    data['necessary_material'] = this.necessaryMaterial;
    data['material_details'] = this.materialDetails;
    data['milestone'] = this.milestone;
    data['customer_negotiation_count'] = this.customerNegotiationCount;
    data['professional_negotiation_count'] = this.professionalNegotiationCount;
    data['total'] = this.total;
    data['total_tax'] = this.totalTax;
    data['grand_total'] = this.grandTotal;
    data['grand_total_estimate_price'] = this.grandTotalEstimatePrice;
    data['status'] = this.status;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['email'] = this.email;
    data['contact_number'] = this.contactNumber;
    data['company_details'] = this.companyDetails;
    data['siren_or_siret_no'] = this.sirenOrSiretNo;
    data['rcs_no'] = this.rcsNo;
    data['vat'] = this.vat;
    data['cust_id'] = this.custId;
    data['job_title'] = this.jobTitle;
    data['category'] = this.category;
    data['location'] = this.location;
    return data;
  }
}

class CompanyDetailsData {
  String? categoryId;
  String? subcategoryId;
  String? companyName;
  String? location;
  String? country;
  String? title;
  String? periode;
  String? fromYear;

  CompanyDetailsData(
      {this.categoryId,
      this.subcategoryId,
      this.companyName,
      this.location,
      this.country,
      this.title,
      this.periode,
      this.fromYear});

  CompanyDetailsData.fromJson(Map<String, dynamic> json) {
    categoryId = json['category_id'];
    subcategoryId = json['subcategory_id'];
    companyName = json['company_name'];
    location = json['location'];
    country = json['country'];
    title = json['title'];
    periode = json['periode'];
    fromYear = json['from_year'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['category_id'] = this.categoryId;
    data['subcategory_id'] = this.subcategoryId;
    data['company_name'] = this.companyName;
    data['location'] = this.location;
    data['country'] = this.country;
    data['title'] = this.title;
    data['periode'] = this.periode;
    data['from_year'] = this.fromYear;
    return data;
  }
}


class QuoteMaterialDetailsDataModel {
  String? materialName;
  String? materialQty;
  String? unit;
  String? unitPrice;
  String? subTotal;
  String? tax;
  String? taxAmount;
  String? totalAmount;

  QuoteMaterialDetailsDataModel(
      {this.materialName,
      this.materialQty,
      this.unit,
      this.unitPrice,
      this.subTotal,
      this.tax,
      this.taxAmount,
      this.totalAmount});

  QuoteMaterialDetailsDataModel.fromJson(Map<String, dynamic> json) {
    materialName = json['material_name'];
    materialQty = json['material_qty'];
    unit = json['unit'];
    unitPrice = json['unit_price'];
    subTotal = json['sub_total'];
    tax = json['tax'];
    taxAmount = json['tax_amount'];
    totalAmount = json['total_amount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['material_name'] = this.materialName;
    data['material_qty'] = this.materialQty;
    data['unit'] = this.unit;
    data['unit_price'] = this.unitPrice;
    data['sub_total'] = this.subTotal;
    data['tax'] = this.tax;
    data['tax_amount'] = this.taxAmount;
    data['total_amount'] = this.totalAmount;
    return data;
  }
}