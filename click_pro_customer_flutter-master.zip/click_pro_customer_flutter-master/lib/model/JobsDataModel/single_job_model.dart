import 'package:click_pro_customer/model/JobsDataModel/jobs_data_model.dart';

class SingleJobDataModel {
  String? status;
  String? message;
  JobsData? data;

  SingleJobDataModel({this.status, this.message, this.data});

  SingleJobDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new JobsData.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

