import 'dart:convert';

import 'package:click_pro_customer/model/QuoteDataModel/view_quotation.dart';

class AppointmentViewDataModel {
  String? status;
  AppointmentViewData? data;

  AppointmentViewDataModel({this.status, this.data});

  AppointmentViewDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['Data'] != null ? new AppointmentViewData.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class AppointmentViewData {
  String? id;
  String? userId;
  String? quotId;
  String? jobId;
  String? title;
  String? addApointment;
  String? day;
  String? preferTime;
  String? date;
  String? time;
  String? meetingUrl;
  String? description;
  String? attachment;
  String? attachmentPath;
  String? status;
  String? createdBy;
  String? reseduleBy;
  String? createdDate;
  String? updatedDate;
  String? firstName;
  String? lastName;
  String? email;
  String? contactNumber;
  String? companyDetails;
  String? custId;
  String? jobTitle;
  String? category;
  String? location;
  List<String> attachmentList = [];
  List<CompanyDetailsData> companyDetailsDtaList = [];

  AppointmentViewData(
      {this.id,
      this.userId,
      this.quotId,
      this.jobId,
      this.title,
      this.addApointment,
      this.day,
      this.preferTime,
      this.date,
      this.time,
      this.meetingUrl,
      this.description,
      this.attachment,
      this.attachmentPath,
      this.status,
      this.createdBy,
      this.reseduleBy,
      this.createdDate,
      this.updatedDate,
      this.firstName,
      this.lastName,
      this.email,
      this.contactNumber,
      this.companyDetails,
      this.custId,
      this.jobTitle,
      this.category,
      this.location});

  AppointmentViewData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    quotId = json['quot_id'];
    jobId = json['job_id'];
    title = json['title']!=null?json['title'].toString():"";
    addApointment = json['add_apointment']!=null?json['add_apointment'].toString():"";
    day = json['day']!=null?json['day'].toString():"";
    preferTime = json['prefer_time']!=null?json['prefer_time'].toString():"";
    date = json['date']!=null?json['date'].toString():"";
    time = json['time']!=null?json['time'].toString():"";
    meetingUrl = json['meeting_url']!=null?json['meeting_url'].toString():"";
    description = json['description']!=null?json['description'].toString():"";
    attachment = json['attachment']!=null?json['attachment'].toString():"";
    attachmentPath = json['attachment_path']!=null?json['attachment_path'].toString():"";
    status = json['status']!=null?json['status'].toString():"";
    createdBy = json['created_by']!=null?json['created_by'].toString():"";
    reseduleBy = json['resedule_by']!=null?json['resedule_by'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
    firstName = json['first_name']!=null?json['first_name'].toString():"";
    lastName = json['last_name']!=null?json['last_name'].toString():"";
    email = json['email']!=null?json['email'].toString():"";
    contactNumber = json['contact_number']!=null?json['contact_number'].toString():"";
    companyDetails = json['company_details']!=null?json['company_details'].toString():"";
    custId = json['cust_id']!=null?json['cust_id'].toString():"";
    jobTitle = json['job_title']!=null?json['job_title'].toString():"";
    category = json['category']!=null?json['category'].toString():"";
    location = json['location']!=null?json['location'].toString():"";

    if(![null,"","[]",[]].contains(json['attachment'])){
      List<dynamic> list = jsonDecode(json['attachment']);
      if(list!=null && list.length>0){
        list.forEach((element) {
          attachmentList.add(attachmentPath! +  element);
        });
      }
    }

    if(![null,""].contains(json['company_details'])){
      List<dynamic> list = jsonDecode(json['company_details']);
      if(list!=null ){
        list.forEach((element) {
          companyDetailsDtaList.add(CompanyDetailsData.fromJson((element)));
        });
      }
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['quot_id'] = this.quotId;
    data['job_id'] = this.jobId;
    data['title'] = this.title;
    data['add_apointment'] = this.addApointment;
    data['day'] = this.day;
    data['prefer_time'] = this.preferTime;
    data['date'] = this.date;
    data['time'] = this.time;
    data['meeting_url'] = this.meetingUrl;
    data['description'] = this.description;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['status'] = this.status;
    data['created_by'] = this.createdBy;
    data['resedule_by'] = this.reseduleBy;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['email'] = this.email;
    data['contact_number'] = this.contactNumber;
    data['company_details'] = this.companyDetails;
    data['cust_id'] = this.custId;
    data['job_title'] = this.jobTitle;
    data['category'] = this.category;
    data['location'] = this.location;
    return data;
  }
}

