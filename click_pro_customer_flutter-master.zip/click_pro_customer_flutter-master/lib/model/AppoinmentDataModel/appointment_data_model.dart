import 'dart:convert';

class AppointmentDataModel {
  String? status;
  int? totalRow;
  List<AppointmentData>? data;

  AppointmentDataModel({this.status, this.totalRow, this.data});

  AppointmentDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    totalRow = json['total_row'];
    if (json['Data'] != null) {
      data = <AppointmentData>[];
      json['Data'].forEach((v) {
        data!.add(new AppointmentData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['total_row'] = this.totalRow;
    if (this.data != null) {
      data['Data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class AppointmentData {
  String? profId;
  String? firstName;
  String? lastName;
  String? categoryDetails;
  String? id;
  String? userId;
  String? quotId;
  String? jobId;
  String? title;
  String? addApointment;
  String? day;
  String? preferTime;
  String? date;
  String? time;
  String? meetingUrl;
  String? description;
  String? attachment;
  String? attachmentPath;
  String? status;
  String? createdBy;
  String? reseduleBy;
  String? createdDate;
  String? updatedDate;
  String? userid;
  String? jobCreatedDate;
  String? jobTitle;
  String? bidCount;
  String? dueDate;
  String? custId;
  List<String> appointmentDaysList = [];
  List<String> preferTimeList = [];

  AppointmentData(
      {this.profId,
      this.firstName,
      this.lastName,
      this.categoryDetails,
      this.id,
      this.userId,
      this.quotId,
      this.jobId,
      this.title,
      this.addApointment,
      this.day,
      this.preferTime,
      this.date,
      this.time,
      this.meetingUrl,
      this.description,
      this.attachment,
      this.attachmentPath,
      this.status,
      this.createdBy,
      this.reseduleBy,
      this.createdDate,
      this.updatedDate,
      this.userid,
      this.jobCreatedDate,
      this.jobTitle,
      this.bidCount,
      this.dueDate,
      this.custId});

  AppointmentData.fromJson(Map<String, dynamic> json) {
    profId = json['prof_id'];
    firstName = json['first_name']!=null?json['first_name'].toString():"";
    lastName = json['last_name']!=null?json['last_name'].toString():"";
    categoryDetails = json['category_details']!=null?json['category_details'].toString():"";
    id = json['id']!=null?json['id'].toString():"";
    userId = json['user_id']!=null?json['user_id'].toString():"";
    quotId = json['quot_id']!=null?json['quot_id'].toString():"";
    jobId = json['job_id']!=null?json['job_id'].toString():"";
    title = json['title']!=null?json['title'].toString():"";
    addApointment = json['add_apointment']!=null?json['add_apointment'].toString():"";
    day = json['day']!=null?json['day'].toString():"";
    preferTime = json['prefer_time']!=null?json['prefer_time'].toString():"";
    date = json['date']!=null?json['date'].toString():"";
    time = json['time']!=null?json['time'].toString():"";
    meetingUrl = json['meeting_url']!=null?json['meeting_url'].toString():"";
    description = json['description']!=null?json['description'].toString():"";
    attachment = json['attachment']!=null?json['attachment'].toString():"";
    attachmentPath = json['attachment_path']!=null?json['attachment_path'].toString():"";
    status = json['status']!=null?json['status'].toString():"";
    createdBy = json['created_by']!=null?json['created_by'].toString():"";
    reseduleBy = json['resedule_by']!=null?json['resedule_by'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
    userid = json['userid']!=null?json['userid'].toString():"";
    jobCreatedDate = json['job_created_date']!=null?json['job_created_date'].toString():"";
    jobTitle = json['job_title']!=null?json['job_title'].toString():"";
    bidCount = json['bid_count']!=null?json['bid_count'].toString():"";
    dueDate = json['due_date']!=null?json['due_date'].toString():"";
    custId = json['cust_id']!=null?json['cust_id'].toString():"";
    
    if(![null,"",[],"[]"].contains(json['day'])){
      List<dynamic> list = jsonDecode(json['day']);
      if(list!=null && list.length>0){
       list.forEach((element) {
        appointmentDaysList.add(element);
       });
      }
    }

    if(![null,"",[],"[]"].contains(json['prefer_time'])){
      List<dynamic> list = jsonDecode(json['prefer_time']);
      if(list!=null && list.length>0){
       list.forEach((element) {
        preferTimeList.add(element);
       });
      }
    }

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['prof_id'] = this.profId;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['category_details'] = this.categoryDetails;
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['quot_id'] = this.quotId;
    data['job_id'] = this.jobId;
    data['title'] = this.title;
    data['add_apointment'] = this.addApointment;
    data['day'] = this.day;
    data['prefer_time'] = this.preferTime;
    data['date'] = this.date;
    data['time'] = this.time;
    data['meeting_url'] = this.meetingUrl;
    data['description'] = this.description;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['status'] = this.status;
    data['created_by'] = this.createdBy;
    data['resedule_by'] = this.reseduleBy;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    data['userid'] = this.userid;
    data['job_created_date'] = this.jobCreatedDate;
    data['job_title'] = this.jobTitle;
    data['bid_count'] = this.bidCount;
    data['due_date'] = this.dueDate;
    data['cust_id'] = this.custId;
    return data;
  }
}