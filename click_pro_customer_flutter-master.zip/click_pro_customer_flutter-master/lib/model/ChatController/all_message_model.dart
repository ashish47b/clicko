class AllMessageListDataModel {
  String? status;
  String? message;
  List<ChatMessage>? chatMessage;
  Profile? profile;

  AllMessageListDataModel(
      {this.status, this.message, this.chatMessage, this.profile});

  AllMessageListDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    if (json['chat_message'] != null) {
      chatMessage = <ChatMessage>[];
      json['chat_message'].forEach((v) {
        chatMessage!.add(new ChatMessage.fromJson(v));
      });
    }
    profile =
        json['profile'] != null ? new Profile.fromJson(json['profile']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.chatMessage != null) {
      data['chat_message'] = this.chatMessage!.map((v) => v.toJson()).toList();
    }
    if (this.profile != null) {
      data['profile'] = this.profile!.toJson();
    }
    return data;
  }
}

class ChatMessage {
  String? name;
  String? message;
  String? createdAt;
  String? id;
  String? userId;
  String? customerId;
  String? createdBy;

  ChatMessage(
      {this.name,
      this.message,
      this.createdAt,
      this.id,
      this.userId,
      this.customerId,
      this.createdBy});

  ChatMessage.fromJson(Map<String, dynamic> json) {
    name = json['name']!=null?json['name'].toString():"";
    message = json['message']!=null?json['message'].toString():"";
    createdAt = json['created_at']!=null?json['created_at'].toString():"";
    id = json['id']!=null?json['id'].toString():"";
    userId = json['user_id']!=null?json['user_id'].toString():"";
    customerId = json['customer_id']!=null?json['customer_id'].toString():"";
    createdBy = json['created_by']!=null?json['created_by'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['message'] = this.message;
    data['created_at'] = this.createdAt;
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['customer_id'] = this.customerId;
    data['created_by'] = this.createdBy;
    return data;
  }
}

class Profile {
  String? id;
  String? showHomePage;
  String? userId;
  String? firstName;
  String? lastName;
  String? email;
  String? password;
  String? gender;
  String? profDeviceToken;
  String? idProofAttachment;
  String? contactNumber;
  String? profilePic;
  String? profilePicPath;
  String? description;
  String? cityId;
  String? address;
  String? proofAcceptTravelCity;
  String? website;
  String? categoryDetails;
  String? workHistory;
  String? previousWorkAttachment;
  String? previousWorkAttachmentPath;
  String? subscriptionPlanId;
  String? certificate;
  String? certificatePath;
  String? companyDetails;
  String? sirenOrSiretNo;
  String? rcsNo;
  String? vat;
  String? jobDone;
  String? status;
  String? approvedBy;
  String? createdDate;
  String? updatedDate;

  Profile(
      {this.id,
      this.showHomePage,
      this.userId,
      this.firstName,
      this.lastName,
      this.email,
      this.password,
      this.gender,
      this.profDeviceToken,
      this.idProofAttachment,
      this.contactNumber,
      this.profilePic,
      this.profilePicPath,
      this.description,
      this.cityId,
      this.address,
      this.proofAcceptTravelCity,
      this.website,
      this.categoryDetails,
      this.workHistory,
      this.previousWorkAttachment,
      this.previousWorkAttachmentPath,
      this.subscriptionPlanId,
      this.certificate,
      this.certificatePath,
      this.companyDetails,
      this.sirenOrSiretNo,
      this.rcsNo,
      this.vat,
      this.jobDone,
      this.status,
      this.approvedBy,
      this.createdDate,
      this.updatedDate});

  Profile.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    showHomePage = json['show_home_page'];
    userId = json['user_id'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    email = json['email'];
    password = json['password'];
    gender = json['gender'];
    profDeviceToken = json['prof_device_token'];
    idProofAttachment = json['id_proof_attachment'];
    contactNumber = json['contact_number'];
    profilePic = json['profile_pic'];
    profilePicPath = json['profile_pic_path'];
    description = json['description'];
    cityId = json['city_id'];
    address = json['address'];
    proofAcceptTravelCity = json['proof_accept_travel_city'];
    website = json['website'];
    categoryDetails = json['category_details'];
    workHistory = json['work_history'];
    previousWorkAttachment = json['previous_work_attachment'];
    previousWorkAttachmentPath = json['previous_work_attachment_path'];
    subscriptionPlanId = json['subscription_plan_id'];
    certificate = json['certificate'];
    certificatePath = json['certificate_path'];
    companyDetails = json['company_details'];
    sirenOrSiretNo = json['siren_or_siret_no'];
    rcsNo = json['rcs_no'];
    vat = json['vat'];
    jobDone = json['job_done'];
    status = json['status'];
    approvedBy = json['approved_by'];
    createdDate = json['created_date'];
    updatedDate = json['updated_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['show_home_page'] = this.showHomePage;
    data['user_id'] = this.userId;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['email'] = this.email;
    data['password'] = this.password;
    data['gender'] = this.gender;
    data['prof_device_token'] = this.profDeviceToken;
    data['id_proof_attachment'] = this.idProofAttachment;
    data['contact_number'] = this.contactNumber;
    data['profile_pic'] = this.profilePic;
    data['profile_pic_path'] = this.profilePicPath;
    data['description'] = this.description;
    data['city_id'] = this.cityId;
    data['address'] = this.address;
    data['proof_accept_travel_city'] = this.proofAcceptTravelCity;
    data['website'] = this.website;
    data['category_details'] = this.categoryDetails;
    data['work_history'] = this.workHistory;
    data['previous_work_attachment'] = this.previousWorkAttachment;
    data['previous_work_attachment_path'] = this.previousWorkAttachmentPath;
    data['subscription_plan_id'] = this.subscriptionPlanId;
    data['certificate'] = this.certificate;
    data['certificate_path'] = this.certificatePath;
    data['company_details'] = this.companyDetails;
    data['siren_or_siret_no'] = this.sirenOrSiretNo;
    data['rcs_no'] = this.rcsNo;
    data['vat'] = this.vat;
    data['job_done'] = this.jobDone;
    data['status'] = this.status;
    data['approved_by'] = this.approvedBy;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    return data;
  }
}