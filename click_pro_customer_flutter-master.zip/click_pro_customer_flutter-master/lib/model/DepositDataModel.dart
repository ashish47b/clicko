class DepositDataModel {
  String? status;
  List<DepositData>? msg;
  String? invId;

  DepositDataModel({this.status, this.msg});

  DepositDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['msg'] != null) {
      msg = <DepositData>[];
      json['msg'].forEach((v) {
        msg!.add(new DepositData.fromJson(v));
      });
    }
      invId = json['inv_id']!=null?json['inv_id'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.msg != null) {
      data['msg'] = this.msg!.map((v) => v.toJson()).toList();
    }
    data['inv_id'] = this.invId;
    return data;
  }
}

class DepositData {
  String? id;
  String? paymentId;
  String? amount;
  String? adminCusCommission;
  String? paymentStatus;
  String? customerPaymentDate;
  String? customerName;
  String? proName;
  String? jobTitle;
  String? categoryName;
  String? cityName;

  DepositData(
      {this.id,
      this.paymentId,
      this.amount,
      this.adminCusCommission,
      this.paymentStatus,
      this.customerPaymentDate,
      this.customerName,
      this.proName,
      this.jobTitle,
      this.categoryName,
      this.cityName});

  DepositData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    paymentId = json['payment_id']!=null?json['payment_id'].toString():"";
    amount = json['amount']!=null?json['amount'].toString():"";
    adminCusCommission = json['admin_cus_commission']!=null?json['admin_cus_commission'].toString():"";
    paymentStatus = json['payment_status']!=null?json['payment_status'].toString():"";
    customerPaymentDate = json['customer_payment_date']!=null?json['customer_payment_date'].toString():"";
    customerName = json['customer_name']!=null?json['customer_name'].toString():"";
    proName = json['pro_name']!=null?json['pro_name'].toString():"";
    jobTitle = json['job_title']!=null?json['job_title'].toString():"";
    categoryName = json['category_name']!=null?json['category_name'].toString():"";
    cityName = json['city_name']!=null?json['city_name'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['payment_id'] = this.paymentId;
    data['amount'] = this.amount;
    data['admin_cus_commission'] = this.adminCusCommission;
    data['payment_status'] = this.paymentStatus;
    data['customer_payment_date'] = this.customerPaymentDate;
    data['customer_name'] = this.customerName;
    data['pro_name'] = this.proName;
    data['job_title'] = this.jobTitle;
    data['category_name'] = this.categoryName;
    data['city_name'] = this.cityName;
    return data;
  }
}