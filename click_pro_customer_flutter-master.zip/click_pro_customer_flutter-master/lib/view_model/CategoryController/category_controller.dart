import 'package:click_pro_customer/data/repository/CategoryRepo/category_repo.dart';
import 'package:click_pro_customer/model/CategoryDataModel/category_data.dart';
import 'package:get/get.dart';

class CategoryController extends GetxController{
  
  RxBool isLoading = true.obs;

  setIsLoading(val){
    isLoading.value = val;
  }
   
  final apiRepo = CategoryRepo();

  RxList<CategoryData>? categoryData = <CategoryData>[].obs;

  getCategoryApi()async {
    setIsLoading(true);
    apiRepo.categoryRepo().then((value) {
      print("fine");
      setIsLoading(false);
      if(value.status=="true"){
         if(value.data!=null && value.data!.length>0){
           categoryData!.clear();
           value.data!.forEach((element) {
              if(![null,""].contains(element.categoryName!)){
                 categoryData!.add(element);
              }
           });
           print("lenght of catergory " + categoryData!.length.toString());
         }
      }

    }).onError((error, stackTrace) {
       setIsLoading(false);
    });
  }

}