import 'package:get/get.dart';

import '../res/LocalStoreage/shared)key_name.dart';
import '../res/LocalStoreage/shared_methods.dart';

class LoaderController extends GetxController{

  RxBool isLoading = false.obs;

  setIsLoading(val){
    isLoading.value = val;
  }


  

}