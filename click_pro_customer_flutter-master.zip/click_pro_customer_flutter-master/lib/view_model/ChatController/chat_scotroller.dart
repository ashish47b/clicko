import 'package:click_pro_customer/data/repository/ChatRepo/chat_repo.dart';
import 'package:click_pro_customer/model/ChatController/all_message_model.dart';
import 'package:click_pro_customer/model/ChatController/chat_users_model.dart';
import 'package:get/get.dart';

import '../../res/LocalStoreage/shared)key_name.dart';
import '../../res/LocalStoreage/shared_methods.dart';

class ChatController extends GetxController{
  final apiRepo = ChatRepo();

  RxBool isLoading = true.obs;

  setIsLoading(val){
    isLoading.value = val;
  }
 
 List<ChatUser> chatUserList=[];
  getChatUsers()async {
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {
      "user_type":"2"
    };

    apiRepo.chatUserRepo(map).then((value) {
      setIsLoading(false);
       chatUserList.clear();
      if(value.status=="true"){
        if(value.data!=null){
           if(value.data!.users!=null  && value.data!.users!.length>0){
            chatUserList.addAll(value.data!.users!);
           }
        }
      }

    }).onError((error, stackTrace) {
        setIsLoading(false);
    });
  
  }

  // 
  List<ChatMessage> messageList = [];
  getMessages({String?profId})async {
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {
      "user_type":"2","cust_id":userId,"userId":profId
    };
    apiRepo.msgRepo(map).then((value) {
       setIsLoading(false);
        messageList.clear();
       if(value.status=="true"){
        if(value.chatMessage!=null && value.chatMessage!.length>0){
          messageList.addAll(value.chatMessage!);
        }
       }
    }).onError((error, stackTrace) {
      setIsLoading(false);
    });
  }

  // add message.
  addMessage(String?prof_id,String?message)async {
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {
      "user_type":"2","customer_id":userId,"userid":prof_id,"message":message
    };

    apiRepo.addMsgRepo(map).then((value) {
       setIsLoading(false);
      if(value.status=="true"){
        getMessages(profId: prof_id);
      }

    }).onError((error, stackTrace) {
         setIsLoading(false);
    });
  }
  
}