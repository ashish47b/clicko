import 'package:click_pro_customer/data/repository/CityRepo/city_repo.dart';
import 'package:click_pro_customer/model/CityModel/city_model.dart';
import 'package:get/get.dart';

class CityController extends GetxController{

    RxBool isLoading = true.obs;

  setIsLoading(val){
    isLoading.value = val;
  }
   
   final apiRepo = CityRepo();

   RxList<CityData>? citiesList = <CityData>[].obs;

   Future getCity()async {
    setIsLoading(true);
    apiRepo.cityRepo().then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
        if(value.data!=null && value.data!.length>0){
          citiesList!.clear();
          citiesList!.addAll(value.data!);
          print("citiesList! list"+citiesList!.length.toString());
        }
      }

    }).onError((error, stackTrace) {
        setIsLoading(false);
    });
   }

}