import 'package:click_pro_customer/data/repository/CustomerSearchRepo/customerSearchRepo.dart';
import 'package:click_pro_customer/model/CustomerSearchDataModel.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:get/get.dart';

class CustomerSeachController extends GetxController{

    RxBool isLoading = false.obs;

  setIsLoading(val){
    isLoading.value = val;
  }
   
   final apiRepo = CustomerSearchRepo();

   List<CustomerSearchProfessionals> customerSearchProList = [];

   clearSearchList(){
    customerSearchProList.clear();
   }

   Future getSearchData({String?cityID,String?catId})async {
    setIsLoading(true);
    Map map = {
        "locationid":cityID!=null?cityID:"",
        "cat_id":catId!=null?catId:""
    };
    apiRepo.customerSerachRepo(map).then((value) {
      setIsLoading(false);
      customerSearchProList.clear();
      print(value);
      if(value.status=="true"){
        if(value.data!=null && value.data!.professionalsa!=null && value.data!.professionalsa!.length>0){
            customerSearchProList.addAll(value.data!.professionalsa!);
        }else{
          showToastMsg("No Result".tr);
        }
      }

    }).onError((error, stackTrace) {
        setIsLoading(false);
    });
   }

}