import 'dart:convert';

import 'package:click_pro_customer/data/repository/AppointmentRepo/appointment_repo.dart';
import 'package:click_pro_customer/model/AppoinmentDataModel/appointment_data_model.dart';
import 'package:click_pro_customer/model/AppoinmentDataModel/appointment_view_data_model.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class AppointmentController extends GetxController{

  final apiRepo = AppointmentRepo();


  RxBool isLoading = false.obs;

  setIsLoading(val){
    isLoading.value = val;
  }
  



  // all appointments 
  List<AppointmentData>? allAppointmentList=[];
  allAppointments({int?limit})async {
    setIsLoading(true);
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"user_id": "3", "type": "2","limit":limit!=null?limit:"1"};

    apiRepo.allAppointmentRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(limit==1){
        allAppointmentList!.clear();
       }
      if(value.status=="true"){
        if(value.data!=null && value.data!.length>0){
           allAppointmentList!.addAll(value.data!);
           print("allAppointmentList legth >> " + allAppointmentList!.length.toString());
        }
      }
    }).onError((error, stackTrace) {
      setIsLoading(false);

    });

  }

  //
    // all appointments 
  List<AppointmentData>? todayAppointmentList=[];
  todayAppointments({int?limit})async {
    setIsLoading(true);
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"user_id": "3", "type": "2","limit":limit!=null?limit:"1"};

    apiRepo.todayAppointRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(limit==1){
         todayAppointmentList!.clear();
       }
      if(value.status=="true"){
        if(value.data!=null && value.data!.length>0){
           todayAppointmentList!.addAll(value.data!);
           print("todayAppointmentList legth >> " + todayAppointmentList!.length.toString());
        }
      }

    }).onError((error, stackTrace) {
      setIsLoading(false);

    });

  }
  

  // all appointments 
  List<AppointmentData>? previousAppointmentList=[];
  previousAppointment({int?limit})async {
    setIsLoading(true);
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"user_id": "3", "type": "2","limit":limit!=null?limit:"1"};

    apiRepo.previousAppointRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(limit==1){
        previousAppointmentList!.clear();
      }
      if(value.status=="true"){
        if(value.data!=null && value.data!.length>0){
           previousAppointmentList!.addAll(value.data!);
           print("previousAppointmentList legth >> " + previousAppointmentList!.length.toString());
        }
      }

    }).onError((error, stackTrace) {
      setIsLoading(false);

    });

  }


  // view appointment
  AppointmentViewData? appointViewData;
    appointViewDataApi({String?appointmnet_id})async {
    setIsLoading(true);
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"user_id": "3", "type": "2","appointment_id":appointmnet_id};

    apiRepo.viewAppointRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
        if(value.data!=null){
          appointViewData = value.data!;
        }
      }

    }).onError((error, stackTrace) {
      setIsLoading(false);

    });

  }

  // reschedult appointmnet
   rscheduleAppointment({String?quot_id,String?job_id,String?title,
   List<String>? preferTimeList,List<String>? daysList,String?desc,String?url,
   String?appointment_id
   })async {
    setIsLoading(true);
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map<String,String> map = {
          "userId":userId!,
          "quot_id":quot_id!,
          "job_id":job_id!,
          "title":title!,
          "prefer_time":jsonEncode(preferTimeList!),
          "day":jsonEncode(daysList!),
          "time":"00:00",
          "description":desc!,
          "edit_id":appointment_id!,
          "meeting_url":url!
      };

      print(map);

    apiRepo.saveAppointment(map).then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
        showToastMsg("Successfully Updated".tr);
        Get.back();
      }else{
        showToastMsg(value.message!);
      }
    }).onError((error, stackTrace) {
        setIsLoading(false);
    });
   }

}