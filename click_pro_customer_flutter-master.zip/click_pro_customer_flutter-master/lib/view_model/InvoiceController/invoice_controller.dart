import 'package:click_pro_customer/data/repository/InvoiceRepo/invoice_repo.dart';
import 'package:click_pro_customer/model/InvoiceModel/invoice_model.dart';
import 'package:click_pro_customer/model/InvoiceModel/view_invoice_model.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:get/get.dart';

import '../../res/LocalStoreage/shared)key_name.dart';

class InvoiceController extends GetxController{
  
  final apiRepo = InvoiceRepo();

  
  RxBool isLoading = true.obs;

  setIsLoading(val){
    isLoading.value = val;
  }
  InvoiceDataListModel? invoiceDataListModel;
  List<InvoiceDataList> invoiceList=[];
  getInvoices({String?date,int?limit})async {
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {
      "job_id":"","userId":userId,"search":"","created_date":date!=null?date:"","limit":limit!=null?limit:"1"
    };
    
    apiRepo.invocieListRepo(map).then((value) {
      setIsLoading(false);
      if(limit==1){
        invoiceList.clear();
        invoiceDataListModel=null;
      }
      if(value.status=="true"){
        if(value.data!=null && value.data!.length>0){
          invoiceDataListModel = value;
            invoiceList.addAll(value.data!);
        }
      }
    }).onError((error, stackTrace) {
       setIsLoading(false);
    });
  }


  //  get invoice details
  ViewInvoiceData? viewInvoiceData;
  ViewInvoiceCusData? viewInvoiceCusData;
  ViewInvoiceProData?viewInvoiceProData;
  ViewInvoiceJobData?viewInvoiceJobData;
  getInvoiceDetails({String?invc_id})async {
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"invc_id":invc_id};
    apiRepo.invoDetailsRepo(map).then((value){
       setIsLoading(false);
       if(value.status=="true"){
          if(value.data!=null){
            viewInvoiceData = value.data!;
          }
          if(value.proData!=null){
            viewInvoiceProData = value.proData!;
          }
          if(value.cusData!=null){
            viewInvoiceCusData = value.cusData!;
          }
          if(value.jobData!=null){
            viewInvoiceJobData = value.jobData!;
          }
        }
    });
  }

}