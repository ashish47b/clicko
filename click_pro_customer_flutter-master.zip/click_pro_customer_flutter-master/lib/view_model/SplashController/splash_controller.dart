import 'dart:async';

import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:get/get.dart';

class SplashController extends GetxController{



  naviagteOnScreen()async{
    String? userEmail = await SharedMethods.getLocalStringData(key: SPKeys.USER_EMAIL);
    String? userToken = await SharedMethods.getLocalStringData(key: SPKeys.USER_TOKEN);
    String? userPhone = await SharedMethods.getLocalStringData(key: SPKeys.USER_PHONE);
    String? userVerify = await SharedMethods.getLocalStringData(key: SPKeys.USER_VERIFY);

    // print("USER_EMAIL >> " + userEmail!);
    // print("USER_TOKEN >> " + userToken!);
    // print("USER_PHONE >> " + userPhone!);
    // print("USER_VERIFY >> " + userVerify!);


    

       
      if(userVerify=="1" && ![null,""].contains(userToken)){
         Get.toNamed(RoutesName.dashboardView);
       } else {
      Get.toNamed(RoutesName.onBoardView);
       }
     

  }
   
   
}