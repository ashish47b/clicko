import 'dart:convert';
import 'dart:io';

import 'package:click_pro_customer/data/repository/ProfileRepo/profile_repo.dart';
import 'package:click_pro_customer/model/CustomerProfile/cust_profile_model.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:get/get.dart';

class ProfileController extends GetxController{

  final apiRepo = ProfileRepo();

  RxBool isLoading = true.obs;

  setIsLoading(val){
    isLoading.value = val;
  }
 CustomerProfileData? profileData;
 getProfile()async{
  setIsLoading(true);
  String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
  Map map = {"user_id": userId, "type": "2"};

  apiRepo.getProfile(map).then((value) {
    setIsLoading(false);
    print(value);
    if(value.status=="true"){
      if(value.data!=null){
       profileData = value.data!;
      }
    }

  }).onError((error, stackTrace) {
     setIsLoading(false);
  });
 }

 // save profile 
 savePorfile({String?attachFile,String? name, String?phone,String?email,
 String?gender,String?city_id,String?desx,String?address,String?from})async {
  setIsLoading(true);
  String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
  Map<String,String> map = { 
    "user_id":userId!,
    "type": "2",
    "name":name!,
    "email":email!,
    "phone":phone!,
    "gender":gender!,
    "city_id":city_id!,
    "description":desx!,
    "address":address!
  };
  apiRepo.saveProfile(map, attachFile).then((value){
   print(jsonEncode(value));
   if(value.status=="true"){
    showToastMsg("Profile Update Successfully".tr);
    if(![null,""].contains(from)){
      Get.toNamed(RoutesName.dashboardView);
    }else{
      Get.back();
    }
    
    getProfile();
   }

  }).onError((error, stackTrace){

  });

 }

}