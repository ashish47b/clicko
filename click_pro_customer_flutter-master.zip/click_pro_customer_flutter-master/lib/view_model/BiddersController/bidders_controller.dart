import 'dart:convert';

import 'package:click_pro_customer/data/repository/BiddersRepo/bidders_repo.dart';
import 'package:click_pro_customer/data/response/api_response.dart';
import 'package:click_pro_customer/model/BidsDataModel/bids_data_model.dart';
import 'package:click_pro_customer/model/NegotiationMOdel/negotiation_list.dart';
import 'package:click_pro_customer/model/ProfessionalModel/prof_profile_model.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/api/api.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/views/Bidders/negotiation_page.dart';
import 'package:click_pro_customer/widgets/payment_success_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class BidderController extends GetxController{



  final apiRepo = BiddersRepo();

  RxBool isLoading = false.obs;

  setIsLoading(val){
    isLoading.value = val;
  }

  RxList<Bidders>? biddersList = <Bidders>[].obs;

  getBidders({String?job_id})async{
    setIsLoading(true);
   String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);

   Map map = {"user_id": userId, "type": "2","job_id":job_id};

   apiRepo.getBiddersRepo(map).then((value) {
    setIsLoading(false);
    biddersList!.clear();
    if(value.status=="true"){
      if(value.bidders!=null && value.bidders!.length>0){
        biddersList!.addAll(value.bidders!);
        print("Bidders >> " + biddersList!.length.toString());
      }
    }

   }).onError((error, stackTrace) {
      setIsLoading(false);
   });
  }

  // reject bid
  rejectBidApi({String?bid_id,String?job_id})async {
    setIsLoading(true);
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"user_id": userId, "type": "2","job_id":job_id,"prof_id":bid_id};

    apiRepo.rejectBidRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
        showToastMsg(value.message!);
      }

    }).onError((error, stackTrace) {
      setIsLoading(false);
      
    });

  }

  // approve bid
    approveBidApi({String?bid_id,String?job_id,String?pay_id})async {
      setIsLoading(true);
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"user_id": userId, "type": "2","job_id":job_id,"prof_id":bid_id,"payment_id":pay_id};

    apiRepo.approveBidRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
        showToastMsg(value.message!);
      }

    }).onError((error, stackTrace) {
      setIsLoading(false);
      
    });

  }


  // see bidder profile
  ProfessionalData?obj;
    getProfDetails({String?prof_id})async{
      setIsLoading(true);
      obj=null;
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map ={"user_id": userId, "type": "2","prof_id":prof_id};
    print(map);
    apiRepo.profRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
         if(value.data!=null){
            obj = value.data!;
         }
      }

    }).onError((error, stackTrace) {
      setIsLoading(false);

    });

   }

   // get rating
   String?ratingBar = "0";
   getProfratings({String?prof_id})async{
    setIsLoading(true);
      String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
      Map map ={"user_id": userId, "type": "2","prof_id":prof_id};
      print(map);
      apiRepo.getRatingRepo(map).then((value){
        setIsLoading(false);
        print(value);
        if(value.status=="true"){
         if(![null,""].contains(value.data)){
          ratingBar = value.data!.toString();
          print("Rating >> "+ ratingBar!);
         }
        }
      }).onError((error, stackTrace) {
        setIsLoading(false);

      });
   }


      // no of time u hired
   String?hireTime = "0";
   hiredTime({String?prof_id})async {
     setIsLoading(true);
      String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
      Map map = {"user_id": userId, "type": "2","prof_id":prof_id,};
      print(map);

      apiRepo.nofTimeuHire(map).then((value) {
        setIsLoading(false);
        print(value);
        if(value.status=="true"){
          hireTime = value.data;
        }

      }).onError((error, stackTrace) {
        setIsLoading(false);

      });
   }
   

   // negotiation list
   List<Negotiation> negotiationList = [];
   NegotiationListDataModel?negoObj;
   negotiationListApi({String?quot_id})async {
      setIsLoading(true);
      String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
      Map map = {"user_id": userId, "type": "2","quot_id":quot_id,};
      print(map);
      apiRepo.negotiationListRepo(map).then((value) {
        print("DONNEEEE");
        setIsLoading(false);
        if(value.status=="true"){
         negoObj = value;
        }

      }).onError((error, stackTrace) {
        setIsLoading(false);

      });
   }

  // save negotiation


saveNegotiation(BuildContext context, SaveNegotiationData model)async {
  try{
    setIsLoading(true);
    
    print(API.SAVE_MILESTONE);
    var request = http.MultipartRequest("POST", Uri.parse(API.SAVE_MILESTONE));
    request.fields["quote_id"] = model.quote_id!;
    request.fields["job_id"] = model.jobId!;
    request.fields["estimate_price"] = model.estimate_price!;
    request.fields["userId"] = model.userId!;
    request.fields["milestone"] = model.milestone!;
    request.fields["cust_id"] = model.cust_id!;
    request.fields["negotiation_data"] = jsonEncode(model.negotiationData!);

    
    print(request.fields);
    var responsedData = await request.send();
    if (responsedData.statusCode == 200) {
    } else if (responsedData.statusCode == 422 /*&& data!=null*/) {
      // showTostMsg(data["message"]);
    } else {
      showToastMsg("Something went wrong".tr);
    }

    responsedData.stream.transform(utf8.decoder).listen((value) { 
    print(value);
     var data = jsonDecode(value);
     if(responsedData.statusCode==200){
      if(data["status"]=="true"){
        showToastMsg("Save Negotiation Successfully".tr);
        Get.toNamed(RoutesName.dashboardView);
        
      }
     }
    });
    
  }catch(e){
    print(e);
  }finally{
    setIsLoading(false);
  }
 }


 //
 saveDepositApi(BuildContext context, {String?payment_id,String?prof_id,String?paymentStatus,String?paymentDate,String?negoID,String?quote_id,String?job_id,String?pay_count,String?amount})async {
    setIsLoading(true);
    Map map ={
       "payment_id":payment_id,
       "payment_status":paymentStatus,
       "customer_payment_date":paymentDate,
       "neo_id":negoID,
       "pay_count":pay_count!=null?pay_count:"0",
       "quot_id":quote_id,
       "job_id":job_id,
       "amount":amount,
       "prof_id":prof_id,
    };
    apiRepo.saveDepositRepo(map).then((value){
       setIsLoading(false);
       if(value.status=="true"){
           showToastMsg("Payment Successfully!!");
          Get.toNamed(RoutesName.payment_success_view, arguments: [value]);
       }
    }).onError((error, stackTrace){
      setIsLoading(false);
      showToastMsg("Something wrong");
    });
  }


   payDepositApi({String?negoID})async {
    setIsLoading(true);
    Map map ={
       "neo_id":negoID
    };
    apiRepo.payDepositRepo(map).then((value){
       setIsLoading(false);
       if(value.status=="true"){
           showToastMsg("Payment Successfully!!");
          Get.toNamed(RoutesName.dashboardView);
       }
    }).onError((error, stackTrace){
      setIsLoading(false);
      showToastMsg("Something wrong");
    });
  }
}