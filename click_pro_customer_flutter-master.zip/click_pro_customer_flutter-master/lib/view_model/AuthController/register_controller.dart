

import 'package:click_pro_customer/data/repository/AuthRepo/auth_repo.dart';
import 'package:click_pro_customer/data/response/status.dart';
import 'package:click_pro_customer/model/AuthModel/RegisterModel.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class RegisterController extends GetxController{
   
  final apiRepo = AuthRepo();
   // final sharedMethods  = SharedMethods();
   


  
  final nameController = TextEditingController(text: "").obs;
  final emailController = TextEditingController(text: "").obs;
  final passwordController = TextEditingController(text: "").obs;
  final confirmPassController = TextEditingController(text: "").obs;
  final phoneController = TextEditingController(text: "").obs;
    final otpController = TextEditingController(text: "").obs;

    RxBool isObsecure = true.obs;

    setIsObsecure(val){
      isObsecure.value = val;
    }
  

  // register api 
  register()async {
    setIsObsecure(true);
    Map map = {
      "name": nameController.value.text,
      "email": emailController.value.text,
      "password": passwordController.value.text,
      "conf_password": confirmPassController.value.text,
      "phone": phoneController.value.text,
      "fcm_token": "fcm_token",
      "type": "2"
    };
    apiRepo.registerRepo(map).then((value) {
      setIsObsecure(false);

       print("DATA " + value.toString());  
         if(value.status=="false"){
           snackBarWidget(value.message!,"");
         }else if(value.status=="true"){
            SharedMethods.saveLocalStringData(key: SPKeys.USER_ID, value: value.data!.id);
             SharedMethods.saveLocalStringData(key: SPKeys.USER_EMAIL, value: value.data!.email);
             SharedMethods.saveLocalStringData(key: SPKeys.USER_PHONE, value: value.data!.phone);
             SharedMethods.saveLocalStringData(key: SPKeys.USER_TOKEN, value: value.data!.customerToken);
             SharedMethods.saveLocalStringData(key: SPKeys.USER_VERIFY, value: value.data!.emailVerification);
             SharedMethods.saveLocalStringData(key: SPKeys.USER_NAME, value: value.data!.name);
            snackBarWidget("Register".tr, "Register Successfully".tr);
            Get.toNamed(RoutesName.verifyAccount);
         }

    }).onError((error, stackTrace) {
      setIsObsecure(false);

           print("error");
          snackBarWidget("Not Register".tr,"Try Again".tr);
    });

    
  }



}