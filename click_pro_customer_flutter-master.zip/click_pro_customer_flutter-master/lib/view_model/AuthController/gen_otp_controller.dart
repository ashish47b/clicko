import 'package:click_pro_customer/data/repository/AuthRepo/auth_repo.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:get/get.dart';

class GenerateOtpController extends GetxController{
   
  RxBool isLoading = false.obs;

  setIsLoading(val){
    isLoading.value = val;
  }

   final apiRepo = AuthRepo();

   generateOtpRepo()async{
    setIsLoading(true);
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {
      "user_id": userId, "type": "2"
    };
    apiRepo.generate_otp(map).then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
        snackBarWidget("Succss".tr, "Otp has been sent on your gmail".tr);
        Get.toNamed(RoutesName.verifyAccount);
      }
    }).onError((error, stackTrace) {
      setIsLoading(false);

    });
   } 

  resendOTPApi()async{
    setIsLoading(true);
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    String? email = await SharedMethods.getLocalStringData(key: SPKeys.USER_EMAIL);
    Map map = {
      "user_id": userId, "type": "2","email":email
    };
    apiRepo.resendOtpRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
        snackBarWidget("Succss".tr, "Otp has been sent on your gmail".tr);
        //Get.toNamed(RoutesName.verifyAccount);
      }
    }).onError((error, stackTrace) {
      setIsLoading(false);
    });
   }

  logOutApi()async{
    setIsLoading(true);
    String? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    String? userToken = await SharedMethods.getLocalStringData(key: SPKeys.USER_TOKEN);
    Map map = {
      "user_tocken": userToken,
      "u_id":userId,
      "type":"1",
      "log_time":DateTime.now().toString()
    };
    apiRepo.logOutRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
         logOut();
        //snackBarWidget("Succss".tr, "Otp has been sent on your gmail".tr);
        //Get.toNamed(RoutesName.verifyAccount);
      }
    }).onError((error, stackTrace) {
      setIsLoading(false);

    });
   }     

   logOut()async {
     await SharedMethods.removeSharedData(key: SPKeys.USER_TOKEN);
          Get.toNamed(RoutesName.onBoardView);
   }

}