import 'package:click_pro_customer/data/repository/AuthRepo/auth_repo.dart';
import 'package:click_pro_customer/data/response/api_response.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/view_model/ProfileController.dart/profile_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class VerifyAccountController extends GetxController{

   final apiRepo = AuthRepo();

   final otpController = TextEditingController(text: "").obs;



   verifyApi()async {
     String? userID =await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
     Map  map = {
        "user_id": userID,
         "type": "2",
         "otp":otpController.value.text,
     };

     apiRepo.verifyAccount(map).then((value) {
      print("verify data >> " + value.toString());
      if(value.status=="true"){
        snackBarWidget("Account Verified".tr, "Successfully".tr);
          SharedMethods.saveLocalStringData(key: SPKeys.USER_VERIFY, value: "1");
        Get.toNamed(RoutesName.successVerifyView);
      }else if(value.status=="false"){
         snackBarWidget("Verification Unsuccessfull".tr, value.message);
      }

     }).onError((error, stackTrace) {
         snackBarWidget("Try again".tr,"Error Occured".tr);
     });
      
   }



}


