import 'package:click_pro_customer/data/repository/AuthRepo/auth_repo.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/app_color.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/utils/text_styles.dart';
import 'package:click_pro_customer/widgets/Account_verify_dialog.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_connect/http/src/utils/utils.dart';

class LoginController extends GetxController{

    final apiRepo = AuthRepo();

    final emailController = TextEditingController(text: "").obs;
    final passController = TextEditingController(text: "").obs;

  RxBool isLoading = false.obs;

  RxBool isShow = true.obs;



  setIsLoading(val){
    isLoading.value = val;
  }

    loginApi(BuildContext context)async {
      setIsLoading(true);
      Map map = {
        "email": emailController.value.text,
        "password": passController.value.text,
        "fcm_token": "eBi3X",
        "type": "2"
      };

      apiRepo.loginRepo(map).then((value) {
        setIsLoading(false);

        print(value.toString());
        if(value.status=="false"){
           snackBarWidget( "Not Successful".tr,value.message);
        }else if ( value.status=="true"){

          if(value.data!.emailVerification=="1"){
             Get.toNamed(RoutesName.dashboardView);
          }else{
             showDialog(context: context,
             barrierDismissible: false, builder: (val){
              
              return AccountVerifyDialog();
             });
          }
            SharedMethods.saveLocalStringData(key: SPKeys.USER_ID, value: value.data!.id);
             SharedMethods.saveLocalStringData(key: SPKeys.USER_EMAIL, value: value.data!.email);
             SharedMethods.saveLocalStringData(key: SPKeys.USER_PHONE, value: value.data!.phone);
             SharedMethods.saveLocalStringData(key: SPKeys.USER_TOKEN, value: value.data!.customerToken);
             SharedMethods.saveLocalStringData(key: SPKeys.USER_VERIFY, value: value.data!.emailVerification);
             SharedMethods.saveLocalStringData(key: SPKeys.USER_NAME, value: value.data!.name);
        }

      }).onError((error, stackTrace) {
        setIsLoading(false);
         print("Not Successfully".tr);
         snackBarWidget("Try Again".tr, "");
      });
    }




}