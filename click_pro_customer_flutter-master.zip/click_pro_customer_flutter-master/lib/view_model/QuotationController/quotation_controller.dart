import 'package:click_pro_customer/data/repository/QuotationRepo/quotation_repo.dart';
import 'package:click_pro_customer/model/QuoteDataModel/quote_data_model.dart';
import 'package:click_pro_customer/model/QuoteDataModel/view_quotation.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:get/get.dart';

class QuotationController extends GetxController{

  final apiRepo = QuotationRepo();


  RxBool isLoading = true.obs;

  setIsLoading(val){
    isLoading.value = val;
  }


  RxInt currentIndex = 0.obs;

  setCurrentIndex(val){
    currentIndex.value = val;
    print(currentIndex.value);
  }


  // pending quotes
  RxList<QuoteData>? pendingQuotesList=<QuoteData>[].obs;
  getPendingQuotes({int?limit,String?job_id})async{
    setIsLoading(true);
 
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"user_id": userId, "type": "2","job_id":job_id!=null?job_id:"","limit":limit!=null?limit.toString():"1"};

    apiRepo.pending_quoteRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(limit==1){
        pendingQuotesList!.clear();
      }
      if(value.status=="true"){

        if(value.data!=null && value.data!.length>0){

            pendingQuotesList!.addAll(value.data!);
            print("pendingQuotesList length " + pendingQuotesList!.length.toString());
        }
      }

    }).onError((error, stackTrace) {
       setIsLoading(false);
    });

  }

  // active quotes
  RxList<QuoteData>? activeQuotesList=<QuoteData>[].obs;
  getActiveQuotes({int?limit,String?job_id})async{
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"user_id": userId, "type": "2","job_id":job_id!=null?job_id:"","limit":limit!=null?limit:1};

    apiRepo.active_quoteRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(limit==1){
        activeQuotesList!.clear();
      }
      if(value.status=="true"){
        if(value.data!=null && value.data!.length>0){

            activeQuotesList!.addAll(value.data!);
            print("pendingQuotesList length " + activeQuotesList!.length.toString());
        }
      }

    }).onError((error, stackTrace) {
      setIsLoading(false);

    });

  }


  // reject quotes
  RxList<QuoteData>? rejectQuotesList=<QuoteData>[].obs;
  getRejectQuotes({int?limit,String?job_id})async{
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"user_id": userId, "type": "2","job_id":job_id!=null?job_id:"","limit":limit!=null?limit:1};

    apiRepo.reject_quoteRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
        if(limit==1){
          rejectQuotesList!.clear();
        }
        if(value.data!=null && value.data!.length>0){
            rejectQuotesList!.addAll(value.data!);
            print("pendingQuotesList length " + rejectQuotesList!.length.toString());
        }
      }

    }).onError((error, stackTrace) {
       setIsLoading(false);
    });

  }

  // view quotes
  ViewQuoteData?viewQuoteData;
  viewQuotes({String?quote_id})async{ 
    setIsLoading(true);

    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
    Map map = {"user_id": userId, "type": "2","quot_id":quote_id,};

    apiRepo.view_quoteRepo(map).then((value) {
      setIsLoading(false);
      print(value);
      if(value.status=="true"){
       if(value.data!=null){
        viewQuoteData = value.data;
       }
      }

    }).onError((error, stackTrace) {
      setIsLoading(false);

    });

  }

}