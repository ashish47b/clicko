import 'dart:convert';
import 'dart:io';

import 'package:click_pro_customer/data/repository/JobRepo/job_repo.dart';
import 'package:click_pro_customer/model/JobsDataModel/jobs_data_model.dart';
import 'package:click_pro_customer/model/ViewJObDataModel/view_job_model.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared)key_name.dart';
import 'package:click_pro_customer/res/LocalStoreage/shared_methods.dart';
import 'package:click_pro_customer/res/route/routes_name.dart';
import 'package:click_pro_customer/utils/common.dart';
import 'package:click_pro_customer/views/BottomNavBar/bottomNavbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class JobController extends GetxController{

  RxBool isLoading = false.obs;

  setIsLoading(val){
    isLoading.value = val;
  }

   final apiRepo = JobRepo();


  
  
   //  save jobs 
   
   saveJobApi(BuildContext context, {String?catId,String?date,String?city_id,String?attachFiles,String?job_id,String?title,String?desc,String?amount})async {
    setIsLoading(true);
    
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
     
    Map<String,String> map = {
      "user_id":userId.toString(),
      "type":"2",
      "cust_id":userId.toString(),
      "job_id":job_id!=null?job_id:"",
      "job_title":title!,
      "due_date":date.toString(),
      "category":catId.toString(),
      "location":city_id.toString(),
      "description":desc!,
      "price":amount!
    };
     print(map);
    apiRepo.savaJobRepo(map, attachFiles!).then((value) {
      setIsLoading(false);
       print(jsonEncode(value));
       if(value.status=="true"){
        showToastMsg("Job Posted Successfully".tr);
        getPendingJobs(limit: 1);
        //Get.back();
        navigateWithPageTransition(context, BottomNavBar(1));
       }
       
    }).onError((error, stackTrace) {
      setIsLoading(false);
    });
   }

   // get pending jobs
   RxList<JobsData>? pendingJobsList = <JobsData>[].obs;
   getPendingJobs({int?limit}) async {
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);

    Map map = {"user_id": userId, "type": "2","category":"","limit":limit!=null?limit.toString():"1"};

    apiRepo.getPendinfJobRepo(map).then((value) {
      setIsLoading(false);
      if(value.status=="true"){
        if(limit==1){
        pendingJobsList!.clear();
        }
        if(value.data!=null && value.data!.length>0){

            pendingJobsList!.addAll(value.data!);
            print("Jobs Pending Length >> " + pendingJobsList!.length.toString());
        }
      }
    }).onError((error, stackTrace) {
      setIsLoading(false);
       
    });
   }

   // get active jobs
  RxList<JobsData>? activeJobsList = <JobsData>[].obs;
   getActiveJobs({int?limit}) async {
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);

    Map map = {"user_id": userId, "type": "2","category":"","limit":limit!=null?limit.toString():"1"};

    apiRepo.getActiveJobRepo(map).then((value) {
      setIsLoading(false);
      if(value.status=="true"){
                  if(limit==1){
                 activeJobsList!.clear();
              }
        if(value.data!=null && value.data!.length>0){

            activeJobsList!.addAll(value.data!);
            print("Jobs Active Length >> " + activeJobsList!.length.toString());
        }
      }
    }).onError((error, stackTrace) {
      setIsLoading(false);
       
    });
   }

  // get hired jobs
  RxList<JobsData>? hiredJobsList = <JobsData>[].obs;
   getHiredJobs({int?limit}) async {
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);

    Map map = {"user_id": userId, "type": "2","category":"","limit":limit!=null?limit.toString():"1"};

    apiRepo.getHiredJobRepo(map).then((value) {
      setIsLoading(false);
      if(value.status=="true"){
                  if(limit==1){
            hiredJobsList!.clear();
           }
        if(value.data!=null && value.data!.length>0){

            hiredJobsList!.addAll(value.data!);
            print("Jobs Hired Length >> " + hiredJobsList!.length.toString());
        }
      }
    }).onError((error, stackTrace) {
      setIsLoading(false);
       
    });
   }

// get hired jobs
  RxList<JobsData>? completeJobsList = <JobsData>[].obs;
   getCompleteJobs({int?limit}) async {
    setIsLoading(true);
    String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);

    Map map = {"user_id": userId, "type": "2","category":"","limit":limit!=null?limit.toString():"1"};

    apiRepo.getCompleteJobRepo(map).then((value) {
      setIsLoading(false);
      if(value.status=="true"){
                  if(limit==1){
              completeJobsList!.clear();
            }
        if(value.data!=null && value.data!.length>0){

            completeJobsList!.addAll(value.data!);
            print("Jobs Complete Length >> " + completeJobsList!.length.toString());
        }
      }
    }).onError((error, stackTrace) {
      setIsLoading(false);
       
    });
   }


   // activate jobs 
   activatePendingJobs({String? job_id})async {
    setIsLoading(true);
      String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
      Map map = {"user_id": userId, "type": "2","job_id":job_id};
      print(map);
      apiRepo.activateJobRepo(map).then((value) {
        setIsLoading(false);
        print(value);
        if(value.status=="true"){
          showToastMsg(value.message!);
          getPendingJobs(limit: 1);
          getActiveJobs(limit: 1);
        }
      });
   }

   // viewJob
   ViewJobData?viewJobData;
   viewJobApi({String? job_id})async {
     setIsLoading(true);
     viewJobData=null;
      String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
      Map map = {"user_id": userId, "type": "2","job_id":job_id};

      apiRepo.viewJobRepo(map).then((value) {
         setIsLoading(false);
        if(value.status=="true"){
           if(value.data!=null){
            viewJobData = value.data;
           }
        }

      }).onError((error, stackTrace) {
        setIsLoading(false);
      });
   }

   // mark complete
   markCompleteApi({String?jobId,String?rating,String?feedback})async {
      setIsLoading(true);
      String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
      Map map = {"user_id": userId, "type": "2","job_id":jobId, "rating":rating, "feedback":feedback};

      print(map);
      apiRepo.markCompleteRepo(map).then((value) {
          setIsLoading(false);
       print(value);
       if(value.status=="true"){
         showToastMsg(value.message!);

         Get.back();
          getHiredJobs(limit: 1);
          getCompleteJobs(limit: 1);
       }
      }).onError((error, stackTrace) {
          setIsLoading(false);
           showToastMsg("Try Again");
      });
   }

  // chk payment
   String?pay_status="0";
   chkPaymnetApi({String?jobId,})async {
      setIsLoading(true);
      String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
      Map map = {"user_id": userId, "type": "2","job_id":jobId,};

      print(map);
      apiRepo.chekPaymentRepo(map).then((value) {
          setIsLoading(false);
       print(value);
       if(value.status=="true"){
         pay_status = "1";
       }
      }).onError((error, stackTrace) {
          setIsLoading(false);
           showToastMsg("Try Again");
      });
   }


   // get single jon
   JobsData? singleJobDtaa;
   getSingleJob({String?jobId})async {
      setIsLoading(true);
      String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
      Map map = {"user_id": userId, "type": "2","job_id":jobId,};

print(map);
      apiRepo.getSingleJobRepo(map).then((value) {
       setIsLoading(false);
       if(value.status=="true"){
        if(value.data!=null){
          singleJobDtaa = value.data!;
        }
       }
      }).onError((error, stackTrace){
       setIsLoading(false);

      });
   }


   //
  deActivateJobs({String? job_id})async {
    setIsLoading(true);
      String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
      Map map = {"id":job_id};
      print(map);
      apiRepo.deactivateJobREpo(map).then((value) {
        setIsLoading(false);
        print(value);
        if(value.status=="true"){
          showToastMsg(value.message!);
          getActiveJobs(limit: 1);
        }
      });
   }

   //

  deleteJobs({String? job_id})async {
    setIsLoading(true);
      String ? userId = await SharedMethods.getLocalStringData(key: SPKeys.USER_ID);
      Map map = {"id":job_id};
      print(map);
      apiRepo.deleteJobRepo(map).then((value) {
        setIsLoading(false);
        print(value);
        if(value.status=="true"){
          showToastMsg(value.message!);
          getPendingJobs(limit: 1);
          getActiveJobs(limit: 1);
          getHiredJobs(limit: 1);
          getCompleteJobs(limit: 1);
        }
      });
   }




}