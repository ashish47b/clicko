import 'dart:convert';

import 'package:clik_pro_professional/view/ProfilePage/personal_info.dart';

class ProfileDataModel {
  String? status;
  String? message;
  ProfileData? data;

  ProfileDataModel({this.status, this.message, this.data});

  ProfileDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new ProfileData.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class ProfileData {
  String? id;
  String? showHomePage;
  String? userId;
  String? firstName;
  String? lastName;
  String? email;
  String? password;
  String? gender;
  String? profDeviceToken;
  String? idProofAttachment;
  String? contactNumber;
  String? profilePic;
  String? profilePicPath;
  String? description;
  String? cityId;
  String? address;
  String? proofAcceptTravelCity;
  String? website;
  String? categoryDetails;
  String? workHistory;
  String? previousWorkAttachment;
  String? previousWorkAttachmentPath;
  String? subscriptionPlanId;
  String? certificate;
  String? certificatePath;
  String? companyDetails;
  String? sirenOrSiretNo;
  String? rcsNo;
  String? vat;
  String? jobDone;
  String? status;
  String? approvedBy;
  String? createdDate;
  String? updatedDate;
  String? name;
  String? phone;
  String? userType;
  String? emailVerification;
  String? resetCode;
  String? resetCodeUpdated;
  String? registerationType;
  String? logintype;
  String? lastOnline;
  String? customerToken;
  String? professionalToken;
  String? firbaseToken;
  String? cityName;
  List<String>? category;
  List<String>? subcategory;
  List<String>? workImageList=[];
  List<String>? certificateImageList=[];
  List<CategoryDetails>? categoryDetailsList=[];
  String?profile_status;
  String?linkedinLink;
  String?instagramLink;
  String?twittrLink;
  String?facebookLink;
  String?companyLogo;
  String?companyName;
  String?companyLogoPath;
  String?education_data;
  List<DiplomaData> diplomaDataList = [];
  List<CompanyDetailsData> companyDetailsList = [];
  String?total_quot_pending;
  String?total_invoice_pending;

  ProfileData(
      {this.id,
      this.showHomePage,
      this.userId,
      this.firstName,
      this.lastName,
      this.email,
      this.password,
      this.gender,
      this.profDeviceToken,
      this.idProofAttachment,
      this.contactNumber,
      this.profilePic,
      this.profilePicPath,
      this.description,
      this.cityId,
      this.address,
      this.proofAcceptTravelCity,
      this.website,
      this.categoryDetails,
      this.workHistory,
      this.previousWorkAttachment,
      this.previousWorkAttachmentPath,
      this.subscriptionPlanId,
      this.certificate,
      this.certificatePath,
      this.companyDetails,
      this.sirenOrSiretNo,
      this.rcsNo,
      this.vat,
      this.jobDone,
      this.status,
      this.approvedBy,
      this.createdDate,
      this.updatedDate,
      this.name,
      this.phone,
      this.userType,
      this.emailVerification,
      this.resetCode,
      this.resetCodeUpdated,
      this.registerationType,
      this.logintype,
      this.lastOnline,
      this.customerToken,
      this.professionalToken,
      this.firbaseToken,
      this.cityName,
      this.category,
      this.subcategory,
      this.profile_status,
      this.instagramLink,
      this.facebookLink,
      this.twittrLink,
      this.linkedinLink,
      this.companyLogo,
      this.companyName,
      this.companyLogoPath,
      this.education_data,
      this.total_invoice_pending,
      this.total_quot_pending,
      });

  ProfileData.fromJson(Map<String, dynamic> json) {
    id = json['id']!=null?json['id'].toString():'';
    showHomePage = json['show_home_page']!=null?json['show_home_page'].toString():"";
    userId = json['user_id']!=null?json['user_id'].toString():"";
    firstName = json['first_name']!=null?json['first_name'].toString():"";
    lastName = json['last_name']!=null?json['last_name'].toString():"";
    email = json['email']!=null?json['email'].toString():"";
    password = json['password']!=null?json['password'].toString():"";
    gender = json['gender']!=null?json['gender'].toString():"";
    profDeviceToken = json['prof_device_token']!=null?json['prof_device_token'].toString():"";
    idProofAttachment = json['id_proof_attachment']!=null?json['id_proof_attachment'].toString():"";
    contactNumber = json['contact_number']!=null?json['contact_number'].toString():"";
    profilePic = json['profile_pic']!=null?json['profile_pic'].toString():"";
    profilePicPath = json['profile_pic_path']!=null?json['profile_pic_path'].toString():"";
    description = json['description']!=null?json['description'].toString():"";
    cityId = json['city_id']!=null?json['city_id'].toString():"";
    address = json['address']!=null?json['address'].toString():"";
    proofAcceptTravelCity = json['proof_accept_travel_city']!=null?json['proof_accept_travel_city'].toString():"";
    website = json['website']!=null?json['website'].toString():"";
    categoryDetails = json['category_details']!=null?json['category_details'].toString():"";
    workHistory = json['work_history']!=null?json['work_history'].toString():"";
    previousWorkAttachment = json['previous_work_attachment']!=null?json['previous_work_attachment'].toString():"";
    previousWorkAttachmentPath = json['previous_work_attachment_path']!=null?json['previous_work_attachment_path'].toString():"";
    subscriptionPlanId = json['subscription_plan_id']!=null?json['subscription_plan_id'].toString():"";
    certificate = json['certificate']!=null?json['certificate'].toString():"";
    certificatePath = json['certificate_path']!=null?json['certificate_path'].toString():"";
    companyDetails = json['company_details']!=null?json['company_details'].toString():"";
    sirenOrSiretNo = json['siren_or_siret_no']!=null?json['siren_or_siret_no'].toString():"";
    rcsNo = json['rcs_no']!=null?json['rcs_no'].toString():"";
    vat = json['vat']!=null?json['vat'].toString():"";
    jobDone = json['job_done']!=null?json['job_done'].toString():"";
    status = json['status']!=null?json['status'].toString():"";
    approvedBy = json['approved_by']!=null?json['approved_by'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
    name = json['name']!=null?json['name'].toString():"";
    phone = json['phone']!=null?json['phone'].toString():"";
    userType = json['user_type']!=null?json['user_type'].toString():"";
    emailVerification = json['email_verification']!=null?json['email_verification'].toString():"";
    resetCode = json['reset_code']!=null?json['reset_code'].toString():"";
    resetCodeUpdated = json['reset_code_updated']!=null?json['reset_code_updated'].toString():"";
    registerationType = json['registeration_type']!=null?json['registeration_type'].toString():"";
    logintype = json['logintype']!=null?json['logintype'].toString():"";
    lastOnline = json['last_online']!=null?json['last_online'].toString():"";
    customerToken = json['customerToken']!=null?json['customerToken'].toString():"";
    professionalToken = json['professionalToken']!=null?json['professionalToken'].toString():"";
    firbaseToken = json['firbaseToken']!=null?json['firbaseToken'].toString():"";
    cityName = json['city_name']!=null?json['city_name'].toString():"";
    category =![null,""].contains(json['category'])? json['category'].cast<String>():[];
    subcategory =![null,""].contains(json['subcategory'])? json['subcategory'].cast<String>() :[];
    profile_status = ![null,""].contains(json['profile_status'])?json['profile_status'].toString():"0";
    facebookLink = ![null,""].contains(json['facebook'])?json['facebook'].toString():"";
    instagramLink = ![null,""].contains(json['instagram'])?json['instagram'].toString():"";
    twittrLink = ![null,""].contains(json['twitter'])?json['twitter'].toString():"";
    linkedinLink = ![null,""].contains(json['linkedin'])?json['linkedin'].toString():"";
    companyLogo = ![null,""].contains(json['company_logo'])?json['company_logo'].toString():"";
    companyName = ![null,""].contains(json['company_name'])?json['company_name'].toString():"";
    companyLogoPath = ![null,""].contains(json['company_logo_path'])?json['company_logo_path'].toString():"";
    education_data = ![null,""].contains(json['education_data'])?json['education_data'].toString():"";
    total_invoice_pending = ![null,""].contains(json['total_invoice_pending'])?json['total_invoice_pending'].toString():"";
    total_quot_pending = ![null,""].contains(json['total_quot_pending'])?json['total_quot_pending'].toString():"";
    

    if(![null,"",[],"[]"].contains(json['education_data'])){
      List<dynamic> list = jsonDecode(json['education_data']);
      if(list!=null && list.length>0){
        list.forEach((element) {
          diplomaDataList.add(DiplomaData.fromJson(element));
        });
      }
    }
 

    if(![null,"",[],"[]"].contains(json["previous_work_attachment"]) && ![null,""].contains(json['previous_work_attachment_path'])){
      List<dynamic> list = jsonDecode(json["previous_work_attachment"]);
      if(list!=null&& list.length>0){
       list.forEach((element) {
        workImageList!.add(previousWorkAttachmentPath! + element);
       });
      }
    }

    //
    if(![null,"",[],"[]"].contains(json["certificate"]) && ![null,""].contains(json['certificate_path'])){
      List<dynamic> list = jsonDecode(json["certificate"]);
      if(list!=null&& list.length>0){
       list.forEach((element) {
        certificateImageList!.add(certificatePath! + element);
       });
      }
    }

    if(![null,"","[]",[]].contains(json['category_details'])){
      List<dynamic> list = jsonDecode(json['category_details']);
      if(list!=null && list.length>0){
        list.forEach((element) {
          categoryDetailsList!.add(CategoryDetails.fromJson(element));
        });
      }
    }

    if(![null,"",[],"[]"].contains(json['company_details'])){
      List<dynamic> list = jsonDecode(json['company_details']);
      if(list!=null && list.length>0){
        list.forEach((element) {
          companyDetailsList.add(CompanyDetailsData.fromJson(element));
        });
      }
    }

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['show_home_page'] = this.showHomePage;
    data['user_id'] = this.userId;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['email'] = this.email;
    data['password'] = this.password;
    data['gender'] = this.gender;
    data['prof_device_token'] = this.profDeviceToken;
    data['id_proof_attachment'] = this.idProofAttachment;
    data['contact_number'] = this.contactNumber;
    data['profile_pic'] = this.profilePic;
    data['profile_pic_path'] = this.profilePicPath;
    data['description'] = this.description;
    data['city_id'] = this.cityId;
    data['address'] = this.address;
    data['proof_accept_travel_city'] = this.proofAcceptTravelCity;
    data['website'] = this.website;
    data['category_details'] = this.categoryDetails;
    data['work_history'] = this.workHistory;
    data['previous_work_attachment'] = this.previousWorkAttachment;
    data['previous_work_attachment_path'] = this.previousWorkAttachmentPath;
    data['subscription_plan_id'] = this.subscriptionPlanId;
    data['certificate'] = this.certificate;
    data['certificate_path'] = this.certificatePath;
    data['company_details'] = this.companyDetails;
    data['siren_or_siret_no'] = this.sirenOrSiretNo;
    data['rcs_no'] = this.rcsNo;
    data['vat'] = this.vat;
    data['job_done'] = this.jobDone;
    data['status'] = this.status;
    data['approved_by'] = this.approvedBy;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    data['name'] = this.name;
    data['phone'] = this.phone;
    data['user_type'] = this.userType;
    data['email_verification'] = this.emailVerification;
    data['reset_code'] = this.resetCode;
    data['reset_code_updated'] = this.resetCodeUpdated;
    data['registeration_type'] = this.registerationType;
    data['logintype'] = this.logintype;
    data['last_online'] = this.lastOnline;
    data['customerToken'] = this.customerToken;
    data['professionalToken'] = this.professionalToken;
    data['firbaseToken'] = this.firbaseToken;
    data['city_name'] = this.cityName;
    data['category'] = this.category;
    data['subcategory'] = this.subcategory;
    data['profile_status']=this.profile_status;
    data['facebook']=this.facebookLink;
    data['instagram']=this.instagramLink;
    data['twitter']=this.twittrLink;
    data['linkedin']=this.linkedinLink;
    data['company_logo_path']=this.companyLogoPath;
    data['company_logo']=this.companyLogo;
    data['company_name']=this.companyName;
    data['total_invoice_pending']=this.total_invoice_pending;
    data['total_quot_pending']=this.total_quot_pending;
    return data;
  }
}



class DiplomaData {
  int? certiId;
  String? nameOfCertificat;
  String? nameOfUniver;
  String? passingYear;
  String? eduCertificate;

  DiplomaData(
      {this.certiId,
      this.nameOfCertificat,
      this.nameOfUniver,
      this.passingYear,
      this.eduCertificate});

  DiplomaData.fromJson(Map<String, dynamic> json) {
    certiId = json['certi_id'];
    nameOfCertificat = json['name_of_certificat']!=null?json['name_of_certificat'].toString():"";
    nameOfUniver = json['name_of_univer']!=null?json['name_of_univer'].toString():"";
    passingYear = json['passing_year']!=null?json['passing_year'].toString():"";
    eduCertificate = json['edu_certificate']!=null?json['edu_certificate'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['certi_id'] = this.certiId;
    data['name_of_certificat'] = this.nameOfCertificat;
    data['name_of_univer'] = this.nameOfUniver;
    data['passing_year'] = this.passingYear;
    data['edu_certificate'] = this.eduCertificate;
    return data;
  }
}



class CompanyDetailsData {
  String? categoryId;
  String? subcategoryId;
  String? companyName;
  String? location;
  String? country;
  String? title;
  String? periode;
  String? fromYear;

  CompanyDetailsData(
      {this.categoryId,
      this.subcategoryId,
      this.companyName,
      this.location,
      this.country,
      this.title,
      this.periode,
      this.fromYear});

  CompanyDetailsData.fromJson(Map<String, dynamic> json) {
    categoryId = json['category_id'];
    subcategoryId = json['subcategory_id']!=null?json['subcategory_id'].toString():"";
    companyName = json['company_name']!=null?json['company_name'].toString():"";
    location = json['location']!=null?json['location'].toString():"";
    country = json['country']!=null?json['country'].toString():"";
    title = json['title']!=null?json['title'].toString():"";
    periode = json['periode']!=null?json['periode'].toString():"";
    fromYear = json['from_year']!=null?json['from_year'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['category_id'] = this.categoryId;
    data['subcategory_id'] = this.subcategoryId;
    data['company_name'] = this.companyName;
    data['location'] = this.location;
    data['country'] = this.country;
    data['title'] = this.title;
    data['periode'] = this.periode;
    data['from_year'] = this.fromYear;
    return data;
  }
}