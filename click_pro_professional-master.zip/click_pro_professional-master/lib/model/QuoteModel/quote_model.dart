import 'dart:convert';

import 'package:clik_pro_professional/model/MaterialModel/material_Model.dart';

class QuoteModelData {
  String? status;
  int? total;
  List<QuoteData>? data;

  QuoteModelData({this.status, this.total, this.data});

  QuoteModelData.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    total = json['total'];
    if (json['Data'] != null) {
      data = <QuoteData>[];
      json['Data'].forEach((v) {
        data!.add(new QuoteData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['total'] = this.total;
    if (this.data != null) {
      data['Data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class QuoteData {
  String? id;
  String? userId;
  String? jobId;
  String? clientrefId;
  String? estimate;
  String? totalVat;
  String? estimatePrice;
  String? estimateProjectTime;
  String? coverDescription;
  String? sendQuot;
  String? instalmentPlan;
  String? attachment;
  String? attachmentPath;
  String? priceDownload;
  String? workStartDate;
  String? workEndDate;
  String? comment;
  String? necessaryMaterial;
  String? materialDetails;
  String? milestone;
  String? customerNegotiationCount;
  String? professionalNegotiationCount;
  String? total;
  String? totalTax;
  String? grandTotal;
  String? grandTotalEstimatePrice;
  String? status;
  String? createdDate;
  String? updatedDate;
  String? userid;
  String? jobCreatedDate;
  String? jobTitle;
  String? bidCount;
  String? dueDate;
  String? custId;
  List<MaterialModel> userMaterialModelList = [];

  QuoteData(
      {this.id,
      this.userId,
      this.jobId,
      this.clientrefId,
      this.estimate,
      this.totalVat,
      this.estimatePrice,
      this.estimateProjectTime,
      this.coverDescription,
      this.sendQuot,
      this.instalmentPlan,
      this.attachment,
      this.attachmentPath,
      this.priceDownload,
      this.workStartDate,
      this.workEndDate,
      this.comment,
      this.necessaryMaterial,
      this.materialDetails,
      this.milestone,
      this.customerNegotiationCount,
      this.professionalNegotiationCount,
      this.total,
      this.totalTax,
      this.grandTotal,
      this.grandTotalEstimatePrice,
      this.status,
      this.createdDate,
      this.updatedDate,
      this.userid,
      this.jobCreatedDate,
      this.jobTitle,
      this.bidCount,
      this.dueDate,
      this.custId});

  QuoteData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id']!=null?json['user_id'].toString():"";
    jobId = json['job_id']!=null?json['job_id'].toString():"";
    clientrefId = json['clientref_id']!=null?json['clientref_id'].toString():"";
    estimate = json['estimate']!=null?json['estimate'].toString():"";
    totalVat = json['total_vat']!=null?json['total_vat'].toString():"";
    estimatePrice = json['estimate_price']!=null?json['estimate_price'].toString():"";
    estimateProjectTime = json['estimate_project_time']!=null?json['estimate_project_time'].toString():"";
    coverDescription = json['cover_description']!=null?json['cover_description'].toString():"";
    sendQuot = json['send_quot']!=null?json['send_quot'].toString():"";
    instalmentPlan = json['instalment_plan']!=null?json['instalment_plan'].toString():"1";
    attachment = json['attachment']!=null?json['attachment'].toString():"";
    attachmentPath = json['attachment_path']!=null?json['attachment_path'].toString():"";
    priceDownload = json['price_download']!=null?json['price_download'].toString():"";
    workStartDate = json['work_start_date']!=null?json['work_start_date'].toString():"";
    workEndDate = json['work_end_date']!=null?json['work_end_date'].toString():"";
    comment = json['comment']!=null?json['comment'].toString():"";
    necessaryMaterial = json['necessary_material']!=null?json['necessary_material'].toString():"";
    materialDetails = json['material_details']!=null?json['material_details'].toString():"";
    milestone = json['milestone']!=null?json['milestone'].toString():"";
    customerNegotiationCount = json['customer_negotiation_count']!=null?json['customer_negotiation_count'].toString():"";
    professionalNegotiationCount = json['professional_negotiation_count']!=null?json['professional_negotiation_count'].toString():"";
    total = json['total']!=null?json['total'].toString():"";
    totalTax = json['total_tax']!=null?json['total_tax'].toString():"";
    grandTotal = json['grand_total']!=null?json['grand_total'].toString():"";
    grandTotalEstimatePrice = json['grand_total_estimate_price']!=null?json['grand_total_estimate_price'].toString():"";
    status = json['status']!=null?json['status'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
    userid = json['userid']!=null?json['userid'].toString():"";
    jobCreatedDate = json['job_created_date']!=null?json['job_created_date'].toString():"";
    jobTitle = json['job_title']!=null?json['job_title'].toString():"";
    bidCount = json['bid_count']!=null?json['bid_count'].toString():"";
    dueDate = json['due_date']!=null?json['due_date'].toString():"";
    custId = json['cust_id']!=null?json['cust_id'].toString():"";
    if(![null,"","[]"].contains(json['material_details'])){
      List<dynamic> list = jsonDecode(json['material_details']);
      list.forEach((element) {
        userMaterialModelList.add(MaterialModel.fromJson(element));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['job_id'] = this.jobId;
    data['clientref_id'] = this.clientrefId;
    data['estimate'] = this.estimate;
    data['total_vat'] = this.totalVat;
    data['estimate_price'] = this.estimatePrice;
    data['estimate_project_time'] = this.estimateProjectTime;
    data['cover_description'] = this.coverDescription;
    data['send_quot'] = this.sendQuot;
    data['instalment_plan'] = this.instalmentPlan;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['price_download'] = this.priceDownload;
    data['work_start_date'] = this.workStartDate;
    data['work_end_date'] = this.workEndDate;
    data['comment'] = this.comment;
    data['necessary_material'] = this.necessaryMaterial;
    data['material_details'] = this.materialDetails;
    data['milestone'] = this.milestone;
    data['customer_negotiation_count'] = this.customerNegotiationCount;
    data['professional_negotiation_count'] = this.professionalNegotiationCount;
    data['total'] = this.total;
    data['total_tax'] = this.totalTax;
    data['grand_total'] = this.grandTotal;
    data['grand_total_estimate_price'] = this.grandTotalEstimatePrice;
    data['status'] = this.status;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    data['userid'] = this.userid;
    data['job_created_date'] = this.jobCreatedDate;
    data['job_title'] = this.jobTitle;
    data['bid_count'] = this.bidCount;
    data['due_date'] = this.dueDate;
    data['cust_id'] = this.custId;
    return data;
  }
}