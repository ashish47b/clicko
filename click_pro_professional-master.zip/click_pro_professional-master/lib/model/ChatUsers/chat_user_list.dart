import 'package:flutter/foundation.dart';

class ChatUserListDataModel {
  String? status;
  String? message;
  ChatUserListData? data;

  ChatUserListDataModel({this.status, this.message, this.data});

  ChatUserListDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new ChatUserListData.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class ChatUserListData {
  List<ChatUser>? users;

  ChatUserListData({this.users});

  ChatUserListData.fromJson(Map<String, dynamic> json) {
    if (json['users'] != null) {
      users = <ChatUser>[];
      json['users'].forEach((v) {
        users!.add(new ChatUser.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.users != null) {
      data['users'] = this.users!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ChatUser {
  String? id;
  String? name;
  String? email;
  String? cityId;
  String? address;
  String? logintype;
  String? profilePic;
  String? profilePicPath;
  String? lastOnline;
  String?first_name;
  String?last_name;

  ChatUser(
      {this.id,
      this.name,
      this.email,
      this.cityId,
      this.address,
      this.logintype,
      this.profilePic,
      this.profilePicPath,
      this.first_name,
      this.last_name,
      this.lastOnline});

  ChatUser.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    first_name = json['first_name']!=null?json['first_name'].toString():"";
    last_name = json['last_name']!=null?json['last_name'].toString():"";
    name = ![null,""].contains(json['name'])?json["name"].toString()  : "";
    email = json['email']!=null?json['email'].toString():"";
    cityId = json['city_id']!=null?json['city_id'].toString():"";
    address = json['address']!=null?json['address'].toString():"";
    logintype = json['logintype']!=null?json['logintype'].toString():"";
    profilePic = json['profile_pic']!=null?json['profile_pic'].toString():"";
    profilePicPath = json['profile_pic_path']!=null?json['profile_pic_path'].toString():"";
    lastOnline = json['last_online']!=null?json['last_online'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['city_id'] = this.cityId;
    data['address'] = this.address;
    data['logintype'] = this.logintype;
    data['profile_pic'] = this.profilePic;
    data['profile_pic_path'] = this.profilePicPath;
    data['last_online'] = this.lastOnline;
    return data;
  }
}