import 'dart:convert';

import 'package:provider/provider.dart';



class JobsDataModel {
  String? status;
  String? message;
  JobsData? data;

  JobsDataModel({this.status, this.message, this.data});

  JobsDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new JobsData.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class JobsData {
  List<JobSubCat>? jobSubCat;
  List<JobCategories>? jobCategories;
  List<Cities>? cities;
  List<ActiveJobs>? activeJobs;

  JobsData({this.jobSubCat, this.jobCategories, this.cities, this.activeJobs});

  JobsData.fromJson(Map<String, dynamic> json) {
    if (json['job_sub_cat'] != null) {
      jobSubCat = <JobSubCat>[];
      json['job_sub_cat'].forEach((v) {
        jobSubCat!.add(new JobSubCat.fromJson(v));
      });
    }
    if (json['job_categories'] != null) {
      jobCategories = <JobCategories>[];
      json['job_categories'].forEach((v) {
        jobCategories!.add(new JobCategories.fromJson(v));
      });
    }
    if (json['cities'] != null) {
      cities = <Cities>[];
      json['cities'].forEach((v) {
        cities!.add(new Cities.fromJson(v));
      });
    }
    if (json['active_jobs'] != null) {
      activeJobs = <ActiveJobs>[];
      json['active_jobs'].forEach((v) {
        activeJobs!.add(new ActiveJobs.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.jobSubCat != null) {
      data['job_sub_cat'] = this.jobSubCat!.map((v) => v.toJson()).toList();
    }
    if (this.jobCategories != null) {
      data['job_categories'] =
          this.jobCategories!.map((v) => v.toJson()).toList();
    }
    if (this.cities != null) {
      data['cities'] = this.cities!.map((v) => v.toJson()).toList();
    }
    if (this.activeJobs != null) {
      data['active_jobs'] = this.activeJobs!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class JobSubCat {
  String? id;
  String? subcategoryName;

  JobSubCat({this.id, this.subcategoryName});

  JobSubCat.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    subcategoryName = json['subcategory_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['subcategory_name'] = this.subcategoryName;
    return data;
  }
}

class JobCategories {
  String? id;
  String? categoryName;

  JobCategories({this.id, this.categoryName});

  JobCategories.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    categoryName = json['category_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['category_name'] = this.categoryName;
    return data;
  }
}

class Cities {
  String? id;
  String? cityName;

  Cities({this.id, this.cityName});

  Cities.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    cityName = json['city_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['city_name'] = this.cityName;
    return data;
  }
}

class ActiveJobs {
  String? id;
  String? showHomePage;
  String? custId;
  String? jobTitle;
  String? category;
  String? subcategory;
  String? tags;
  String? location;
  String? description;
  String? price;
  String? attachment;
  String? attachmentPath;
  String? status;
  String? bidCount;
  String? bidAppliedPropfessional;
  String? bidRejectedPropfessional;
  String? rejectedBid;
  String? remarksByProf;
  String? markedDone;
  String? startDate;
  String? dueDate;
  String? hiredDate;
  String? completionDate;
  String? professionalFeedback;
  String? professionalRating;
  String? professionalId;
  String? payAmount;
  String? paymentStatus;
  String? createdDate;
  String? updatedDate;
  bool?saveQuote=false;
  List<String> attachmnetList = [];
  List<String> bidProfessionalList=[];
  String?city_name;
  String?category_name;
  String?name;

  ActiveJobs(
      {this.id,
      this.showHomePage,
      this.custId,
      this.jobTitle,
      this.category,
      this.subcategory,
      this.tags,
      this.location,
      this.description,
      this.price,
      this.attachment,
      this.attachmentPath,
      this.status,
      this.bidCount,
      this.bidAppliedPropfessional,
      this.bidRejectedPropfessional,
      this.rejectedBid,
      this.remarksByProf,
      this.markedDone,
      this.startDate,
      this.dueDate,
      this.hiredDate,
      this.completionDate,
      this.professionalFeedback,
      this.professionalRating,
      this.professionalId,
      this.payAmount,
      this.paymentStatus,
      this.createdDate,
      this.updatedDate,this.category_name,this.city_name,this.name});

  ActiveJobs.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    showHomePage = json['show_home_page'];
    custId = json['cust_id'];
    jobTitle = json['job_title']!=null?json['job_title'].toString():"";
    category = json['category']!=null?json['category'].toString():"";
    subcategory = json['subcategory']!=null?json['subcategory'].toString():"";
    tags = json['tags']!=null?json['tags'].toString():"";
    location = json['location']!=null?json['location'].toString():"N/A";
    description = json['description']!=null?json['description'].toString():"";
    price = json['price']!=null?json['price'].toString():"";
    attachment = json['attachment']!=null?json['attachment'].toString():"";
    attachmentPath = json['attachment_path']!=null?json['attachment_path'].toString():"";
    status = json['status']!=null?json['status'].toString():"";
    bidCount = json['bid_count']!=null?json['bid_count'].toString():"";
    bidAppliedPropfessional = json['bid_applied_propfessional']!=null?json['bid_applied_propfessional'].toString():"";
    bidRejectedPropfessional = json['bid_rejected_propfessional']!=null?json['bid_rejected_propfessional'].toString():"";
    rejectedBid = json['rejected_bid']!=null?json['rejected_bid'].toString():"";
    remarksByProf = json['remarks_by_prof']!=null?json['remarks_by_prof'].toString():"";
    markedDone = json['marked_done']!=null?json['marked_done'].toString():"";
    startDate = json['start_date']!=null?json['start_date'].toString():"";
    dueDate = json['due_date']!=null?json['due_date'].toString():"";
    hiredDate = json['hired_date']!=null?json['hired_date'].toString():"";
    completionDate = json['completion_date']!=null?json['completion_date'].toString():"";
    professionalFeedback = json['professional_feedback']!=null?json['professional_feedback'].toString():"";
    professionalRating = json['professional_rating']!=null?json['professional_rating'].toString():"";
    professionalId = json['professional_id']!=null?json['professional_id'].toString():"";
    payAmount = json['pay_amount']!=null?json['pay_amount'].toString():"";
    paymentStatus = json['payment_status']!=null?json['payment_status'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
    city_name = json['city_name']!=null?json['city_name'].toString():"";
    category_name = json['category_name']!=null?json['category_name'].toString():"";
    name = json['name']!=null?json['name'].toString():"";
     

    if(![null,"",[],"[]"].contains(json["attachment"])){
      List<dynamic> list = jsonDecode(json["attachment"]);
      if(list!=null&& list.length>0){
       list.forEach((element) {
        attachmnetList.add(attachmentPath! + element);
       });
      }
    }
    
    if(![null,"",[],"[]"].contains(json['bid_applied_propfessional'])){
      List<dynamic> list = jsonDecode(json['bid_applied_propfessional']);
      if(list!=null && list.length>0){
        list.forEach((element) {
          bidProfessionalList.add(element);
        });
      }
    }

    // if(myProvider!.cityList!=null && myProvider!.cityList.length>0){
    //   if(widget.obj!=null && ![null,""].contains(widget.obj!.location)){
    //     myProvider!.cityList.forEach((element) { 
    //       if(element.id!.compareTo(widget.obj!.location!)==0){
    //          locationName = element.cityName;
    //       }
    //     });
    //   }
    // }

    // if(myProvider!.categoryList!=null && myProvider!.categoryList.length>0){
    //   if(widget.obj!=null && ![null,""].contains(widget.obj!.category)){
    //     myProvider!.categoryList.forEach((element) { 
    //       if(element.id!.compareTo(widget.obj!.category!)==0){
    //          locationName = element.categoryName;
    //       }
    //     });
    //   }
    // }

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['show_home_page'] = this.showHomePage;
    data['cust_id'] = this.custId;
    data['job_title'] = this.jobTitle;
    data['category'] = this.category;
    data['subcategory'] = this.subcategory;
    data['tags'] = this.tags;
    data['location'] = this.location;
    data['description'] = this.description;
    data['price'] = this.price;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['status'] = this.status;
    data['bid_count'] = this.bidCount;
    data['bid_applied_propfessional'] = this.bidAppliedPropfessional;
    data['bid_rejected_propfessional'] = this.bidRejectedPropfessional;
    data['rejected_bid'] = this.rejectedBid;
    data['remarks_by_prof'] = this.remarksByProf;
    data['marked_done'] = this.markedDone;
    data['start_date'] = this.startDate;
    data['due_date'] = this.dueDate;
    data['hired_date'] = this.hiredDate;
    data['completion_date'] = this.completionDate;
    data['professional_feedback'] = this.professionalFeedback;
    data['professional_rating'] = this.professionalRating;
    data['professional_id'] = this.professionalId;
    data['pay_amount'] = this.payAmount;
    data['payment_status'] = this.paymentStatus;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    data['name'] = this.name;
    data['category_name'] = this.category_name;
    data['city_name'] = this.city_name;
    return data;
  }
}