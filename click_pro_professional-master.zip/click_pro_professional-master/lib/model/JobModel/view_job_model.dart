class ViewJobDataModel {
  String? status;
  String? message;
  ViewJobData? data;

  ViewJobDataModel({this.status, this.message, this.data});

  ViewJobDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new ViewJobData.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class ViewJobData {
  ViewJob? job;
  ViewJobUser? user;

  ViewJobData({this.job, this.user});

  ViewJobData.fromJson(Map<String, dynamic> json) {
    job = json['job'] != null ? new ViewJob.fromJson(json['job']) : null;
    user = json['user'] != null ? new ViewJobUser.fromJson(json['user']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.job != null) {
      data['job'] = this.job!.toJson();
    }
    if (this.user != null) {
      data['user'] = this.user!.toJson();
    }
    return data;
  }
}

class ViewJob {
  String? id;
  String? showHomePage;
  String? custId;
  String? jobTitle;
  String? category;
  String? subcategory;
  String? tags;
  String? location;
  String? description;
  String? price;
  String? attachment;
  String? attachmentPath;
  String? status;
  String? bidCount;
  String? bidAppliedPropfessional;
  String? bidRejectedPropfessional;
  String? rejectedBid;
  String? remarksByProf;
  String? markedDone;
  String? startDate;
  String? dueDate;
  String? hiredDate;
  String? completionDate;
  String? professionalFeedback;
  String? professionalRating;
  String? professionalId;
  String? payAmount;
  String? paymentStatus;
  String? createdDate;
  String? updatedDate;

  ViewJob(
      {this.id,
      this.showHomePage,
      this.custId,
      this.jobTitle,
      this.category,
      this.subcategory,
      this.tags,
      this.location,
      this.description,
      this.price,
      this.attachment,
      this.attachmentPath,
      this.status,
      this.bidCount,
      this.bidAppliedPropfessional,
      this.bidRejectedPropfessional,
      this.rejectedBid,
      this.remarksByProf,
      this.markedDone,
      this.startDate,
      this.dueDate,
      this.hiredDate,
      this.completionDate,
      this.professionalFeedback,
      this.professionalRating,
      this.professionalId,
      this.payAmount,
      this.paymentStatus,
      this.createdDate,
      this.updatedDate});

  ViewJob.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    showHomePage = json['show_home_page']!=null?json['show_home_page'].toString():"";
    custId = json['cust_id']!=null?json['cust_id'].toString():"";
    jobTitle = json['job_title']!=null?json['job_title'].toString():"";
    category = json['category']!=null?json['category'].toString():"";
    subcategory = json['subcategory']!=null?json['subcategory'].toString():"";
    tags = json['tags']!=null?json['tags'].toString():"";
    location = json['location']!=null?json['location'].toString():"";
    description = json['description']!=null?json['description'].toString():"";
    price = json['price']!=null?json['price'].toString():"";
    attachment = json['attachment']!=null?json['attachment'].toString():"";
    attachmentPath = json['attachment_path']!=null?json['attachment_path'].toString():"";
    status = json['status']!=null?json['status'].toString():"";
    bidCount = json['bid_count']!=null?json['bid_count'].toString():"";
    bidAppliedPropfessional = json['bid_applied_propfessional']!=null?json['bid_applied_propfessional'].toString():"";
    bidRejectedPropfessional = json['bid_rejected_propfessional']!=null?json['bid_rejected_propfessional'].toString():"";
    rejectedBid = json['rejected_bid']!=null?json['rejected_bid'].toString():"";
    remarksByProf = json['remarks_by_prof']!=null?json['remarks_by_prof'].toString():"";
    markedDone = json['marked_done']!=null?json['marked_done'].toString():"";
    startDate = json['start_date']!=null?json['start_date'].toString():"";
    dueDate = json['due_date']!=null?json['due_date'].toString():"";
    hiredDate = json['hired_date']!=null?json['hired_date'].toString():"";
    completionDate = json['completion_date']!=null?json['completion_date'].toString():"";
    professionalFeedback = json['professional_feedback']!=null?json['professional_feedback'].toString():"";
    professionalRating = json['professional_rating']!=null?json['professional_rating'].toString():"";
    professionalId = json['professional_id']!=null?json['professional_id'].toString():"";
    payAmount = json['pay_amount']!=null?json['pay_amount'].toString():"";
    paymentStatus = json['payment_status']!=null?json['payment_status'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['show_home_page'] = this.showHomePage;
    data['cust_id'] = this.custId;
    data['job_title'] = this.jobTitle;
    data['category'] = this.category;
    data['subcategory'] = this.subcategory;
    data['tags'] = this.tags;
    data['location'] = this.location;
    data['description'] = this.description;
    data['price'] = this.price;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['status'] = this.status;
    data['bid_count'] = this.bidCount;
    data['bid_applied_propfessional'] = this.bidAppliedPropfessional;
    data['bid_rejected_propfessional'] = this.bidRejectedPropfessional;
    data['rejected_bid'] = this.rejectedBid;
    data['remarks_by_prof'] = this.remarksByProf;
    data['marked_done'] = this.markedDone;
    data['start_date'] = this.startDate;
    data['due_date'] = this.dueDate;
    data['hired_date'] = this.hiredDate;
    data['completion_date'] = this.completionDate;
    data['professional_feedback'] = this.professionalFeedback;
    data['professional_rating'] = this.professionalRating;
    data['professional_id'] = this.professionalId;
    data['pay_amount'] = this.payAmount;
    data['payment_status'] = this.paymentStatus;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    return data;
  }
}

class ViewJobUser {
  String? id;
  String? name;
  String? email;
  String? phone;
  String? password;
  String? userType;
  String? emailVerification;
  String? resetCode;
  String? resetCodeUpdated;
  String? registerationType;
  String? logintype;
  String? lastOnline;
  String? customerToken;
  String? professionalToken;
  String? firbaseToken;
  String? updatedDate;
  String? createdDate;
  String? showHomePage;
  String? userId;
  String? gender;
  String? profilePic;
  String? profilePicPath;
  String? location;
  String? address;
  String? countryId;
  String? regionId;
  String? cityId;
  String? description;
  String? professionalHired;
  String? jobPosting;
  String? deviceToken;
  String? status;
  

  ViewJobUser(
      {this.id,
      this.name,
      this.email,
      this.phone,
      this.password,
      this.userType,
      this.emailVerification,
      this.resetCode,
      this.resetCodeUpdated,
      this.registerationType,
      this.logintype,
      this.lastOnline,
      this.customerToken,
      this.professionalToken,
      this.firbaseToken,
      this.updatedDate,
      this.createdDate,
      this.showHomePage,
      this.userId,
      this.gender,
      this.profilePic,
      this.profilePicPath,
      this.location,
      this.address,
      this.countryId,
      this.regionId,
      this.cityId,
      this.description,
      this.professionalHired,
      this.jobPosting,
      this.deviceToken,
      this.status,
     });

  ViewJobUser.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name']!=null?json['name'].toString():"";
    email = json['email']!=null?json['email'].toString():"";
    phone = json['phone']!=null?json['phone'].toString():"";
    password = json['password']!=null?json['password'].toString():"";
    userType = json['user_type']!=null?json['user_type'].toString():"";
    emailVerification = json['email_verification']!=null?json['email_verification'].toString():"";
    resetCode = json['reset_code']!=null?json['reset_code'].toString():"";
    resetCodeUpdated = json['reset_code_updated']!=null?json['reset_code_updated'].toString():"";
    registerationType = json['registeration_type']!=null?json['registeration_type'].toString():"";
    logintype = json['logintype']!=null?json['logintype'].toString():"";
    lastOnline = json['last_online']!=null?json['last_online'].toString():"";
    customerToken = json['customerToken']!=null?json['customerToken'].toString():"";
    professionalToken = json['professionalToken']!=null?json['professionalToken'].toString():"";
    firbaseToken = json['firbaseToken']!=null?json['firbaseToken'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    showHomePage = json['show_home_page']!=null?json['show_home_page'].toString():"";
    userId = json['user_id']!=null?json['user_id'].toString():"";
    gender = json['gender']!=null?json['gender'].toString():"";
    profilePic = json['profile_pic']!=null?json['profile_pic'].toString():"";
    profilePicPath = json['profile_pic_path']!=null?json['profile_pic_path'].toString():"";
    location = json['location']!=null?json['location'].toString():"";
    address = json['address']!=null?json['address'].toString():"";
    countryId = json['country_id']!=null?json['country_id'].toString():"";
    regionId = json['region_id']!=null?json['region_id'].toString():"";
    cityId = json['city_id']!=null?json['city_id'].toString():"";
    description = json['description']!=null?json['description'].toString():"";
    professionalHired = json['professional_hired']!=null?json['professional_hired'].toString():"";
    jobPosting = json['job_posting']!=null?json['job_posting'].toString():"";
    deviceToken = json['device_token']!=null?json['device_token'].toString():"";
    status = json['status']!=null?json['status'].toString():"";

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['phone'] = this.phone;
    data['password'] = this.password;
    data['user_type'] = this.userType;
    data['email_verification'] = this.emailVerification;
    data['reset_code'] = this.resetCode;
    data['reset_code_updated'] = this.resetCodeUpdated;
    data['registeration_type'] = this.registerationType;
    data['logintype'] = this.logintype;
    data['last_online'] = this.lastOnline;
    data['customerToken'] = this.customerToken;
    data['professionalToken'] = this.professionalToken;
    data['firbaseToken'] = this.firbaseToken;
    data['updated_date'] = this.updatedDate;
    data['created_date'] = this.createdDate;
    data['show_home_page'] = this.showHomePage;
    data['user_id'] = this.userId;
    data['gender'] = this.gender;
    data['profile_pic'] = this.profilePic;
    data['profile_pic_path'] = this.profilePicPath;
    data['location'] = this.location;
    data['address'] = this.address;
    data['country_id'] = this.countryId;
    data['region_id'] = this.regionId;
    data['city_id'] = this.cityId;
    data['description'] = this.description;
    data['professional_hired'] = this.professionalHired;
    data['job_posting'] = this.jobPosting;
    data['device_token'] = this.deviceToken;
    data['status'] = this.status;

    return data;
  }
}