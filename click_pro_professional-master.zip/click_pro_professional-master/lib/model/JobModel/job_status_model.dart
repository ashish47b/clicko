import 'dart:convert';

class JobStatusDataModel {
  String? status;
  String? message;
  Data? data;

  JobStatusDataModel({this.status, this.message, this.data});

  JobStatusDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new Data.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<JobStatusData>? pendingJobs;
  List<JobStatusData>? activeJobs;
  List<JobStatusData>? hiringJobs;
  List<JobStatusData>? completedJobs;

  Data(
      {this.pendingJobs, this.activeJobs, this.hiringJobs, this.completedJobs});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['pending_jobs'] != null) {
      pendingJobs = <JobStatusData>[];
      json['pending_jobs'].forEach((v) {
        pendingJobs!.add(new JobStatusData.fromJson(v));
      });
    }
    if (json['active_jobs'] != null) {
      activeJobs = <JobStatusData>[];
      json['active_jobs'].forEach((v) {
        activeJobs!.add(new JobStatusData.fromJson(v));
      });
    }
    if (json['hiring_jobs'] != null) {
      hiringJobs = <JobStatusData>[];
      json['hiring_jobs'].forEach((v) {
        hiringJobs!.add(new JobStatusData.fromJson(v));
      });
    }
    if (json['completed_jobs'] != null) {
      completedJobs = <JobStatusData>[];
      json['completed_jobs'].forEach((v) {
        completedJobs!.add(new JobStatusData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.pendingJobs != null) {
      data['pending_jobs'] = this.pendingJobs!.map((v) => v.toJson()).toList();
    }
    if (this.activeJobs != null) {
      data['active_jobs'] = this.activeJobs!.map((v) => v.toJson()).toList();
    }
    if (this.hiringJobs != null) {
      data['hiring_jobs'] = this.hiringJobs!.map((v) => v.toJson()).toList();
    }
    if (this.completedJobs != null) {
      data['completed_jobs'] =
          this.completedJobs!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class JobStatusData {
  String? id;
  String? showHomePage;
  String? custId;
  String? jobTitle;
  String? category;
  String? subcategory;
  String? tags;
  String? location;
  String? description;
  String? price;
  String? attachment;
  String? attachmentPath;
  String? status;
  String? bidCount;
  String? bidAppliedPropfessional;
  String? bidRejectedPropfessional;
  String? rejectedBid;
  String? remarksByProf;
  String? markedDone;
  String? startDate;
  String? dueDate;
  String? hiredDate;
  String? completionDate;
  String? professionalFeedback;
  String? professionalRating;
  String? professionalId;
  String? payAmount;
  String? paymentStatus;
  String? createdDate;
  String? updatedDate;
  List<String>attachmentsList=[];

  JobStatusData(
      {this.id,
      this.showHomePage,
      this.custId,
      this.jobTitle,
      this.category,
      this.subcategory,
      this.tags,
      this.location,
      this.description,
      this.price,
      this.attachment,
      this.attachmentPath,
      this.status,
      this.bidCount,
      this.bidAppliedPropfessional,
      this.bidRejectedPropfessional,
      this.rejectedBid,
      this.remarksByProf,
      this.markedDone,
      this.startDate,
      this.dueDate,
      this.hiredDate,
      this.completionDate,
      this.professionalFeedback,
      this.professionalRating,
      this.professionalId,
      this.payAmount,
      this.paymentStatus,
      this.createdDate,
      this.updatedDate});

  JobStatusData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    showHomePage = json['show_home_page'];
    custId = json['cust_id'];
    jobTitle = json['job_title'];
    category = json['category'];
    subcategory = json['subcategory'];
    tags = json['tags'];
    location = json['location'];
    description = json['description'];
    price = json['price'];
    attachment = json['attachment'];
    attachmentPath = json['attachment_path'];
    status = json['status'];
    bidCount = json['bid_count'];
    bidAppliedPropfessional = json['bid_applied_propfessional'];
    bidRejectedPropfessional = json['bid_rejected_propfessional'];
    rejectedBid = json['rejected_bid'];
    remarksByProf = json['remarks_by_prof'];
    markedDone = json['marked_done'];
    startDate = json['start_date'];
    dueDate = json['due_date'];
    hiredDate = json['hired_date'];
    completionDate = json['completion_date'];
    professionalFeedback = json['professional_feedback'];
    professionalRating = json['professional_rating'];
    professionalId = json['professional_id'];
    payAmount = json['pay_amount'];
    paymentStatus = json['payment_status'];
    createdDate = json['created_date'];
    updatedDate = json['updated_date'];

    if(![null,"","[]"].contains(json["attachment"]) && ![null,"","[]"].contains(json["attachment_path"])){
      List<dynamic> list = jsonDecode(json['attachment']);
      if(list!=null && list.length>0){
        list.forEach((element) {
          attachmentsList.add(json["attachment_path"].toString()+ element);
        });
      }

    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['show_home_page'] = this.showHomePage;
    data['cust_id'] = this.custId;
    data['job_title'] = this.jobTitle;
    data['category'] = this.category;
    data['subcategory'] = this.subcategory;
    data['tags'] = this.tags;
    data['location'] = this.location;
    data['description'] = this.description;
    data['price'] = this.price;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['status'] = this.status;
    data['bid_count'] = this.bidCount;
    data['bid_applied_propfessional'] = this.bidAppliedPropfessional;
    data['bid_rejected_propfessional'] = this.bidRejectedPropfessional;
    data['rejected_bid'] = this.rejectedBid;
    data['remarks_by_prof'] = this.remarksByProf;
    data['marked_done'] = this.markedDone;
    data['start_date'] = this.startDate;
    data['due_date'] = this.dueDate;
    data['hired_date'] = this.hiredDate;
    data['completion_date'] = this.completionDate;
    data['professional_feedback'] = this.professionalFeedback;
    data['professional_rating'] = this.professionalRating;
    data['professional_id'] = this.professionalId;
    data['pay_amount'] = this.payAmount;
    data['payment_status'] = this.paymentStatus;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    return data;
  }
}

