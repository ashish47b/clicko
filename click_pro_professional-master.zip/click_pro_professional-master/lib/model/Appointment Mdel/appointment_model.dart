class AppointmentListDataModel {
  String? status;
  String? message;
  int? rows;
  List<AppointmentListData>? data;

  AppointmentListDataModel({this.status, this.message, this.rows, this.data});

  AppointmentListDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    rows = json['rows'];
    if (json['Data'] != null) {
      data = <AppointmentListData>[];
      json['Data'].forEach((v) {
        data!.add(AppointmentListData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    data['rows'] = this.rows;
    if (this.data != null) {
      data['Data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class AppointmentListData {
  String? profId;
  String? firstName;
  String? lastName;
  String? categoryDetails;
  String? id;
  String? userId;
  String? quotId;
  String? jobId;
  String? title;
  String? addApointment;
  String? day;
  String? preferTime;
  String? date;
  String? time;
  String? meetingUrl;
  String? description;
  String? attachment;
  String? attachmentPath;
  String? status;
  String? createdBy;
  String? reseduleBy;
  String? createdDate;
  String? updatedDate;
  String? userid;
  String? jobCreatedDate;
  String? jobTitle;
  String? bidCount;
  String? dueDate;
  String? custId;

  AppointmentListData(
      {this.profId,
      this.firstName,
      this.lastName,
      this.categoryDetails,
      this.id,
      this.userId,
      this.quotId,
      this.jobId,
      this.title,
      this.addApointment,
      this.day,
      this.preferTime,
      this.date,
      this.time,
      this.meetingUrl,
      this.description,
      this.attachment,
      this.attachmentPath,
      this.status,
      this.createdBy,
      this.reseduleBy,
      this.createdDate,
      this.updatedDate,
      this.userid,
      this.jobCreatedDate,
      this.jobTitle,
      this.bidCount,
      this.dueDate,
      this.custId});

  AppointmentListData.fromJson(Map<String, dynamic> json) {
    profId = json['prof_id'];
    firstName = json['first_name']!=null?json['first_name'].toString():"";
    lastName = json['last_name']!=null?json['last_name'].toString():"";
    categoryDetails = json['category_details']!=null?json['category_details'].toString():"";
    id = json['id'];
    userId = json['user_id'];
    quotId = json['quot_id'];
    jobId = json['job_id'];
    title = json['title'];
    addApointment = json['add_apointment']!=null?json['add_apointment'].toString():"";
    day = json['day']!=null?json['day'].toString():"";
    preferTime = json['prefer_time'];
    date = json['date']!=null?json['date'].toString():"";
    time = json['time'];
    meetingUrl = json['meeting_url']!=null?json['meeting_url'].toString():"";
    description = json['description']!=null?json['description'].toString():"";
    attachment = json['attachment'];
    attachmentPath = json['attachment_path'];
    status = json['status'];
    createdBy = json['created_by'];
    reseduleBy = json['resedule_by'];
    createdDate = json['created_date'];
    updatedDate = json['updated_date'];
    userid = json['userid'];
    jobCreatedDate = json['job_created_date'];
    jobTitle = json['job_title'];
    bidCount = json['bid_count'];
    dueDate = json['due_date'];
    custId = json['cust_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['prof_id'] = this.profId;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['category_details'] = this.categoryDetails;
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['quot_id'] = this.quotId;
    data['job_id'] = this.jobId;
    data['title'] = this.title;
    data['add_apointment'] = this.addApointment;
    data['day'] = this.day;
    data['prefer_time'] = this.preferTime;
    data['date'] = this.date;
    data['time'] = this.time;
    data['meeting_url'] = this.meetingUrl;
    data['description'] = this.description;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['status'] = this.status;
    data['created_by'] = this.createdBy;
    data['resedule_by'] = this.reseduleBy;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    data['userid'] = this.userid;
    data['job_created_date'] = this.jobCreatedDate;
    data['job_title'] = this.jobTitle;
    data['bid_count'] = this.bidCount;
    data['due_date'] = this.dueDate;
    data['cust_id'] = this.custId;
    return data;
  }
}