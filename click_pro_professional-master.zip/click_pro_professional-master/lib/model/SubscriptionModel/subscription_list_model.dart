class SubscriptionListDataModel {
  String? status;
  String? message;
  List<SubscriptionListData>? data;


  SubscriptionListDataModel({this.status, this.message, this.data});

  SubscriptionListDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    if (json['Data'] != null) {
      data = <SubscriptionListData>[];
      json['Data'].forEach((v) {
        data!.add(new SubscriptionListData.fromJson(v));
      });
    }


  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class SubscriptionListData {
  String? id;
  String? title;
  String? priceTitle;
  String? price;
  String? smallDescription;
  String? quotManage;
  String? invoiceManage;
  String? appointmentManage;
  String? whatsappAutoReminder;
  String? commission;
  String? subscriptionType;
  String? status;
  String? createdBy;
  String? approvedBy;
  String? createdDate;
  String? updatedDate;
  bool?isSubscribe=false;

  SubscriptionListData(
      {this.id,
      this.title,
      this.priceTitle,
      this.price,
      this.smallDescription,
      this.quotManage,
      this.invoiceManage,
      this.appointmentManage,
      this.whatsappAutoReminder,
      this.commission,
      this.subscriptionType,
      this.status,
      this.createdBy,
      this.approvedBy,
      this.createdDate,
      this.updatedDate});

  SubscriptionListData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title']!=null?json['title'].toString():"";
    priceTitle = json['price_title']!=null?json['price_title'].toString():"";
    price = json['price']!=null?json['price'].toString():"";
    smallDescription = json['small_description']!=null?json['small_description'].toString():"";
    quotManage = json['quot_manage']!=null?json['quot_manage'].toString():"";
    invoiceManage = json['invoice_manage']!=null?json['invoice_manage'].toString():"";
    appointmentManage = json['appointment_manage']!=null?json['appointment_manage'].toString():"";
    whatsappAutoReminder = json['whatsapp_auto_reminder']!=null?json['whatsapp_auto_reminder'].toString():"";
    commission = json['commission']!=null?json['commission'].toString():"";
    subscriptionType = json['subscription_type']!=null?json['subscription_type'].toString():"";
    status = json['status']!=null?json['status'].toString():"";
    createdBy = json['created_by']!=null?json['created_by'].toString():"";
    approvedBy = json['approved_by']!=null?json['approved_by'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['price_title'] = this.priceTitle;
    data['price'] = this.price;
    data['small_description'] = this.smallDescription;
    data['quot_manage'] = this.quotManage;
    data['invoice_manage'] = this.invoiceManage;
    data['appointment_manage'] = this.appointmentManage;
    data['whatsapp_auto_reminder'] = this.whatsappAutoReminder;
    data['commission'] = this.commission;
    data['subscription_type'] = this.subscriptionType;
    data['status'] = this.status;
    data['created_by'] = this.createdBy;
    data['approved_by'] = this.approvedBy;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    return data;
  }
}