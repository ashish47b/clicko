class ProSearchDataModel {
  String? status;
  String? message;
  List<ProSearchData>? data;

  ProSearchDataModel({this.status, this.message, this.data});

  ProSearchDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    if (json['Data'] != null) {
      data = <ProSearchData>[];
      json['Data'].forEach((v) {
        data!.add(new ProSearchData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ProSearchData {
  String? id;
  String? custId;
  String? jobTitle;
  String? description;
  String? price;
  String? startDate;
  String? dueDate;
  String? name;
  String? categoryName;
  String? cityName;

  ProSearchData(
      {this.id,
      this.custId,
      this.jobTitle,
      this.description,
      this.price,
      this.startDate,
      this.dueDate,
      this.name,
      this.categoryName,
      this.cityName});

  ProSearchData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    custId = json['cust_id'];
    jobTitle = json['job_title']!=null?json['job_title'].toString():"";
    description = json['description']!=null?json['description'].toString():"";
    price = json['price']!=null?json['price'].toString():"";
    startDate = json['start_date']!=null?json['start_date'].toString():"";
    dueDate = json['due_date']!=null?json['due_date'].toString():"";
    name = json['name']!=null?json['name'].toString():"";
    categoryName = json['category_name']!=null?json['category_name'].toString():"";
    cityName = json['city_name']!=null?json['city_name'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['cust_id'] = this.custId;
    data['job_title'] = this.jobTitle;
    data['description'] = this.description;
    data['price'] = this.price;
    data['start_date'] = this.startDate;
    data['due_date'] = this.dueDate;
    data['name'] = this.name;
    data['category_name'] = this.categoryName;
    data['city_name'] = this.cityName;
    return data;
  }
}