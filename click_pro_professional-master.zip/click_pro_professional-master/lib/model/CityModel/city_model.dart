class CityDataModel {
  String? status;
  String? message;
  List<CityData>? data;

  CityDataModel({this.status, this.message, this.data});

  CityDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    if (json['Data'] != null) {
      data = <CityData>[];
      json['Data'].forEach((v) {
        data!.add(new CityData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CityData {
  String? id;
  String? cityName;
  String?attachment_path;
  String?attachment;
  String?city_image;

  CityData({this.id, this.cityName});

  CityData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    cityName = json['city_name']!=null?json['city_name'].toString():"";
     attachment_path = json['attachment_path']!=null?json['attachment_path'].toString():"";
    attachment = json['attachment']!=null?json['attachment'].toString():"";
    if(![null,""].contains(json["attachment_path"]) && ![null,"attachment"].contains(json["attachment"])){
       city_image = json["attachment_path"] + json["attachment"];
       
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['city_name'] = this.cityName;
        data['attachment_path'] = this.attachment_path;
    data['attachment'] = this.attachment;
    return data;
  }
}