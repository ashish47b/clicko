class ViewInvoiceDataModel {
  String? status;
  String? message;
  ViewInvoiceData? data;
  ViewInvoiceCusData? cusData;
  ViewInvoiceProData? proData;
  ViewInvoiceJobData? jobData;

  ViewInvoiceDataModel(
      {this.status,
      this.message,
      this.data,
      this.cusData,
      this.proData,
      this.jobData});

  ViewInvoiceDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new ViewInvoiceData.fromJson(json['Data']) : null;
    cusData = json['cus_data'] != null
        ? new ViewInvoiceCusData.fromJson(json['cus_data'])
        : null;
    proData = json['pro_data'] != null
        ? new ViewInvoiceProData.fromJson(json['pro_data'])
        : null;
    jobData = json['job_data'] != null
        ? new ViewInvoiceJobData.fromJson(json['job_data'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    if (this.cusData != null) {
      data['cus_data'] = this.cusData!.toJson();
    }
    if (this.proData != null) {
      data['pro_data'] = this.proData!.toJson();
    }
    if (this.jobData != null) {
      data['job_data'] = this.jobData!.toJson();
    }
    return data;
  }
}

class ViewInvoiceData {
  String? id;
  String? paymentId;
  String? deffDays;
  String? paymentDueDate;
  String? amount;
  String? adminCusCommission;
  String? adminCusPer;
  String? paymentStatus;
  String? approveStatusPro;
  String? paymentApprovedStatus;
  String? quotId;
  String? jobId;
  String? custId;
  String? profId;
  String? customerPaymentDate;
  String? professionalPadStatus;
  String? professionalPaidAmount;
  String? adminCommission;
  String? professionalPadId;
  String? createdDate;
  String? professionalPaidDate;
  String? updatedDate;

  ViewInvoiceData(
      {this.id,
      this.paymentId,
      this.deffDays,
      this.paymentDueDate,
      this.amount,
      this.adminCusCommission,
      this.adminCusPer,
      this.paymentStatus,
      this.approveStatusPro,
      this.paymentApprovedStatus,
      this.quotId,
      this.jobId,
      this.custId,
      this.profId,
      this.customerPaymentDate,
      this.professionalPadStatus,
      this.professionalPaidAmount,
      this.adminCommission,
      this.professionalPadId,
      this.createdDate,
      this.professionalPaidDate,
      this.updatedDate});

  ViewInvoiceData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    paymentId = json['payment_id'];
    deffDays = json['deff_days'];
    paymentDueDate = json['payment_due_date'];
    amount = json['amount'];
    adminCusCommission = json['admin_cus_commission'];
    adminCusPer = json['admin_cus_per'];
    paymentStatus = json['payment_status'];
    approveStatusPro = json['approve_status_pro'];
    paymentApprovedStatus = json['payment_approved_status'];
    quotId = json['quot_id'];
    jobId = json['job_id'];
    custId = json['cust_id'];
    profId = json['prof_id'];
    customerPaymentDate = json['customer_payment_date'];
    professionalPadStatus = json['professional_pad_status'];
    professionalPaidAmount = json['professional_paid_amount'];
    adminCommission = json['admin_commission'];
    professionalPadId = json['professional_pad_id'];
    createdDate = json['created_date'];
    professionalPaidDate = json['professional_paid_date'];
    updatedDate = json['updated_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['payment_id'] = this.paymentId;
    data['deff_days'] = this.deffDays;
    data['payment_due_date'] = this.paymentDueDate;
    data['amount'] = this.amount;
    data['admin_cus_commission'] = this.adminCusCommission;
    data['admin_cus_per'] = this.adminCusPer;
    data['payment_status'] = this.paymentStatus;
    data['approve_status_pro'] = this.approveStatusPro;
    data['payment_approved_status'] = this.paymentApprovedStatus;
    data['quot_id'] = this.quotId;
    data['job_id'] = this.jobId;
    data['cust_id'] = this.custId;
    data['prof_id'] = this.profId;
    data['customer_payment_date'] = this.customerPaymentDate;
    data['professional_pad_status'] = this.professionalPadStatus;
    data['professional_paid_amount'] = this.professionalPaidAmount;
    data['admin_commission'] = this.adminCommission;
    data['professional_pad_id'] = this.professionalPadId;
    data['created_date'] = this.createdDate;
    data['professional_paid_date'] = this.professionalPaidDate;
    data['updated_date'] = this.updatedDate;
    return data;
  }
}

class ViewInvoiceCusData {
  String? userId;
  String? name;

  ViewInvoiceCusData({this.userId, this.name});

  ViewInvoiceCusData.fromJson(Map<String, dynamic> json) {
    userId = json['user_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user_id'] = this.userId;
    data['name'] = this.name;
    return data;
  }
}

class ViewInvoiceProData {
  String? userId;
  String? firstName;
  String? lastName;

  ViewInvoiceProData({this.userId, this.firstName, this.lastName});

  ViewInvoiceProData.fromJson(Map<String, dynamic> json) {
    userId = json['user_id'];
    firstName = json['first_name'];
    lastName = json['last_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user_id'] = this.userId;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    return data;
  }
}

class ViewInvoiceJobData {
  String? jobTitle;
  String? description;

  ViewInvoiceJobData({this.jobTitle, this.description});

  ViewInvoiceJobData.fromJson(Map<String, dynamic> json) {
    jobTitle = json['job_title'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['job_title'] = this.jobTitle;
    data['description'] = this.description;
    return data;
  }
}