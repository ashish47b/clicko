class InvoiceDataListModel {
  String? status;
  String? message;
  String? totalTransactions;
  String? totalTransAmount;
  List<InvoiceDataList>? data;

  InvoiceDataListModel(
      {this.status,
      this.message,
      this.totalTransactions,
      this.totalTransAmount,
      this.data});

  InvoiceDataListModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    totalTransactions = json['total_transactions']!=null?json['total_transactions'].toString():"";
    totalTransAmount = json['total_trans_amount']!=null?json['total_trans_amount'].toString():"";
    if (json['Data'] != null) {
      data = <InvoiceDataList>[];
      json['Data'].forEach((v) {
        data!.add(new InvoiceDataList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    data['total_transactions'] = this.totalTransactions;
    data['total_trans_amount'] = this.totalTransAmount;
    if (this.data != null) {
      data['Data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class InvoiceDataList {
  String? id;
  String? paymentId;
  String? deffDays;
  String? paymentDueDate;
  String? amount;
  String? paymentStatus;
  String? paymentApprovedStatus;
  String? quotId;
  String? jobId;
  String? custId;
  String? profId;
  String? customerPaymentDate;
  String? professionalPadStatus;
  String? professionalPaidAmount;
  String? professionalPadId;
  String? createdDate;
  String? professionalPaidDate;
  String? updatedDate;
  String?admin_commission;
  String?pro_name;
  String?cus_name;
  String?category_name;
  String?location;

  InvoiceDataList(
      {this.id,
      this.paymentId,
      this.deffDays,
      this.paymentDueDate,
      this.amount,
      this.paymentStatus,
      this.paymentApprovedStatus,
      this.quotId,
      this.jobId,
      this.custId,
      this.profId,
      this.customerPaymentDate,
      this.professionalPadStatus,
      this.professionalPaidAmount,
      this.professionalPadId,
      this.createdDate,
      this.professionalPaidDate,
      this.updatedDate,
      this.admin_commission,
      this.pro_name,
      this.cus_name,
      this.category_name,
      this.location,
      });

  InvoiceDataList.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    paymentId = json['payment_id'];
    deffDays = json['deff_days']!=null?json['deff_days'].toString():"";
    paymentDueDate = json['payment_due_date']!=null?json['payment_due_date'].toString():"";
    amount = json['amount']!=null?json['amount'].toString():"";
    paymentStatus = json['payment_status']!=null?json['payment_status'].toString():"";
    paymentApprovedStatus = json['payment_approved_status']!=null?json['payment_approved_status'].toString():"";
    quotId = json['quot_id']!=null?json['quot_id'].toString():"";
    jobId = json['job_id']!=null?json['job_id'].toString():"";
    custId = json['cust_id']!=null?json['cust_id'].toString():"";
    profId = json['prof_id']!=null?json['prof_id'].toString():"";
    customerPaymentDate = json['customer_payment_date']!=null?json['customer_payment_date'].toString():"";
    professionalPadStatus = json['professional_pad_status']!=null?json['professional_pad_status'].toString():"";
    professionalPaidAmount = ![null,""].contains(json['professional_paid_amount'])?json['professional_paid_amount'].toString():"0";
    professionalPadId = json['professional_pad_id']!=null?json['professional_pad_id'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    professionalPaidDate = json['professional_paid_date']!=null?json['professional_paid_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
    admin_commission = ![null,""].contains(json['admin_commission'])?json['admin_commission'].toString():"0";
    pro_name = json['pro_name']!=null?json['pro_name'].toString():"";
    cus_name = json['cus_name']!=null?json['cus_name'].toString():"";
    category_name = json['category_name']!=null?json['category_name'].toString():"";
    location = json['location']!=null?json['location'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['payment_id'] = this.paymentId;
    data['deff_days'] = this.deffDays;
    data['payment_due_date'] = this.paymentDueDate;
    data['amount'] = this.amount;
    data['payment_status'] = this.paymentStatus;
    data['payment_approved_status'] = this.paymentApprovedStatus;
    data['quot_id'] = this.quotId;
    data['job_id'] = this.jobId;
    data['cust_id'] = this.custId;
    data['prof_id'] = this.profId;
    data['customer_payment_date'] = this.customerPaymentDate;
    data['professional_pad_status'] = this.professionalPadStatus;
    data['professional_paid_amount'] = this.professionalPaidAmount;
    data['professional_pad_id'] = this.professionalPadId;
    data['created_date'] = this.createdDate;
    data['professional_paid_date'] = this.professionalPaidDate;
    data['updated_date'] = this.updatedDate;
    data['admin_commission'] = this.admin_commission;
    data['pro_name'] = this.pro_name;
    data['cus_name'] = this.cus_name;
    data['category_name'] = this.category_name;
    data['cus_name'] = this.cus_name;
    data['location'] = this.location;
    return data;
  }
}