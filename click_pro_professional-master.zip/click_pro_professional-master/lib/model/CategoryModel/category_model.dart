class CategoryDataModel {
  String? status;
  String? message;
  List<CategoryData>? data;

  CategoryDataModel({this.status, this.message, this.data});

  CategoryDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    if (json['Data'] != null) {
      data = <CategoryData>[];
      json['Data'].forEach((v) {
        data!.add(new CategoryData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CategoryData {
  String? id;
  String? categoryName;
  String?attachment_path;
  String?attachment;
  String?cat_image;
  CategoryData({this.id, this.categoryName});

  CategoryData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    categoryName = json['category_name']!=null?json['category_name'].toString():"";
    attachment_path = json['attachment_path']!=null?json['attachment_path'].toString():"";
    attachment = json['attachment']!=null?json['attachment'].toString():"";
    if(![null,""].contains(json["attachment_path"]) && ![null,"attachment"].contains(json["attachment"])){
       cat_image = json["attachment_path"] + json["attachment"];
       
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['category_name'] = this.categoryName;
    data['attachment_path'] = this.attachment_path;
    data['attachment'] = this.attachment;
    return data;
  }
}