class MaterialModel {
  String? materialName;
  String? materialQty;
  String? unit;
  String? unitPrice;
  String? subTotal;
  String? tax;
  String? taxAmount;
  String? totalAmount;

  MaterialModel(
      {this.materialName,
      this.materialQty,
      this.unit,
      this.unitPrice,
      this.subTotal,
      this.tax,
      this.taxAmount,
      this.totalAmount});

  MaterialModel.fromJson(Map<String, dynamic> json) {
    materialName = json['material_name'];
    materialQty = json['material_qty'];
    unit = json['unit'];
    unitPrice = json['unit_price'];
    subTotal = json['sub_total'];
    tax = json['tax'];
    taxAmount = json['tax_amount'];
    totalAmount = json['total_amount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['material_name'] = this.materialName;
    data['material_qty'] = this.materialQty;
    data['unit'] = this.unit;
    data['unit_price'] = this.unitPrice;
    data['sub_total'] = this.subTotal;
    data['tax'] = this.tax;
    data['tax_amount'] = this.taxAmount;
    data['total_amount'] = this.totalAmount;
    return data;
  }
}