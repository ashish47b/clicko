class UserDataModel {
  String? status;
  String? message;
  UserData? data;

  UserDataModel({this.status, this.message, this.data});

  UserDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['Data'] != null ? new UserData.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class UserData {
  String? id;
  String? name;
  String? email;
  String? phone;
  String? password;
  String? userType;
  String? emailVerification;
  String? resetCode;
  String? resetCodeUpdated;
  String? registerationType;
  String? logintype;
  String? lastOnline;
  String? customerToken;
  String? professionalToken;
  String? firbaseToken;
  String? updatedDate;
  String? createdDate;

  UserData(
      {this.id,
      this.name,
      this.email,
      this.phone,
      this.password,
      this.userType,
      this.emailVerification,
      this.resetCode,
      this.resetCodeUpdated,
      this.registerationType,
      this.logintype,
      this.lastOnline,
      this.customerToken,
      this.professionalToken,
      this.firbaseToken,
      this.updatedDate,
      this.createdDate});

  UserData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name']!=null?json['name'].toString():"";
    email = json['email']!=null?json['email'].toString():"";
    phone = json['phone']!=null?json['phone'].toString():"";
    password = json['password']!=null?json['password'].toString():"";
    userType = json['user_type'];
    emailVerification = json['email_verification']!=null?json['email_verification'].toString():"0";
    resetCode = json['reset_code'];
    resetCodeUpdated = json['reset_code_updated'];
    registerationType = json['registeration_type'];
    logintype = json['logintype'];
    lastOnline = json['last_online'];
    customerToken = json['customerToken'];
    professionalToken = json['professionalToken']!=null?json['professionalToken'].toString():"";
    firbaseToken = json['firbaseToken'];
    updatedDate = json['updated_date'];
    createdDate = json['created_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['email'] = this.email;
    data['phone'] = this.phone;
    data['password'] = this.password;
    data['user_type'] = this.userType;
    data['email_verification'] = this.emailVerification;
    data['reset_code'] = this.resetCode;
    data['reset_code_updated'] = this.resetCodeUpdated;
    data['registeration_type'] = this.registerationType;
    data['logintype'] = this.logintype;
    data['last_online'] = this.lastOnline;
    data['customerToken'] = this.customerToken;
    data['professionalToken'] = this.professionalToken;
    data['firbaseToken'] = this.firbaseToken;
    data['updated_date'] = this.updatedDate;
    data['created_date'] = this.createdDate;
    return data;
  }
}