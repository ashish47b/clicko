class NegotiationList {
  String? status;
  String? message;
  Job? job;
  List<Negotiation>? negotiation;
  Quot? quot;

  NegotiationList(
      {this.status, this.message, this.job, this.negotiation, this.quot});

  NegotiationList.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    job = json['job'] != null ? new Job.fromJson(json['job']) : null;
    if (json['negotiation'] != null) {
      negotiation = <Negotiation>[];
      json['negotiation'].forEach((v) {
        negotiation!.add(new Negotiation.fromJson(v));
      });
    }
    quot = json['quot'] != null ? new Quot.fromJson(json['quot']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.job != null) {
      data['job'] = this.job!.toJson();
    }
    if (this.negotiation != null) {
      data['negotiation'] = this.negotiation!.map((v) => v.toJson()).toList();
    }
    if (this.quot != null) {
      data['quot'] = this.quot!.toJson();
    }
    return data;
  }
}

class Job {
  String? id;
  String? showHomePage;
  String? custId;
  String? jobTitle;
  String? category;
  String? subcategory;
  String? tags;
  String? location;
  String? description;
  String? price;
  String? attachment;
  String? attachmentPath;
  String? status;
  String? bidCount;
  String? bidAppliedPropfessional;
  String? bidRejectedPropfessional;
  String? rejectedBid;
  String? remarksByProf;
  String? markedDone;
  String? startDate;
  String? dueDate;
  String? hiredDate;
  String? completionDate;
  String? professionalFeedback;
  String? professionalRating;
  String? professionalId;
  String? payAmount;
  String? paymentStatus;
  String? createdDate;
  String? updatedDate;

  Job(
      {this.id,
      this.showHomePage,
      this.custId,
      this.jobTitle,
      this.category,
      this.subcategory,
      this.tags,
      this.location,
      this.description,
      this.price,
      this.attachment,
      this.attachmentPath,
      this.status,
      this.bidCount,
      this.bidAppliedPropfessional,
      this.bidRejectedPropfessional,
      this.rejectedBid,
      this.remarksByProf,
      this.markedDone,
      this.startDate,
      this.dueDate,
      this.hiredDate,
      this.completionDate,
      this.professionalFeedback,
      this.professionalRating,
      this.professionalId,
      this.payAmount,
      this.paymentStatus,
      this.createdDate,
      this.updatedDate});

  Job.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    showHomePage = json['show_home_page'];
    custId = json['cust_id'];
    jobTitle = json['job_title'];
    category = json['category'];
    subcategory = json['subcategory'];
    tags = json['tags'];
    location = json['location'];
    description = json['description'];
    price = json['price'];
    attachment = json['attachment'];
    attachmentPath = json['attachment_path'];
    status = json['status'];
    bidCount = json['bid_count'];
    bidAppliedPropfessional = json['bid_applied_propfessional'];
    bidRejectedPropfessional = json['bid_rejected_propfessional'];
    rejectedBid = json['rejected_bid'];
    remarksByProf = json['remarks_by_prof'];
    markedDone = json['marked_done'];
    startDate = json['start_date'];
    dueDate = json['due_date'];
    hiredDate = json['hired_date'];
    completionDate = json['completion_date'];
    professionalFeedback = json['professional_feedback'];
    professionalRating = json['professional_rating'];
    professionalId = json['professional_id'];
    payAmount = json['pay_amount'];
    paymentStatus = json['payment_status'];
    createdDate = json['created_date'];
    updatedDate = json['updated_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['show_home_page'] = this.showHomePage;
    data['cust_id'] = this.custId;
    data['job_title'] = this.jobTitle;
    data['category'] = this.category;
    data['subcategory'] = this.subcategory;
    data['tags'] = this.tags;
    data['location'] = this.location;
    data['description'] = this.description;
    data['price'] = this.price;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['status'] = this.status;
    data['bid_count'] = this.bidCount;
    data['bid_applied_propfessional'] = this.bidAppliedPropfessional;
    data['bid_rejected_propfessional'] = this.bidRejectedPropfessional;
    data['rejected_bid'] = this.rejectedBid;
    data['remarks_by_prof'] = this.remarksByProf;
    data['marked_done'] = this.markedDone;
    data['start_date'] = this.startDate;
    data['due_date'] = this.dueDate;
    data['hired_date'] = this.hiredDate;
    data['completion_date'] = this.completionDate;
    data['professional_feedback'] = this.professionalFeedback;
    data['professional_rating'] = this.professionalRating;
    data['professional_id'] = this.professionalId;
    data['pay_amount'] = this.payAmount;
    data['payment_status'] = this.paymentStatus;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    return data;
  }
}

class Negotiation {
  String? id;
  String? paymentId;
  String? deffDays;
  String? paymentDueDate;
  String? amount;
  String? paymentStatus;
  String? paymentApprovedStatus;
  String? quotId;
  String? jobId;
  String? custId;
  String? profId;
  String? customerPaymentDate;
  String? professionalPadStatus;
  String? professionalPaidAmount;
  String? professionalPadId;
  String? createdDate;
  String? professionalPaidDate;
  String? updatedDate;

  Negotiation(
      {this.id,
      this.paymentId,
      this.deffDays,
      this.paymentDueDate,
      this.amount,
      this.paymentStatus,
      this.paymentApprovedStatus,
      this.quotId,
      this.jobId,
      this.custId,
      this.profId,
      this.customerPaymentDate,
      this.professionalPadStatus,
      this.professionalPaidAmount,
      this.professionalPadId,
      this.createdDate,
      this.professionalPaidDate,
      this.updatedDate});

  Negotiation.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    paymentId = json['payment_id']!=null?json['payment_id'].toString():"";
    deffDays =![null,""].contains(json['deff_days'])?json['deff_days'].toString():"0";
    paymentDueDate = json['payment_due_date']!=null?json['payment_due_date'].toString():"";
    amount = json['amount']!=null?json['amount'].toString():"";
    paymentStatus = json['payment_status']!=null?json['payment_status'].toString():"";
    paymentApprovedStatus = json['payment_approved_status']!=null?json['payment_approved_status'].toString():"";
    quotId = json['quot_id']!=null?json['quot_id'].toString():"";
    jobId = json['job_id']!=null?json['job_id'].toString():"";
    custId = json['cust_id']!=null?json['cust_id'].toString():"";
    profId = json['prof_id']!=null?json['prof_id'].toString():"";
    customerPaymentDate = json['customer_payment_date']!=null?json['customer_payment_date'].toString():"";
    professionalPadStatus = json['professional_pad_status']!=null?json['professional_pad_status'].toString():"";
    professionalPaidAmount = json['professional_paid_amount']!=null?json['professional_paid_amount'].toString():"";
    professionalPadId = json['professional_pad_id']!=null?json['professional_pad_id'].toString():"";
    createdDate = json['created_date']!=null?json['created_date'].toString():"";
    professionalPaidDate = json['professional_paid_date']!=null?json['professional_paid_date'].toString():"";
    updatedDate = json['updated_date']!=null?json['updated_date'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['payment_id'] = this.paymentId;
    data['deff_days'] = this.deffDays;
    data['payment_due_date'] = this.paymentDueDate;
    data['amount'] = this.amount;
    data['payment_status'] = this.paymentStatus;
    data['payment_approved_status'] = this.paymentApprovedStatus;
    data['quot_id'] = this.quotId;
    data['job_id'] = this.jobId;
    data['cust_id'] = this.custId;
    data['prof_id'] = this.profId;
    data['customer_payment_date'] = this.customerPaymentDate;
    data['professional_pad_status'] = this.professionalPadStatus;
    data['professional_paid_amount'] = this.professionalPaidAmount;
    data['professional_pad_id'] = this.professionalPadId;
    data['created_date'] = this.createdDate;
    data['professional_paid_date'] = this.professionalPaidDate;
    data['updated_date'] = this.updatedDate;
    return data;
  }
}

class Quot {
  String? id;
  String? userId;
  String? jobId;
  String?cust_id;
  String? clientrefId;
  String? estimate;
  String? totalVat;
  String? estimatePrice;
  String? estimateProjectTime;
  String? coverDescription;
  String? sendQuot;
  String? instalmentPlan;
  String? attachment;
  String? attachmentPath;
  String? priceDownload;
  String? workStartDate;
  String? workEndDate;
  String? comment;
  String? necessaryMaterial;
  String? materialDetails;
  String? milestone;
  String? customerNegotiationCount;
  String? professionalNegotiationCount;
  String? total;
  String? totalTax;
  String? grandTotal;
  String? grandTotalEstimatePrice;
  String? status;
  String? createdDate;
  String? updatedDate;

  Quot(
      {this.id,
      this.userId,
      this.jobId,
      this.clientrefId,
      this.estimate,
      this.totalVat,
      this.estimatePrice,
      this.estimateProjectTime,
      this.coverDescription,
      this.sendQuot,
      this.instalmentPlan,
      this.attachment,
      this.attachmentPath,
      this.priceDownload,
      this.workStartDate,
      this.workEndDate,
      this.comment,
      this.necessaryMaterial,
      this.materialDetails,
      this.milestone,
      this.customerNegotiationCount,
      this.professionalNegotiationCount,
      this.total,
      this.totalTax,
      this.grandTotal,
      this.grandTotalEstimatePrice,
      this.status,
      this.createdDate,
      this.cust_id,
      this.updatedDate});

  Quot.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    jobId = json['job_id'];
    clientrefId = json['clientref_id'];
    estimate = json['estimate']!=null?json['estimate'].toString():"";
    totalVat = json['total_vat'];
    estimatePrice = json['estimate_price']!=null?json['estimate_price'].toString():"";
    estimateProjectTime = json['estimate_project_time'];
    coverDescription = json['cover_description'];
    sendQuot = json['send_quot'];
    instalmentPlan = json['instalment_plan']!=null?json['instalment_plan'].toString():"";
    attachment = json['attachment'];
    attachmentPath = json['attachment_path'];
    priceDownload = json['price_download'];
    workStartDate = json['work_start_date'];
    workEndDate = json['work_end_date'];
    comment = json['comment'];
    necessaryMaterial = json['necessary_material'];
    materialDetails = json['material_details'];
    milestone = json['milestone'];
    customerNegotiationCount = json['customer_negotiation_count'];
    professionalNegotiationCount = json['professional_negotiation_count'];
    total = json['total'];
    totalTax = json['total_tax'];
    grandTotal = json['grand_total'];
    grandTotalEstimatePrice = json['grand_total_estimate_price'];
    status = json['status'];
    createdDate = json['created_date'];
    updatedDate = json['updated_date'];
    cust_id = json['cust_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['job_id'] = this.jobId;
    data['clientref_id'] = this.clientrefId;
    data['estimate'] = this.estimate;
    data['total_vat'] = this.totalVat;
    data['estimate_price'] = this.estimatePrice;
    data['estimate_project_time'] = this.estimateProjectTime;
    data['cover_description'] = this.coverDescription;
    data['send_quot'] = this.sendQuot;
    data['instalment_plan'] = this.instalmentPlan;
    data['attachment'] = this.attachment;
    data['attachment_path'] = this.attachmentPath;
    data['price_download'] = this.priceDownload;
    data['work_start_date'] = this.workStartDate;
    data['work_end_date'] = this.workEndDate;
    data['comment'] = this.comment;
    data['necessary_material'] = this.necessaryMaterial;
    data['material_details'] = this.materialDetails;
    data['milestone'] = this.milestone;
    data['customer_negotiation_count'] = this.customerNegotiationCount;
    data['professional_negotiation_count'] = this.professionalNegotiationCount;
    data['total'] = this.total;
    data['total_tax'] = this.totalTax;
    data['grand_total'] = this.grandTotal;
    data['grand_total_estimate_price'] = this.grandTotalEstimatePrice;
    data['status'] = this.status;
    data['created_date'] = this.createdDate;
    data['updated_date'] = this.updatedDate;
    data['cust_id'] = this.cust_id;
    return data;
  }
}