
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/ChatUsers/all_messages.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';
import 'package:provider/provider.dart';

class ChatScreen extends StatefulWidget {
  String?customerID,first_name,last_name;
  ChatScreen({this.customerID,this.first_name,this.last_name});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }

  getData()async {
    await Provider.of<UserProvider>(context,listen: false).allMessage(widget.customerID);
    getAfterData();
  }
  getAfterData() async{
    await Future.delayed(Duration(seconds: 5));
    getData();
  }

  Size?_size;

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return Scaffold(
      appBar: AppBar(
            backgroundColor: AppColor.appThemeColorOlive,
            elevation: 0,
            //automaticallyImplyLeading: false,
            title: Text(widget.first_name!=""?widget.first_name!:widget.customerID! ,style: AppTextStyles.k18TextN,),

      ),
      body: Stack(
        children: [
          Column(
            children: [
               
               Expanded(
                  child: GroupedListView<ChatMessage, DateTime>(
                    padding: const EdgeInsets.all(8),
                    reverse: true,
                    order: GroupedListOrder.DESC,
                    useStickyGroupSeparators: true,
                    floatingHeader: true,
                    elements: model.messageList,
                    groupBy: (element) => DateTime(DateTime.now().year),
                    // groupBy: (message) => DateTime(
                    //   message.createdAt.year,
                    //   message.date.month,
                    //   message.date.day,
                    // ),
                    groupHeaderBuilder: (ChatMessage message) =>const SizedBox(
                      // height: 40,
                      // child: Center(
                      //   child: Card(
                      //     //color: Color(0xff4169E1),
                      //     child: Padding(
                      //       padding: const EdgeInsets.all(8),
                      //       // child: Text(
                      //       //   DateFormat.yMMMd().format(message.date),
                      //       //   style: const TextStyle(color: Colors.white),
                      //       // ),
                      //     ),
                      //   ),
                      // ),
                    ),
                    itemBuilder: (context, ChatMessage message) => Align(
                      alignment: message.createdBy==widget.customerID
                          ? Alignment.centerLeft
                          : Alignment.centerRight,
                      child: Card(
                        elevation: 8,
                        color: message.createdBy==widget.customerID? AppColor.appThemeColorOlive.withOpacity(0.3) : AppColor.appThemeColorOlive.withOpacity(0.5),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(message.message!),
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                
                  margin: EdgeInsets.only(
                    left: _size!.width / 18,
                    right: _size!.width / 18,
                    bottom: _size!.height / 40,
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.only(left: _size!.width / 30),
                          height: 50,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            // color: Colours.bgColor,
                            border: Border.all(color: Colors.black, width: 1),
                          ),
                          child: Row(
                            children: [
                              // SvgPicture.asset("images/icons/smile.svg"),
                              SizedBox(
                                width: _size!.width / 36,
                              ),
                              Expanded(
                                child: TextField(
                                  onChanged: (value) {
                                    setState(() {});
                                  },
                                  controller: _textController,
                                  cursorColor: Colors.deepPurple,
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    hintText: "Type Message..",
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        width: _size!.width / 36,
                      ),
                      Visibility(
                        visible: _textController.text
                            .isNotEmpty, // If message is not empty then send button will visible
                        child: GestureDetector(
                          onTap: () async{
                           // addMessage(model);
                            
                            // final message = MessageModel(
                            //   text: _textController.text,
                            //   date: DateTime.now(),
                            //   isSentByMe: true,
                            // );
                             await model.addMessage(widget.customerID, _textController.text);
                            setState(() {
                              //messages.add(message);
                              _textController.clear();
                            });
                          },
                          child: Container(
                            padding: EdgeInsets.all(8),
                            height: 42,
                            width: 42,
                            decoration: BoxDecoration(
                                color: AppColor.appThemeColorOlive.withOpacity(0.2),
                                shape: BoxShape.circle,
                                border: Border.all(color: AppColor.appThemeColorOlive)),
                            child: Image.asset(
                              "assets/images/send.png",
                              height: 20,
                            ),
                            // child: SvgPicture.asset(
                            //   "images/icons/send.svg",
                            //   height: 17,
                            //   width: 11,
                            // ),
                          ),
                        ),
                        replacement: Container(),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        
         model.isLoading!?CustomLoader():Container()
        ],
      ),
    );
    });
  }
  TextEditingController _textController = TextEditingController();
}


class MessageModel {
  final String text;
  final DateTime date;
  final bool isSentByMe;

  MessageModel({required this.text, required this.date, required this.isSentByMe});
}

