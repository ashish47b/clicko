import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/ChatUsers/chat_user_list.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/Chat/chat_screen.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AllChats extends StatefulWidget {
  const AllChats({super.key});

  @override
  State<AllChats> createState() => _AllChatsState();
}

class _AllChatsState extends State<AllChats> {
   
  @override
  void initState() {
    // TODO: implement initState
    Future.delayed(Duration(milliseconds: 300),()=> getData());
    super.initState();
  }

  getData()async {
    await Provider.of<UserProvider>(context,listen: false).chatUser();
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return Scaffold(
        appBar:AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          centerTitle: true,
          title: Text("CHATS".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
          iconTheme:const IconThemeData(color: Colors.black),
        ),
        body: Container(
        child: Column(
          children: [
          const Divider(color: Colors.black,),
         
            Expanded(
              child: ListView.builder(
              itemCount: model.chatUserList.length,
              itemBuilder: (context,index){
                ChatUser obj = model.chatUserList[index];
              return InkWell(
              onTap: (){
                navigateWithPageTransition(context, ChatScreen(customerID: obj.id,first_name: obj.name!));
              },
              child: Container(
                padding:const EdgeInsets.symmetric(vertical: 5,horizontal: 10),
                margin:const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  //border: Border.all(color: Colors.black),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: AppColor.appThemeColorOlive.withOpacity(0.2),
                      
                      spreadRadius: 3,blurRadius: 3
                    )
                  ]
                ),
                child: Row(
                  children: [
                    obj.profilePic!=null && obj.profilePic!=""?
                   Container(
                    height: 60,
                    width: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                       image: DecorationImage(image: NetworkImage(obj.profilePicPath! + obj.profilePic!),fit: BoxFit.fill)
                    ),
                   ) :Container(
                    height: 60,
                    width: 60,
                    decoration:const BoxDecoration(
                      shape: BoxShape.circle,
                       image: DecorationImage(image: AssetImage("assets/icons/profile_image.png"), fit: BoxFit.fill)
                    ),
                   ) ,
                   const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(obj.name!,style: AppTextStyles.k18TextN,),
                        //Text("Plumber",style: AppTextStyles.k16TextN,),
                        
                      ],
                    )
                  ],
                ),
              ),
            );
            }))
          ],
        ),
    ),
      );
    });
  }
}