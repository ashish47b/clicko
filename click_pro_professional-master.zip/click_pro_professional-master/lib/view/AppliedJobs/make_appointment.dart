import 'dart:io';

import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MakeAppointment extends StatefulWidget {
 String?job_id,quote_id;
 MakeAppointment({this.job_id,this.quote_id});

  @override
  State<MakeAppointment> createState() => _MakeAppointmentState();
}

class _MakeAppointmentState extends State<MakeAppointment> {

  

  final titleController = TextEditingController(text: "");
  final appointController = TextEditingController(text: "");
  final desscController = TextEditingController(text: "");
     String? selectedImage;

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return Scaffold(
      appBar: AppBar(
        title: Text("Make Appointment".tr(),style: AppTextStyles.k18TextN.copyWith(color: Colors.black)),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        iconTheme:const IconThemeData(color: Colors.black),
      ),
      body: Stack(
        children: [
          ListView(
            padding:const EdgeInsets.symmetric(horizontal: 12),
            children: [
                SizedBox(height: _size!.height*0.01),
                getTextFieldTextType("Enter Title".tr(), "Enter Title".tr(),radius: 10, controller: titleController),
                SizedBox(height: _size!.height*0.01),
                getTextFieldTextType("Add Appointment".tr(), "Add Appointment".tr(),radius: 10, controller: appointController),
                SizedBox(height: _size!.height*0.01),
                              
                  InkWell(
                    onTap: (){
                      selectDate();
                    },
                    child: Container(
                      height: 50,
                      padding:const EdgeInsets.symmetric(horizontal: 10),
                      decoration: BoxDecoration(
                       borderRadius: BorderRadius.circular(20),
                       border: Border.all(color: AppColor.appThemeColorOlive)
                      ),
                      child: Row(
                        children: [
                         const Icon(Icons.calendar_today, color: AppColor.appThemeColorOlive,),
                         const SizedBox(width: 10),
                          Text(currentTime!=null && dateSet!?currentTime!.toString().substring(0,10) :"Select Due Date", style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),)
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: _size!.height*0.02),
                  
                  InkWell(
                    onTap: (){
                      _selectTime(context);
                    },
                    child: Container(
                      height: 50,
                      padding:const EdgeInsets.symmetric(horizontal: 10),
                      decoration: BoxDecoration(
                       borderRadius: BorderRadius.circular(20),
                       border: Border.all(color: AppColor.appThemeColorOlive)
                      ),
                      child: Row(
                        children: [
                         const Icon(Icons.calendar_today, color: AppColor.appThemeColorOlive,),
                         const SizedBox(width: 10),
                          Text(selectedTime!=null ? selectedTime.toString():"Select Time", style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),)
                        ],
                      ),
                    ),
                  ),
                SizedBox(height: _size!.height*0.02),
                getTextFieldTextType("Enter Description".tr(), "Enter Description".tr(),radius: 10, controller: desscController),
                SizedBox(height: _size!.height*0.02),
                InkWell(
                onTap: ()async{
                 String?str= await pickedImage(context);
                 if(![null,""].contains(str)){
                   selectedImage = str;
                 }
                 setState(() {
                   
                 });
                },
                child: Container(
                  padding:const EdgeInsets.symmetric(vertical: 3),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColor.appThemeColorOlive),
                    borderRadius: BorderRadius.circular(12),
                    color: AppColor.appThemeColorOlive
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.add,color: Colors.white),
                      const SizedBox(width: 6),
                      Text("Attach Files",style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
                    ],
                  ),
                ),
              ),
             
             SizedBox(height: _size!.height*0.01),
             selectedImage!=null? Wrap(
               children: [
                 Container(
                  height: 80,width: 80,
                  decoration: BoxDecoration(
                    border: Border.all(color:AppColor.appThemeColorOlive),
                    borderRadius: BorderRadius.circular(10),
                    image: DecorationImage(image: FileImage(File(selectedImage!)),fit: BoxFit.fill)
                  ),
                 ),
               ],
             ):Container()
            ],
          ),
         
         model.isLoading!?CustomLoader():Container()
        ],
      ),
      bottomNavigationBar: InkWell(
        onTap: ()async{
          if(titleController.text.isNotEmpty && appointController.text.isNotEmpty){
            await model.saveAppointment(context,
                title: titleController.text,
                appointmnet: appointController.text,
                desc: desscController.text,
                date:currentTime!=null? ddMMMyyyy.format(currentTime!) :"",
                quote_id: widget.quote_id,
                job_Id: widget.job_id,
                attach_file: selectedImage!=null?selectedImage:""
            );

          }else{
            showToastMsg("Enter Details".tr());
          }
        },
        child: Container(
          margin:const EdgeInsets.symmetric(horizontal: 12,vertical: 10),
          height: 45,
          decoration: BoxDecoration(
            color: AppColor.appThemeColorOlive,
            borderRadius: BorderRadius.circular(12)
          ),
          child: Center(
            child: Text("Save".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
          ),
        ),
      ),
    );
    });
  }

  bool?dateSet = false;
  DateTime? currentTime;
  selectDate() async{
    DateTime? date = DateTime.now();
    var newDate = new DateTime(date.year, date.month - 11, date.day);
    DateTime? newDateFrom=await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: newDate,
        lastDate: DateTime(2100));
    if (newDateFrom !=null) {
      setState(() {
        
      });
      currentTime = newDateFrom;
      dateSet = true;
      //getData();
    }
   }
   
TimeOfDay selectedTime = TimeOfDay.now();

Future<void> _selectTime(BuildContext context) async {
final TimeOfDay? picked_s = await showTimePicker(
    context: context,
    initialTime: selectedTime, builder: (BuildContext? context, Widget? child) {
       return MediaQuery(
         data: MediaQuery.of(context!).copyWith(alwaysUse24HourFormat: false),
        child: child!,
      );});

if (picked_s != null && picked_s != selectedTime )
  setState(() {
    selectedTime = picked_s;
  });
}

}