import 'dart:convert';

import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/QuoteModel/quote_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
//import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:provider/provider.dart';

class NegotiationPage extends StatefulWidget {
  String?quote_id;
  String?installment;
  String?price;
  QuoteData?obj;

  NegotiationPage({this.installment,this.obj,this.price,this.quote_id});

  @override
  State<NegotiationPage> createState() => _NegotiationPageState();
}

class _NegotiationPageState extends State<NegotiationPage> {
  

  getData()async{
     Provider.of<UserProvider>(context,listen: false).negotiationListAPI(quote_id: widget.quote_id);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }

  final installmentController = TextEditingController(text: "");
  final priceController = TextEditingController(text: "");
  final percentageController = TextEditingController(text: "");
  final dateController = TextEditingController(text: "");
  UserProvider? myProvider;
  Size?_size;
  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context,listen: false);
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      if(model.quote!=null){
      print("Enter");
       installmentController.text = model.quote!.instalmentPlan!=null?myProvider!.quote!.instalmentPlan!:"";
       priceController.text = model.quote!.estimate!=null?myProvider!.quote!.estimate!:"";
       percentageController.text = "0 %";
       dateController.text = model.quote!.workStartDate!=null?myProvider!.quote!.workStartDate!:"";
     }
      return Scaffold(
      appBar: AppBar(
        title: Text("Negotiation Page",style: AppTextStyles.k18TextN.copyWith(color: Colors.black)),
        iconTheme:const IconThemeData(color: Colors.black),
        backgroundColor: Colors.transparent,
        elevation: 0.0,
      ),

      body: ListView(
        padding:const EdgeInsets.symmetric(horizontal: 8),
        children: [
          SizedBox(height: _size!.height*0.01),
          Row(
            children: [
              Text("Price For Professionals" + " : ",style: AppTextStyles.k16TextN),
              Text("€ "+ (model.quote!=null && model.quote!.estimate!=null?model.quote!.estimate!:""),style: AppTextStyles.k16TextN,)
            ],
          ),
          SizedBox(height: _size!.height*0.02),
          model.negotiationList!=null && model.negotiationList.length>0
          ?Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Milestone",style: AppTextStyles.k16TextN),
              const SizedBox(height: 10),
              Container(margin:const EdgeInsets.symmetric(horizontal: 10), child: getTextFieldTextType("Installment", "Installment",isEnabled: false, radius: 10,controller: installmentController)),
              ListView.builder(
                itemCount: model.negotiationList.length,
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: (context,index){
                return Container(
                padding: const EdgeInsets.all(7),
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColor.appThemeColorOrange)
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Container(
                          padding:const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                          border: Border.all(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(child: Text(model.negotiationList[index].amount!,style: AppTextStyles.k14TextN),),)),
                        const SizedBox(width: 5),
                         Expanded(child: Container(
                          padding:const EdgeInsets.symmetric(vertical: 8),
                          decoration: BoxDecoration(
                          border: Border.all(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(child: Text(model.negotiationList[index].deffDays! + " %",style: AppTextStyles.k16TextN),),)),
                        const SizedBox(width: 5),
                        Expanded(child: Container(
                          padding:const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                          border: Border.all(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(child: Text(model.negotiationList[index].paymentDueDate!,style: AppTextStyles.k14TextN),),)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    if(model.negotiationList[index].paymentStatus!=null &&model.negotiationList[index].paymentStatus=="Complete")
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 20,vertical: 5),
                          decoration: BoxDecoration(
                            color: AppColor.appThemeColorGreen,
                            borderRadius: BorderRadius.circular(6)
                          ),
                          child: Center(child: Text("Complete",style: AppTextStyles.k16TextN.copyWith(color: Colors.white))),
                        )
                      ],
                    ),
                  ],
                ),
              );
              }),
            ],
          )
          :Container(
            padding: const EdgeInsets.all(7),
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              border: Border.all(color: AppColor.appThemeColorOrange)
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Milestone",style: AppTextStyles.k16TextN),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: getTextFieldTextType("Installment", "Installment",isEnabled: false, radius: 10,controller: installmentController)),
                    const SizedBox(width: 10),
                    Expanded(child: getTextFieldTextType("Amount", "Amount",isEnabled: false, radius: 10,controller: priceController))
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: getTextFieldTextType("Percentage(%)", "Percentage(%)",isEnabled: false, radius: 10,controller: percentageController)),
                    const SizedBox(width: 10),
                    Expanded(child: getTextFieldTextType("Date", "Date",isEnabled: false, radius: 10,controller: dateController))
                  ],
                ),
              ],
            ),
          ),
       
          SizedBox(height:_size!.height*0.02),
          if(model.negotiationList!=null && model.negotiationList.length>0 && model.quote!.customerNegotiationCount=="1" && model.quote!.professionalNegotiationCount!="1" )
          Row(
            children: [
              TextButton(onPressed: (){
                model.approveNegotiation(context, quote_id: model.quote!.id, status: "1");
              },style: ButtonStyle(backgroundColor: MaterialStateProperty.all(AppColor.appThemeColorOrange)), child: Text("Approve",style: AppTextStyles.k16TextN.copyWith(color: Colors.white))),
              const SizedBox(width: 10),
              TextButton(onPressed: (){
                model.approveNegotiation(context, quote_id: model.quote!.id, status: "2");
              },style: ButtonStyle(backgroundColor: MaterialStateProperty.all(AppColor.appRedColor)), child: Text("Reject",style: AppTextStyles.k16TextN.copyWith(color: Colors.white))),
            ],
          )

        ],
      ),
    );
    });
  }
  saveData(UserProvider model)async{

  if(model.quote==null && [null,""].contains(model.quote!.instalmentPlan)){
    showToastMsg("No Data");
    return;
  }

    List<NegotiationData> list =[];
    for(int i=0;i<model.negotiationList.length;i++){
      NegotiationData obj1 = NegotiationData(
        negeditId: "0",
        amount: model.negotiationList[i].amount,
        deffDays: model.negotiationList[i].deffDays,
        paymentDueDate: model.negotiationList[i].paymentDueDate,
      );
      list.add(obj1);
    }
    print(jsonEncode(list));

    
    SaveNegotiationData obj = SaveNegotiationData(
      quote_id: model.quote!=null ? model.quote!.id!:"",
      jobId:  model.quote!=null && model.quote!.jobId!=null ? model.quote!.jobId:"",
      negotiationData: list,
      userId: model.quote!.userId,
      milestone: model.quote!.instalmentPlan,
      cust_id: ![null,""].contains(model.quote!.cust_id)?model.quote!.cust_id: model.negotiationList[0].custId,
      estimate_price: model.quote!.estimate,
    );

    print(jsonEncode(obj));
    //model.saveNegotiation(context, obj);
    model.approveNegotiation(context, quote_id: model.quote!.id, status: "0");
}
}

class SaveNegotiationData {
  String? quote_id;
  String?cust_id;
  String? jobId;
  List<NegotiationData>? negotiationData;
  String? userId;
  String? milestone;
  String?estimate_price;

  SaveNegotiationData(
      {this.quote_id,
      this.jobId,
      this.negotiationData,
      this.userId,
      this.milestone,this.cust_id,
      this.estimate_price,
      });

  SaveNegotiationData.fromJson(Map<String, dynamic> json) {
    quote_id = json['quote_id'];
    jobId = json['job_id'];
    if (json['negotiation_data'] != null) {
      negotiationData = <NegotiationData>[];
      json['negotiation_data'].forEach((v) {
        negotiationData!.add(new NegotiationData.fromJson(v));
      });
    }
    userId = json['userId'];
    milestone = json['milestone'];
    cust_id = json['cust_id'];
    estimate_price=  json['estimate_price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['quote_id'] = this.quote_id;
    data['job_id'] = this.jobId;
    if (this.negotiationData != null) {
      data['negotiation_data'] =
          this.negotiationData!.map((v) => v.toJson()).toList();
    }
    data['userId'] = this.userId;
    data['milestone'] = this.milestone;
    data['cust_id'] = this.cust_id;
    data['estimate_price'] = this.estimate_price;
    return data;
  }
}

class NegotiationData {
  String? negeditId;
  String? amount;
  String? deffDays;
  String? paymentDueDate;

  NegotiationData(
      {this.negeditId, this.amount, this.deffDays, this.paymentDueDate});

  NegotiationData.fromJson(Map<String, dynamic> json) {
    negeditId = json['negedit_id']!=null?json['negedit_id'].toString():"";
    amount = json['amount']!=null?json['amount'].toString():"";
    deffDays = json['deff_days']!=null?json['deff_days'].toString():"";
    paymentDueDate = json['payment_due_date']!=null?json['payment_due_date'].toString():"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['negedit_id'] = this.negeditId;
    data['amount'] = this.amount;
    data['deff_days'] = this.deffDays;
    data['payment_due_date'] = this.paymentDueDate;
    return data;
  }
}