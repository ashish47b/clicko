import 'package:clik_pro_professional/model/QuoteModel/quote_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/AppliedJobs/make_appointment.dart';
import 'package:clik_pro_professional/view/AppliedJobs/negotiation_page.dart';
import 'package:clik_pro_professional/view/AppliedJobs/view_quotes.dart';
import 'package:clik_pro_professional/view/Quote/send_quote.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class QuotesItem extends StatefulWidget {
QuoteData?obj;
final tabIndex;

QuotesItem({this.obj,this.tabIndex});

  @override
  State<QuotesItem> createState() => _QuotesItemState();
}

class _QuotesItemState extends State<QuotesItem> {


  
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Container(
       child: Column(
            //padding: const EdgeInsets.symmetric(horizontal: 16),
          children: [

                SizedBox(height: _size!.height*0.01),

               SizedBox(height: _size!.height*0.02),
               InkWell(
                onTap: (){
                     // Get.toNamed(RoutesName.joDetailsView);
                },
                 child: Container(
                   //height: 150,
                   margin:const EdgeInsets.symmetric(horizontal: 12),
                   padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                   decoration: BoxDecoration(
                      border: Border.all(color: AppColor.appThemeColorGreen)
                   ),
                   child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(child: Text(widget.obj!.jobTitle!,style: AppTextStyles.k18TextH.copyWith(color: AppColor.appThemeColorSky))),
                           
                            Container(
                              
                              padding:const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: AppColor.appThemeColorGreen,
                                borderRadius: BorderRadius.circular(10)
                              ),
                              child: Text("€ "+ widget.obj!.estimatePrice!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                            ),

                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const Icon(Icons.calendar_today,color: AppColor.appThemeColorOlive),
                            const SizedBox(width: 5),
                            Text("Posted on".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(ddMMMyyyy.format(DateTime.parse(widget.obj!.createdDate!)).toString(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorGreen),)
                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const Icon(Icons.calendar_today,color: AppColor.appThemeColorOlive),
                            const SizedBox(width: 5),
                            Text("Expires on".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(ddMMMyyyy.format(DateTime.parse(widget.obj!.dueDate!)).toString(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appRedColor),)
                          ],
                        ),
                          SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/auction.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Category".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(widget.obj!.bidCount!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                         SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/auction.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Number of Payments".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text(widget.obj!.instalmentPlan!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                        SizedBox(height: _size!.height*0.01),
                        Row(
                          children: [
                            const ImageIcon(AssetImage("assets/icons/auction.png"), color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 5),
                            Text("Client Id".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                            Text("COC-"+ widget.obj!.custId!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                          ],
                        ),
                        Divider(color: Colors.grey,),
                        SizedBox(height: _size!.height*0.01),
                        Text(widget.obj!.coverDescription!,style: AppTextStyles.k14TextN,maxLines: 4,overflow: TextOverflow.ellipsis,),
                        SizedBox(height: _size!.height*0.01),
                        Divider(color: Colors.grey,),
                        Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [

                                 //const SizedBox(width: 10),
                                 if(widget.tabIndex=="0" || widget.tabIndex=="1" || widget.tabIndex=="2")
                                 Expanded(
                                   child: InkWell(
                                    onTap: (){
                                      navigateWithPageTransition(context, ViewQuotes(quote_id: widget.obj!.id));
                                      //Get.toNamed(RoutesName.view_quotes,arguments: [widget.obj!.id]);
                                    },
                                     child: Container(
                                      padding:const EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: AppColor.appThemeColorOrange,
                                        borderRadius: BorderRadius.circular(8)
                                      ),
                                      child:Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text("View".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                                          SizedBox(width: 10),
                                          Icon(Icons.remove_red_eye, color: Colors.white,)
                                        ],
                                      )
                                     ),
                                ),
                                 ),
                                 const SizedBox(width: 6),
                                if(widget.tabIndex=="0" || widget.tabIndex=="1")
                                Expanded(
                                  child: InkWell(
                                    onTap: (){
                                      navigatetoAnotherPage(context,
                                          SendQuote(job_id:  widget.obj!.jobId,obj: widget.obj,customer_budget: widget.obj!.estimate,));
                                    },
                                     child: Container(
                                      padding:const EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: AppColor.appThemeColorOrange,
                                        borderRadius: BorderRadius.circular(8)
                                      ),
                                      child:Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text("Edit".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                                          SizedBox(width: 10),
                                          Icon(Icons.edit, color: Colors.white,)
                                        ],
                                      )),
                                   ),
                                ),



                              ],
                            ),
                            SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                if(widget.tabIndex=="1")
                                Expanded(
                                   child: InkWell(
                                    onTap: (){
                                      navigatetoAnotherPage(context, MakeAppointment(quote_id: widget.obj!.id,job_id: widget.obj!.jobId!,));
                                      //Get.toNamed(RoutesName.view_job,arguments: [widget.obj!.id]);
                                    },
                                     child: Container(
                                      padding:const EdgeInsets.symmetric(horizontal: 4,vertical: 6),
                                      decoration: BoxDecoration(
                                        color: AppColor.appThemeColorOrange,
                                        borderRadius: BorderRadius.circular(8)
                                      ),
                                      child:Center(child: Text("Appointment".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),))                               ),
                                   ),
                                 ),

                                const SizedBox(width: 2),
                                if(widget.tabIndex=="0" || widget.tabIndex=="1")
                                Expanded(
                                  child: InkWell(
                                    onTap: (){
                                      navigatetoAnotherPage(context, NegotiationPage(quote_id: widget.obj!.id,obj: widget.obj, installment:widget.obj!.instalmentPlan, price: widget.obj!.estimate,));
                                      //Get.toNamed(RoutesName.view_job,arguments: [widget.obj!.id]);
                                    },
                                     child: Container(
                                         padding:const EdgeInsets.symmetric(horizontal: 4,vertical: 6),
                                      decoration: BoxDecoration(
                                        color: AppColor.appThemeColorOrange,
                                        borderRadius: BorderRadius.circular(8)
                                      ),
                                      child:Text("Negotiation".tr(),textAlign: TextAlign.center,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)                               ),
                                   ),
                                ),



                              ],
                            ),
                          ],
                        )
                    ],
                   ),
                             ),
               ),
          ],
        ),
    );
  }
}