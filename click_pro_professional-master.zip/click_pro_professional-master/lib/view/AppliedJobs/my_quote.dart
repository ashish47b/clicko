
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/QuoteModel/quote_model.dart';
import 'package:clik_pro_professional/view/AppliedJobs/quote_item.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:clik_pro_professional/widgets/NoData.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../utils/app_color.dart';

class MyQuote extends StatefulWidget {
  const MyQuote({super.key});

  @override
  State<MyQuote> createState() => _MyQuoteState();
}

class _MyQuoteState extends State<MyQuote> {

    var scController=ScrollController();



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    scController.addListener(listener);
    Future.delayed(Duration(milliseconds: 300),(() => getData()));
  }

  getData()async{
   if(currentIndex ==0){
       Provider.of<UserProvider>(context,listen: false).pendingQuote(limit: skipValue);
   }else if(currentIndex ==1){
      Provider.of<UserProvider>(context,listen: false).activeQuote(limit: skipValue);
   }else if(currentIndex==2){
     Provider.of<UserProvider>(context,listen: false).rejextQuote(limit: skipValue);
   }
  }
  int currentIndex = 0;
  int skipValue=1;
  listener(){
    if(scController.position.pixels == scController.position.maxScrollExtent){
      skipValue=skipValue+1;
      getData();
      print("called");
    }else{
      print("sorry");
    }
  }



  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,controller,child){
      return Stack(
        children: [
          Container(
          width: _size!.width,
    //  height: _size!.height,
          child: DefaultTabController(length: 3, child: Column(
           children: [
            Divider(color: Colors.black,),
            Container(
                 height: 50,
                 decoration: BoxDecoration(
           //color: primaryColor
                 ),
                 child: TabBar(tabs: [
            Text("Pending".tr()),
            Text("Accepted".tr()),
            Text("Rejected".tr()),
                 //  Text("DisApproved")
                 ],indicatorColor: AppColor.appThemeColorOrange,
                     isScrollable: false,automaticIndicatorColorAdjustment: true,
                   unselectedLabelColor: Colors.black54,
                   labelColor: AppColor.appThemeColorOlive,
                   physics: NeverScrollableScrollPhysics(),
                   indicator: UnderlineTabIndicator(
                   borderSide: BorderSide(color: AppColor.appThemeColorOlive, width: 4.0),
                   //insets: EdgeInsets.fromLTRB(50.0, 0.0, 50.0, 40.0),
            
                   ),onTap: (val){
                     print(val);
                      currentIndex = val;
                      skipValue = 1;
                      //getData();
                     },
          
                 ),
          ),
             Expanded(
               child: TabBarView(children: [
                      controller.pendingQuoteList!=null && controller.pendingQuoteList.length>0 && 
                      !controller.isLoading!?  ListView.builder(
                        itemCount: controller.pendingQuoteList.length,
                        shrinkWrap: true,
                        controller: scController,
                        itemBuilder: (context,index){
                          print("isime aa rha h");
                        QuoteData obj = controller.pendingQuoteList[index];
                        return QuotesItem(obj: obj,tabIndex: "0",);
                       }) : NoDataWidget(isloading: controller.isLoading!),
                        
                        //current Index =1
                        controller.activeQuoteList!=null && controller.activeQuoteList.length>0?  ListView.builder(
                        itemCount: controller.activeQuoteList.length,
                        shrinkWrap: true,
                        controller: scController,
                        itemBuilder: (context,index){
                        QuoteData obj = controller.activeQuoteList[index];
                        return QuotesItem(obj: obj,tabIndex: "1",);
                       }) : NoDataWidget(isloading: controller.isLoading),

                       // currentIndex=2
                        controller.rwjetcQuoteList!=null && controller.rwjetcQuoteList.length>0?  ListView.builder(
                        itemCount: controller.rwjetcQuoteList.length,
                        shrinkWrap: true,
                        controller: scController,
                        itemBuilder: (context,index){
                        QuoteData obj = controller.rwjetcQuoteList[index];
                        return QuotesItem(obj: obj,tabIndex: "2",);
                       }) : NoDataWidget(isloading: controller.isLoading),
                           
                         ]),
             ),
              
           ],
                 )),
    ),
        
          controller.isLoading!?CustomLoader(): Container(),
        ],
      );
    });
  }
}