
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/MaterialModel/material_Model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:clik_pro_professional/widgets/NoData.dart';
import 'package:clik_pro_professional/widgets/RowWithText.dart';
import 'package:clik_pro_professional/widgets/fade_in_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';



class ViewQuotes extends StatefulWidget {
  String?quote_id;
  ViewQuotes({this.quote_id});

  @override
  State<ViewQuotes> createState() => _ViewQuotesState();
}

class _ViewQuotesState extends State<ViewQuotes> {

   
   getData()async{
      await Provider.of<UserProvider>(context,listen: false).viewQuote(quot_id:widget.quote_id);
   }


   @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }
  Size?_size;

   @override
   Widget build(BuildContext context) {
     _size = MediaQuery.of(context).size;
     return Consumer<UserProvider>(
       builder: (context, model, child ) {
         return Scaffold(
             appBar:  AppBar(
               backgroundColor: Colors.transparent,
               elevation: 0.0,
               centerTitle: true,
               title: Text("Quote Details".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
               iconTheme: IconThemeData(color: Colors.black),
             ),
             body: Stack(
               children: [
                 model.viewQuoteData==null? NoDataWidget(isloading: model.isLoading):
                 Container(
                   padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                   margin: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                   width: double.infinity,
                   decoration: BoxDecoration(
                       borderRadius: BorderRadius.circular(6),
                       border: Border.all(color: AppColor.appThemeColorGreen)
                   ),
                   child: ListView(

                     children: [
                       SizedBox(height: _size!.height*0.01),
                       /*Text(model.viewQuoteData!.jobTitle!,style: AppTextStyles.k20TextN.copyWith(color: AppColor.appThemeColorOrange)),
                       SizedBox(height: _size!.height*0.01),*/
                      /* Text(model.viewQuoteData!.companyDetailsDtaList!=null && model.viewQuoteData!.companyDetailsDtaList.length>0?
                               model.viewQuoteData!.companyDetailsDtaList[0].location!:"",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                       SizedBox(height: _size!.height*0.01),*/
                       Container(
                        padding:const EdgeInsets.symmetric(vertical: 6),
                        decoration:const BoxDecoration(
                          color: AppColor.appThemeColorOlive,
                        ),
                        child: Center(child: Text(model.prof_Data!=null ? (model.prof_Data!.firstName!+ " " + model.prof_Data!.lastName!) : "", style: AppTextStyles.k20TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),))),
                       SizedBox(height: _size!.height*0.02),
                       Row(
                         children: [
                           Text("Enterprise".tr().toString() + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                           Text("", style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                         ],
                       ),
                       SizedBox(height: _size!.height*0.01),
                       Row(
                         children: [
                           Text("SIREN Ou SIRET No".tr().toString() + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                           Text(model.prof_Data!=null?model.prof_Data!.sirenOrSiretNo!:"", style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                         ],
                       ),
                       SizedBox(height: _size!.height*0.01),
                       Row(
                         children: [
                           Text("RCS Non".tr().toString() + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                           Text(model.prof_Data!=null?model.prof_Data!.rcsNo!:"", style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                         ],
                       ),
                       SizedBox(height: _size!.height*0.01),
                       Row(
                         children: [
                           Text("TVA(%)".tr().toString() + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                           Text(model.prof_Data!=null?model.prof_Data!.vat!:"", style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                         ],
                       ),
                       SizedBox(height: _size!.height*0.01),
                       Row(
                         children: [
                           Text("Start Date".tr().toString() + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                           Text(model.viewQuoteData!.workStartDate!, style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                         ],
                       ),
                       SizedBox(height: _size!.height*0.01),
                       Row(
                         children: [
                           Text("End Date".tr().toString() + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                           Text(model.viewQuoteData!.workEndDate!, style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange),)
                         ],
                       ),
                       const Divider(color: AppColor.appThemeColorOlive),
                       Container(
                         margin: EdgeInsets.all(10),
                         padding:const EdgeInsets.all(8),
                         decoration: BoxDecoration(
                           border: Border.all(color: AppColor.appThemeColorOrange),
                           borderRadius: BorderRadius.circular(10),
                         ),
                         child: Column(
                           children: [
                             SizedBox(height: _size!.height*0.005),
                             RowWtihText(title: "Price".tr().toString(), value:"€ " +  model.viewQuoteData!.estimate!),
                             SizedBox(height: _size!.height*0.01),
                             RowWtihText(title: "TVA(%)".tr().toString(), value:model.viewQuoteData!.vat!),
                             SizedBox(height: _size!.height*0.01),
                             RowWtihText(title: "Total Vat".tr().toString(), value:"€ " +  model.viewQuoteData!.totalVat!),
                             SizedBox(height: _size!.height*0.01),
                             RowWtihText(title: "Total Price".tr().toString(), value:"€ " +  model.viewQuoteData!.estimatePrice!),
                           ],
                         ),
                       ),
                       const Divider(color: AppColor.appThemeColorOlive),
                       SizedBox(height: _size!.height*0.02),
                       model.viewQuoteData!.userMaterialModelList!=null && model.viewQuoteData!.userMaterialModelList.length>0? Column(
                         children: [
                           Text("Material Details".tr().toString() ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                           SizedBox(height: _size!.height*0.015),
                           Container(
                             child: SingleChildScrollView(
                               scrollDirection: Axis.horizontal,
                               child:  DataTable(headingRowColor: MaterialStateProperty.all(AppColor.appThemeColorOlive),
                                 columnSpacing: 16,
                                 columns: [
                                   DataColumn(label: Center(child: Text('Name'.tr().toString(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                                   DataColumn(label: Center(child: Text('Qty'.tr().toString(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                                   DataColumn(label: Center(child: Text('Unit'.tr().toString(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                                   DataColumn(label: Center(child: Text('Price(Unit)'.tr().toString(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                                   DataColumn(label: Center(child: Text('Vat(%)'.tr().toString(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                                   DataColumn(label: Center(child: Text('Total Vat'.tr().toString(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                                   DataColumn(label: Center(child: Text('Total Price'.tr().toString(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white)))),
                                 ],
                                 rows: getDataCells(model),
                                 //:CircularProgressIndicator(),
                                 showCheckboxColumn: true,
                                 decoration: BoxDecoration(),dataRowHeight: 22,headingRowHeight: 28,

                               ),
                             ),
                           ),
                         ],
                       ): Container(),

                       SizedBox(height: _size!.height*0.01),
                       const Divider(color: AppColor.appThemeColorOlive),
                       SizedBox(height: _size!.height*0.01),
                       Text("Description".tr().toString() + " : " ,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                       SizedBox(height: _size!.height*0.007),
                       Text(model.viewQuoteData!.coverDescription!, style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOrange)),
                       SizedBox(height: _size!.height*0.01),
                       const Divider(color: AppColor.appThemeColorOlive),
                       Text("Attachments".tr().toString(),style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),),
                       SizedBox(height: _size!.height*0.01),

                       model.viewQuoteData!.attachmentsList!=null && model.viewQuoteData!.attachmentsList.length>0? Container(
                           height: 100,
                           child: ListView.builder(
                               itemCount: model.viewQuoteData!.attachmentsList.length,
                               shrinkWrap: true,
                               scrollDirection: Axis.horizontal,
                               itemBuilder: (context,index){
                                 return Container(
                                     height: 80,
                                     width: 80,
                                     child: ClipRRect(
                                         borderRadius: BorderRadius.circular(12),
                                         child: FadeImageWithError(imgPath: model.viewQuoteData!.attachmentsList[index])));
                               })
                       ): Container(),
                     ],

                   ),
                 ),

                 model.isLoading! ?CustomLoader(): Container(),
               ],
             )
         );
       }
     );
   }

   getDataCells(UserProvider?model){
     List<DataRow> dataRows=[];
     for(int i=0;i<model!.viewQuoteData!.userMaterialModelList.length;i++){
       MaterialModel product= model.viewQuoteData!.userMaterialModelList[i];

       dataRows.add(DataRow(cells: [
         DataCell(Text(product.materialName!,textAlign: TextAlign.center,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),),),
         DataCell(Center(child: Text(product.materialQty!,textAlign: TextAlign.left,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),

         DataCell(Center(child: Text(product.unit!,textAlign: TextAlign.center,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),
         DataCell(Center(child: Text(product.unitPrice!,textAlign: TextAlign.left,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),
         DataCell(Center(child: Text( product.tax!,textAlign: TextAlign.center,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),
         DataCell(Center(child: Text(product.taxAmount!,textAlign: TextAlign.center,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),
         DataCell(Center(child: Text(product.totalAmount!,textAlign: TextAlign.center,style: TextStyle(color: i.isEven?AppColor.appThemeColorOlive.withOpacity(.8):Colors.white),))),


       ],color: i.isOdd?MaterialStateProperty.all(AppColor.appThemeColorOlive.withOpacity(.4)):MaterialStateProperty.all(Colors.white)));
     }
     return dataRows;
   }
}