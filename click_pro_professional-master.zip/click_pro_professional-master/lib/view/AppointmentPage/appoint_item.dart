import 'package:clik_pro_professional/model/Appointment%20Mdel/appointment_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class AppointmentItem extends StatefulWidget {
  AppointmentListData?obj;
  final tabIndex;
  AppointmentItem({this.obj, this.tabIndex});

  @override
  State<AppointmentItem> createState() => _AppointmentItemState();
}

class _AppointmentItemState extends State<AppointmentItem> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Container(
      margin:const EdgeInsets.symmetric(horizontal: 8,vertical: 10),
      padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 7),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: AppColor.appThemeColorOlive.withOpacity(0.2),
            blurRadius: 3,spreadRadius: 3
          ),
        ]
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
           Text(widget.obj!.title!,style: AppTextStyles.k18TextH.copyWith(color: AppColor.appThemeColorSky)),
           SizedBox(height: _size!.height*0.01),
           Row(
              children: [
                Text("Job Title".tr() + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                Text(widget.obj!.jobTitle!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
              ],
            ),
             SizedBox(height: _size!.height*0.01),
            Row(
              children: [
                Text("Name".tr() + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                Text(widget.obj!.firstName!+ " " + widget.obj!.lastName!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
              ],
            ),
            SizedBox(height: _size!.height*0.015),
          Row(
            children: [
            Text("Appointment Days".tr() + " : "  ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
            Text(widget.obj!.date!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
            //SizedBox(width: _size!.height*0.03),
           /* for(int i=0; i<widget.obj!.appointmentDaysList.length;i++)
             Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: AppColor.appThemeColorOrange.withOpacity(0.4),
                    blurRadius: 2,spreadRadius: 2
                  )
                ]
              ),
              child: Text(widget.obj!.appointmentDaysList[i]),
             ),*/
            ],
          ),
            SizedBox(height: _size!.height*0.01),
          Row(
            children: [
              Text("Prefer Time".tr() + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
              Expanded(child: Text(widget.obj!.time!, style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange))),
            //SizedBox(width: _size!.height*0.03),
           /* for(int i=0; i<widget.obj!.preferTimeList.length;i++)
             Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: AppColor.appThemeColorOrange.withOpacity(0.4),
                    blurRadius: 2,spreadRadius: 2
                  )
                ]
              ),
              child: Text(widget.obj!.preferTimeList[i]),
             ),*/
            /* InkWell(
              onTap: (){
              
              },
               child: Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: AppColor.appThemeColorOlive,
                  borderRadius: BorderRadius.circular(8),             
                ),
                child: Text("Details",style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
               ),
             )*/
            ],
          )
 
        ],
      ),
    );
  }
}