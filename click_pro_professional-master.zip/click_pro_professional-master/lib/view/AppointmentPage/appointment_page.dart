

import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/Appointment%20Mdel/appointment_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/AppointmentPage/appoint_item.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:clik_pro_professional/widgets/NoData.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../utils/common.dart';


class AppointmentPage extends StatefulWidget {


  @override
  State<AppointmentPage> createState() => _AppointmentPageState();
}

class _AppointmentPageState extends State<AppointmentPage> {


var scController=ScrollController();

 @override
  void initState() {
    // TODO: implement initState
    super.initState();
    scController.addListener(listener);
    Future.delayed(Duration(milliseconds: 300),(() => getData()));
  }


  getData()async{
      skipValue = 1;
      await Provider.of<UserProvider>(context,listen: false).clearAppointmentList();
      await Future.delayed(Duration(milliseconds: 500));
      await Provider.of<UserProvider>(context,listen: false).getAppointment(limit: skipValue,
      tab: currentIndex==0?"":(currentIndex==1?"all":"prev"));
     // setState(() {  });
  }

  int skipValue=1;
  listener(){
    if(scController.position.pixels == scController.position.maxScrollExtent){
      skipValue=skipValue+1;
      getData();
      print("called");
    }else{
      print("sorry");
    }
  }

  int currentIndex = 0;

  Size?_size;


  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return Stack(
      children: [
        StatefulBuilder(
          builder: (context, myState) {
            return Scaffold(
              /* appBar:AppBar(
                  backgroundColor: Colors.transparent,
                  elevation: 0.0,
                  centerTitle: true,
                  title: Text("APPOINTMENT".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
                  iconTheme: IconThemeData(color: Colors.black),
                ),*/
                body: DefaultTabController(
                  length: 3,
                  child: Column(
                    children: [
                      Container(
                        //height: 50,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12)
                        ),
                        child: TabBar(
                          unselectedLabelColor: AppColor.appThemeColorOlive,
                          labelColor: AppColor.appThemeColorOrange,
                          labelStyle: AppTextStyles.k16TextN.copyWith(
                              fontSize: 16.0,
                              color: AppColor.appThemeColorOlive,
                              fontWeight: FontWeight.w700),
                          tabs: [
                            Tab(child: Container(width: _size!.width*0.25, child: Center(child: Text("Today".tr())))),
                             Tab(child: Container(width: _size!.width*0.25, child: Center(child: Text("All".tr())))),
                              Tab(child: Container(width: _size!.width*0.25, child: Center(child: Text("Previous".tr())))),
                        ],indicatorColor: AppColor.appThemeColorOrange,
                          isScrollable: false,
                          automaticIndicatorColorAdjustment: true,
                          //physics: NeverScrollableScrollPhysics(),
                        onTap: (val)async{
                          print(val);
                          currentIndex = val;
                           await getData();
                           setState(() {
                             
                           });
                           
        
                          },
                        ),
                      ),
                  Expanded(child: TabBarView(physics: NeverScrollableScrollPhysics(),children: [
                    // current index = 0
                       model.appointmentList.isNotEmpty && 
                      !model.isLoading!?  ListView.builder(
                        itemCount: model.appointmentList.length,
                        shrinkWrap: true,
                        controller: scController,
                        itemBuilder: (context,index){
                          print("isime aa rha h");
                        if(model.appointmentList.isNotEmpty){
                        AppointmentListData obj = model.appointmentList[index];
                        return AppointmentItem(obj: obj,tabIndex: "0",);
                          } else {
                            return Container();
                          }
                       }) : NoDataWidget(isloading: model.isLoading),
                        
                        //current Index =1
                       model.appointmentList.isNotEmpty && 
                      !model.isLoading!?  ListView.builder(
                        itemCount: model.appointmentList.length,
                        shrinkWrap: true,
                        controller: scController,
                        itemBuilder: (context,index){
                          print("isime aa rha h");
                          if(model.appointmentList.isNotEmpty){
                        AppointmentListData obj = model.appointmentList[index];
                        return AppointmentItem(obj: obj,tabIndex: "0",);
                          } else {
                            return Container(child: Text(""),);
                          }
                       }) : NoDataWidget(isloading: model.isLoading),
        
                        //current Index = 2
                         model.appointmentList.isNotEmpty && 
                      !model.isLoading!?  ListView.builder(
                        itemCount: model.appointmentList.length,
                        shrinkWrap: true,
                        controller: scController,
                        itemBuilder: (context,index){
                          print("isime aa rha h");
                        if(model.appointmentList.isNotEmpty){
                        AppointmentListData obj = model.appointmentList[index];
                        return AppointmentItem(obj: obj,tabIndex: "0",);
                          } else {
                            return Container(child: Text(""),);
                          }
                       }) : NoDataWidget(isloading: model.isLoading),
             
                  ]))
                    ],
                  )
                  ),
                
                /*floatingActionButton: FloatingActionButton(
                  onPressed: (){
                     Get.toNamed(RoutesName.appointmentUserView);
                  },
                  backgroundColor: AppColor.appThemeColorSky,
                  child: Icon(Icons.add),
                ),*/
            );
          }
        ),
        model.isLoading!?CustomLoader():Container()
      ],
    );
    });
    
  }
}