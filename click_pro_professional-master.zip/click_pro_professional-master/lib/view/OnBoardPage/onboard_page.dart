
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/Auth/login.dart';
import 'package:clik_pro_professional/view/Auth/register.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class OnBoardPage extends StatefulWidget {
  const OnBoardPage({super.key});

  @override
  State<OnBoardPage> createState() => _OnBoardPageState();
}

class _OnBoardPageState extends State<OnBoardPage> {

    List<dynamic> slides= [
    {
      "image":"assets/images/onboard1.png",
      "title":"GET A JOB",
      "desc":"This is the platform where you can post a job for services like Electrician, Gardner, Plumber."
    },
     {
      "image":"assets/images/onboard1.png",
      "title":"GET BETTER OPPORTUNITIES",
      "desc":"This is the platform where you can post a job for services like Electrician, Gardner, Plumber."
    },
     {
      "image":"assets/images/onboard.png",
      "title":"ALL SERVICES",
      "desc":"This is the platform where you can post a job for services like Electrician, Gardner, Plumber."
    },
  ];
  
  int currentIndex= 0;
  PageController _pageController = PageController();

  @override
  void initState() {
    _pageController = PageController(initialPage: 0);
    super.initState();
  }
   

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            Column(
                children: [
                 
                  Container(
                    margin: EdgeInsets.only(top: _size!.height*0.05),
                    width: _size!.width*0.7,
                    height: _size!.height*0.1,
                  
                    child: Image.asset("assets/logos/logo1.png"),
                  ),
               Expanded(
                 child: PageView.builder(
                 scrollDirection: Axis.horizontal,
                 controller: _pageController,
                 itemCount: slides.length,
                 onPageChanged: (value){
                       setState(() {
                         currentIndex = value;
                       });
                     },
                 itemBuilder: (context,index){
                 return Slider(
                    image: slides[index]['image'],
                    title: slides[index]['title'],
                    description: slides[index]['desc'],
                 );
                        }),
               )
                
                ],
            ),
              Provider.of<UserProvider>(context).isLoading!?CustomLoader():Container()
          ],
        ),
        bottomNavigationBar:  Wrap(
                    children: [
                      Center(
                        child: InkWell(
                          onTap: ()async{
                            //context.locale = Locale('fr', 'BE');
                            model.setLoader(true);
                            await Future.delayed(Duration(seconds: 2));
                            model.setLoader(false);
                            navigateWithPageTransition(context, UserLogin(),);
                          },
                          child: Container(
                            height: _size!.height*0.05,
                            width: _size!.width*0.9,
                            margin: EdgeInsets.symmetric(vertical: _size!.height*0.04),
                            decoration: BoxDecoration(
                              color: AppColor.appThemeColorOrange,
                              borderRadius: BorderRadius.circular(20)
                            ),
                            child: Center(child: Text("Log In".tr().toString(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: ()async{
                            model.setLoader(true);
                            await Future.delayed(Duration(seconds: 2));
                            model.setLoader(false);
                         navigateWithPageTransition(context, UserRegister(),);
                        },
                        child: Center(child: Text("Don't have an Account? Sign Up".tr().toString(),style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),))),
                      SizedBox(height: _size!.height*0.06,)                    ],
                  ),
      ),
      
      );
    });
  }
}

class Slider extends StatelessWidget {
  String?image,title,description;

  Slider({this.description,this.image,this.title});

  @override
  Widget build(BuildContext context) {
    Size _size = MediaQuery.of(context).size;
    return Container(
      child: Column(

        children: [
          Container(
            padding:const EdgeInsets.all(10),
           
            child: Image.asset(image!,fit: BoxFit.fill,height: _size.height*0.4,width: _size.width*0.8,),
            ),
       
          Text(title!.tr().toString(), style: AppTextStyles.k20TextH),
          //SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(description!.tr().toString(),style: AppTextStyles.k14TextN,textAlign:TextAlign.center,),
          ),
         
        ],
      ),
    );
  }
}