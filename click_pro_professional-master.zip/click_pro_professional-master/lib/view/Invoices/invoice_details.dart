import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:clik_pro_professional/widgets/RowWithText.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class InvoiceDetails extends StatefulWidget {
 String?invocie_id;
 InvoiceDetails({this.invocie_id});

  @override
  State<InvoiceDetails> createState() => _InvoiceDetailsState();
}

class _InvoiceDetailsState extends State<InvoiceDetails> {

  getData()async {
    await Provider.of<UserProvider>(context,listen: false).viewInvoices(widget.invocie_id);
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return Stack(
        children: [
          Scaffold(
            appBar: AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0.0,
                centerTitle: true,
                title: Text("Invoice Details".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
                iconTheme:const IconThemeData(color: Colors.black),
              ),
              body: ListView(
            padding:const EdgeInsets.symmetric(horizontal: 14),
            children: [         
              SizedBox(height: _size!.height*0.05),
              //RowWtihText(title: "Payment ID",value:model.viewInvoiceData!=null && model.viewInvoiceData!.paymentId!=null ? model.viewInvoiceData!.paymentId!:""),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Payment ID".tr() + (" : " ),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
                  Expanded(child: Text(model.viewInvoiceData!=null && model.viewInvoiceData!.paymentId!=null ? model.viewInvoiceData!.paymentId!:"", style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),))
                ],
              ),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Status".tr(),value:model.viewInvoiceData!=null && model.viewInvoiceData!.paymentStatus!=null?model.viewInvoiceData!.paymentStatus! :""),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Payment Date".tr(),value:model.viewInvoiceData!=null && model.viewInvoiceData!.professionalPaidDate!=null?model.viewInvoiceData!.professionalPaidDate! :""),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Total Amount".tr(),value:model.viewInvoiceData!=null && model.viewInvoiceData!.amount!=null?("€ "+ model.viewInvoiceData!.amount!) :""),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Professional Amount".tr(),value:model.viewInvoiceData!=null && model.viewInvoiceData!.professionalPaidAmount!=null?("€ "+ model.viewInvoiceData!.professionalPaidAmount!) :""),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Commission Amount".tr(),value:model.viewInvoiceData!=null && model.viewInvoiceData!.adminCommission!=null?("€ "+ model.viewInvoiceData!.adminCommission!) :""),
              SizedBox(height: _size!.height*0.02),
              const Divider(color: AppColor.appThemeColorOlive),
              Text("Job Details".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title: "Title".tr(),value:model.viewInvoiceJobData!=null && model.viewInvoiceJobData!.jobTitle!=null?model.viewInvoiceJobData!.jobTitle! :""),
              SizedBox(height: _size!.height*0.01),
              Text(model.viewInvoiceJobData!=null && model.viewInvoiceJobData!.description!=null?model.viewInvoiceJobData!.description!:"",style: AppTextStyles.k14TextN,),
              SizedBox(height: _size!.height*0.02),
              const Divider(color: AppColor.appThemeColorOlive),
              Text("Professional Details".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title:"Name".tr(),value:model.viewInvoiceProData!=null && model.viewInvoiceProData!.firstName!=null?(model.viewInvoiceProData!.firstName!+" " + model.viewInvoiceProData!.lastName!):""),
              SizedBox(height: _size!.height*0.02),
              const Divider(color: AppColor.appThemeColorOlive),
              Text("Customer Details".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
              SizedBox(height: _size!.height*0.01),
              RowWtihText(title:"Name".tr(),value:model.viewInvoiceCusData!=null && model.viewInvoiceCusData!.name!=null?model.viewInvoiceCusData!.name!:""),
              SizedBox(height: _size!.height*0.01),
               RowWtihText(title:"Customer ID".tr(),value:model.viewInvoiceCusData!=null && model.viewInvoiceCusData!.userId!=null?("COC-" + model.viewInvoiceCusData!.userId!):""),
           
            ],
           ),
          /* bottomNavigationBar: Container(
            height: 45,
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColor.appThemeColorOlive,
              borderRadius: BorderRadius.circular(10)
            ),
            child: Center(
              child: Text("PRINT",style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)),
            ),
           ),*/

    ),
         model.isLoading!?const CustomLoader():Container()
        ],
      );

    });
  }
}