import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/InvoiceModel/invoice_list.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/Invoices/invoice_details.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:clik_pro_professional/widgets/NoData.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Invoices extends StatefulWidget {
  const Invoices({super.key});

  @override
  State<Invoices> createState() => _InvoicesState();
}

class _InvoicesState extends State<Invoices> {
  
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }
  
  getData()async {
    await Provider.of<UserProvider>(context,listen: false).getInvocie();
  }
  
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return SafeArea(

      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          centerTitle: true,
          title: Text("INVOICES".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
          iconTheme:const IconThemeData(color: Colors.black),
        ),
        body:  Stack(
          children: [
            ListView(children: [
              SizedBox(height: _size!.height*0.013,),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 6),
                  margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    //border: Border.all(color:AppColor.appThemeColorOlive),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: AppColor.appThemeColorOrange.withOpacity(0.2),
                        blurRadius: 3,spreadRadius: 3
                    )
                  ]
                ),
                child: Row(
                  children: [
                    Text("Total Transaction".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                    Text(model.invoiceDataListModel!=null&& model.invoiceDataListModel!.totalTransactions!=null? model.invoiceDataListModel!.totalTransactions!:"",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 6),
                  margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    //border: Border.all(color:AppColor.appThemeColorOlive),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: AppColor.appThemeColorOrange.withOpacity(0.2),
                        blurRadius: 3,spreadRadius: 3
                    )
                  ]
                ),
                child: Row(
                  children: [
                    Text("Total Amount".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                    Text("€ " + (model.invoiceDataListModel!=null&& model.invoiceDataListModel!.totalTransAmount!=null? model.invoiceDataListModel!.totalTransAmount!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                  ],
                ),
              ),
             model.invoiceList!=null && model.invoiceList.length>0? ListView.builder(
                itemCount: model.invoiceList.length,
                shrinkWrap: true,
                physics:const NeverScrollableScrollPhysics(),
                itemBuilder: (context,index){
                  InvoiceDataList obj = model.invoiceList[index];
                return InkWell(
                  onTap: (){
                      navigateWithPageTransition(context, InvoiceDetails(invocie_id: obj.id));             
                    },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 6),
                        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color:AppColor.appThemeColorOlive),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: AppColor.appThemeColorOlive.withOpacity(0.2),
                              blurRadius: 3,spreadRadius: 3
                            )
                          ]
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Customer Name".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Expanded(child: Text((obj.cus_name!=null? obj.cus_name!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange))),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            
                            Row(
                              children: [
                                Text("Professional Name".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Expanded(child: Text((obj.pro_name!=null? obj.pro_name!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange))),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            
                            Row(
                              children: [
                                Text("Category".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Expanded(child: Text((obj.category_name!=null? obj.category_name!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange))),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            
                            Row(
                              children: [
                                Text("Location".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Expanded(child: Text((obj.location!=null? obj.location!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange))),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            Row(
                              children: [
                                Text("Amount".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Text(" € "+  (obj.professionalPaidAmount!=null? obj.professionalPaidAmount!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            Row(
                              children: [
                                Text("Service Fee".tr() + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Text(" € "+ (obj.admin_commission!=null? obj.admin_commission!:""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            Row(
                              children: [
                                Text("Total Amount".tr() + " : " ,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Text(" € "+ (obj.professionalPaidAmount!=null && obj.admin_commission!=null? (double.parse(obj.professionalPaidAmount!) + double.parse(obj.admin_commission!)).toString() :""),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            
                           /* Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(child: Text("Created Date : " + obj.professionalPaidDate!.toString().substring(0,10),style: AppTextStyles.k14TextN)),
                                Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.black12)
                                  ),
                                 //child: Icon(Icons.picture_as_pdf, color: Colors.red,size: 20,),
                                ),
                              const SizedBox(width: 10),
                            
                              ],
                            ),*/
                    
                          ],
                        ),
                      ),
                    );
              }) : NoDataWidget(isloading: model.isLoading,)
            ],),
            model.isLoading!?const CustomLoader():Container()
          ],
        ),
      ),
    );
    });
  }
}