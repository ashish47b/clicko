
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/AppliedJobs/my_quote.dart';
import 'package:clik_pro_professional/view/AppointmentPage/appointment_page.dart';

import 'package:clik_pro_professional/view/Chat/all_chat_user.dart';
import 'package:clik_pro_professional/view/DashBoard/dashboard.dart';
import 'package:clik_pro_professional/view/JobStatusWise/my_jobs.dart';
import 'package:clik_pro_professional/view/NavDrawer/nav_drawer.dart';
import 'package:clik_pro_professional/view/ProfilePage/profile_page.dart';
import 'package:clik_pro_professional/view/SearchJobs/search_jobs.dart';
import 'package:clik_pro_professional/widgets/show_dialog.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class BottomNavBar extends StatefulWidget {
  int currentIndex = 0;
  BottomNavBar(this.currentIndex);
  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
    final List<Widget> _childrens = [
      DashBoardPage(),
      ActiveJobsPage(),
      MyQuote(),
      AppointmentPage(),
      
      AllJobsScreen(),

  ];

    getProfileData() async{
      Provider.of<UserProvider>(context,listen: false).profileList();
    }
    @override
  void initState() {
    Future.delayed(Duration(milliseconds: 300)).whenComplete(() => getProfileData());
    super.initState();
  }
  final scaffoldKey = GlobalKey<ScaffoldState>();
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return RefreshIndicator(
      displacement: 250,
      backgroundColor: AppColor.appThemeColorGreen,
      color: Colors.white,
      strokeWidth: 3,
      triggerMode: RefreshIndicatorTriggerMode.onEdge,
      onRefresh: () async {
          
      },
      child: SafeArea(
        child: Scaffold(
          key: scaffoldKey,
        drawer: NavDrawer(),
        body: Column(
          children: [
              SizedBox(height: _size!.height*0.02),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    //if(widget.currentIndex==0 || widget.currentIndex==1 ||  widget.currentIndex==2 || widget.currentIndex==3)
                    InkWell(
                       onTap: (){
                     scaffoldKey.currentState!.openDrawer();
                      },
                      child: Image.asset("assets/icons/menu.png", height: 25)
                    ),
                   


                    /// for current index 0
                    if(widget.currentIndex==0)
                   model.profileData!=null && ![null,""].contains(model.profileData!.cityName!)? Expanded(
                      child: Row(
                      children: [
                      const SizedBox(width: 15,),
                      Text(model.profileData!.cityName!,style: AppTextStyles.k14TextN),
                      Icon(Icons.keyboard_arrow_down, color: Colors.grey,),
                       ],
                     ),
                    ):Container(),

                    // for currentIndex 1
                    if(widget.currentIndex==1)
                    Text("AVAILABLE JOBS".tr(),style: AppTextStyles.k16TextN,),
                    
                     // for current Index 2
                     if(widget.currentIndex==2)
                    Text("MY QUOTES".tr(),style: AppTextStyles.k16TextN,),

                    // for current Index 3
                     if(widget.currentIndex==3)
                    Text("APPOINTMENT".tr(),style: AppTextStyles.k16TextN,),

                    // 
                      if(widget.currentIndex==4)
                    Text("My Jobs".tr(),style: AppTextStyles.k16TextN,),

                    // current index = 0
                    if(widget.currentIndex==0 || widget.currentIndex==3 || widget.currentIndex==4)
                    InkWell(
                      onTap: (){
                           navigateWithPageTransition(context, ProfessionalProfilePage());
                      },
                      child: Container(
                        height: 30,
                        width: 30,
                        padding:const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          //border: Border.all(color: AppColor.appThemeColorOlive)
                          color: AppColor.appThemeColorOlive,
                          image:model.profileData!=null && ![null,""].contains(model.profileData!.profilePic)? DecorationImage(image: NetworkImage(model.profileData!.profilePicPath! + model.profileData!.profilePic!),fit: BoxFit.fill):null
                          
                        ),
                        child:model.profileData!=null && ![null,""].contains(model.profileData!.profilePic)?Container(): const Icon(Icons.person, color:Colors.white),
                       ),
                      ),

                     if(widget.currentIndex==1)
                     const Icon(Icons.more_vert),
                     if(widget.currentIndex==2)
                     const Icon(Icons.more_vert)
                  ],
                ),
              ),
            Expanded(child: _childrens[widget.currentIndex],)
          ],
        ),
        bottomNavigationBar: Theme(
          data: Theme.of(context).copyWith(
            canvasColor:   Colors.white,  //AppColor.appThemeColor
          ),
          child: WillPopScope(
            onWillPop: _onBackButtonPressed,
            child: Container(
              height: 60.0,
              child: BottomNavigationBar(
                  showSelectedLabels: true,
                  showUnselectedLabels: false,
                  selectedItemColor: AppColor.appThemeColorOrange,
                  unselectedItemColor: Colors.black45,
                
                  onTap: onTabTapped,
                  currentIndex: widget.currentIndex,
                  items: const [
                    BottomNavigationBarItem(
                      icon: Padding(
                        padding: EdgeInsets.only(bottom: 3),
                        child: ImageIcon(
                         AssetImage("assets/icons/home.png"),
                         size:20,
                         ),
                      ),
                      label: 'Maison',
                    ),
                    BottomNavigationBarItem(
                      icon: Padding(
                        padding: EdgeInsets.only(bottom: 3),
                        child: ImageIcon(
                         AssetImage("assets/icons/search.png"),
                         size:20,
                         ),
                      ),
                      label: 'Emplois actifs',
                    ),
                    BottomNavigationBarItem(
                      icon: Padding(
                        padding: EdgeInsets.only(bottom: 3),
                        child: ImageIcon(
                         AssetImage("assets/icons/job.png"),
                         size:20,
                         ),
                      ),
                      label: 'Citations',
                    ),
                    BottomNavigationBarItem(
                      icon: Padding(
                        padding: EdgeInsets.only(bottom: 3),
                        child: ImageIcon(
                         AssetImage("assets/icons/deadline.png"),
                         size:20,
                         ),
                      ),
                      label: 'Rendez-vous',
                    ),
                    // BottomNavigationBarItem(
                    //   icon: Icon(Icons.shopping_bag),
                    //   label: 'Orders',
                    // ),
                    
                    
                    BottomNavigationBarItem(
                      icon: Padding(
                        padding: EdgeInsets.only(bottom: 3),
                        child: ImageIcon(
                         AssetImage("assets/icons/job.png"),
                         size:20,
                         ),
                      ),
                      label: 'Rendez-vous',
                    ),
                  ]),
            ),
          ),
        ),
      ),)
    );
    });
  }
    Future<bool> _onBackButtonPressed() async {
    bool request = await showDialog(
        context: context,
        builder: ((context) {
          return ShowDialogsss().exitDialog(context);
        }));

    return request;
  }

  void onTabTapped(int index) {
    setState(() {
      widget.currentIndex = index;
    });
  }
}