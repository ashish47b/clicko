
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/ChatUsers/chat_user_list.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/view/AppointmentPage/appointment_page.dart';
import 'package:clik_pro_professional/view/Chat/all_chat_user.dart';
import 'package:clik_pro_professional/view/Invoices/invoices.dart';
import 'package:clik_pro_professional/view/Sponsership/sponsorship.dart';
import 'package:clik_pro_professional/view/Subscribe/subscribe_page.dart';
import 'package:clik_pro_professional/widgets/languageBox.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class NavDrawer extends StatefulWidget {
  const NavDrawer({super.key});

  @override
  State<NavDrawer> createState() => _NavDrawerState();
}

class _NavDrawerState extends State<NavDrawer> {
 
//  SharedPreferences? spData;
//  String?userEmail;
//  String?userName;
//  String?userMobile;
//   getData() async {
//     spData = await SharedPreferences.getInstance();
//     userEmail = spData!.getString(Constants.keyEmail);
//     userName = spData!.getString(Constants.keyUserName);
//     userMobile = spData!.getString(Constants.keyPhoneNumber);
//     setState(() {
      
//     });
//   }



 @override
  void initState() {
   // getData();
    super.initState();
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
   // print("User Name : " + userMobile!);
    return  Stack(
      children: [

       Consumer<UserProvider>(builder: (context,model,child){
        return  Container(
          width: _size!.width * 0.7,
          padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
          decoration:const BoxDecoration(
              color: AppColor.appThemeColorOlive,
              borderRadius: BorderRadius.only(topRight: Radius.circular(50), bottomRight: Radius.circular(50)),
              gradient: LinearGradient(colors: [AppColor.appThemeColorOlive, AppColor.appThemeColorOlive ], begin: Alignment.topCenter, end: Alignment.bottomCenter)
            ),
          child: ListView(
            children: [
             SizedBox(height: _size!.height * 0.02,),
              Container(
               child: Row(
                children: [
                  Container(
                    child: CircleAvatar(
                      backgroundColor: AppColor.appThemeColorOrange,
                      maxRadius: 32,
                      child: CircleAvatar(
                       backgroundColor: Colors.white,
                       maxRadius: 30,
                        child:  Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset("assets/images/avatar.png",
                            ),
                        ),
                     ),
                   ),
                 ),
                 const SizedBox(width: 20,),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(model.userName!,style:const TextStyle(fontSize: 18, fontWeight: FontWeight.w600,color: Colors.white),),
                      const SizedBox(height: 3,),
                      Text(model.userEmail!,style:const TextStyle(fontSize: 14, fontWeight: FontWeight.w400,color: Colors.white),)
                    ],
                  )

               ],
              ),
             ),
              SizedBox(height: _size!.height*0.02),
              const Divider(color:Colors.white,),
              
              SizedBox(height: _size!.height*0.02),
            ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/invoice.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      navigateWithTransition(context,Invoices() );
                    },
                  title: Text("Invoices".tr(),style:const TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
             const Divider(color:Colors.white60,),
                ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/time.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      navigateWithTransition(context,AllChats() );
                    },
                  title: Text("Chats".tr(),style:const TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
             const Divider(color:Colors.white60,),
                ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/subscribe.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      navigateWithTransition(context,SubscriberPage() );
                    },
                  title: Text("Subscriptions".tr(),style:const TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
             /* Divider(color:Colors.white60,),
                ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/gallery.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      navigateWithTransition(context,Sponsorship() );
                    },
                  title: Text("Sponsorship".tr(),style: TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),*/
             const Divider(color:Colors.white60,),
                ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/translation.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                      showDialog(context: context, builder:(context){
                        return LanguageDialogBox();
                      });
                     // navigateWithTransition(context,SubscriberPage() );
                    },
                  title: Text("Language".tr(),style:const TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
             const Divider(color:Colors.white60,),
                ListTile(
                   leading: CircleAvatar(
                     backgroundColor: AppColor.appThemeColorOrange,
                     maxRadius: 26,
                     child: CircleAvatar(
                             backgroundColor: Colors.white,
                             maxRadius: 24,
                             child: Padding(
                                     padding: const EdgeInsets.all(6.0),
                                     child: Image.asset("assets/images/logout.png",
                                    height: 30,),
                                  ),
                            ),
                    ),
                    onTap: (){
                     // navigateWithTransition(context,Productlist(type:"normal") );
                     model.logOut(context);
                     // logout(context);
                    },
                  title: Text("Log Out".tr(),style:const TextStyle(fontSize: 18,fontWeight: FontWeight.w700,color: Colors.white),),
            ),
            const Divider(color:Colors.white60,),
      
        //      Divider(color:Colors.white24,),
        //     ListTile(
        //            leading: CircleAvatar(
        //              backgroundColor: Colors.blue,
        //              maxRadius: 26,
        //              child: CircleAvatar(
        //                      backgroundColor: Colors.white,
        //                      maxRadius: 24,
        //                      child: Padding(
        //                              padding: const EdgeInsets.all(6.0),
        //                              child: Image.asset("assets/images/logout.png",
        //                             height: 30,),
        //                           ),
        //                     ),
        //             ),
        //              onTap: () async {
        //                   await SharedPreferences.getInstance()..clear();
        //                      Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) =>
        //                          LoginScreen()), (Route<dynamic> route) => false);
        // },
        //           title: Text("Logout",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w600,color: Colors.white),),
        //     ),
            ],
          ),
        );
       })
      ],
    );
  }
}