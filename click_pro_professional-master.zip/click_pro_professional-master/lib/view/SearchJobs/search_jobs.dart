import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/JobModel/job_data_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:clik_pro_professional/widgets/NoData.dart';
import 'package:clik_pro_professional/widgets/job_card.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ActiveJobsPage extends StatefulWidget {
  const ActiveJobsPage({super.key});

  @override
  State<ActiveJobsPage> createState() => _ActiveJobsPageState();
}

class _ActiveJobsPageState extends State<ActiveJobsPage> {
  
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 250),()=> getData());
  }

  getData()async {
    await Provider.of<UserProvider>(context,listen: false).getJObs();
  }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return  Container(
      child: Stack(
        children: [
          Column(
            children: [
            const Divider(color:Colors.black,),
            /* Container(
              height: 30,
               //ssscolor: Colors.red,
              
               child: model.jobData!=null && model.jobData!.activeJobs!=null && model.jobData!.activeJobs!.length>0? ListView.builder(
                itemCount: model.jobData!.activeJobs!.length,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,

                itemBuilder: (context,index){
                //ActiveJobs obj = model.jobData!.activeJobs![index];
                return Container(
                  padding: EdgeInsets.symmetric(horizontal: 8,),
                  margin: EdgeInsets.symmetric(horizontal: 5),
                  decoration: BoxDecoration(
                    color: AppColor.appThemeColorSky.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),

                  ),
                  child: Center(
                    child: Text(categoriesImage[index]['title'],style: AppTextStyles.k14TextN,),
                  ),
                );
               }) : NoDataWidget(isloading: model.isLoading,)
             ),*/
             SizedBox(height: _size!.height*0.01),
              Expanded(
                child:!model.isLoading!&& model.jobData!=null && model.jobData!.activeJobs!=null && model.jobData!.activeJobs!.length>0? ListView(
                  children: [
                  
                   SizedBox(height: _size!.height*0.01),
              
                   ListView.builder(
                    shrinkWrap: true,
                    itemCount: model.jobData!.activeJobs!.length,
                    physics:const NeverScrollableScrollPhysics(),
                    itemBuilder: (context,index){
                    ActiveJobs obj = model.jobData!.activeJobs![index];
                    return JobItemCard(obj: obj,);
                   })
                  ],
                ) : NoDataWidget(isloading: model.isLoading),
              ),
            ],
          ),
          
          Provider.of<UserProvider>(context).isLoading!?const CustomLoader():Container()
        ],
      ),
    );
    });
  }
  
}