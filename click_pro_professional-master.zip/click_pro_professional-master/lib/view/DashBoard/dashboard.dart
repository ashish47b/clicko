import 'package:carousel_slider/carousel_slider.dart';
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/JobModel/job_data_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/DashBoard/search_professionals.dart';


import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:clik_pro_professional/widgets/fade_in_image.dart';
import 'package:clik_pro_professional/widgets/job_card.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:provider/provider.dart';

class DashBoardPage extends StatefulWidget {
  const DashBoardPage({super.key});

  @override
  State<DashBoardPage> createState() => _DashBoardPageState();
}

class _DashBoardPageState extends State<DashBoardPage> {
  
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }

  getData()async{
    await Provider.of<UserProvider>(context,listen: false).getJObs(limit: 1);
    await Provider.of<UserProvider>(context,listen: false).profileList();
    await Provider.of<UserProvider>(context,listen: false).getCategory();
    await Provider.of<UserProvider>(context,listen: false).getCity();
    if(myProvider!.profileData!=null && ![null,""].contains(myProvider!.profileData!.profile_status)){
      profile_percent = (double.parse(myProvider!.profileData!.profile_status!)/100);
      print("PROFILE STTAUS" + profile_percent.toString());
    }
  }

  PageController pageController = PageController(initialPage: 0);
  int curentIndex = 0;

  Size?_size;
  double?profile_percent=0.0;
  UserProvider?myProvider;
  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context,listen: false);
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return  ListView(
        children: [
           SizedBox(height: _size!.height*0.03),
            //  Text("Hii, Yash!!",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
              SizedBox(height: _size!.height*0.01),
              InkWell(
                onTap: (){
                
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Container(
                    //height: 50,
                    
                    padding:const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppColor.appThemeColorOlive.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12)
                    ),
                    child: Row(
                      children: [
                          Padding(
                            padding: const EdgeInsets.symmetric( horizontal:8.0),
                            child: CircularPercentIndicator(
                              radius: 22.0,
                              lineWidth: 3.0,
                              percent: profile_percent!,
                              center:  Text(myProvider!.profileData!=null && ![null,""].contains(myProvider!.profileData!.profile_status)?myProvider!.profileData!.profile_status!: "0%"),
                              progressColor: AppColor.appThemeColorOrange,
                            ),
                          ),
                         const SizedBox(width: 5,),
                          Expanded(child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Hii".tr()+"  " +  model.userName!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange)),
                              myProvider!.profileData!=null && ["100.0"].contains(myProvider!.profileData!.profile_status)?
                              Text("Congratulations !!! Your Profile is Complete".tr(),style: AppTextStyles.k12TextN) : 
                              Text("Complete your profile for better engagement".tr(),style: AppTextStyles.k12TextN),
                            ],
                          )),
                          const SizedBox(width: 10),
                         const Icon(Icons.arrow_forward_ios_outlined, size: 16),
                         const SizedBox(width: 10)
                      ],
                    ),
                  ),
                ),
              ),
              SizedBox(height: _size!.height*0.02),
              GestureDetector(
                    onTap: (){
                      navigateWithPageTransition(context, SearchProfessionals());
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Container(
                        
                        padding:const EdgeInsets.symmetric(vertical: 10,horizontal: 10),
                        decoration: BoxDecoration(
                          border: Border.all(color: AppColor.appThemeColorOlive),
                          borderRadius: BorderRadius.circular(50),
                          //color: AppColor.appThemeColorOlive
                        ),
                       child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                         children: [
                           Text("Search Professionals".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.grey)),
                           Icon(Icons.search,color: Colors.grey),
                         ],
                       )
                      ),
                    ),
                  ),
              SizedBox(height: _size!.height*0.02),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text("Popular Categories".tr(),style: AppTextStyles.k20TextH),
              ),
              SizedBox(height: _size!.height*0.02),


          
         /* Padding(
             padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Container(
                    height: _size!.height*0.2,
                  child: PageView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 5,
                    itemBuilder: (context,index){
                    return Container(
                    
                    height: _size!.height*0.18,
                    margin:const EdgeInsets.symmetric(horizontal: 5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      //border: Border.all(color: AppColor.appThemeColorOlive),
                      color: Colors.white,
                       image:const DecorationImage(image: AssetImage("assets/images/home_ser1.jpg"), fit: BoxFit.fill)
                    ),
                 //  child: Image.asset("assets/images/home_ser1.jpg", fit: BoxFit.fill,),
                  );
                  }),
                ),
          ),*/
          
                CarouselSlider(
                  items: model.categoryList.map((e){
                    return Builder(builder: (context){
                      return Stack(
                        children: [
                          Container(
                            height: _size!.height*0.25,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                                Colors.black,Colors.black
                              ], begin: Alignment.topCenter,end: Alignment.bottomCenter),
                              borderRadius: BorderRadius.circular(8),
                              image: DecorationImage(image: NetworkImage(e.cat_image!),fit: BoxFit.fill,opacity: 0.7)
                            ),
                          ),
                          Positioned(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text(e.categoryName!,style: AppTextStyles.k20TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),)))
                        ],
                      );
                    });
                  }).toList(),
                  options: CarouselOptions(
                      height: _size!.height*0.2,
                      aspectRatio: 16/9,
                      viewportFraction: 0.8,
                      initialPage: 0,
                      enableInfiniteScroll: true,
                      reverse: false,
                      autoPlay: true,
                      autoPlayInterval: Duration(seconds: 3),
                      autoPlayAnimationDuration: Duration(milliseconds: 800),
                      autoPlayCurve: Curves.fastOutSlowIn,
                      enlargeCenterPage: true,
                      enlargeFactor: 0.3,
                      scrollDirection: Axis.horizontal,
                  )
                ),
            
              SizedBox(height: _size!.height*0.02),
               Padding(
                 padding: const EdgeInsets.symmetric(horizontal: 12),
                 child: Text("All Cities".tr(),style: AppTextStyles.k20TextH),
               ),
                  SizedBox(height: _size!.height*0.01),
              model.cityList!=null && model.cityList.length>0?
                Container(
                  height: _size!.height*0.3,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                child: GridView.builder(
                  
                  shrinkWrap: true,
                  itemCount: model.cityList.length,
                  scrollDirection: Axis.horizontal,
                  gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, 
                  childAspectRatio: 2/3,
                  crossAxisSpacing: 10,
                ), itemBuilder: (context,index){
                  return InkWell(
                    onTap: (){
                     navigateWithPageTransition(context, SearchProfessionals(cityID: model.cityList[index].id,));
                    },
                    child: Stack(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 10,right: 10),
                          decoration: BoxDecoration(
                               borderRadius: BorderRadius.circular(12),
                               color: Colors.black,
                               image: DecorationImage(image: NetworkImage(model.cityList[index].city_image!),fit: BoxFit.fill,opacity: 0.6)
                          ),
                        ),
                        Positioned(
                         child: Align(
                          alignment: Alignment.center,
                           child: Text(model.cityList[index].cityName!,textAlign: TextAlign.center ,style: AppTextStyles.k14TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                         ),
                       ),
                      ],
                    ),
                  );
                }),
              ):Container(),
                 SizedBox(height: _size!.height*0.02),
               Padding(
                 padding: const EdgeInsets.symmetric(horizontal: 12),
                 child: Text("All Category".tr(),style: AppTextStyles.k20TextH),
               ),
                  SizedBox(height: _size!.height*0.01),
              model.categoryList!=null && model.categoryList.length>0?
                Container(
                  height: _size!.height*0.3,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                child: GridView.builder(
                  
                  shrinkWrap: true,
                  itemCount: model.categoryList.length,
                  scrollDirection: Axis.horizontal,
                  gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, 
                  childAspectRatio: 2/3,
                  crossAxisSpacing: 10,
                ), itemBuilder: (context,index){
                  return InkWell(
                    onTap: (){
                     navigateWithPageTransition(context, SearchProfessionals(catID: model.categoryList[index].id,));
                    },
                    child: Stack(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 10,right: 10),
                          decoration: BoxDecoration(
                               borderRadius: BorderRadius.circular(12),
                               color: Colors.black,
                               image: DecorationImage(image: NetworkImage(model.categoryList[index].cat_image!),fit: BoxFit.fill,opacity: 0.6)
                          ),
                        ),
                        Positioned(
                         child: Align(
                          alignment: Alignment.center,
                           child: Text(model.categoryList[index].categoryName!,textAlign: TextAlign.center ,style: AppTextStyles.k14TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold),),
                         ),
                       ),
                      ],
                    ),
                  );
                }),
              ):Container(),
                SizedBox(height: _size!.height*0.02),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text("Recommended Jobs".tr() ,style: AppTextStyles.k20TextH),
              ),
              SizedBox(height: _size!.height*0.02),
              model.jobData!=null && model.jobData!.activeJobs!=null && model.jobData!.activeJobs!.length>0?
              ListView.builder(
                itemCount: model.jobData!.activeJobs!.length,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context,index){
                  ActiveJobs obj = model.jobData!.activeJobs![index];
                  return JobItemCard(obj: obj,);
              }) :const CustomLoader()
        ],
      );
    });
  }
}