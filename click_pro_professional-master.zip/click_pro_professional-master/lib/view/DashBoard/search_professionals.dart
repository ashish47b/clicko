
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/CategoryModel/category_model.dart';
import 'package:clik_pro_professional/model/CityModel/city_model.dart';
import 'package:clik_pro_professional/model/ProSearchDataModel.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/Chat/chat_screen.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:clik_pro_professional/widgets/RowWithText.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';

import '../../widgets/job_details_page.dart';


class SearchProfessionals extends StatefulWidget {
  String?cityID;
  String?catID;
  SearchProfessionals({this.cityID,this.catID});
  @override
  State<SearchProfessionals> createState() => _SearchProfessionalsState();
}

class _SearchProfessionalsState extends State<SearchProfessionals> {


    @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }
  String?userName="";
  String?userEmail = "";
  getData()async{
    await Provider.of<UserProvider>(context,listen: false).getCategory();
    await Provider.of<UserProvider>(context,listen: false).getCity();
    await Provider.of<UserProvider>(context,listen: false).clearSearchData();



    if(myProvider!.cityList!=null && myProvider!.cityList.length>0){
        if(![null,""].contains(widget.cityID)){
            myProvider!.cityList.forEach((element) {
              if(element.id!.compareTo(widget.cityID!)==0){
                selectedCity = element;
              }
            });
        }
    }
    if(myProvider!.categoryList!=null && myProvider!.categoryList.length>0){
        if(![null,""].contains(widget.catID)){
            myProvider!.categoryList.forEach((element) {
              if(element.id!.compareTo(widget.catID!)==0){
                selectCategory = element;
              }
            });
        }
    }
    if(widget.cityID!=null){
      await Provider.of<UserProvider>(context,listen: false).getProSearchData(catID: selectCategory!=null? selectCategory!.id:"", cityID: selectedCity!=null?selectedCity!.id:"");
    }
    if(widget.catID!=null){
      await Provider.of<UserProvider>(context,listen: false).getProSearchData(catID: selectCategory!=null? selectCategory!.id:"", cityID: selectedCity!=null?selectedCity!.id:"");
    }
  }
  UserProvider?myProvider;
  Size?_size;
 String? cityName="";

  CityData?selectedCity;
  CategoryData?selectCategory;
  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context,listen: false);
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return Scaffold(
      appBar: AppBar(
        title: Text("Search".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.black),),
        elevation: 0.0,
        iconTheme: IconThemeData(color: Colors.black),
        centerTitle: true,
        backgroundColor: Colors.transparent,
      ),
      body: Stack(
        children: [
        ListView(
          padding:const EdgeInsets.symmetric(horizontal: 16,vertical: 10),
          children: [
          Text("Select Category".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
          SizedBox(height: _size!.height*0.01),
          Container(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(
                border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
                  borderRadius: BorderRadius.circular(10),
                  
              ),
                
              child:  DropdownSearch<CategoryData>(
                            //asyncItems: (String filter) => getData(filter),
            itemAsString: (CategoryData? u) => u!.categoryName!,
            items: model.categoryList,
            dropdownButtonProps: const DropdownButtonProps(
      
            ),
            dropdownDecoratorProps:  DropDownDecoratorProps(
              dropdownSearchDecoration: InputDecoration(hintText: "Select Category".tr(), border: InputBorder.none)
            ),
            popupProps:  PopupProps.dialog(
            showSearchBox: true,
          //  showSelectedItems: true,
              title: Text("Select Category".tr()),
          ),selectedItem:selectCategory ,
      
              onChanged: (CategoryData? data) async {
              setState(() {
                selectCategory = data!;
              });
            },
            onSaved: (data){
              print("hi");
            },
            ),
          ),
      
          SizedBox(height: _size!.height*0.01),
          Text("Select City".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
          SizedBox(height: _size!.height*0.01),
          Container(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
                    borderRadius: BorderRadius.circular(10),
                    
                ),
                  
                child:  DropdownSearch<CityData>(
                              //asyncItems: (String filter) => getData(filter),
              itemAsString: (CityData? u) => u!.cityName!,
              items: model.cityList,
              dropdownButtonProps: const DropdownButtonProps(
        
              ),
              dropdownDecoratorProps:  DropDownDecoratorProps(
                dropdownSearchDecoration: InputDecoration(hintText: "Select City".tr(), border: InputBorder.none)
              ),
              popupProps:  PopupProps.dialog(
              showSearchBox: true,
            //  showSelectedItems: true,
                title: Text("Select Category".tr()),
            ),selectedItem:selectedCity ,
        
                onChanged: (CityData? data) async {
                setState(() {
                  selectedCity = data!;
                });
              },
              onSaved: (data){
                print("hi");
              },
              ),
            ),
          
          SizedBox(height: _size!.height*0.04),
          InkWell(
            onTap: (){
              if(selectCategory==null && selectedCity==null){
                return showToastMsg("Please Select".tr());
              }
              model.getProSearchData(catID: selectCategory!=null? selectCategory!.id:"", cityID: selectedCity!=null?selectedCity!.id:"");
            },
            child: Container(
              padding:const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: AppColor.appThemeColorOrange,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Center(
                child: Text("Search Jobs".tr(),style: AppTextStyles.k14TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)),
              ),
            ),
          ),
          SizedBox(height: _size!.height*0.03),
          //Text("Jobs",style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive)),
          SizedBox(height: _size!.height*0.01),
         model.proSearchDataList!=null &&  model.proSearchDataList.length>0?
           ListView.builder(
            itemCount:  model.proSearchDataList.length,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: (context,index){
              ProSearchData obj =  model.proSearchDataList[index];
              //    agoTIme = Jiffy(obj.startDate, "yyyy-MM-dd hh:mm:ss").fromNow();
            return Container(
                   //height: 150,
                   margin:const EdgeInsets.symmetric(vertical: 6),
                   padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                   decoration: BoxDecoration(
                       borderRadius: BorderRadius.circular(12),
                  //border: Border.all(color: Colors.black),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: AppColor.appThemeColorOlive.withOpacity(0.2),
                      
                      spreadRadius: 3,blurRadius: 3
                    )
                  ]
                   ),
                   child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(child: Text(obj.jobTitle!.toUpperCase(),style: AppTextStyles.k18TextH.copyWith(color: AppColor.appThemeColorSky))),
                            SizedBox(width: _size!.width*0.04),
                           
                             Container(
                              padding:const EdgeInsets.symmetric(horizontal: 6,vertical: 4),
                              decoration: BoxDecoration(
                              color: AppColor.appThemeColorGreen,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(("€" )+ obj.price!,style: AppTextStyles.k14TextN.copyWith(color: Colors.white)),
                            ),
                          ],
                        ),
                        SizedBox(height: _size!.height*0.005),
                        RowWtihText(title: "Location".tr(),value: obj.cityName,),
                        SizedBox(height: _size!.height*0.005),
                        RowWtihText(title: "Category".tr(),value: obj.categoryName,),
                        SizedBox(height: _size!.height*0.01),
                       // Text("Posted".tr() + (" ") + agoTIme!,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),),
                       // SizedBox(height: _size!.height*0.01),
                        RowWtihText(title: "Due Date".tr(),value: obj.dueDate,valueColr: AppColor.appRedColor,),
                        SizedBox(height: _size!.height*0.01),
                        // Row(children: [
                        //           Container(
                        //             padding:const EdgeInsets.all(3),
                        //             decoration: BoxDecoration(
                        //               borderRadius: BorderRadius.circular(6),
                        //               color: AppColor.appThemeColorOrange
                        //             ),
                        //             child: Text(widget.obj!.bidCount!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                        //           ),
                        //           const SizedBox(width: 8),
                        //           Text("Proposals".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),)
                        //         ],
                        //       ),
                              SizedBox(height: _size!.height*0.01),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                          
                            InkWell(
                                onTap: (){
                                  navigateWithPageTransition(context, ChatScreen(customerID: obj.custId,first_name: obj.name));
                                },
                              child: Container(
                                 padding:const EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      color: AppColor.appThemeColorOrange
                                    ),
                                    child:const Icon(Icons.chat,size:20,color: Colors.white,),
                              ),
                            ),
                              const SizedBox(width: 8),
                            // InkWell(
                            //     onTap: (){
                            //       navigateWithPageTransition(context, JobDetailsPage(obj: obj,));
                            //     },
                            //   child: Container(
                            //      padding:const EdgeInsets.all(3),
                            //         decoration: BoxDecoration(
                            //           borderRadius: BorderRadius.circular(6),
                            //           color: AppColor.appThemeColorOrange
                            //         ),
                            //         child:const Icon(Icons.remove_red_eye,color: Colors.white,),
                            //   ),
                            // ),
                            const SizedBox(width: 8),
                            //  !sendQuote!?
                            //  InkWell(
                            //   onTap: (){ 
                            //          navigateWithPageTransition(context, SendQuote(job_id: widget.obj!.id,customer_budget:widget.obj!.price,cust_id: widget.obj!.custId,));
                            //   },
                            //    child: Container(
                            //      padding:const EdgeInsets.all(5),
                            //         decoration: BoxDecoration(
                            //           borderRadius: BorderRadius.circular(6),
                            //           color: AppColor.appThemeColorOrange
                            //         ),
                            //         child:Text("Send a Quote".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)
                            //      ),
                            //  ):InkWell(
                            //   onTap: (){
                            //          navigateWithPageTransition(context, ViewQuotes(quote_id:  widget.obj!.id,));
                            //   },
                            //    child: Container(
                            //      padding:const EdgeInsets.all(5),
                            //         decoration: BoxDecoration(
                            //           borderRadius: BorderRadius.circular(6),
                            //           color: AppColor.appThemeColorOlive
                            //         ),
                            //         child:Text("See the Quote".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)
                            //      ),
                            //  ),

                          ],
                        ),
                    ],
                   ),
                 );
          }):Container()
          ],
        ),
        model.isLoading!?CustomLoader():Container()
      ]),
    );
    });
  }
}