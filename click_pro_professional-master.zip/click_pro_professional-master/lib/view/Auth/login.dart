

import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
//import 'package:clik_pro_professional/view/BottomNavBar/bottomNavbar.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:easy_localization/easy_localization.dart';
//import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
//import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';

class UserLogin extends StatefulWidget {
  const UserLogin({super.key});

  @override
  State<UserLogin> createState() => _UserLoginState();
}

class _UserLoginState extends State<UserLogin> {
  
  final emailController = TextEditingController(text: "");
  final passwordController = TextEditingController(text: "");

  bool?isShow=true;

  Size?_size;
  
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return Scaffold(
      body: Stack(
        children: [
          ListView(
             children: [
              SizedBox(height: _size!.height*0.05),
                Container(
                    margin: EdgeInsets.only(top: _size!.height*0.05),
                    width: _size!.width*0.7,
                    height: _size!.height*0.1,
                  
                    child: Image.asset("assets/logos/logo1.png"),
               ),
                 SizedBox(height: _size!.height*0.03),
              Center(child: Text("LOGIN".tr(),style: AppTextStyles.k20TextH.copyWith(color: AppColor.appThemeColorOlive))),
               SizedBox(height: _size!.height*0.03),

               Container(
                //height: 300,
                margin:const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
                decoration: BoxDecoration(
                 //s border: Border.all(color: AppColor.appThemeColorOrange),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  children: [

                    
                    getTextFieldTextType("Enter Email".tr(), "Enter Email".tr(), controller: emailController),
                    SizedBox(height: _size!.height*0.02),
                    getTextFieldTextType("Enter Password".tr(), "Enter Password".tr(),
                      suffix: InkWell(
                        onTap: (){
                          isShow = !isShow!;
                          setState(() {
                            
                          });
                        },
                        child: Icon(Icons.remove_red_eye)),
                     controller: passwordController,obscureText: isShow!),
                    SizedBox(height: _size!.height*0.02),
                   
             
                    InkWell(
                        onTap: (){
                         if(emailController.text.isNotEmpty && passwordController.text.isNotEmpty){
                            model.loginAPi(context, email: emailController.text, pass: passwordController.text);
                         }else{
                          showToastMsg("Please Enter Credentials".tr());
                         }
                        },
                         child: Container(
                          height: _size!.height*0.05,
                          decoration: BoxDecoration(
                            color: AppColor.appThemeColorOrange,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(child: Text("Log In".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),),
                         ),
                       ) ,
                     /* SizedBox(height: _size!.height*0.03),
                      Center(child: Text("OR".tr(),style: AppTextStyles.k12TextN,),),
                       SizedBox(height: _size!.height*0.03),

                    InkWell(
                        onTap: () async{
                           // navigateWithPageTransition(context, BottomNavBar(0),);
                          await signInWithGoogle(context);
                        },
                         child: Container(
                          height: _size!.height*0.05,
                          decoration: BoxDecoration(
                            //color: AppColor.appThemeColorOlive,
                            border: Border.all(color: AppColor.appThemeColorOlive),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                               Image.asset("assets/images/google.png", height: 25,),
                              const SizedBox(width: 10,),
                              Text("Log In With Google".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.black,fontWeight: FontWeight.w600),),
                            ],
                          ),
                         ),
                       ) ,*/ 

                  ],
                ),
               ),
             ],
          ),
           Provider.of<UserProvider>(context).isLoading!?CustomLoader():Container()
        ],
      ),
    );
    });
  }

  // FirebaseAuth? _auth = FirebaseAuth.instance;
  // Future<void> signInWithGoogle(BuildContext context) async {
  //   try{
  //     final GoogleSignIn _googleSignIn = new GoogleSignIn();
  //      await _googleSignIn.signOut();
  //     final GoogleSignInAccount? googleSignInAccount = await _googleSignIn.signIn();
  //     final GoogleSignInAuthentication? googleSignInAuthentication =  await googleSignInAccount!.authentication;
  //     // setState(() {
  //     //   apiCalled=true;
  //     // });
  //     final AuthCredential credential = GoogleAuthProvider.credential(
  //         idToken: googleSignInAuthentication!.idToken,
  //         accessToken: googleSignInAuthentication.accessToken);
  //     UserCredential? result = await _auth!.signInWithCredential(credential);
  //     User userDetails = result.user!;
  //     //  loginViaGmail(userDetails.email!);
  //     if([null,""].contains(userDetails.email)){
  //       // setState(() {
  //       //   apiCalled=false;
  //       // });
  //     }
  //    // signOut();
  //     if(userDetails!=null && ![null,""].contains(userDetails.email)){
  //       print(userDetails.email);
  //       print(userDetails.phoneNumber);
  //       print(userDetails.photoURL);
  //     }
  //   }catch(ex){
  //     print(ex.toString());
  //     //showTostMsg(ex.toString());

  //   }
  // }

  // Future signOut() async {
  //   try {
  //     return await _auth!.signOut();
  //   } catch (e) {
  //     print("error signout"+e.toString());
  //     return null;
  //   }
  // }
}

