
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/res/sp_keys.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import 'package:pinput/pin_put/pin_put.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../utils/text_styles.dart';

class VerifyOTP extends StatefulWidget {
  const VerifyOTP({super.key});

  @override
  State<VerifyOTP> createState() => _VerifyOTPState();
}

class _VerifyOTPState extends State<VerifyOTP> {

  final pinputController = TextEditingController(text: "");


   Size?_size;
  final _pinPutFocusNode = FocusNode();
  final _pinPutController = TextEditingController();

  getData()async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
   email = sharedPreferences.getString(SPData.USER_EMAIL);
  }

  initState(){
    super.initState();
    Future.delayed(Duration(milliseconds: 100),()=> getData());
  }

  String?email="";

  @override
  Widget build(BuildContext context){
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          ListView(
            children: [
                 SizedBox(height: _size!.height*0.05),
                  Container(
                    margin: EdgeInsets.only(top: _size!.height*0.05),
                    width: _size!.width*0.7,
                    height: _size!.height*0.1,
                  
                    child: Image.asset("assets/logos/logo1.png"),
               ),
              SizedBox(height: _size!.height*0.05), 
                         // SizedBox(height: _size!.height*0.02),
              Center(child: Text("VERIFY".tr(),style: AppTextStyles.k20TextH.copyWith(color: AppColor.appThemeColorOlive))),
               SizedBox(height: _size!.height*0.02),
               Padding(
                 padding: const EdgeInsets.symmetric(horizontal: 40),
                 child: Text("We have sent an Security Code on your register email".tr(), textAlign: TextAlign.center, style: AppTextStyles.k14TextN,),
               ),
               Text(email!, textAlign: TextAlign.center,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorGreen,fontWeight: FontWeight.w600,fontStyle: FontStyle.italic),),
              SizedBox(height: _size!.height*0.05), 
               Padding(padding: EdgeInsets.all(8),
                child: Container(
                  child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 8.0, horizontal: 30),
                      child: otpPinWidget(model)),
                ),),
               SizedBox(height: _size!.height*0.05), 
                InkWell(
                        onTap: ()async{
                          print("fine");
                          
                           if(pinputController.text.isNotEmpty){
                             model.verifyOtp(context,otp: pinputController.text);
                           }else{
                            showToastMsg("Please Enter Security Code first".tr());
                           }
                           // navigateWithPageTransition(context, BottomNavBar(0),);
                        },
                         child: Container(
                          height: _size!.height*0.05,
                          margin:const EdgeInsets.symmetric(horizontal: 20),
                          decoration: BoxDecoration(
                            color: AppColor.appThemeColorOrange,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(child: Text("Verify Account".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),),
                         ),
                      ),
            ],
          ),
          Provider.of<UserProvider>(context).isLoading!?CustomLoader():Container()
        ],
      ),
    );
    });
  }

    Widget otpPinWidget(UserProvider model) {

    final BoxDecoration pinPutDecoration = BoxDecoration(
      color:  Colors.white,
      boxShadow: [
        BoxShadow(
            color: AppColor.appThemeColorOlive,
            blurRadius: 2,spreadRadius: 2
        )
      ],
      borderRadius: BorderRadius.circular(12.0),
      border: Border.all(
        color: Colors.white,
      ),
    );

        final BoxDecoration selectedpinPutDecoration = BoxDecoration(
      color:  Colors.white,
      boxShadow: [
        BoxShadow(
            color: AppColor.appThemeColorOrange,
            blurRadius: 2,spreadRadius: 2
        )
      ],
      borderRadius: BorderRadius.circular(12.0),
      border: Border.all(
        color: Colors.white,
      ),
    );

    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: PinPut(
        fieldsCount: 4,
        withCursor: true,
        enabled: true,
        separator: SizedBox(width: 8,),
        textStyle: const TextStyle(fontSize: 25.0, color: AppColor.appThemeColorGreen,fontWeight: FontWeight.w700),
        eachFieldWidth: 45.0,
        eachFieldHeight: 50.0,eachFieldPadding: EdgeInsets.all(8),
        onSubmit: (String pin) async {
            if(pin.length==4){
                model.verifyOtp(context,otp: pinputController.text);
            }
        },
        focusNode: _pinPutFocusNode,
        controller: pinputController,onTap: (){},keyboardType: TextInputType.number,
        submittedFieldDecoration: selectedpinPutDecoration,
        selectedFieldDecoration: pinPutDecoration,
        followingFieldDecoration: pinPutDecoration,
        pinAnimationType: PinAnimationType.fade,

      ),
    );

  }

}

