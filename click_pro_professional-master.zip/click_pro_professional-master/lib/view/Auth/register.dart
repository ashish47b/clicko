
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/view/BottomNavBar/bottomNavbar.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../utils/common.dart';
import '../../utils/text_styles.dart';

class UserRegister extends StatefulWidget {
  const UserRegister({super.key});

  @override
  State<UserRegister> createState() => _UserRegisterState();
}

class _UserRegisterState extends State<UserRegister> {
  
  final TextEditingController nameController = TextEditingController(text: "");
  final TextEditingController last_nameController = TextEditingController(text: "");
  final TextEditingController emailController = TextEditingController(text: "");
  final TextEditingController phoneController = TextEditingController(text: "");
  final TextEditingController passwordController = TextEditingController(text: "");
  final TextEditingController confirmPassController = TextEditingController(text: "");
  

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return Scaffold(
      body: Stack(
        children: [
          ListView(
         children: [
         
            Container(
                margin: EdgeInsets.only(top: _size!.height*0.05),
                width: _size!.width*0.7,
                height: _size!.height*0.07,
              
                child: Image.asset("assets/logos/logo1.png"),
           ),
             SizedBox(height: _size!.height*0.01),
          Center(child: Text("REGISTER".tr(),style: AppTextStyles.k20TextH.copyWith(color: AppColor.appThemeColorOlive))),
           SizedBox(height: _size!.height*0.01),

           Container(
            //height: 300,
            margin:const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
            padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 8),
            decoration: BoxDecoration(
             //s border: Border.all(color: AppColor.appThemeColorOrange),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              children: [

                getTextFieldTextType("Enter Name".tr(), "Enter Name".tr(), controller: nameController),
                SizedBox(height: _size!.height*0.01),
                getTextFieldTextType("Enter Last Name".tr(), "Enter Last Name".tr(), controller: last_nameController),
                SizedBox(height: _size!.height*0.01),
                getTextFieldTextType("Enter Email".tr(), "Enter Email".tr(), controller: emailController,textInputType: TextInputType.emailAddress),
                SizedBox(height: _size!.height*0.01),
                 getTextFieldTextType("Enter Phone Number".tr(), "Enter Phone NUmber".tr(),
                    controller: phoneController,
                   textInputType: TextInputType.number,
                   textInputFormatter: [
                    LengthLimitingTextInputFormatter(10),
                    FilteringTextInputFormatter.digitsOnly
                   ]
                   ),
                  SizedBox(height: _size!.height*0.01),
                getTextFieldTextType("Enter Password".tr(), "Enter Password".tr(),
                controller: passwordController,
                 obscureText: true
                 ),
                SizedBox(height: _size!.height*0.01),
                  getTextFieldTextType("Enter Password".tr(), "Enter Password".tr(),
                   controller: confirmPassController,
                   obscureText: true
                   ),
                SizedBox(height: _size!.height*0.03),
                InkWell(
                    onTap: (){
                      print("fine");
                       
                       validateMethods(model);
                       // navigateWithPageTransition(context, BottomNavBar(0),);
                    },
                     child: Container(
                      height: _size!.height*0.05,
                      decoration: BoxDecoration(
                        color: AppColor.appThemeColorOrange,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Center(child: Text("Create Account".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),),
                     ),
                  ),
                  SizedBox(height: _size!.height*0.02),
                  // Center(child: Text("OR".tr(),style: AppTextStyles.k12TextN,),),
                  //  SizedBox(height: _size!.height*0.02),
               /* InkWell(
                    onTap: (){
                      //  navigateWithPageTransition(context, BottomNavBar(0),);
                    },
                     child: Container(
                      height: _size!.height*0.05,
                      decoration: BoxDecoration(
                        color: AppColor.appThemeColorOlive,
                        border: Border.all(color: AppColor.appThemeColorOlive),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,                   
                        children: [
                           Image.asset("assets/images/google.png", height: 25,),
                          const SizedBox(width: 10,),
                          Text("Sign Up With Google".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),
                        ],
                      ),
                     ),
                ) , 
                SizedBox(height: _size!.height*0.02),
                InkWell(
                    onTap: (){
                       // navigateWithPageTransition(context, BottomNavBar(0),);
                    },
                     child: Container(
                      height: _size!.height*0.05,
                      decoration: BoxDecoration(
                        color: AppColor.appThemeColorOlive,
                        border: Border.all(color: AppColor.appThemeColorOlive),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                           Image.asset("assets/images/facebook.png", height: 25,),
                          const SizedBox(width: 10,),
                          Text("Sign Up With Facebook".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),
                        ],
                      ),
                     ),
                   ) ,*/
              ],
            ),
           ),
         ],
      ),

      //loaderController.isLoading.value?CustomLoader():Container()
        Provider.of<UserProvider>(context).isLoading!?CustomLoader():Container()
        ],
      )
    );
    });
  }
    validateMethods(UserProvider model)async{
    if(nameController.text.isNotEmpty){
      if(last_nameController.text.isNotEmpty){
        if(emailController.text.isNotEmpty){
        if(phoneController.text.isNotEmpty && phoneController.text.length==10){
          if(passwordController.text.isNotEmpty && passwordController.text.length>7){
             if(confirmPassController.text.isNotEmpty ){
               if(confirmPassController.text == passwordController.text){                 
                  model.userRegister(context, first_name: nameController.text,last_name: last_nameController.text, email: emailController.text, phone: phoneController.text, pass: passwordController.text, confirmPass: confirmPassController.text);
               }
               else{
                showToastMsg("Both Password should be same".tr());
               }
             }else{
             }

          }else{
            showToastMsg("Please Enter Password and and enter a strong password(choose min 8 characters)".tr());
          }

        }else{
           showToastMsg("Please Enter Phone Number".tr());
        }

      }else{
         showToastMsg("Please Enter Email".tr());
      }
      }else{
        showToastMsg("Please Enter Name".tr());
      }
    }else{
      showToastMsg("Please Enter Name".tr());
    }
  }
}