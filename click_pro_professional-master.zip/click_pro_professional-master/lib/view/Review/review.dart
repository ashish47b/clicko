import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class ReviewList extends StatefulWidget {
  const ReviewList({super.key});

  @override
  State<ReviewList> createState() => _ReviewListState();
}

class _ReviewListState extends State<ReviewList> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
     return SafeArea(
       child: Scaffold(
           appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0.0,
            title: Text("Reviews".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black)),
            centerTitle: true,
            iconTheme:const IconThemeData(color: Colors.black),
           ),
           body: ListView(
                children: [
                  SizedBox(height: _size!.height*0.02),
                  ListView.builder(
                    shrinkWrap: true,
                    physics:const NeverScrollableScrollPhysics(),
                    itemCount: 5,
                    itemBuilder: (context,index){
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 12,vertical: 12),
                         child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                           children: [
                             Row(
                              children: [
                               const CircleAvatar(
                                  radius: 28,
                                  backgroundColor: Colors.white,
                                  backgroundImage: AssetImage("assets/images/person.jpg"),
                                ),
                               const SizedBox(width: 20),
                               Expanded(
                                 child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                   children: [
                                     Text("Courtney Henry",style: AppTextStyles.k18TextN,),
                                     Text("2 days ago",style: AppTextStyles.k14TextN,),
                                   ],
                                 ),
                               ),

                               Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.grey[300],
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.star,color: Colors.yellow[800]),
                                   const SizedBox(width: 5),
                                    Text("4.5",style: AppTextStyles.k14TextN,)
                                  ],
                                ),
                               )

                              ],
                             ),
                             const SizedBox(height: 20),
                             Text("Very professional and knowledgeable. They were quick to schedule and showed up on time. Would call them again.The best plumber in the state of Ohio. Clearly Leon is the man💪 professional and polite ",
                             style: AppTextStyles.k13TextN,
                             ),
                             const Divider(color: Colors.grey,)
                           ],
                         ),
                    );
                  })
                ],
           ),
         ),
     );
  }
}