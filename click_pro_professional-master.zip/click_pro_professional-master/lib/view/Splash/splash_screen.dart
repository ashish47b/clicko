import 'dart:async';


import 'package:clik_pro_professional/res/sp_keys.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/view/BottomNavBar/bottomNavbar.dart';
import 'package:clik_pro_professional/view/OnBoardPage/onboard_page.dart';
import 'package:clik_pro_professional/widgets/custome_loader.dart';
import 'package:flutter/material.dart';

import 'package:lottie/lottie.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  Size?_size;


  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 3), ()=> getValidation());
  }

  getValidation()async{
   SharedPreferences sp  = await SharedPreferences.getInstance();
   String?userToken = sp.getString(SPData.USER_TOKEN);
    String?verify = sp.getString(SPData.USER_VERIFY);
    print("USERTOKEN" + userToken.toString());
    print("USERTOKEN" + verify.toString());
    if(verify=="1" && ![null,""].contains(userToken)){
      navigatetoAnotherPage(context, BottomNavBar(0));
    }else{
      navigatetoAnotherPage(context, OnBoardPage());
    }
  }



  @override
  Widget build(BuildContext context) {
      
    _size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        children: [
          SizedBox(height: _size!.height*0.02),
            Container(
              margin: EdgeInsets.only(top: _size!.height*0.05),
              width: _size!.width*0.7,
              height:_size!.height*0.1,           
              child: Image.asset("assets/logos/logo1.png"),
          ),
         
          SizedBox(height: _size!.height*0.04),
            InkWell(
              onTap: (){
                //Get.toNamed(RoutesName.onBoardView);
              },
              child: Container(
              padding:const EdgeInsets.all(10),
              height: _size!.height*0.4,
              child: Lottie.asset("assets/lottie/splash.json")
              ),
            ),
            SizedBox(height: _size!.height*0.05),
            const CustmerLoader()
        ],
      ),
    );
  }
}