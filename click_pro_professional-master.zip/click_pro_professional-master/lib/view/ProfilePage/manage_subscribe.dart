import 'package:carousel_slider/carousel_slider.dart';
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/SubscriptionModel/subscription_list_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ManageSubscribe extends StatefulWidget {
  SubscriptionListData? selectedPlan;
  ManageSubscribe({this.selectedPlan});

  @override
  State<ManageSubscribe> createState() => _ManageSubscribeState();
}

class _ManageSubscribeState extends State<ManageSubscribe> {
  
  bool isMonth=false;
  bool isYear=false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 200),()=> getData());
    isMonth = true;
  }


  getData()async {
    await Provider.of<UserProvider>(context,listen: false).subscriptionList();
  }


  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return StatefulBuilder(builder: (context,myState){
      return Consumer<UserProvider>(builder: (context,model,child){
        return Stack(
          children: [
          ListView(
           children: [
             SizedBox(height: _size!.height*0.02,),
            // Center(child: Text("Manage Subscription",style: AppTextStyles.k18TextH)),
             SizedBox(height: _size!.height*0.02),
             Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: (){
                    isMonth = true;
                    isYear = false;
                    //monthlyWidget(myState,model,viaYear: false);
                    controller.jumpToPage(0);
                    myState(() {
                      
                    });
                  },
                  child: Container(
                    width: 100,
                    padding:const EdgeInsets.symmetric(vertical: 3),
                    decoration: BoxDecoration(color:isMonth? AppColor.appThemeColorOrange:Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColor.appThemeColorOrange)
                    ),
                  child:  Center(child: Text("Monthly".tr(), style: AppTextStyles.k16TextN.copyWith(color:isMonth? Colors.white:AppColor.appThemeColorOrange),)),
                  ),
                ),
               const SizedBox(width: 20),
                   InkWell(
                    onTap: (){
                    isMonth = false;
                    isYear = true;
                   // monthlyWidget(myState,model,viaYear: true);
                    controller.jumpToPage(0);
                    myState(() {
                      
                    });
                    },
                     child: Container(
                                 width: 100,
                                 padding:const EdgeInsets.symmetric(vertical: 3),
                                 decoration: BoxDecoration(color:isYear? AppColor.appThemeColorOrange :Colors.white,
                                 borderRadius: BorderRadius.circular(12),
                                 border:Border.all(color: AppColor.appThemeColorOrange)
                                 ),
                               child:  Center(child: Text("Yearly".tr(), style: AppTextStyles.k16TextN.copyWith(color:isYear? Colors.white :AppColor.appThemeColorOrange),)),
                               ),
                   ),
              ],
             ),

             SizedBox(height: _size!.height*0.05),

            monthlyWidget(myState, model,viaYear: isYear?true:false)
      ],
    ),
          
           model.isLoading!?const CustomLoader():Container()
          ],
        );
      });
    });
  }
  int initialPage = 1;
  CarouselController controller = CarouselController();
  monthlyWidget(myState,UserProvider model,{bool?viaYear=false}){
    //initialPage = 1;
    return Container(
      child: CarouselSlider(
        options: CarouselOptions(
          height: _size!.height*0.5,
          viewportFraction: 0.65,
          enlargeFactor: 0.2,
          enlargeCenterPage: true,
          enableInfiniteScroll :false,
          initialPage: 2,
      ),carouselController: controller,
  items: (viaYear!=null && viaYear?model.yearList:model.monthList)!.map((i) {
    return Builder(
      builder: (BuildContext context) {
        SubscriptionListData obj = i;
        return subscriptionBox(
          myState,
          obj: obj,
            model,
        );
      },
    );
  }).toList(),
)
 );
  }

  int? selectedItem;

  subscriptionBox(myState, UserProvider?model,{SubscriptionListData? obj } ){
    return InkWell(
      onTap: (){
          if(selectedItem!=null){
            selectedItem = null;
            model.selectedPlan(null);
          } else {
            selectedItem = int.parse(obj.id!);
            //widget.selectedPlan = obj;
            model.selectedPlan(obj);
          }
          myState(() {

          });
      },
      child: Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              color: selectedItem!=null && selectedItem!.compareTo(int.parse(obj!.id!))==0 && model!.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)!=0?
                  Colors.grey.shade300
                :(model!.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj!.id!)==0?AppColor.appThemeColorOrange:Colors.white),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColor.appThemeColorOrange,width:1),
              boxShadow: [
                BoxShadow(
                  color: AppColor.appThemeColorOrange.withOpacity(0.2),
                  blurRadius: 3, spreadRadius: 3,
                )
              ]
            ),
           child: Column(
            children: [
              Image.asset("assets/logos/logo1.png", height: 100, width: 150),
              SizedBox(height: _size!.height*0.01),
              Text(obj!.title!,style: AppTextStyles.k25TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorOrange)),
               SizedBox(height: _size!.height*0.01),
               ["0","0.00"].contains(obj.price)
               ?Text("FREE",style: AppTextStyles.k16TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorGreen))
               :Row(
                mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   Text( "\$ " + obj.price!, style: AppTextStyles.k16TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorOrange)),
                   Text("/ per month",style: AppTextStyles.k16TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorOlive)),
                 ],
               ),
                SizedBox(height: _size!.height*0.02),
              
             obj.quotManage=="all"? Text("No Limit",style: AppTextStyles.k16TextN.copyWith(
                 color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorGreen)) :
             Text("${obj.quotManage} Quotes",style: AppTextStyles.k16TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorOlive)),
              SizedBox(height: _size!.height*0.01),
                  obj.invoiceManage=="all"? Text("No Limit",
                      style: AppTextStyles.k16TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorGreen)) :
                  Text("${obj.invoiceManage} Bills",style: AppTextStyles.k16TextN.copyWith(
                    color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorOlive
                  )),
              SizedBox(height: _size!.height*0.01),
              // Text("Appointment Management",style: AppTextStyles.k16TextN),

               Row(
                mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   Text("Appointment ",style: AppTextStyles.k16TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorOlive)),
                  obj.appointmentManage=="0"? Icon(Icons.close, color: Colors.red,):Icon(Icons.check, color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:Colors.green,)
                 ],
               ),
                SizedBox(height: _size!.height*0.01),
               Row(
                mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   Text("WhatsApp Reminder",style: AppTextStyles.k16TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorOlive)),
                  obj.whatsappAutoReminder=="0"? Icon(Icons.close, color: Colors.red,):
                  Icon(Icons.check, color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:Colors.green,)
                 ],
               ),
               SizedBox(height: _size!.height*0.01),
            obj.commission=="no"? Text("No Commission ",style: AppTextStyles.k16TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorGreen)) :   Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Commission ",style: AppTextStyles.k16TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorOlive)),
                  Text("(${obj.commission}%)",style: AppTextStyles.k18TextN.copyWith(color: model.profileData!=null && model.profileData!.subscriptionPlanId!.compareTo(obj.id!)==0?Colors.white:AppColor.appThemeColorOrange))
                ],
              ),
            ],
           ),
          ),
    );
  }




}