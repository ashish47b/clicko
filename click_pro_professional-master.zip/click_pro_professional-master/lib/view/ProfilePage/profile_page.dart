
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/ProfileDataModel/profile_data_model.dart';
import 'package:clik_pro_professional/model/SubscriptionModel/subscription_list_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/ProfilePage/manage_subscribe.dart';
import 'package:clik_pro_professional/view/ProfilePage/personal_info.dart';

import 'package:clik_pro_professional/view/Review/review.dart';
import 'package:clik_pro_professional/view/Subscribe/subscribe_page.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:clik_pro_professional/widgets/NoData.dart';
import 'package:clik_pro_professional/widgets/RowWithText.dart';
import 'package:clik_pro_professional/widgets/TextWithIcon.dart';
import 'package:clik_pro_professional/widgets/fade_in_image.dart';
import 'package:clik_pro_professional/widgets/image_preview.dart';
import 'package:clik_pro_professional/widgets/language_switcher.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:provider/provider.dart';


class ProfessionalProfilePage extends StatefulWidget {
  const ProfessionalProfilePage({super.key});

  @override
  State<ProfessionalProfilePage> createState() => _ProfessionalProfilePageState();
}

class _ProfessionalProfilePageState extends State<ProfessionalProfilePage> {
   



  getData()async{
    await Provider.of<UserProvider>(context,listen: false).profileList();
     Provider.of<UserProvider>(context,listen: false).getRatings();
    await Provider.of<UserProvider>(context,listen: false).subscriptionList();
    if(myProvider!.subscribeList!=null && myProvider!.subscribeList.length>0){
      if(myProvider!.profileData!=null && ![null,""].contains(myProvider!.profileData!.subscriptionPlanId)){
        myProvider!.subscribeList.forEach((element) {
          if(element.id!.compareTo(myProvider!.profileData!.subscriptionPlanId!)==0){
              subscriptionListData = element;
          }
        });
      }
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(const Duration(milliseconds: 300),()=> getData());
  }

  SubscriptionListData?subscriptionListData;

  Size?_size;
  UserProvider?myProvider;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    myProvider = Provider.of<UserProvider>(context,listen: false);
    return Consumer<UserProvider>(builder: (context,controller,child){
      return SafeArea(
      child: Stack(
        children: [
          Scaffold(
            appBar: AppBar(
               backgroundColor: Colors.transparent,
               elevation: 0.0,
               title: Text("PROFILE",style: AppTextStyles.k18TextH.copyWith(color: Colors.black)),
               centerTitle: true,
               iconTheme: IconThemeData(color: Colors.black),
               actions: [
                IconButton(onPressed: (){
                  navigateWithPageTransition(context, AddPersonalScreen(profileData: controller.profileData));
                }, icon: Icon(Icons.edit,color: AppColor.appThemeColorOrange))
               ],
            ),
            body:controller.profileData==null?
    NoDataWidget(isloading: controller.isLoading,)
    : ListView(
              children: [
               
            Container(
              color: Colors.grey[200],
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              child: Column(
                //crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ![null,""].contains(controller.profileData!.profilePic) && ![null,""].contains(controller.profileData!.profilePicPath)?
                  InkWell(
                    onTap: (){
                      print(controller.profileData!.profilePicPath! + controller.profileData!.profilePic!);
                      navigatetoAnotherPage(context, ImagePreviewScreen(path: controller.profileData!.profilePicPath! + controller.profileData!.profilePic!));
                    },
                    child: Container(
                      height: _size!.height*0.15,
                      width: _size!.width*0.25,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColor.appThemeColorOlive,
                          border: Border.all(color: AppColor.appThemeColorOrange,width: 2),
                          image: DecorationImage(image: NetworkImage(controller.profileData!.profilePicPath! + controller.profileData!.profilePic!),fit: BoxFit.fill) 
                        ),
                    ),
                  ):Container(
                    height: _size!.height*0.15,
                    width: _size!.width*0.25,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColor.appThemeColorOlive,
                        border: Border.all(color: AppColor.appThemeColorOrange,width: 2),
                        image:const DecorationImage(image: AssetImage("assets/icons/profile_image.png"), fit: BoxFit.fill)
                      ),
                  ),
                  Text(controller.profileData!.name!.toUpperCase(),style: AppTextStyles.k20TextH.copyWith(color: AppColor.appThemeColorOlive)),
                 /* Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.phone,color:AppColor.appThemeColorGreen,size: 20),
                      const SizedBox(width: 7),
                      Text(controller.profileData!.phone!.toUpperCase(),style: AppTextStyles.k20TextH.copyWith(color: AppColor.appThemeColorOlive)),
                    ],
                  ),*/
                  SizedBox(height: _size!.height*0.005),
                  if(![null,""].contains(controller.profileData!.cityName!))
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.location_city,color: AppColor.appThemeColorOrange,size: 25),
                      SizedBox(width: _size!.width*0.02),
                      Text(controller.profileData!.cityName!,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive)),
                    ],
                  ),
                  SizedBox(height: _size!.height*0.01),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: AppColor.appThemeColorOrange,
                          borderRadius: BorderRadius.circular(6),
                  
                        ),
                       child: Text(controller.ratingBar!,style: AppTextStyles.k14TextN.copyWith(color: Colors.white),),
                      ),
                      const SizedBox(width: 5),
                     RatingBar.builder(
                          initialRating: controller.ratingBar!=null?double.parse(controller.ratingBar!):1,
                          minRating: 1,
                          direction: Axis.horizontal,
                          allowHalfRating: true,
                          itemCount: 5,
                           itemSize: 18,
                         itemBuilder: (context, _) =>const Icon(
                               Icons.star,
                               color: AppColor.appThemeColorOrange,       
                         ),
                         onRatingUpdate: (rating) {
                             print(rating);
                          },
                      )
                    ],
                  ),
                  SizedBox(height: _size!.height*0.01),
                  if(![null,""].contains(controller.profileData!.jobDone!))
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Total Job Done".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                      Text(controller.profileData!.jobDone!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),)
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
             //
              /*   InkWell(
               onTap: (){
                 navigateWithPageTransition(context, AddPersonalScreen(profileData: controller.profileData,));
               },
               child: Center(
                 child: Container(
                   padding: const EdgeInsets.all(4),
                   margin:const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                   decoration: BoxDecoration(
                     color: Colors.white,
                     border: Border.all(color: AppColor.appThemeColorOrange),
                     borderRadius: BorderRadius.circular(10),
                     boxShadow: [
                       BoxShadow(
                         color: AppColor.appThemeColorOrange.withOpacity(0.2),
                         blurRadius: 2,spreadRadius: 2
                       ),
                     ]
                   ),
                   child: Wrap(
                     children: [
                       const Icon(Icons.edit,size: 20,color: AppColor.appThemeColorOrange),
                       const SizedBox(width: 10),
                       Text("EDIT".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),
                      ),
                     ],
                   )),
               ),
             ),*/
             /* Wrap(
                children: [
                  Center(child: TextButton(onPressed: (){},style: ButtonStyle(backgroundColor: MaterialStateProperty.all(AppColor.appThemeColorOrange)), child: Text("Edit".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)))),
                ],
              ),*/
              const SizedBox(height: 10),
              if([null,""].contains(controller.profileData!.sirenOrSiretNo) || [null,""," "].contains(controller.profileData!.description!) ||
              controller.profileData!.category!.isEmpty || [null,""].contains(controller.profileData!.workHistory!) && controller.profileData!.workImageList!.isEmpty ||
              controller.profileData!.certificateImageList!.isEmpty)
              Center(child: Text("Please Complete Your Profile".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange,fontStyle: FontStyle.italic))),
             //SizedBox(height: _size!.height*0.01),

             if(![null,""," "].contains(controller.profileData!.description!))
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //SizedBox(height: _size!.height*0.01),
              Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("About".tr(),style: AppTextStyles.k18TextH),
              
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Text(controller.profileData!.description!,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),),
            ),
              ],
            ),
            SizedBox(height: _size!.height*0.01),
             controller.profileData!=null && (![null,""].contains(controller.profileData!.companyName) || ![null,""].contains(controller.profileData!.companyLogo))?
             Container(
              padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              margin:const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: AppColor.appThemeColorOlive.withOpacity(0.2),
                    blurRadius: 2,spreadRadius: 2
                  )
                ]
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text("Company Name".tr() + " : ",style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive,fontWeight: FontWeight.w600)),
                      Expanded(child: Text(controller.profileData!.companyName!=null ? controller.profileData!.companyName!:"",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange,fontWeight: FontWeight.bold))),
                    ],
                  ),
                  SizedBox(height: _size!.height*0.01),
                  Row(
                    children: [
                      Text("Company Logo".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive,fontWeight: FontWeight.w600)),
                      const SizedBox(width: 20),
                      InkWell(
                        onTap:(){
                          navigatetoAnotherPage(context, ImagePreviewScreen(path: controller.profileData!.companyLogoPath! + controller.profileData!.companyLogo!));
                        },
                        child: Container(
                          height: 70,width: 100,
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColor.appThemeColorOlive.withOpacity(0.1)),
                            borderRadius: BorderRadius.circular(10),
                            image: DecorationImage(image: NetworkImage(controller.profileData!.companyLogoPath! + controller.profileData!.companyLogo!),fit: BoxFit.fill)
                          ),
                        ),
                      )
                    ],
                  )
                ],
              ),
             ):Container(),
    
             SizedBox(height: _size!.height*0.01),
             subscriptionListData!=null?
             Container(
              padding:const EdgeInsets.symmetric(horizontal: 8,vertical: 8),
              margin: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: AppColor.appThemeColorOrange,
                boxShadow: [
                  BoxShadow(
                    color: AppColor.appThemeColorOlive.withOpacity(0.2),
                    blurRadius: 2,spreadRadius: 2
                  )
                ]
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   //Text("Subscription Plan",style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)),
                   Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                     children: [
                       Text(subscriptionListData!.title!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)),
                       Text(subscriptionListData!.price! + " , " + subscriptionListData!.priceTitle!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.bold)),
                     ],
                   ),
                   Text("Total Invoices".tr() + " : " +(controller.profileData!=null && ![null,""].contains(controller.profileData!.total_invoice_pending)? controller.profileData!.total_invoice_pending! :(subscriptionListData!.invoiceManage!=null?subscriptionListData!.invoiceManage!:"")), style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
                   Text("Total Quotes".tr() + " : " + (controller.profileData!=null && ![null,""].contains(controller.profileData!.total_quot_pending)? controller.profileData!.total_quot_pending! :(subscriptionListData!.quotManage!=null?subscriptionListData!.quotManage!:"")), style: AppTextStyles.k16TextN.copyWith(color: Colors.white)),
                   Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                     children: [
                       TextButton(onPressed: (){
                        navigatetoAnotherPage(context, SubscriberPage());
                       },
                         style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Colors.white)),
                        child: Text("Update Subscribe Plan".tr(),style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOrange,fontWeight: FontWeight.bold))),
                     ],
                   )
                ],
              ),
             ):Container(),
             SizedBox(height: _size!.height*0.01),

             controller.profileData!=null && controller.profileData!.companyDetailsList!=null && controller.profileData!.companyDetailsList.length>0?
             Container(
              margin:const EdgeInsets.symmetric(horizontal: 12,vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow:[
                  BoxShadow(
                    color: AppColor.appThemeColorOlive.withOpacity(0.2),
                    blurRadius: 2,spreadRadius: 2,
                  ),
                ],
              ),
              padding: const EdgeInsets.symmetric(horizontal: 7,vertical: 7),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Company Details".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive,fontWeight: FontWeight.bold)),
                  SizedBox(height: _size!.height*0.01),
                  ListView.builder(
                    itemCount: controller.profileData!.companyDetailsList.length,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (context,index){
                      CompanyDetailsData obj = controller.profileData!.companyDetailsList[index];
                    return Container(
                      padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 8),
                      margin:const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: AppColor.appThemeColorOlive.withOpacity(0.1),blurRadius: 1,spreadRadius: 1
                          )
                        ]
                      ),
                       child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                         Row(
                            children: [
                              Text("Company Name".tr() + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text(obj.companyName!=null?obj.companyName!:'',style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600))),
                            ],
                          ),
                          SizedBox(height: _size!.height*0.01),
                          Row(
                            children: [
                              Text("Location".tr() + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text(obj.location!=null?obj.location!:'',style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600))),
                            ],
                          ),
                          SizedBox(height: _size!.height*0.01),
                          Row(
                            children: [
                              Text("Title".tr() + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text(obj.title!=null?obj.title!:'',style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600))),
                            ],
                          ),
                          SizedBox(height: _size!.height*0.01),
                          Row(
                            children: [
                              Text("Perios".tr() + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Text(obj.periode!=null?obj.periode! + " / ":'',style: AppTextStyles.k14TextN.copyWith(color: Colors.green,fontWeight: FontWeight.w600)),
                              Text(obj.fromYear!=null?obj.fromYear!:'',style: AppTextStyles.k14TextN.copyWith(color: Colors.red,fontWeight: FontWeight.w600)),
                              
                            ],
                          ),
                        ],
                       ),
                    );
                  }),
                ],
              ),
             ):Container(),
 
            SizedBox(height: _size!.height*0.01),
             controller.profileData!=null && controller.profileData!.diplomaDataList!=null && controller.profileData!.diplomaDataList.length>0?
             Container(
              margin:const EdgeInsets.symmetric(horizontal: 12,vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow:[
                  BoxShadow(
                    color: AppColor.appThemeColorOlive.withOpacity(0.2),
                    blurRadius: 2,spreadRadius: 2,
                  ),
                ],
              ),
              padding: const EdgeInsets.symmetric(horizontal: 7,vertical: 7),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Diploma & Qualifications".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive,fontWeight: FontWeight.bold)),
                  SizedBox(height: _size!.height*0.01),
                  ListView.builder(
                    itemCount: controller.profileData!.diplomaDataList.length,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (context,index){
                      DiplomaData obj = controller.profileData!.diplomaDataList[index];
                    return Container(
                      padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 8),
                      margin:const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: AppColor.appThemeColorOlive.withOpacity(0.1),blurRadius: 1,spreadRadius: 1
                          )
                        ]
                      ),
                       child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                         Row(
                            children: [
                              Text("Certificate Name".tr() + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text(obj.nameOfCertificat!=null?obj.nameOfCertificat!:'',style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600))),
                            ],
                          ),
                          SizedBox(height: _size!.height*0.01),
                          Row(
                            children: [
                              Text("University Name".tr() + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text(obj.nameOfUniver!=null?obj.nameOfUniver!:'',style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600))),
                            ],
                          ),
                          SizedBox(height: _size!.height*0.01),
                          Row(
                            children: [
                              Text("Passing Year".tr() + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text(obj.passingYear!=null?obj.passingYear!:'',style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600))),
                            ],
                          ),
                          SizedBox(height: _size!.height*0.01),
                          Row(
                            children: [
                              Text("Attachment".tr() + " : ",style: AppTextStyles.k14TextN.copyWith(color: Colors.grey,fontWeight: FontWeight.w600)),
                              Expanded(child: Text("link".tr(),style: AppTextStyles.k14TextN.copyWith(color: Colors.blue,fontWeight: FontWeight.w600))),
                            ],
                          ),
                        ],
                       ),
                    );
                  }),
                ],
              ),
             ):Container(),
            //  about 
            //SizedBox(height: _size!.height*0.02),
           /* if(![null,""].contains(controller.profileData!.sirenOrSiretNo))
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: RowWtihText(title: "SIRET or SIREN NO".tr(),value: controller.profileData!.sirenOrSiretNo!,),
            ),

            SizedBox(height: _size!.height*0.01),
            if(![null,""].contains(controller.profileData!.rcsNo))
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: RowWtihText(title: "RCS NO".tr(),value: controller.profileData!.rcsNo!,),
            ),

            SizedBox(height: _size!.height*0.01),
            if(![null,""].contains(controller.profileData!.vat))
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: RowWtihText(title: "TVA(%)".tr(),value: controller.profileData!.vat!,),
            ),*/

            
            
            //
            SizedBox(height: _size!.height*0.03),
            
            // jobs categories
               
               Row(
            children: [
              if(controller.profileData!.category!=null && controller.profileData!.category!.length>0)
              Expanded(child: Container(
                height: _size!.height*0.15,
                padding: const EdgeInsets.symmetric(vertical: 5,horizontal: 8),
                margin: const EdgeInsets.only(left: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: AppColor.appThemeColorSky.withOpacity(0.2),
                ),
                child: Column(
                 mainAxisAlignment: MainAxisAlignment.center,
                 crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Categoriers".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorSky)),
                    const Divider(color: Colors.white),
                    Expanded(child: ListView.builder(
                      itemCount: controller.profileData!.category!.length,
                      itemBuilder: (context,index){
                        return                     Row(
                            children: [
                              const Icon(Icons.star,color: AppColor.appThemeColorSky),
                              const SizedBox(width: 5),
                              Text(controller.profileData!.category![index],style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorSky)),
              
                            ],
                          );
                      }
                      ))

                  ],
                ),
              ),),
              const SizedBox(width: 10),
              if(controller.profileData!.subcategory!=null && controller.profileData!.subcategory!.length>0)
              Expanded(child: Container(
                height: _size!.height*0.15,
                padding: const EdgeInsets.symmetric(vertical: 5,horizontal: 8),
                margin: const EdgeInsets.only(right: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: AppColor.appThemeColorSky.withOpacity(0.2),
                ),
                child: Column(
                 mainAxisAlignment: MainAxisAlignment.center,
                 crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("SubCategories".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorSky)),
                    const Divider(color: Colors.white),
                    Expanded(child: ListView.builder(
                      itemCount: controller.profileData!.subcategory!.length,
                      itemBuilder: (context,index){
                        return                     Row(
                            children: [
                              const Icon(Icons.star,color: AppColor.appThemeColorSky),
                              const SizedBox(width: 5),
                              Text(controller.profileData!.subcategory![index],style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorSky)),
              
                            ],
                          );
                      }
                      ))

                  ],
                ),
              ),),


            ],

               ),

               /* if(controller.profileData!.category!=null && controller.profileData!.category!.length>0)
             Container(
                height: _size!.height*0.15,
                width: _size!.width*0.6,
                padding: const EdgeInsets.symmetric(vertical: 5,horizontal: 8),
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: AppColor.appThemeColorSky.withOpacity(0.2),
                ),
                child: Column(
                 mainAxisAlignment: MainAxisAlignment.center,
                 crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Job Categoriers".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorSky)),
                    Divider(color: Colors.white),
                    Expanded(child: ListView.builder(
                      itemCount: controller.profileData!.category!.length,
                      itemBuilder: (context,index){
                        return                     Row(
                            children: [
                              Icon(Icons.star,color: AppColor.appThemeColorSky),
                              SizedBox(width: 5),
                              Text(controller.profileData!.category![index],style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorSky)),
              
                            ],
                          );
                      }
                      ))

                  ],
                ),
              ),*/

               if(![null,""].contains(controller.profileData!.workHistory!))
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Text("Work Knowledge".tr(),style: AppTextStyles.k18TextH),
            ),
             Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Text(controller.profileData!.workHistory!,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),),
            ),
              ],
            ),

            // work knowledge
               if(controller.profileData!.workImageList!=null && controller.profileData!.workImageList!.length>0)
               Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: _size!.height*0.01),
             Container(
              height: _size!.height*.15,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ListView.builder(
                itemCount: controller.profileData!.workImageList!.length,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context,index){
                 return InkWell(
                   onTap: (){
                     navigatetoAnotherPage(context, ImagePreviewScreen(path: controller.profileData!.workImageList![index],));
                   },
                   child: Container(
                                 height: _size!.height*0.15,
                                 width: _size!.width*0.3,
                         
                                 margin: const EdgeInsets.only(right: 10),
                                 decoration: BoxDecoration(
                                  border: Border.all(color: AppColor.appThemeColorGreen,width: 2),
                                  borderRadius: BorderRadius.circular(10),
                                 
                  
                                 ),
                                 child: ClipRRect(
                                     borderRadius: BorderRadius.circular(10),
                                  child: FadeImageWithError(imgPath: controller.profileData!.workImageList![index],)),
                               ),
                 );
              }),
            ),
            ],
               ),



             // work knowledge
            if(controller.profileData!.certificateImageList!=null && controller.profileData!.certificateImageList!.length>0)
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                  SizedBox(height: _size!.height*0.03),
              Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Text("Certificates".tr(),style: AppTextStyles.k18TextH),
            ),
            SizedBox(height: _size!.height*0.01),
             Container(
              height: _size!.height*.15,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ListView.builder(
                itemCount: controller.profileData!.certificateImageList!.length,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context,index){
                 return InkWell(
                   onTap: (){
                    navigatetoAnotherPage(context, ImagePreviewScreen(path: controller.profileData!.certificateImageList![index],));
                   },
                   child: Container(
                                 height: _size!.height*0.15,
                                 width: _size!.width*0.3,
                         
                                 margin: const EdgeInsets.only(right: 10),
                                 decoration: BoxDecoration(
                                  border: Border.all(color: AppColor.appThemeColorGreen,width: 2),
                                  borderRadius: BorderRadius.circular(10),
                                 
                  
                                 ),
                                 child: ClipRRect(
                                     borderRadius: BorderRadius.circular(10),
                                  child: FadeImageWithError(imgPath: controller.profileData!.certificateImageList![index],)),
                               ),
                 );
              }),
            ),
              ],
            ),
            
            
            //\ reviews
             /* SizedBox(height: _size!.height*0.03),
              Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12,vertical: 5),
              child: Text("REVIEWS ",style: AppTextStyles.k18TextH),
            ),
            SizedBox(height: _size!.height*0.01),
             Container(
              height: _size!.height*.2,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ListView.builder(
                itemCount: 3,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context,index){
                 return Container( 
                width: _size!.width*0.6,
                margin: const EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: AppColor.appThemeColorOrange,
                ),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    children: [
                      Row(
                                children: [
                                  CircleAvatar(
                                    radius: 24,
                                    backgroundColor: Colors.white,
                                    backgroundImage: AssetImage("assets/images/person.jpg"),
                                  ),
                                 const SizedBox(width: 20),
                                 Expanded(
                                   child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                     children: [
                                       Text("Courtney Henry",style: AppTextStyles.k14TextN,),
                                       Text("2 days ago",style: AppTextStyles.k12TextN,),
                                     ],
                                   ),
                                 ),
                                ],
                      ),
                         SizedBox(height: _size!.height*0.01),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(
                                 color: Colors.white,
                              borderRadius: BorderRadius.circular(6),
            
                            ),
                            child: Text("4.5",style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOrange),),
                          ),
                          SizedBox(width: 5),
                          RatingBar.builder(
                              initialRating:3,
                              minRating: 1,
                              direction: Axis.horizontal,
                              allowHalfRating: true,
                              itemCount: 5,
                               itemSize: 18,
                             itemBuilder: (context, _) => Icon(
                                   Icons.star,
                                   color: Colors.white,
                                  
                                   
                             ),
                             onRatingUpdate: (rating) {
                                 print(rating);
                              },
                          )
                        ],
                      ),
                      Divider(color: Colors.white),
                       Text("Very professional and knowledgeable. They were quick to schedule and showed up on time. ",
                             style: AppTextStyles.k12TextN.copyWith(color: Colors.white),
                             maxLines: 3,
                             ),
                    ],
                  ),
                ),
              );
              
              }),
            ),*/
             SizedBox(height: _size!.height*0.02),
                 controller.profileData!=null && (![null,""].contains(controller.profileData!.instagramLink) || ![null,""].contains(controller.profileData!.facebookLink) || ![null,""].contains(controller.profileData!.linkedinLink) || ![null,""].contains(controller.profileData!.twittrLink) )?
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                  padding: EdgeInsets.symmetric(vertical: 10,horizontal: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: AppColor.appThemeColorOrange,
                    boxShadow: [
                      BoxShadow(
                        color: AppColor.appThemeColorOlive.withOpacity(0.2),spreadRadius: 2,blurRadius: 2,
                      )
                    ]
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      if(controller.profileData!=null && ![null,""].contains(controller.profileData!.instagramLink))
                      InkWell(
                        onTap: ()async{
                          print(controller.profileData!.instagramLink);
                         await launchURL(controller.profileData!.instagramLink);
                        },
                        child: Container(
                          height: 40,width: 40,
                          child: Image.asset("assets/icons/instagram.png"),
                        ),
                      ),
                      if(controller.profileData!=null && ![null,""].contains(controller.profileData!.facebookLink))
                      InkWell(
                        onTap: ()async{
                          print(controller.profileData!.facebookLink);
                         await launchURL(controller.profileData!.facebookLink);
                        },
                        child: Container(
                          height: 40,width: 40,
                          child: Image.asset("assets/icons/facebook.png"),
                        ),
                      ),
                      if(controller.profileData!=null && ![null,""].contains(controller.profileData!.linkedinLink))
                      InkWell(
                        onTap: ()async{
                          print(controller.profileData!.linkedinLink);
                         await launchURL(controller.profileData!.linkedinLink);
                        },
                        child: Container(
                          height: 40,width: 40,
                          child: Image.asset("assets/icons/linkedin.png"),
                        ),
                      ),
                      if(controller.profileData!=null && ![null,""].contains(controller.profileData!.twittrLink))
                      InkWell(
                        onTap: ()async{
                          print(controller.profileData!.twittrLink);
                         await launchURL(controller.profileData!.twittrLink);
                        },
                        child: Container(
                          height: 40,width: 40,
                          child: Image.asset("assets/icons/twitter.png"),
                        ),
                      ),
                    ],
                  ),
                ):Container(),
                SizedBox(height: _size!.height*0.02),
              ],
            )
          ),
          controller.isLoading!?const CustomLoader(): Container(),
        ],
      ),
    );
    });
  }
  


}