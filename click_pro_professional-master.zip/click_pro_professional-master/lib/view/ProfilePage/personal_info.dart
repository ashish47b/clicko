import 'dart:convert';
import 'dart:io';


import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/CategoryModel/category_model.dart';
import 'package:clik_pro_professional/model/CityModel/city_model.dart';
import 'package:clik_pro_professional/model/ProfileDataModel/profile_data_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/BottomNavBar/bottomNavbar.dart';
import 'package:clik_pro_professional/widgets/image_preview.dart';
import 'package:clik_pro_professional/widgets/show_dialog.dart';
import 'package:dropdown_search/dropdown_search.dart';

import 'package:easy_localization/easy_localization.dart';
//import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:multi_select_flutter/bottom_sheet/multi_select_bottom_sheet_field.dart';
import 'package:multi_select_flutter/chip_display/multi_select_chip_display.dart';
import 'package:multi_select_flutter/util/multi_select_item.dart';
import 'package:multi_select_flutter/util/multi_select_list_type.dart';
import 'package:provider/provider.dart';

class AddPersonalScreen extends StatefulWidget {
  ProfileData? profileData;
  String?from;

  AddPersonalScreen({this.profileData,this.from});


  @override
  State<AddPersonalScreen> createState() => _AddPersonalScreenState();
}

class _AddPersonalScreenState extends State<AddPersonalScreen> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> addCategoryBox(myProvider!, 0));
    Future.delayed(Duration(milliseconds: 200),()=> addDiplomaBox(myProvider!, 0));
    Future.delayed(Duration(milliseconds: 200),()=> getData());
    myProvider = Provider.of<UserProvider>(context,listen: false);
    getProfileData();
    
  }

  getProfileData()async {
    if(widget.profileData!=null){
      firstNameController.text = ![null,""].contains(widget.profileData!.firstName)?widget.profileData!.firstName!:"";
      endNameController.text = ![null,""].contains(widget.profileData!.lastName)?widget.profileData!.lastName!:"";
      //selectGender = ![null,""].contains(widget.profileData!.gender)?widget.profileData!.gender:null;
      phoneController.text = ![null,""].contains(widget.profileData!.phone)?widget.profileData!.phone!:"";
      descrController.text = ![null,""].contains(widget.profileData!.description)?widget.profileData!.description!:"";
      websiteController.text = ![null,""].contains(widget.profileData!.website)?widget.profileData!.website!:"";
      siretNoController.text = ![null,""].contains(widget.profileData!.sirenOrSiretNo)?widget.profileData!.sirenOrSiretNo!:"";
      rcsNoController.text = ![null,""].contains(widget.profileData!.rcsNo)?widget.profileData!.rcsNo!:"";
      vatController.text = ![null,""].contains(widget.profileData!.vat)?widget.profileData!.vat!:"";
      workHistoryController.text = ![null,""].contains(widget.profileData!.workHistory)?widget.profileData!.workHistory!:"";
      instagramController.text = ![null,""].contains(widget.profileData!.instagramLink)?widget.profileData!.instagramLink!:"";
      facebookController.text = ![null,""].contains(widget.profileData!.facebookLink)?widget.profileData!.facebookLink!:"";
      twitterController.text = ![null,""].contains(widget.profileData!.twittrLink)?widget.profileData!.twittrLink!:"";
      linkedinController.text = ![null,""].contains(widget.profileData!.linkedinLink)?widget.profileData!.linkedinLink!:"";
      companyNameController.text = ![null,""].contains(widget.profileData!.companyName)?widget.profileData!.companyName!:"";
     // selectedCity!.id = ![null,""].contains(widget.profileData!.cityId)?widget.profileData!.cityId!:null;
     if(myProvider!.cityList !=null && myProvider!.cityList.length>0){
        if(widget.profileData!=null && ![null,""].contains(widget.profileData!.cityId)){
          myProvider!.cityList.forEach((element) {
            if(element.id!.compareTo(widget.profileData!.cityId!.trim())==0){
               selectedCity = element;
            }
          });
        }
     }

     if(myProvider!.cityList !=null && myProvider!.cityList.length>0){
        if(widget.profileData!=null && ![null,""].contains(widget.profileData!.proofAcceptTravelCity)){
          myProvider!.cityList.forEach((element) {
            if(element.id!.compareTo(widget.profileData!.proofAcceptTravelCity!.trim())==0){
               travelCity = element;
            }
          });
        }
     }

      if(genders!=null && genders.length>0){
        if(widget.profileData!=null && ![null,""].contains(widget.profileData!.gender)){
          genders.forEach((element) {
            if(element.toLowerCase().compareTo(widget.profileData!.gender!.trim().toLowerCase())==0){
              selectGender = element;
            }
          });
        }
      }


      
      // if(widget.profileData!.categoryDetailsList!.isNotEmpty){
      //    for(int i=0;i<widget.profileData!.categoryDetailsList!.length;i++){
      //      cardIndexValue = i;
      //      addCategoryBox(myProvider!, i);
      //      listCategory![i]!.id = widget.profileData!.categoryDetailsList![i].categoryId!;
      //      listSubCategory![i]!.id = widget.profileData!.categoryDetailsList![i].subcategoryId!;
      //    }
      // }

   /* if(myProvider!.categoryList!=null && myProvider!.categoryList.length>0){
        if(widget.profileData!=null && widget.profileData!.categoryDetailsList!.length>0){
          print("widget.profileData!.categoryDetailsList!"+widget.profileData!.categoryDetailsList!.length.toString());
          
          for(int i=0;i<widget.profileData!.categoryDetailsList!.length;i++){
            print("call me");
            cardIndexValue = i;
            addCategoryBox(myProvider!, i);
            listCategory!.add(null);
            listSubCategory!.add(null);
            myProvider!.categoryList.forEach((element) {
              print("widget.profileData!.categoryDetailsList![i].categoryId!" +widget.profileData!.categoryDetailsList![i].categoryId!);
              if(element.id!.compareTo(widget.profileData!.categoryDetailsList![i].categoryId!)==0){
                print("yes category");
                listCategory![i] = element;
              }
              if(element.id!.compareTo(widget.profileData!.categoryDetailsList![i].subcategoryId!)==0){
                listSubCategory![i] = element;
                print("yes category");
              }
            });
            // if(myProvider!.categoryList[i].id!.compareTo(widget.profileData!.categoryDetailsList![i].categoryId!)==0){
            //   listCategory![i] = myProvider!.categoryList[i];
            // }
            // if(myProvider!.categoryList[i].id!.compareTo(widget.profileData!.categoryDetailsList![i].subcategoryId!)==0){
            //   listSubCategory![i] = myProvider!.categoryList[i];
            // }
            
          }
        }
      }*/

    }
  }

  getData()async {
    await Provider.of<UserProvider>(context,listen: false).getCity();
    await Provider.of<UserProvider>(context,listen: false).getCategory();
    
  }



  UserProvider?myProvider;
   
  final firstNameController = TextEditingController(text: "");
  final endNameController = TextEditingController(text: "");
  final phoneController = TextEditingController(text: "");
  final websiteController = TextEditingController(text: "");
  final facebookController = TextEditingController(text: "");
  final instagramController = TextEditingController(text: "");
  final twitterController = TextEditingController(text: "");
  final linkedinController = TextEditingController(text: "");
  final descrController = TextEditingController(text: "");
  final siretNoController = TextEditingController(text: "");
  final rcsNoController = TextEditingController(text: "");
  final vatController = TextEditingController(text: "");
  final workHistoryController = TextEditingController(text: "");
  final companyNameController = TextEditingController(text: "");
  String?selectGender ;
  String?selectYear;
  CityData?selectedCity;
   CityData?travelCity;
  //CategoryData?selectCategory;
  List<Jobs> _selectedJob = [];
  CategoryData? selectCategory;
  CategoryData? selectSubCategory;
  var genders = [
    "MALE".tr(),
    "FEMALE".tr(),
    "OTHER".tr()
  ];

  var years = [
    "2000","2001","2002","2003","2004","2005"
  ];
  int cardIndexValue=1;
  int diplomaCardIndex=1;
  String?selectedImage;
  List<String>? certificateFile=[];
  String? identitySelectedImage;
  String?companyLogoSelected;
  List<String>? workDoneFiles=[];
  Future<bool> _onBackButtonPressed() async {
    bool request = await showDialog(
        context: context,
        builder: ((context) {
          return ShowDialogsss().exitDialog(context);
        }));

    return request;
  }
  Size?_size;
  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context,listen: false);
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return WillPopScope(
        onWillPop: (){
          return _onBackButtonPressed();
        },
        child: Scaffold(
          appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          automaticallyImplyLeading: false,
          leading:widget.from!=null? null : IconButton(onPressed: (){
            Navigator.pop(context);
          }, icon: Icon(Icons.arrow_back)),
          centerTitle: true,
          iconTheme:const IconThemeData(color: Colors.black),
          title: Text("MY PROFFESSIONAL".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black)),
          /*actions: [
            if(widget.from!=null)
            GestureDetector(
              onTap: (){
                navigatetoAnotherPage(context, BottomNavBar(0));
              },
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text("SKIP",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),),
              ))
          ],*/
        ),
        body: StatefulBuilder(builder: (context,myState){
          return ListView(
        padding:const EdgeInsets.symmetric(horizontal: 10,),
        children: [
          SizedBox(height: _size!.height*0.01),
         Container(
           padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: AppColor.appThemeColorOrange.withOpacity(0.3),
                  spreadRadius: 2,blurRadius: 2
                )
              ]
            ),
           child: Row(
            //mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
             children: [
              
               
               
               InkWell(
                onTap: ()async{
                  String?str = await pickedImage(context);
                  if(![null,""].contains(str)){
                    selectedImage = str;
                  }
                  myState(() {
                    
                  });
                },
                 child: Container(
                  height: 100,
                  width: 100,
                  decoration: BoxDecoration(
                    //.shape: BoxShape.circle,
                    border: Border.all(color:AppColor.appThemeColorOlive),
                    borderRadius: BorderRadius.circular(6)
                    //color: Colors.grey
                  ),
                  child:   ![null,""].contains(selectedImage) ? Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(color:AppColor.appThemeColorOlive),
                                      borderRadius: BorderRadius.circular(6),
                                      image: DecorationImage(image: FileImage(File(selectedImage!)), fit: BoxFit.fill)
                                    ),
                                    
                                  )
                                  :(![null,""].contains(widget.profileData!.profilePic)?Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(color:AppColor.appThemeColorOlive),
                                      borderRadius: BorderRadius.circular(6),
                                      image: DecorationImage(image: NetworkImage(widget.profileData!.profilePicPath! + widget.profileData!.profilePic!), fit: BoxFit.fill)
                                    ),
                                   ): 
                                   Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        const Center(child: Icon(Icons.camera_alt),),
                                        Text("Profile Pic".tr(),)
                                    ],
                                  ))
                 ),
              ),
              const SizedBox(width: 10),
               Expanded(
                 child: Column(
                  children: [
                    getTextFieldTextType("First Name".tr(), "First Name".tr(),radius: 10, controller: firstNameController),
                    const SizedBox(height: 10),
                    getTextFieldTextType("Last Name".tr(), "Last Name".tr(),radius: 10, controller: endNameController),
                  ],
                 ),
               )
             ],
           ),
         ),
          //SizedBox(height: _size!.height*0.02),
           /*  Row(
          children: [
            Expanded(child:  getTextFieldTextType("First Name".tr(), "First Name".tr(),radius: 10, controller: firstNameController)),   
            SizedBox(width: _size!.width*0.07),    
            Expanded(child:  getTextFieldTextType("Last Name".tr(), "Last Name".tr(),radius: 10, controller: endNameController)),
          ],
         ),*/
         SizedBox(height: _size!.height*0.02),
         Text("Personal Informations".tr(),style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange,fontWeight: FontWeight.bold)),
         SizedBox(height: _size!.height*0.02),
         Container(
          padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: AppColor.appThemeColorOrange.withOpacity(0.3),
                  spreadRadius: 2,blurRadius: 2
                )
              ]
            ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: _size!.height*0.02),
         Container(
          decoration: BoxDecoration(
            //border: Border.all(color: AppColor.appThemeColor,width: 1),
              borderRadius: BorderRadius.circular(10)
          ),
          padding:const EdgeInsets.all(1),
          child:  DropdownButtonFormField(
            decoration: InputDecoration(
                border:const OutlineInputBorder(
                  borderRadius:  BorderRadius.all(
                     Radius.circular(10.0),
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  borderSide:const BorderSide(
                    color: AppColor.appThemeColorOlive,
                    width: 1.0,
                  ),
                ),
                filled: true,
                //hintStyle: TextStyle(color: ),
                hintText:"Select Gender".tr(),
                hintStyle: const TextStyle(color: Colors.grey,fontSize: 14),
                contentPadding:const EdgeInsets.all(8.0),
                fillColor: Colors.grey.shade50),
            value: selectGender,
            onTap: (){
              FocusScope.of(context).requestFocus(FocusNode());
            },
            onChanged: (value) async{
              myState(() {
                selectGender = value!;
              });
            },
            items: genders
                .map((val) => DropdownMenuItem<String>(
                value: val,
                child: Padding(
                  padding:const EdgeInsets.all(2.0),
                  child: Text(val,style: const TextStyle(fontSize: 16),),
                )))
                .toList(),
          ),
        ),
      
         SizedBox(height: _size!.height*0.01),
          getTextFieldTextType("Enter Phone".tr(), "Enter Phone".tr(),radius: 10, controller:phoneController,textInputFormatter: [
          FilteringTextInputFormatter.digitsOnly,
          LengthLimitingTextInputFormatter(10),
         ], textInputType: TextInputType.number),
      
          SizedBox(height: _size!.height*0.015),
          Container(
            padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: AppColor.appThemeColorOlive.withOpacity(0.1),
                  spreadRadius: 2,blurRadius: 2
                )
              ]
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              //mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Identity of Evidence".tr(),style: AppTextStyles.k16TextN),
                    InkWell(
                  onTap: ()async{
                   String?str = await pickedImage(context);
                   if(![null,""].contains(str)){
                      identitySelectedImage = str;
                   }
                   myState(() {
                     
                   });
                  },
                  child: Container(
                   padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColor.appThemeColorOlive,
                      border: Border.all(color:AppColor.appThemeColorOlive),
                    ),
                    child: const Icon(Icons.add_circle_outline_outlined, color: Colors.white,),
                  ),
                ),
                  ],
                ),
                ![null,""].contains(identitySelectedImage) ?
                Container(
                  height: 80,
                  width: 80,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColor.appThemeColorOlive),
                    image: DecorationImage(image: FileImage(File(identitySelectedImage!)),fit: BoxFit.fill)
                  ),
                ) : (![null,""].contains(widget.profileData!.idProofAttachment)? InkWell(
                  onTap: (){
                    navigatetoAnotherPage(context, ImagePreviewScreen(path: widget.profileData!.idProofAttachment!));
                  },
                  child: Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColor.appThemeColorOlive),
                      image: DecorationImage(image: NetworkImage(widget.profileData!.idProofAttachment!),fit: BoxFit.fill)
                    ),
                  ),
                ) : Container())
              ],
             ),
          ),
          SizedBox(height: _size!.height*0.015),
      
          getTextFromFieldTextType("Enter Description".tr(),"Enter Description".tr(),maxLines: 5, controller: descrController),
          SizedBox(height: _size!.height*0.01),
          Text("Select City".tr(), style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive)),
          SizedBox(height: _size!.height*0.005),
          Container(
            padding: const EdgeInsets.all(1),
            decoration: BoxDecoration(
              border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
                borderRadius: BorderRadius.circular(16)
            ),
           
            child:  DropdownSearch<CityData>(
                          //asyncItems: (String filter) => getData(filter),
                          itemAsString: (CityData? u) => u!.cityName!,
                          items: model.cityList,
                          dropdownButtonProps: const DropdownButtonProps(
      
                          ),
                          dropdownDecoratorProps:  DropDownDecoratorProps(
                            dropdownSearchDecoration: InputDecoration(hintText: "Select City".tr(), border: InputBorder.none)
                          ),
                          popupProps:  PopupProps.dialog(
                          showSearchBox: true,
                        //  showSelectedItems: true,
                            title: Text("Select City".tr()),
                        ),selectedItem:selectedCity ,
      
                           onChanged: (CityData? data) async {
                            myState(() {
                              selectedCity = data!;
                            });
                          },
                          onSaved: (data){
                            print("hi");
                          },
                        ),
           ),
      
          SizedBox(height: _size!.height*0.015),
          Text("Select City Where You Travel".tr(), style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive)),
          SizedBox(height: _size!.height*0.005),
          Container(
            padding: const EdgeInsets.all(1),
            decoration: BoxDecoration(
              border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
                borderRadius: BorderRadius.circular(16)
            ),
           
            child:  DropdownSearch<CityData>(
                          //asyncItems: (String filter) => getData(filter),
                          itemAsString: (CityData? u) => u!.cityName!,
                          items: model.cityList,
                          dropdownButtonProps: const DropdownButtonProps(
      
                          ),
                          dropdownDecoratorProps:  DropDownDecoratorProps(
                            dropdownSearchDecoration: InputDecoration(hintText: "Select City".tr(), border: InputBorder.none)
                          ),
                          popupProps:  PopupProps.dialog(
                          showSearchBox: true,
                        //  showSelectedItems: true,
                            title: Text("Select City".tr()),
                        ),selectedItem:travelCity ,
      
                           onChanged: (CityData? data) async {
                            myState(() {
                              travelCity= data!;
                            });
                          },
                          onSaved: (data){
                            print("hi");
                          },
                        ),
          ),
      
            SizedBox(height: _size!.height*0.015),
           
            SizedBox(height: _size!.height*0.015),
            Container(
               padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: AppColor.appThemeColorOlive.withOpacity(0.1),
                      spreadRadius: 2,blurRadius: 2
                    )
                  ]
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                      Text("Social Profile".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                      SizedBox(height: _size!.height*0.015),
                      getTextFieldTextType("Website".tr(), "Website".tr(),controller: websiteController,radius: 10),
                      SizedBox(height: _size!.height*0.01),
                      getTextFieldTextType("Linkedin".tr(), "Linkedin".tr(),controller: linkedinController,radius: 10),
                      SizedBox(height: _size!.height*0.01),
                      getTextFieldTextType("Facebook".tr(), "Facebook".tr(),controller: facebookController,radius: 10),
                      SizedBox(height: _size!.height*0.01),
                      getTextFieldTextType("Instagram".tr(), "Instagram".tr(),controller: instagramController,radius: 10),
                      SizedBox(height: _size!.height*0.01),
                      getTextFieldTextType("Twitter".tr(), "Twitter".tr(),controller: twitterController,radius: 10),
                  ],
                ),
            ),
            SizedBox(height: _size!.height*0.02),
            Text("Category Details".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.black,fontWeight: FontWeight.bold)),
            //addCategoryBox(model),
            ListView.builder(
              shrinkWrap: true,
              physics:const NeverScrollableScrollPhysics(),
              itemCount: widgets.length,
              itemBuilder: (context,index){
               return widgets[index];
            }),
      
            Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                    ElevatedButton(onPressed: (){
                      for(int i=0;i<widgets.length;i++){
                        if(listCategory![i]==null && listSubCategory![i] == null){
                          showToastMsg("Please Fill Details".tr());
                          return;
                        }
                      }
                     myState(() {
                       addCategoryBox(model,cardIndexValue);
                       cardIndexValue++;
                     });
                      
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColor.appThemeColorOlive
                    ),
                    child: Text("ADD".tr())
                    )
                ],),
            ],
          ),
         ),
      
         SizedBox(height: _size!.height*0.02),
         Text("Professional Information".tr(),style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOrange,fontWeight: FontWeight.bold)),
         SizedBox(height: _size!.height*0.02),
         Container(
          padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: AppColor.appThemeColorOrange.withOpacity(0.3),
                  spreadRadius: 2,blurRadius: 2
                )
              ]
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: _size!.height*0.02),
                getTextFromFieldTextType("Cover Letter".tr(), "Cover Letter".tr(),controller: workHistoryController, maxLines: 4,radius: 10),
                SizedBox(height: _size!.height*0.02),
                Container(
                  padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: AppColor.appThemeColorOlive.withOpacity(0.1),
                        spreadRadius: 2,blurRadius: 2
                      )
                    ]
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Certificates".tr(),style: AppTextStyles.k16TextN),
                           InkWell(
                        onTap: ()async{
                        String?str = await pickedImage(context);
                        if(![null,""].contains(str)){
                            certificateFile!.add(str!);
                            print("Length certificate " + certificateFile!.length.toString());
                        }
                        myState(() {
                          
                        });
                        },
                          child: Container(
                          padding: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColor.appThemeColorOlive,
                              border: Border.all(color:AppColor.appThemeColorOlive),
                            ),
                            child: const Icon(Icons.add_circle_outline_outlined, color: Colors.white,),
                          ),
                         ),
                        ],
                      ),
                          certificateFile!=null && certificateFile!.length>0?Container(
                              height: 70,
                              child: ListView.builder(
                                itemCount: certificateFile!.length,
                                scrollDirection: Axis.horizontal,
                                shrinkWrap: true,
                                itemBuilder: (context,index){
                                return Container(
                                  
                                  width: 70,
                                  height: 60,
                                  margin:const EdgeInsets.only(right: 10,top: 8),
                                  decoration: BoxDecoration(
                                    //color: Colors.red,
                                    borderRadius: BorderRadius.circular(8),
                                    image: DecorationImage(image: FileImage(File(certificateFile![index])),fit: BoxFit.fill)
                                  ),
                                );
                              }),
                            ):(widget.profileData!.certificateImageList!=null && widget.profileData!.certificateImageList!.length>0?Container(
                              height: 70,
                              child: ListView.builder(
                                itemCount: widget.profileData!.certificateImageList!.length,
                                scrollDirection: Axis.horizontal,
                                shrinkWrap: true,
                                itemBuilder: (context,index){
                                return InkWell(
                                  onTap: (){
                                      navigatetoAnotherPage(context, ImagePreviewScreen(path: widget.profileData!.certificateImageList![index]));
                                    },
                                  child: Container(
                                    width: 70,
                                    height: 60,
                                    margin:const EdgeInsets.only(right: 10,top: 8),
                                    decoration: BoxDecoration(
                                      //color: Colors.red,
                                      borderRadius: BorderRadius.circular(8),
                                      image: DecorationImage(image: NetworkImage(widget.profileData!.certificateImageList![index]),fit: BoxFit.fill)
                                    ),
                                  ),
                                );
                              }),
                            ): Container())
                    ],
                  ),
                ),
      
      
                
                SizedBox(height: _size!.height*0.02),
                getTextFieldTextType("SIREN or SIRET NO".tr(), "SIREN or SIRET NO".tr(), radius: 10,controller: siretNoController),
              SizedBox(height: _size!.height*0.01),
                getTextFieldTextType("RCS No".tr(), "RCS No".tr(), radius: 10,controller: rcsNoController),
                SizedBox(height: _size!.height*0.01),
                getTextFieldTextType("TVA(%)".tr(), "TVA(%)".tr(), radius: 10,controller: vatController, textInputType: TextInputType.number,textInputFormatter: [
                  FilteringTextInputFormatter.digitsOnly,
                ]),
                SizedBox(height: _size!.height*0.02),
                Center(child: Text("Diplomas & Qualifications".tr(),style: AppTextStyles.k16TextN)),
                SizedBox(height: _size!.height*0.02),
                ListView.builder(
                    shrinkWrap: true,
                    physics:const NeverScrollableScrollPhysics(),
                    itemCount: diplomawidgets.length,
                    itemBuilder: (context,index){
                    return diplomawidgets[index];
                  }),
      
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                    ElevatedButton(onPressed: (){
                      for(int i=0;i<diplomawidgets.length;i++){
                        if(diplomaCertificateController![i]!.text.isEmpty && diplomaUnviersityController![i]!.text.isEmpty && yearsList![i]==null){
                          showToastMsg("Please Fill Details".tr());
                          return;
                        }
                      }
                     myState(() {
                       addDiplomaBox(model,diplomaCardIndex);
                       diplomaCardIndex++;
                     });
                      
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColor.appThemeColorOlive
                    ),
                    child: Text("ADD".tr())
                    )
                ],),
                SizedBox(height: _size!.height*0.02),
                Container(
                  padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: AppColor.appThemeColorOlive.withOpacity(0.1),
                        spreadRadius: 2,blurRadius: 2
                      )
                    ]
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(child: Text("Company Details".tr(),style: AppTextStyles.k16TextN)),
                      SizedBox(height: _size!.height*0.01),
                      getTextFieldTextType("Company Name".tr(), "Company Name".tr(),radius: 10,controller: companyNameController),
                      SizedBox(height: _size!.height*0.01),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Company Logo".tr(),style: AppTextStyles.k16TextN),
                          InkWell(
                            onTap: ()async{
                            String?str = await pickedImage(context);
                            if(![null,""].contains(str)){
                                companyLogoSelected = str;
                            }
                            myState(() {
                              
                            });
                            },
                            child: Container(
                              padding: const EdgeInsets.all(3),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColor.appThemeColorOlive,
                                  border: Border.all(color:AppColor.appThemeColorOlive),
                                ),
                                child: const Icon(Icons.add_circle_outline_outlined, color: Colors.white,),
                              ),
                          ),
                        ],
                      ),
                      
                      SizedBox(height: _size!.height*0.01),
                      companyLogoSelected!=null?
                      Container(
                        height: 70,
                        width: 70,
                        decoration: BoxDecoration(
                          border: Border.all(color: AppColor.appThemeColorOlive),
                          borderRadius: BorderRadius.circular(10),
                          image: DecorationImage(image: FileImage(File(companyLogoSelected!)),fit: BoxFit.fill)
                        ),
                      ):(![null,""].contains(widget.profileData!.companyLogo)?Container(
                        height: 70,
                        width: 70,
                        decoration: BoxDecoration(
                          border: Border.all(color: AppColor.appThemeColorOlive.withOpacity(0.3)),
                          borderRadius: BorderRadius.circular(10),
                          image: DecorationImage(image: NetworkImage(widget.profileData!.companyLogoPath! + widget.profileData!.companyLogo!),fit: BoxFit.fill)
                        ),
                      ) : Container())
                    ],
                  ),
                ),
                SizedBox(height: _size!.height*0.02),
                Container(
                  padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: AppColor.appThemeColorOlive.withOpacity(0.1),
                        spreadRadius: 2,blurRadius: 2
                      )
                    ]
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        color: AppColor.appThemeColorOlive.withOpacity(0.2),
                        child: Center(child: Text("Add Work Files".tr(),style: AppTextStyles.k16TextN))),
      
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Add Files".tr(),style: AppTextStyles.k16TextN),
                        InkWell(
                        onTap: ()async{
                        String?str = await pickedImage(context);
                        if(![null,""].contains(str)){
                            workDoneFiles!.add(str!);
                            print("Length workDoneFiles " + workDoneFiles!.length.toString());
                        }
                        myState(() {
                          
                        });
                        },
                        child: Container(
                              padding: const EdgeInsets.all(3),
                              decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColor.appThemeColorOlive,
                              border: Border.all(color:AppColor.appThemeColorOlive),
                            ),
                            child: const Icon(Icons.add_circle_outline_outlined, color: Colors.white,),
                          ),
                      ),
                      ],
                    ),
                      
                      SizedBox(height: _size!.height*0.01),
                        workDoneFiles!=null && workDoneFiles!.length>0?  Container(
                            height: 70,
                            child: ListView.builder(
                              itemCount: workDoneFiles!.length,
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              itemBuilder: (context,index){
                              return Container(
                                width: 70,
                                height: 60,
                                margin:const EdgeInsets.only(right: 10),
                                decoration: BoxDecoration(
                                  //color: Colors.red,
                                  borderRadius: BorderRadius.circular(8),
                                  image: DecorationImage(image: FileImage(File(workDoneFiles![index])),fit: BoxFit.fill)
                                ),
                              );
                            }),
                          ):(widget.profileData!.workImageList!=null && widget.profileData!.workImageList!.length>0?
                            Container(
                            height: 70,
                            child: ListView.builder(
                              itemCount: widget.profileData!.workImageList!.length,
                              scrollDirection: Axis.horizontal,
                              shrinkWrap: true,
                              itemBuilder: (context,index){
                              return InkWell(
                                onTap: (){
                                      navigatetoAnotherPage(context, ImagePreviewScreen(path: widget.profileData!.workImageList![index]));
                                    },
                                child: Container(
                                  width: 70,
                                  height: 60,
                                  margin:const EdgeInsets.only(right: 10),
                                  decoration: BoxDecoration(
                                    //color: Colors.red,
                                    borderRadius: BorderRadius.circular(8),
                                    image: DecorationImage(image: NetworkImage(widget.profileData!.workImageList![index]),fit: BoxFit.fill)
                                  ),
                                ),
                              );
                            }),
                          )
                          : Container()),
                    ],
                  ),
                ),
      
            
              ],
            ),
          ),
      
          
      
           InkWell(
            onTap: (){
              saveData(model);
            },
            child: Container(
            height: 45,
            margin:const EdgeInsets.symmetric( vertical: 10),
            decoration: BoxDecoration(
              color: AppColor.appThemeColorOlive,
              borderRadius: BorderRadius.circular(12)
            ),
            child: Center(
              child: Text("Submit".tr(),style: AppTextStyles.k18TextN.copyWith(color: Colors.white),),
            ),
                ),
          ),
        ],
          );
        })
        ),
      );
      

    });
  }


List<Widget> widgets = [];
List<CategoryData?>? listCategory = [];
List<CategoryData?>? listSubCategory = [];
  
  addCategoryBox(UserProvider model,int index){
   List<Widget> list = [];
   listCategory!.add(null);
   listSubCategory!.add(null);

   list.add(
    Container(
      margin:const EdgeInsets.symmetric(vertical: 5),
      padding:const EdgeInsets.symmetric(horizontal: 6,vertical: 6),
      decoration: BoxDecoration(
       border: Border.all(color: AppColor.appThemeColorOlive),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Container(
          padding: const EdgeInsets.all(1),
          margin:const EdgeInsets.only(bottom: 10),
          decoration: BoxDecoration(
            border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
              borderRadius: BorderRadius.circular(16)
          ), 
          child: DropdownSearch<CategoryData>(
                  //asyncItems: (String filter) => getData(filter),
                  itemAsString: (CategoryData? u) => u!.categoryName!,
                  items: model.categoryList,
                  dropdownButtonProps:  DropdownButtonProps(

                  ),
                  dropdownDecoratorProps:  DropDownDecoratorProps(
                    dropdownSearchDecoration: InputDecoration(hintText: "Job Category".tr(), border: InputBorder.none)
                  ),
                  popupProps:  PopupProps.dialog(
                  showSearchBox: true,
                //  showSelectedItems: true,
                    title: Text("Job Category".tr()),
                ),selectedItem:listCategory![index],

                    onChanged: (CategoryData? data) async {
                    setState(() {
                      listCategory![index]= data!;
                    });
                  },
                  onSaved: (data){
                    print("hi");
                  },
           ),
        ),
         //SizedBox(height: _size!.height*0.01),
          Container(
          padding: const EdgeInsets.all(1),
          decoration: BoxDecoration(
            border: Border.all(color: AppColor.appThemeColorOlive,width: 1),
              borderRadius: BorderRadius.circular(16)
          ), 
          child: DropdownSearch<CategoryData>(
                  //asyncItems: (String filter) => getData(filter),
                  itemAsString: (CategoryData? u) => u!.categoryName!,
                  items: model.categoryList,
                  dropdownButtonProps: const DropdownButtonProps(

                  ),
                  dropdownDecoratorProps:  DropDownDecoratorProps(
                    dropdownSearchDecoration: InputDecoration(hintText: "Job Sub Category".tr(), border: InputBorder.none)
                  ),
                  popupProps:  PopupProps.dialog(
                  showSearchBox: true,
                //  showSelectedItems: true,
                    title: Text("Job Sub Category".tr()),
                ),selectedItem:listSubCategory![index],

                    onChanged: (CategoryData? data) async {
                    setState(() {
                      listSubCategory![index]= data!;
                    });
                  },
                  onSaved: (data){
                    print("hi");
                  },
           ),
        ),
        ],),
    )
   );
  widgets.addAll(list);
  setState(() {
    
  });
    
  }

  List<Widget> diplomawidgets = [];
  List<TextEditingController?>? diplomaCertificateController = [];
  List<TextEditingController?>? diplomaUnviersityController = [];
  List<String?>? yearsList = [];
  List<String?>? diploma_AttachmentList = [];

  addDiplomaBox(UserProvider model, int index){
    List<Widget> list =[];
    diplomaCertificateController!.add(TextEditingController(text: ""));
    diplomaUnviersityController!.add(TextEditingController(text: ""));
    yearsList!.add(null);
    diploma_AttachmentList!.add(null);

    list.add(
      Container(
        padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
              color: AppColor.appThemeColorOlive.withOpacity(0.3),
              spreadRadius: 2,blurRadius: 2
            )
          ]
        ),
        child: Column(
          children: [
             getTextFieldTextType("Certificate Name".tr(), "Certificate Name".tr(),controller: diplomaCertificateController![index],radius: 10),
             SizedBox(height: _size!.height*0.01),
             getTextFieldTextType("University Name".tr(), "University Name".tr(),controller: diplomaCertificateController![index],radius: 10),
             SizedBox(height: _size!.height*0.015),
             Container(
                decoration: BoxDecoration(
                  //border: Border.all(color: AppColor.appThemeColor,width: 1),
                    borderRadius: BorderRadius.circular(10)
                ),
                padding:const EdgeInsets.all(1),
                child:  DropdownButtonFormField(
                  decoration: InputDecoration(
                      border:const OutlineInputBorder(
                        borderRadius:  BorderRadius.all(
                          Radius.circular(10.0),
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide:const BorderSide(
                          color: AppColor.appThemeColorOlive,
                          width: 1.0,
                        ),
                      ),
                      filled: true,
                      //hintStyle: TextStyle(color: ),
                      hintText:"Select year".tr(),
                      hintStyle: const TextStyle(color: Colors.grey,fontSize: 14),
                      contentPadding:const EdgeInsets.all(8.0),
                      fillColor: Colors.grey.shade50),
                  value: selectYear,
                  onTap: (){
                    FocusScope.of(context).requestFocus(FocusNode());
                  },
                  onChanged: (value) async{
                    setState(() {
                      selectYear = value!;
                    });
                  },
                  items: years
                      .map((val) => DropdownMenuItem<String>(
                      value: val,
                      child: Padding(
                        padding:const EdgeInsets.all(2.0),
                        child: Text(val,style: const TextStyle(fontSize: 16),),
                      )))
                      .toList(),
                ),
              ),
              SizedBox(height: _size!.height*0.01),
              InkWell(
                onTap: ()async{
                 String? str = await pickedImage(context);
                 if(![null,""].contains(str)){
                  diploma_AttachmentList![index] = str;
                  setState(() {
                    
                  });
                 }
                },
                child: Container(
                  padding:const EdgeInsets.symmetric(vertical: 5),
                  decoration: BoxDecoration(
                     border: Border.all(color: AppColor.appThemeColorOlive),
                     borderRadius: BorderRadius.circular(10)
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.add, color: AppColor.appThemeColorOlive),
                      Text("Add Attachments".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                    ],
                  ),
                ),
              ),
              SizedBox(height: _size!.height*0.01),
              diploma_AttachmentList![index]!=null?
             Container(
              height: 70,width: 70,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                image: DecorationImage(image: FileImage(File(diploma_AttachmentList![index]!)),fit: BoxFit.fill)
              ),
             ):Container()
          ],
        ),
      )
    );

   diplomawidgets.addAll(list);
   setState(() {
     
   });  
  
  }
 

 saveData(UserProvider model)async {
  if(firstNameController.text.isEmpty){
    return showToastMsg("Enter First Name".tr());
  }

  if(endNameController.text.isEmpty){
    return showToastMsg("Enter Last Name".tr());
  }
  
  if(selectGender==null){
    return showToastMsg("Please Select Gender".tr());
  }

  if(phoneController.text.isEmpty){
    return showToastMsg("Please Enter Phone Number".tr());
  }


  if(selectedCity==null){
    return showToastMsg("Please Select City".tr());
  }
    
  List<CategoryDetails> userCategoryDetails = [];
  for(int i=0; i<widgets.length;i++){
    if(listCategory![i]!=null && listSubCategory![i]!=null){
      CategoryDetails obj = CategoryDetails(
        categoryId: listCategory![i]!.id,
        subcategoryId: listSubCategory![i]!.id,
      );
      print(obj);
      userCategoryDetails.add(obj);
    } else{
      showToastMsg("Enter Category Details".tr());
    }
  }

  List<DiplomaData> userDiplomaList = [];
  for(int i=0;i<diplomawidgets.length;i++){
    if(diplomaCertificateController![i]!.text.isNotEmpty && diplomaUnviersityController![i]!.text.isNotEmpty && yearsList![i]!.isNotEmpty){
      DiplomaData dipObj = DiplomaData(
        certiId: i,
        nameOfCertificat: diplomaCertificateController![i]!.text,
        nameOfUniver: diplomaUnviersityController![i]!.text,
        passingYear: yearsList![i]!,
        eduCertificate: diploma_AttachmentList!=null && diploma_AttachmentList!.length>0? diploma_AttachmentList![i]!:"",
        
      );
      print(dipObj);
      userDiplomaList.add(dipObj);
    }else{
      showToastMsg("Enter Diploma Details");
    }
  }

  print(jsonEncode(userCategoryDetails));
 

  SavePorfileData obj = SavePorfileData(
    firstName: firstNameController.text,
    lastName: endNameController.text,
    gender: selectGender,
    phoneNumber: phoneController.text,
    city_id: selectedCity!.id,
    website: websiteController.text.isNotEmpty?websiteController.text:"",
    categoryDetailsList: userCategoryDetails.isNotEmpty?userCategoryDetails:[],
    siren_or_siret_no: siretNoController.text.isNotEmpty?siretNoController.text:"",
    rcs_no: rcsNoController.text.isNotEmpty?rcsNoController.text:"",
    description: descrController.text.isNotEmpty?descrController.text:"",
    proof_accept_travel_city: travelCity!=null?travelCity!.id:null,
    vat: vatController.text.isNotEmpty?vatController.text:"",
    work_history: workHistoryController.text.isNotEmpty?workHistoryController.text:"",
    profile_pic: selectedImage!=null?selectedImage:"",
    certificateList: certificateFile!.isNotEmpty?certificateFile!:[],
    previous_work_done_file: workDoneFiles!.isNotEmpty?workDoneFiles!:[],
    companYdetails: [],
  );

   
  
 await model.saveProfile(context, obj,from: widget.from!=null? "start":"");


 }
}


class SavePorfileData{
  String? firstName;
  String? lastName;
  String? phoneNumber;
  String?gender;
  String?city_id;
  String?description;
  String?proof_accept_travel_city;
  String?website;
  String?work_history;
  String?siren_or_siret_no;
  String?rcs_no;
  String?vat;
  List<CategoryDetails>? categoryDetailsList = [];
  List<CompanyDetails>? companYdetails=[];
  String?profile_pic;
  List<String>?certificateList=[];
  List<String>?previous_work_done_file=[];


  SavePorfileData({this.categoryDetailsList,this.certificateList,this.city_id,this.companYdetails,this.description,this.firstName,this.gender,this.lastName,this.phoneNumber,this.previous_work_done_file,this.profile_pic,this.proof_accept_travel_city,this.rcs_no,this.siren_or_siret_no,this.vat,this.website,this.work_history});
}


class CategoryDetails {
  String? categoryId;
  String? subcategoryId;

  CategoryDetails({this.categoryId, this.subcategoryId});

  CategoryDetails.fromJson(Map<String, dynamic> json) {
    categoryId = json['category_id'];
    subcategoryId = json['subcategory_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['category_id'] = this.categoryId;
    data['subcategory_id'] = this.subcategoryId;
    return data;
  }
}

class CompanyDetails{
  
}





