import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AddProfessionalInfo extends StatefulWidget {
  const AddProfessionalInfo({super.key});

  @override
  State<AddProfessionalInfo> createState() => _AddProfessionalInfoState();
}

class _AddProfessionalInfoState extends State<AddProfessionalInfo> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return ListView(
        padding:const EdgeInsets.symmetric(horizontal: 14),
      children: [
         SizedBox(height: _size!.height*0.04),
         getTextFromFieldTextType("Add Work History".tr(), "Add Work History".tr(), maxLines: 4,radius: 10),
         SizedBox(height: _size!.height*0.02),
         Row(
          children: [
            Text("Certificates".tr(),style: AppTextStyles.k16TextN),
           const SizedBox(width: 20),
            Expanded(
              child: Container(
               padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 10),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.add_circle_outline_outlined, color: Colors.grey,),
                    const SizedBox(width: 6),
                    Text("Add Files".tr(),style: AppTextStyles.k14TextN,),
                  ],
                ),
              ),
            )
          ],
         ),
        
        SizedBox(height: _size!.height*0.02),
        getTextFieldTextType("SIREN or SIRET NO", "SIREN or SIRET NO", radius: 10),
       SizedBox(height: _size!.height*0.01),
        getTextFieldTextType("RCS No", "RCS No", radius: 10),
        SizedBox(height: _size!.height*0.01),
        getTextFieldTextType("TVA(%)", "TVA(%)", radius: 10,textInputType: TextInputType.number,textInputFormatter: [
          FilteringTextInputFormatter.digitsOnly,
        ]),

      ],
    );
  }
}