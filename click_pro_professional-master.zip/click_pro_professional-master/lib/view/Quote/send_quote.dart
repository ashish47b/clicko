import 'dart:convert';

import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/MaterialModel/material_Model.dart';
import 'package:clik_pro_professional/model/QuoteModel/quote_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

class SendQuote extends StatefulWidget {
String?job_id;
String?cust_id;
String?customer_budget;
QuoteData?obj;

SendQuote({this.job_id,this.obj,this.customer_budget,this.cust_id});

  @override
  State<SendQuote> createState() => _SendQuoteState();
}

class _SendQuoteState extends State<SendQuote> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 400),()=> getData());
    Future.delayed(const Duration(milliseconds: 400)).whenComplete(() => setData());
    if(widget.customer_budget!=null){
      customerBudgetController.text = widget.customer_budget!;
    }
  }
  getData()async {
    await Provider.of<UserProvider>(context,listen: false).profileList();
    coverController.text = myProvider!.profileData!=null && myProvider!.profileData!.description!=null? myProvider!.profileData!.description!:"";
  }
  setData(){
    if(widget.obj!=null){
      estimatedAmountController.text = widget.obj!.estimatePrice!;
      estimatedTimeController.text = widget.obj!.estimateProjectTime!;
      coverController.text = widget.obj!.coverDescription!;
      commentsController.text = widget.obj!.comment!;
      currentTime = DateTime.parse(widget.obj!.workStartDate!);
      endDate = DateTime.parse(widget.obj!.workEndDate!);
      dateSet = true;
      if(![null,""].contains(widget.obj!.instalmentPlan!)) {
        //selectRadio = int.parse(widget.obj!.instalmentPlan!);
      }
      print(currentTime);
      print(selectRadio);
      if(widget.obj!.userMaterialModelList.isNotEmpty){
        isChecked = true;
        for(int i=0;i<widget.obj!.userMaterialModelList.length;i++){
          currentMatIndex = i;
          addaterialProducts(i,viaData: true);
          materialNameController[i].text = widget.obj!.userMaterialModelList[i].materialName!;
          qtyController[i].text = widget.obj!.userMaterialModelList[i].materialQty!;
          unitController[i].text = widget.obj!.userMaterialModelList[i].unit!;
          priceController[i].text = widget.obj!.userMaterialModelList[i].unitPrice!;
          vatController[i].text = widget.obj!.userMaterialModelList[i].tax!;
          totalVatController[i].text = widget.obj!.userMaterialModelList[i].taxAmount!;
          totalPriceController[i].text = widget.obj!.userMaterialModelList[i].subTotal!;
        }
        calculateTaxes();
      }

      myStateSetter!(() {

      });
    } else {
      Future.delayed(const Duration(milliseconds: 400)).whenComplete(() => addaterialProducts(currentMatIndex));
    }
  }

  final estimatedAmountController = TextEditingController(text: "");
  final estimatedTimeController = TextEditingController(text: "");
  final customerBudgetController = TextEditingController(text: "");
  final coverController = TextEditingController(text: "");
  final endDateController = TextEditingController(text: "");
   final commentsController = TextEditingController(text: "");
   String?selectPlanValue;

   bool?isChecked=false;
   UserProvider?myProvider;
  Size?_size;
  StateSetter?myStateSetter;
  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context,listen: false);
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,model,child){
      return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme:const IconThemeData(color: Colors.black),
        title: Text("Quote Submission Form".tr(),style: AppTextStyles.k18TextN.copyWith(color: Colors.black),),
      ),
      body: StatefulBuilder(builder: (context,myState){
        myStateSetter = myState;
        return Stack(
          children: [
            ListView(
              
            padding: const EdgeInsets.symmetric(horizontal: 10),
            children: [
              SizedBox(height: _size!.height*0.003),
              getTextFieldTextType("Customer Budget", "Customer Budget", controller:customerBudgetController),
              SizedBox(height: _size!.height*0.01),
              getTextFieldTextType("Estimated Price".tr(),"Estimated Price".tr(),
              textInputType: TextInputType.number,
              controller: estimatedAmountController,
               textInputFormatter: [
                FilteringTextInputFormatter.digitsOnly
               ],
               callbackFunction: (){
                if(estimatedAmountController.text.isNotEmpty){
                  if(double.parse(estimatedAmountController.text)>double.parse(customerBudgetController.text)){
                    showToastMsg("Estimate Price should be less than or equal to the Customer Budget");
                    estimatedAmountController.clear();
                  }
                }
                
               },
               prefix: Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Text("€",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
              )),
              SizedBox(height: _size!.height*0.01),
              getTextFieldTextType("Estimated Time(Days)".tr(),"Estimated Time(Days)".tr(),controller: estimatedTimeController,
              textInputFormatter: [
                FilteringTextInputFormatter.digitsOnly
              ],
              textInputType: TextInputType.number,
              ),
              SizedBox(height: _size!.height*0.01),
              getTextFromFieldTextType("Cover Letter".tr(), "Cover Letter".tr(),controller: coverController, maxLines: 6),
              SizedBox(height: _size!.height*0.01),
             // Text("Select(*)",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
              Text("Chosse Installment Plan",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
              
              SizedBox(height: _size!.height*0.01),
              Container(
                padding:const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColor.appThemeColorOlive),
                  borderRadius: BorderRadius.circular(8)
                ),
                child: DropdownButtonFormField(
                  value: selectPlanValue,
                  decoration:const InputDecoration(
                    border: InputBorder.none
                  ),
                  items: ["1","2","3","4","5"].map((e){
                    return DropdownMenuItem(child: Text(e),value: e);
                  }).toList(),
                  onChanged: (val){
                    if(estimatedAmountController.text.isNotEmpty){
                       selectPlanValue = val;
                       planDateList!.clear();
                       for(int i=0;i<int.parse(selectPlanValue!);i++){
                        planDateList!.add(null);
                       }
                       
                       installPriceController!.clear();
                       for(int i=0;i<int.parse(selectPlanValue!);i++){
                        installPriceController!.add(TextEditingController(text: ""));
                       }


                       print(selectPlanValue);
                    }else{
                      selectPlanValue=null;
                      print(selectPlanValue);
                      showToastMsg("Please Select Estimate Amount First");
                      setState(() {
                        
                      });
                    }
                    
                    setState(() {
                      
                    });
                  }
                ),
              ),
              SizedBox(height: _size!.height*0.01),
             selectPlanValue!=null? chooseInstallmentPlan():Container(),
              const Divider(color: Colors.grey,),
              SizedBox(height: _size!.height*0.01),
              Text("Start Date (*)".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
              SizedBox(height: _size!.height*0.005),
             InkWell(
              onTap: (){
                selectDate();
              },
              child: Container(
              
                padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 8),
                decoration: BoxDecoration(
                 borderRadius: BorderRadius.circular(20),
                 border: Border.all(color: AppColor.appThemeColorOlive)
                ),
                child: Row(
                  children: [
                   const Icon(Icons.calendar_today, color: AppColor.appThemeColorOlive,),
                   const SizedBox(width: 10),
                    Text(currentTime!=null && dateSet!?onlyDateFormatter.format(currentTime!) :"Select Due Date", style: AppTextStyles.k14TextN,)
                  ],
                ),
              ),
             ),
             SizedBox(height: _size!.height*0.01),
            Text("End Date (*)".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
              SizedBox(height: _size!.height*0.005),
             InkWell(
              onTap: (){
                selectEndDate();
              },
              child: Container(
              
                padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 8),
                decoration: BoxDecoration(
                 borderRadius: BorderRadius.circular(20),
                 border: Border.all(color: AppColor.appThemeColorOlive)
                ),
                child: Row(
                  children: [
                   const Icon(Icons.calendar_today, color: AppColor.appThemeColorOlive,),
                   const SizedBox(width: 10),
                    Text(endDate!=null && dateSetEnd!?onlyDateFormatter.format(endDate!) :"Select Due Date", style: AppTextStyles.k14TextN,)
                  ],
                ),
              ),
             ),
             SizedBox(height: _size!.height*0.01),
             getTextFromFieldTextType("Comments".tr(), "Comments".tr(), maxLines: 2,controller: commentsController),
             SizedBox(height: _size!.height*0.02),
             Row(
              children: [
                Checkbox(
                  activeColor: AppColor.appThemeColorOlive,
                  value: isChecked, onChanged: (val){
                  myState(() {
                  });
                  isChecked = val;
                }),
                Text("Is the material neccessary?".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),)

              ],
             ),

             SizedBox(height: _size!.height*0.01),
            !isChecked!?Container() :Container(
              //height: 100,
              padding:const EdgeInsets.all(7),
              decoration:const BoxDecoration(
               // border: Border.all(color: AppColor.appThemeColorOlive,width: 3)
              ),child: Column(
                children: [
                  Column(
                    children: matWidgetList,
                  ),
                  SizedBox(height: _size!.height*0.01),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      InkWell(
                        onTap: (){
                          if(matWidgetList.length >0){
                            print("hello");
                            currentMatIndex = currentMatIndex+1;
                            addaterialProducts(currentMatIndex);
                          }

                          /*if(materialNameController.text.isNotEmpty && qtyController.text.isNotEmpty && priceController.text.isNotEmpty){
                            MaterialModel obj = MaterialModel(
                              materialName: materialNameController.text,
                              materialQty: qtyController.text,
                              unitPrice: priceController.text,
                              tax: vatController.text.isNotEmpty?vatController.text:"",
                              taxAmount: totalVatController.text,
                              totalAmount: totalPriceController.text,
                              unit: unitController.text,
                              subTotal: totalPriceController.text,
                            );
                            print(obj);
                            model.setUserMaterialModelList(obj);
                            clearText();
                          }else{
                            showToastMsg("Please Enter Details");
                          }*/

                          
                        },
                        child: Container(
                          padding:const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColor.appThemeColorOlive,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text("Add".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                        ),
                      )
                    ],
                  ),
                  const SizedBox(height: 30,),
                  Container(
                    //width: _size!.width*.6,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                                width: _size!.width*.65,
                                child: Text("Sub Total".tr(),textAlign: TextAlign.right,)),
                            Expanded(child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16.0),
                              child: Text(subTotal!.toStringAsFixed(2)),
                            )),
                          ],
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                                width: _size!.width*.65,
                                child: Text("Total Tax".tr(),textAlign: TextAlign.right,)),
                            Expanded(child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16.0),
                              child: Text(totalTax!.toStringAsFixed(2)),
                            )),
                          ],
                        ),
                        Row(
                          children: [
                            Container(
                                width: _size!.width*.65,
                                child: Text("Grand Total".tr(),textAlign: TextAlign.right,)),
                                Expanded(child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                                  child: Text(grandTotal!.toStringAsFixed(2)),
                                )),
                          ],
                        ),
                      ],
                    ),
                  )
                ],
              ),
             ),
             SizedBox(height: _size!.height*0.01),
             InkWell(
              onTap: (){
                saveData(model);
              },
               child: Container(
                padding: EdgeInsets.symmetric(vertical: 5),
                decoration: BoxDecoration(
                  color: AppColor.appThemeColorOlive,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(child: Text(widget.obj!=null?"Update".tr():"SUBMIT".tr(),style: AppTextStyles.k16TextN.copyWith(color:Colors.white))),
               ),
             ),
             SizedBox(height: _size!.height*0.01),
            ],
      ),
            
            model.isLoading!?const CustomLoader():Container()
          ],
        );
      })
    );
    });
  }
   List<TextEditingController>? installPriceController = [];

  chooseInstallmentPlan(){
    if(estimatedAmountController.text.isNotEmpty && selectPlanValue!=null){
      String installmentAmount  = (double.parse(estimatedAmountController.text)/int.parse(selectPlanValue!)).toStringAsFixed(2);
        for(int i=0;i<int.parse(selectPlanValue!);i++){
           installPriceController![i].text = installmentAmount;
        }
        return Column(
          children: [
            for(int i=0;i<int.parse(selectPlanValue!);i++)
             Container(
                    child: Row(children: [
                      Container(
                        width: 20,

                        child: Center(child: Text((i+1).toString(),style: AppTextStyles.k16TextN,))),
                      // Radio(value: i, groupValue: selectRadio, onChanged: (val){
                      //   if(estimatedAmountController.text.isNotEmpty){
                      //     selectRadio = val;
                      //   }else{
                      //     showToastMsg("Please Enter Estimated Amount");
                      //   }

                      //   setState(() {
                          
                      //   });
                      // }),
                      const SizedBox(width: 15),
                      InkWell(
                        onTap: (){
                          print(i);
                            selectPlanDates(context,i);
                        },
                        child: Container(
                           margin: EdgeInsets.only(bottom: 5),
                          padding:const EdgeInsets.symmetric(horizontal: 10,vertical: 8),
                          decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: AppColor.appThemeColorOlive)
                          ),
                          child: Row(
                            children: [
                            const Icon(Icons.calendar_today, color: AppColor.appThemeColorOlive,),
                            const SizedBox(width: 10),
                              Text(planDateList!=null && planDateList![i]!=null ?DateFormat("dd MMM yy").format(planDateList![i]!): "Select Date", style: AppTextStyles.k14TextN,)
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(child: Container(
                        height: 40,
                        margin:const EdgeInsets.only(bottom: 5),
                        child: TextField(
                          controller:installPriceController![i],
                          decoration: InputDecoration(
                            prefix: Text("€  ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),),
                            contentPadding: EdgeInsets.symmetric(vertical: 5,horizontal: 5),
                            border: OutlineInputBorder(borderSide: BorderSide(color: AppColor.appThemeColorOlive))
                          ),
                        ),
                      ))
                    ]),
                  )
          ],
      );
    }else{
      return Container();
    }

  }

int? selectRadio;
 /* chosseInstallments(int index){
   return RadioListTile(
    activeColor: AppColor.appThemeColorOlive,
    value: index+1, groupValue: selectRadio, onChanged: (val){
        setState(() {
          selectRadio = val;
        });
        print(selectRadio);
      },title:Text("Installment".tr() + " " + (index+1).toString(),style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive)));
  }*/
  chosseInstallments(int index){
    return Container(
      child: Row(
        children: [
          
        ],
      ),
    ); 
  }

  bool?dateSet = false;
  DateTime? currentTime;
  selectDate() async{
    DateTime? date = DateTime.now();
    var newDate = new DateTime(date.year, date.month - 11, date.day);
    DateTime? newDateFrom=await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: newDate,
        lastDate: DateTime(2100));
    if (newDateFrom !=null) {
      setState(() {
        
      });
      currentTime = newDateFrom;
      /*if(estimatedTimeController.text.isNotEmpty){
        endDateController.text = onlyDateFormatter.format(DateTime.parse(currentTime!.add(Duration(days: int.parse(estimatedTimeController.text))).toString())) ;
        print(endDateController.text);
      }*/
      dateSet = true;
      //getData();
    }
   }

  bool?dateSetEnd = false;
  DateTime? endDate;
  selectEndDate() async{
    DateTime? date = DateTime.now();
    var newDate = new DateTime(date.year, date.month - 11, date.day);
    DateTime? newDateFrom=await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: newDate,
        lastDate: DateTime(2100));
    if (newDateFrom !=null) {
      setState(() {
        
      });
      endDate = newDateFrom;
     /* if(estimatedTimeController.text.isNotEmpty){
        endDateController.text = onlyDateFormatter.format(DateTime.parse(currentTime!.add(Duration(days: int.parse(estimatedTimeController.text))).toString())) ;
        print(endDateController.text);
      }*/
      dateSetEnd = true;
      //getData();
    }
   }

   // select plan date 
   List<DateTime?>? planDateList=[];
   selectPlanDates(BuildContext context, int index) async{
    DateTime? date = DateTime.now();
    var newDate = DateTime(date.year, date.month - 11, date.day);
     DateTime? newDateFrom=await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: newDate,
        lastDate: DateTime(2100));
        if(newDateFrom !=null) {
          setState(() {
            
          });
          planDateList![index] = newDateFrom;
          print(index);
          print(planDateList![index]);
          
          dateSet = true;
          //getData();
        }
  }

   int currentMatIndex=0;
  List<TextEditingController> materialNameController = [];
  List<TextEditingController> qtyController = [];
  List<TextEditingController> unitController = [];
  List<TextEditingController> vatController = [];
  List<TextEditingController> totalVatController = [];
  List<TextEditingController> totalPriceController = [];
  List<TextEditingController> priceController = [];
  List<TextEditingController> totalWithTaxController = [];

  
  List<Widget> list = [];

  List<Widget> matWidgetList = [];
  addaterialProducts(int countIndex,{bool?viaData}){
     materialNameController.add(TextEditingController(text: ''));
     qtyController.add(TextEditingController(text: ''));
     unitController.add(TextEditingController(text: ''));
     vatController.add(TextEditingController(text: ''));
     totalVatController.add(TextEditingController(text: ''));
     totalPriceController.add(TextEditingController(text: ''));
     priceController.add(TextEditingController(text: ''));
     totalWithTaxController.add(TextEditingController(text: ''));
    List<Widget> list=[];
    list.add(Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Container(
        padding:const EdgeInsets.all(8),
        decoration: BoxDecoration(
          border: Border.all(color: AppColor.appThemeColorOlive),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          children: [
            getTextFieldTextType("Material Name".tr(), "Material Name".tr(), controller: materialNameController[countIndex]),
            SizedBox(height: _size!.height*0.01),
            Row(
              children: [
                Expanded(child: SizedBox(
                  //height: 60,s
                  child:  TextFormField(
                      controller: qtyController[countIndex],
                      decoration: InputDecoration(
                        contentPadding:const EdgeInsets.symmetric(horizontal: 10,vertical: 3),
                        disabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: AppColor.appThemeColorOlive.withOpacity(0.5)),borderRadius: BorderRadius.circular(20)),
                        enabledBorder: OutlineInputBorder(
                            borderSide:const BorderSide(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(20)),
                        focusedBorder: OutlineInputBorder(
                            borderSide:const BorderSide(color: AppColor.appThemeColorOrange),
                            borderRadius: BorderRadius.circular(20)
                        ),
                        labelText: "QTY".tr(),labelStyle: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        alignLabelWithHint: false,
                      ),
                      keyboardType:TextInputType.number,

                      onSaved: (value){

                      },
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly
                      ],

                      onChanged:(str){
                        if(![null,""].contains(str) && ![null,""].contains(priceController[countIndex].text)){
                          calculateTaxes();
                        }
                      }
                    //textInputAction: ,
                  ) ,)),

                /* Expanded(child: getTextFieldTextType("Qty", "Qty",controller: qtyController, textInputType: TextInputType.number,
                 callbackFunction: (val){
                  if(![null,""].contains(val)){
                    double totalAmount = double.parse(qtyController.text) * double.parse(priceController.text);
                    totalPriceController.text = totalAmount.toStringAsFixed(2);
                    double totalWithVat = totalAmount + ((totalAmount * double.parse(vatController.text))/100);

                  }
                 }
                )),*/
                const SizedBox(width: 8),
                Expanded(child: getTextFieldTextType("Unit".tr(), "Unit".tr(),controller: unitController[countIndex])),
              ],
            ),
            SizedBox(height: _size!.height*0.01),
            SizedBox(
              //height: 60,s
              child:  TextFormField(
                  controller: priceController[countIndex],
                  decoration: InputDecoration(
                    contentPadding:const EdgeInsets.symmetric(horizontal: 10,vertical: 3),
                    disabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: AppColor.appThemeColorOlive.withOpacity(0.5)),borderRadius: BorderRadius.circular(20)),
                    enabledBorder: OutlineInputBorder(
                        borderSide:const BorderSide(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(20)),
                    focusedBorder: OutlineInputBorder(
                        borderSide:const BorderSide(color: AppColor.appThemeColorOrange),
                        borderRadius: BorderRadius.circular(20)
                    ),
                    labelText: "Price".tr(),labelStyle: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),
                    floatingLabelBehavior: FloatingLabelBehavior.always,
                    alignLabelWithHint: false,
                  ),
                  keyboardType:TextInputType.number,

                  onSaved: (value){

                  },
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly
                  ],

                  onChanged:(str){
                    if(![null,""].contains(str) && ![null,""].contains(priceController[countIndex].text)){
                      calculateTaxes();
                    }
                  }
                //textInputAction: ,
              ) ,),
            // getTextFieldTextType("Price", "Price",controller: priceController, textInputType: TextInputType.number),
            SizedBox(height: _size!.height*0.015),
            SizedBox(
              //height: 60,s
              child:  TextFormField(
                  controller: vatController[countIndex],
                  decoration: InputDecoration(
                    contentPadding:const EdgeInsets.symmetric(horizontal: 10,vertical: 3),
                    disabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: AppColor.appThemeColorOlive.withOpacity(0.5)),borderRadius: BorderRadius.circular(20)),
                    enabledBorder: OutlineInputBorder(
                        borderSide:const BorderSide(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(20)),
                    focusedBorder: OutlineInputBorder(
                        borderSide:const BorderSide(color: AppColor.appThemeColorOrange),
                        borderRadius: BorderRadius.circular(20)
                    ),
                    labelText: "TVA(%)".tr(),labelStyle: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),
                    floatingLabelBehavior: FloatingLabelBehavior.always,
                    alignLabelWithHint: false,
                  ),
                  keyboardType:TextInputType.number,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly
                  ],

                  onChanged:(str){
                      calculateTaxes();
                  }
                //textInputAction: ,
              ) ,),
          
            SizedBox(height: _size!.height*0.01),
            Row(
              children: [
                Expanded(child: getTextFieldTextType("Total TVA".tr(), "Total TVA".tr(),isEnabled: false,controller: totalVatController[countIndex])),
                const SizedBox(width: 8),
                Expanded(child: getTextFieldTextType("Sub Total".tr(), "Sub Total".tr(),isEnabled: false,controller: totalPriceController[countIndex])),
              ],
            ),
            TextButton(onPressed:() async{
              if(currentMatIndex>0){
                await removeMatIndex(currentMatIndex);
                reloadData();
              }
            }, child: Text("Remove".tr()))
          ],
        ),
      ),
    ));
    matWidgetList.addAll(list);
    print(matWidgetList.length);
    if(viaData==null) {
      myStateSetter!(() {

      });
    }
  }
  reloadData(){
    List<Widget> list=[];
    for(int countIndex=0;countIndex<matWidgetList.length;countIndex++){
      list.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Container(
          padding:const EdgeInsets.all(8),
          decoration: BoxDecoration(
            border: Border.all(color: AppColor.appThemeColorOlive),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            children: [
              getTextFieldTextType("Material Name".tr(), "Material Name".tr(), controller: materialNameController[countIndex]),
              SizedBox(height: _size!.height*0.01),
              Row(
                children: [
                  Expanded(child: SizedBox(
                    //height: 60,s
                    child:  TextFormField(
                        controller: qtyController[countIndex],
                        decoration: InputDecoration(
                          contentPadding:const EdgeInsets.symmetric(horizontal: 10,vertical: 3),
                          disabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: AppColor.appThemeColorOlive.withOpacity(0.5)),borderRadius: BorderRadius.circular(20)),
                          enabledBorder: OutlineInputBorder(
                              borderSide:const BorderSide(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(20)),
                          focusedBorder: OutlineInputBorder(
                              borderSide:const BorderSide(color: AppColor.appThemeColorOrange),
                              borderRadius: BorderRadius.circular(20)
                          ),
                          labelText: "QTY".tr(),labelStyle: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          alignLabelWithHint: false,
                        ),
                        keyboardType:TextInputType.number,

                        onSaved: (value){

                        },
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly
                        ],

                        onChanged:(str){
                          if(![null,""].contains(str) && ![null,""].contains(priceController[countIndex].text)){
                            calculateTaxes();
                          }
                        }
                      //textInputAction: ,
                    ) ,)),

                  /* Expanded(child: getTextFieldTextType("Qty", "Qty",controller: qtyController, textInputType: TextInputType.number,
                 callbackFunction: (val){
                  if(![null,""].contains(val)){
                    double totalAmount = double.parse(qtyController.text) * double.parse(priceController.text);
                    totalPriceController.text = totalAmount.toStringAsFixed(2);
                    double totalWithVat = totalAmount + ((totalAmount * double.parse(vatController.text))/100);

                  }
                 }
                )),*/
                  const SizedBox(width: 8),
                  Expanded(child: getTextFieldTextType("Unit".tr(), "Unit".tr(),controller: unitController[countIndex])),
                ],
              ),
              SizedBox(height: _size!.height*0.01),
              SizedBox(
                //height: 60,s
                child:  TextFormField(
                    controller: priceController[countIndex],
                    decoration: InputDecoration(
                      contentPadding:const EdgeInsets.symmetric(horizontal: 10,vertical: 3),
                      disabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.appThemeColorOlive.withOpacity(0.5)),borderRadius: BorderRadius.circular(20)),
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(20)),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.appThemeColorOrange),
                          borderRadius: BorderRadius.circular(20)
                      ),
                      labelText: "Price".tr(),labelStyle: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),
                      floatingLabelBehavior: FloatingLabelBehavior.always,
                      alignLabelWithHint: false,
                    ),
                    keyboardType:TextInputType.number,

                    onSaved: (value){

                    },
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly
                    ],

                    onChanged:(str){
                      if(![null,""].contains(str) && ![null,""].contains(priceController[countIndex].text)){
                        calculateTaxes();
                      }
                    }
                  //textInputAction: ,
                ) ,),
              // getTextFieldTextType("Price", "Price",controller: priceController, textInputType: TextInputType.number),
              SizedBox(height: _size!.height*0.015),
              SizedBox(
                //height: 60,s
                child:  TextFormField(
                    controller: vatController[countIndex],
                    decoration: InputDecoration(
                      contentPadding:const EdgeInsets.symmetric(horizontal: 10,vertical: 3),
                      disabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.appThemeColorOlive.withOpacity(0.5)),borderRadius: BorderRadius.circular(20)),
                      enabledBorder: OutlineInputBorder(
                          borderSide:const BorderSide(color: AppColor.appThemeColorOlive),borderRadius: BorderRadius.circular(20)),
                      focusedBorder: OutlineInputBorder(
                          borderSide:const BorderSide(color: AppColor.appThemeColorOrange),
                          borderRadius: BorderRadius.circular(20)
                      ),
                      labelText: "TVA(%)".tr(),labelStyle: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive),
                      floatingLabelBehavior: FloatingLabelBehavior.always,
                      alignLabelWithHint: false,
                    ),
                    keyboardType:TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly
                    ],

                    onChanged:(str){
                      calculateTaxes();
                    }
                  //textInputAction: ,
                ) ,),
              // getTextFieldTextType("TVA(%)", "TVA(%)",controller: vatController, textInputType: TextInputType.number),
              SizedBox(height: _size!.height*0.01),
              Row(
                children: [
                  Expanded(child: getTextFieldTextType("Total TVA".tr(), "Total TVA".tr(),isEnabled: false,controller: totalVatController[countIndex])),
                  const SizedBox(width: 8),
                  Expanded(child: getTextFieldTextType("Sub Total".tr(), "Sub Total".tr(),isEnabled: false,controller: totalPriceController[countIndex])),
                ],
              ),
              TextButton(onPressed:() async{
                if(currentMatIndex>0){
                  removeMatIndex(currentMatIndex);
                  reloadData();
                }
              }, child: Text("Remove".tr()))
            ],
          ),
        ),
      ));
    }
    matWidgetList.clear();
    matWidgetList.addAll(list);
    print(matWidgetList.length);
    myStateSetter!(() {

    });
  }

  double?subTotal=0;
  double?totalTax=0;
  double?grandTotal=0;
  calculateTaxes(){
    subTotal = 0;
    totalTax = 0;
    grandTotal = 0;
    if(isChecked!){
      for(int i=0; i<matWidgetList.length;i++) {
        if(qtyController[i].text.isNotEmpty && priceController[i].text.isNotEmpty || vatController[i].text.isNotEmpty) {
          print("heyyy");
          totalVatController[i].text = ((double.parse(qtyController[i].text)* double.parse(priceController[i].text) * double.parse(vatController[i].text.isNotEmpty?vatController[i].text:"0"))/100).toStringAsFixed(2);
          totalPriceController[i].text = ((double.parse(qtyController[i].text)* double.parse(priceController[i].text))).toStringAsFixed(2);
          totalWithTaxController[i].text = (double.parse(totalVatController[i].text)+ double.parse(totalPriceController[i].text)).toStringAsFixed(2);
          subTotal = subTotal! + (double.parse(qtyController[i].text)* double.parse(priceController[i].text));
          totalTax = totalTax! + double.parse(totalVatController[i].text);
          grandTotal = subTotal! + totalTax!;
        } else {
          totalVatController[i].clear();
          totalPriceController[i].clear();
        }
      }
    }
    myStateSetter!(() {

    });
  }
  removeMatIndex(int index) async{
    materialNameController.removeAt(index);
    qtyController.removeAt(index);
    unitController.removeAt(index);
    vatController.removeAt(index);
    totalVatController.removeAt(index);
    totalPriceController.removeAt(index);
    priceController.removeAt(index);
    matWidgetList.removeAt(index);
    totalWithTaxController.removeAt(index);
    currentMatIndex = currentMatIndex -1;
    calculateTaxes();
    myStateSetter!(() {
    });
  }

  clearText(){
    materialNameController.clear();
    qtyController.clear();
    priceController.clear();
    vatController.clear();
    totalPriceController.clear();
    totalVatController.clear();
    unitController.clear();
    unitController.clear();
  }

 // save data 
 saveData(UserProvider model)async {
   List<MaterialModel> userMaterialModelList = [];
   if(isChecked!){
     for(int i=0;i<matWidgetList.length;i++){
       if(materialNameController[i].text.isNotEmpty && qtyController[i].text.isNotEmpty && unitController[i].text.isNotEmpty && vatController[i].text.isNotEmpty && priceController[i].text.isNotEmpty){
         MaterialModel obj = MaterialModel(
           materialName: materialNameController[i].text,
           materialQty: qtyController[i].text,
           unitPrice: priceController[i].text,
           tax: vatController[i].text.isNotEmpty?vatController[i].text:"",
           taxAmount: totalVatController[i].text,
           unit: unitController[i].text,
           subTotal: totalPriceController[i].text,
           totalAmount: totalWithTaxController[i].text,
         );
         print(obj);
         userMaterialModelList.add(obj);
       }else{
         showToastMsg("Please Add Material Details".tr());
       }
     }
    print(jsonEncode(userMaterialModelList));
  }
  // return;
  if(estimatedAmountController.text.isEmpty){
    return showToastMsg("Please Enter Estimated Amount".tr());
  }
  
  if(estimatedTimeController.text.isEmpty){
    return showToastMsg("Please Enter Estimated Days".tr());
  }

  if(coverController.text.isEmpty){
    return showToastMsg("Please Fill Cover Letter".tr());
  }

  // if(selectRadio==null && selectRadio==0){
  //   return showToastMsg("Please Select any one installment method".tr());
  // }

  if(selectPlanValue==null){
    return showToastMsg("Please Select Installment Plan".tr());
  }

   if(currentTime==null){
    return showToastMsg("Please Select Start Date".tr());
   }
  
  if(endDate==null){
    return showToastMsg("Please Select End Date".tr());
   }
   

  String?versement_date1;
  String?versement_date2;
  String?versement_date3;
  String?versement_date4;
  String?versement_date5;
  String?versement_amount1;
  String?versement_amount2;
  String?versement_amount3;
  String?versement_amount4;
  String?versement_amount5;
  List<InstallPlanValueData> listplan=[];
   for(int i=0; i<int.parse(selectPlanValue!);i++){
    InstallPlanValueData obj1 = InstallPlanValueData(
      versementAmount: installPriceController![i].text,
      versementDate: planDateList![i].toString(),
    );

    listplan.add(obj1);
   }

  //  print(list);

  //  for(int i=0;i<list.length;i++){
  //    versement_date1 = list[i].versement_date;
  //    versement_date2 = list[i].versement_date;
  //    versement_date3 = list[i].versement_date;
  //    versement_date4 = list[i].versement_date;
  //    versement_date5 = list[i].versement_date;
  //    versement_amount1 = list[i].versement_amount;
  //    versement_amount2 = list[i].versement_amount;
  //    versement_amount3 = list[i].versement_amount;
  //    versement_amount4 = list[i].versement_amount;
  //    versement_amount5 = list[i].versement_amount;
  //  }
    
    SaveQuotationModel obj = SaveQuotationModel(
      jobId: widget.job_id,
      editId: "",
      estimatePrice: estimatedAmountController.text,
      estimateProjectTime: estimatedTimeController.text,
      coverDescription: coverController.text,
      instalmentPlan: selectPlanValue.toString(),
      workStartDate:  yyMMddDateFormatter.format(currentTime!).toString(),
      workEndDate: yyMMddDateFormatter.format(endDate!).toString(),
      materialList: userMaterialModelList.isNotEmpty?userMaterialModelList:[],//model.userMaterialModelList.isEmpty?[]:model.userMaterialModelList,
      total: userMaterialModelList.isNotEmpty?subTotal!.toStringAsFixed(2):"0",
      totalTax: userMaterialModelList.isNotEmpty?totalTax!.toStringAsFixed(2):"0",
      grandTotal: userMaterialModelList.isNotEmpty?grandTotal!.toStringAsFixed(2):"0",
      grandTotalEstimatePrice: "0",
      comment: commentsController.text,
      versement_amount1: versement_amount1,
      versement_amount2: versement_amount2,
      versement_amount3: versement_amount3,
      versement_amount4: versement_amount4,
      versement_amount5: versement_amount5,
      versement_date1: versement_date1,
      versement_date2: versement_date2,
      versement_date3: versement_date3,
      versement_date4: versement_date4,
      versement_date5: versement_date5,
      installPlanValueList: listplan.isNotEmpty?listplan:[],
      cust_id: widget.cust_id!,

    );

   print(jsonEncode(obj));
  
   await model.saveQuotation(context, obj,edit_id:widget.obj!=null? widget.obj!.id :"");

 }
}

class SaveQuotationModel {
  String? editId;
  String? jobId;
  String? estimatePrice;
  String? estimateProjectTime;
  String? coverDescription;
  String? instalmentPlan;
  String? workStartDate;
  String? workEndDate;
  String? comment;
  String? materialDetails;
  String? userId;
  String? total;
  String? totalTax;
  String? grandTotal;
  String? grandTotalEstimatePrice;
  List<MaterialModel> ? materialList=[];
  String?versement_date1;
  String?versement_date2;
  String?versement_date3;
  String?versement_date4;
  String?versement_date5;
  String?versement_amount1;
  String?versement_amount2;
  String?versement_amount3;
  String?versement_amount4;
  String?versement_amount5;
  String?cust_id;
  List<InstallPlanValueData>? installPlanValueList=[];

  SaveQuotationModel(
      {this.editId,
      this.jobId,
      this.estimatePrice,
      this.estimateProjectTime,
      this.coverDescription,
      this.instalmentPlan,
      this.workStartDate,
      this.workEndDate,
      this.comment,
      this.materialDetails,
      this.userId,
      this.total,
      this.totalTax,
      this.grandTotal,
      this.grandTotalEstimatePrice,
      this.materialList,
      this.versement_date1,
      this.versement_date2,
      this.versement_date3,this.versement_date4,this.versement_date5,
      this.versement_amount1,this.versement_amount2,this.versement_amount3,
      this.versement_amount4,this.versement_amount5,this.installPlanValueList,
      this.cust_id,
      });

  SaveQuotationModel.fromJson(Map<String, dynamic> json) {
    editId = json['edit_id'];
    jobId = json['job_id'];
    estimatePrice = json['estimate_price'];
    estimateProjectTime = json['estimate_project_time'];
    coverDescription = json['cover_description'];
    instalmentPlan = json['instalment_plan'];
    workStartDate = json['work_start_date'];
    workEndDate = json['work_end_date'];
    comment = json['comment'];
    materialDetails = json['material_details'];
    userId = json['userId'];
    total = json['total'];
    totalTax = json['total_tax'];
    grandTotal = json['grand_total'];
    grandTotalEstimatePrice = json['grand_total_estimate_price'];
    versement_date1 = json['versement_date1'];
    versement_date2 = json['versement_date2'];
    versement_date3 = json['versement_date3'];
    versement_date4 = json['versement_date4'];
    versement_date5 = json['versement_date5'];
    versement_amount1 = json['versement_amount1'];
    versement_amount2 = json['versement_amount2'];
    versement_amount3 = json['versement_amount3'];
    versement_amount4 = json['versement_amount4'];
    versement_amount5 = json['versement_amount5'];
    cust_id = json['cust_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['edit_id'] = this.editId;
    data['job_id'] = this.jobId;
    data['estimate_price'] = this.estimatePrice;
    data['estimate_project_time'] = this.estimateProjectTime;
    data['cover_description'] = this.coverDescription;
    data['instalment_plan'] = this.instalmentPlan;
    data['work_start_date'] = this.workStartDate;
    data['work_end_date'] = this.workEndDate;
    data['comment'] = this.comment;
    data['material_details'] = this.materialDetails;
    data['userId'] = this.userId;
    data['total'] = this.total;
    data['total_tax'] = this.totalTax;
    data['grand_total'] = this.grandTotal;
    data['grand_total_estimate_price'] = this.grandTotalEstimatePrice;
    data['versement_date1']=this.versement_date1;
    data['versement_date2']=this.versement_date2;
    data['versement_date3']=this.versement_date3;
    data['versement_date4']=this.versement_date4;
    data['versement_date5']=this.versement_date5;
    data['versement_amount1'] = this.versement_amount1;
    data['versement_amount2'] = this.versement_amount2;
    data['versement_amount3'] = this.versement_amount3;
    data['versement_amount4'] = this.versement_amount4;
    data['versement_amount5'] = this.versement_amount5;
    data['cust_id'] = this.cust_id;
    return data;
  }
}

class InstallPlanValueData {
  String? versementAmount;
  String? versementDate;

  InstallPlanValueData({this.versementAmount, this.versementDate});

  InstallPlanValueData.fromJson(Map<String, dynamic> json) {
    versementAmount = json['versement_amount'];
    versementDate = json['versement_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['versement_amount'] = this.versementAmount;
    data['versement_date'] = this.versementDate;
    return data;
  }
}

