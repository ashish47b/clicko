import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/JobModel/job_data_model.dart';
import 'package:clik_pro_professional/model/JobModel/job_status_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/AppliedJobs/view_quotes.dart';
import 'package:clik_pro_professional/widgets/job_details_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class JobItem extends StatefulWidget {
  JobStatusData?obj;
  final tabIndex;
  JobItem({this.obj,this.tabIndex});

  @override
  State<JobItem> createState() => _JobItemState();
}

class _JobItemState extends State<JobItem> {


   @override
  void initState() {
    // TODO: implement initState
    super.initState();
   // Future.delayed(Duration(milliseconds: 300),()=> checkPayment());

  }

  // checkPayment()async{
  //   if(widget.tabIndex=="2"){
      
  //   } 
  // }

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(
      builder: (context, model, child) {
        return Container(
          child: Column(
                //padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [

                  SizedBox(height: _size!.height*0.01),

                   SizedBox(height: _size!.height*0.02),
                   InkWell(
                    onTap: (){
                         // Get.toNamed(RoutesName.joDetailsView);
                    },
                     child: Container(
                       //height: 150,
                       margin:const EdgeInsets.symmetric(horizontal: 12),
                       padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                       decoration: BoxDecoration(
                          border: Border.all(color: AppColor.appThemeColorGreen)
                       ),
                       child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(child: Text(widget.obj!.jobTitle!,style: AppTextStyles.k18TextH.copyWith(color: AppColor.appThemeColorSky))),
                                Text("€"+" " + widget.obj!.price! ,style: AppTextStyles.k16TextH.copyWith(color: AppColor.appThemeColorGreen)),
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            Row(
                              children: [
                                const Icon(Icons.calendar_today,color: AppColor.appThemeColorOlive),
                                const SizedBox(width: 5),
                                Text("Posted on".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                //Text(ddMMMyyyy.format(DateTime.parse(widget.obj!.startDate!)).toString(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorGreen),)
                                Text(widget.obj!.startDate!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appRedColor),)
                              ],
                            ),
                            SizedBox(height: _size!.height*0.01),
                            Row(
                              children: [
                                const Icon(Icons.calendar_today,color: AppColor.appThemeColorOlive),
                                const SizedBox(width: 5),
                                Text("Expires on".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                //Text(ddMMMyyyy.format(DateTime.parse(widget.obj!.dueDate!)).toString(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appRedColor))
                                Text(widget.obj!.dueDate!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appRedColor),)
                              ],
                            ),
                              SizedBox(height: _size!.height*0.01),
                            Row(
                              children: [
                                const ImageIcon(AssetImage("assets/icons/auction.png"), color: AppColor.appThemeColorOlive,),
                                const SizedBox(width: 5),
                                Text("Total Bid".tr() + " : ",style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                                Text(widget.obj!.bidCount!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOrange),)
                              ],
                            ),
                            const Divider(color: Colors.grey,),
                            SizedBox(height: _size!.height*0.01),
                            Text(widget.obj!.description!,style: AppTextStyles.k14TextN, maxLines: 4,overflow: TextOverflow.ellipsis,),
                            SizedBox(height: _size!.height*0.01),
                            const Divider(color: Colors.grey,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                 if(widget.tabIndex=="0" || widget.tabIndex=="1")
                                 InkWell(
                                  onTap: (){
                                    ActiveJobs?obj = ActiveJobs();
                                    obj.category = widget.obj!.category!;
                                    obj.price = widget.obj!.price!;
                                    obj.jobTitle = widget.obj!.jobTitle!;
                                    obj.status = widget.obj!.status!;
                                    obj.startDate = widget.obj!.startDate!;
                                    obj.location = widget.obj!.location!;
                                    obj.location = widget.obj!.location!;
                                    obj.attachmnetList = widget.obj!.attachmentsList;
                                    obj.description = widget.obj!.description;



                                    navigateWithPageTransition(context, JobDetailsPage(obj: obj,));
                                  },
                                   child: Container(
                                    padding:const EdgeInsets.all(4),
                                    decoration:const BoxDecoration(
                                      color: AppColor.appThemeColorOrange,
                                      shape: BoxShape.circle,
                                    ),
                                    child:const Icon(Icons.remove_red_eye,color: Colors.white,),
                                   ),
                                 ),
                                


                              ]
                            ),
                            SizedBox(height: _size!.height*0.01),
                            if(widget.tabIndex=="1")
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        ElevatedButton(onPressed: (){

                                          navigateWithPageTransition(context, ViewQuotes( quote_id: widget.obj!.id,));
                                        }, child: Text("See the Quote".tr()),
                                        style: ButtonStyle(
                                          backgroundColor: MaterialStateProperty.all(AppColor.appThemeColorOrange),
                                        ),),
                                        SizedBox(width: 8,),
                                        widget.obj!.markedDone=="0"?ElevatedButton(onPressed: (){
                                          showDoneDialog(widget.obj!,model);
                                        }, child: Text("Mark As Done".tr()),
                                        style: ButtonStyle(
                                          backgroundColor: MaterialStateProperty.all(AppColor.appThemeColorOrange),
                                        ),):Container(),
                                      ],
                                    ),
                                  )

                        ],
                       ),
                                 ),
                   ),
              ],
            ),
        );
      }
    );
  }

  var remarksText = TextEditingController(text: '');
  showDoneDialog(JobStatusData obj, UserProvider?model) {
    remarksText.clear();
    showDialog(context: context, builder: (cntxt){
      return AlertDialog(
      insetPadding: EdgeInsets.symmetric(horizontal: 16),
        content: Wrap(
            children: [
              Text(obj.jobTitle!,),
              const SizedBox(height: 16,),
              Text(obj.description!,),
              getTextFieldTextType("Enter Remarks".tr(), "Remarks".tr(),controller: remarksText,maxLines: 3,),
            ],
        ),
        actions: [
          ElevatedButton(onPressed: () async{
            await model!.doCompleteJob(obj.id!);
            Navigator.pop(cntxt);
          }, child: Text("Save".tr()),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all(AppColor.appThemeColorOrange),
            ),),
        ],
      );
    });
  }
}