import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/JobModel/job_status_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/JobStatusWise/jobs_item.dart';
import 'package:clik_pro_professional/widgets/NoData.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../widgets/CustomeLoader.dart';

class AllJobsScreen extends StatefulWidget {
 String?from;

 AllJobsScreen({this.from});

  @override
  State<AllJobsScreen> createState() => _AllJobsScreenState();
}

class _AllJobsScreenState extends State<AllJobsScreen> {

var scController=ScrollController();
  


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    scController.addListener(listener);
    Future.delayed(Duration(milliseconds: 300),(() => getData()));
  }

  getData()async{
    Future.delayed(Duration(milliseconds: 100));
   Provider.of<UserProvider>(context,listen: false).jobStausApi(limit: skipValue);
  }

  int skipValue=1;
  listener(){
    if(scController.position.pixels == scController.position.maxScrollExtent){
      skipValue=skipValue+1;
      getData();
      print("called");
    }else{
      print("sorry");
    }
  }

  int currentIndex = 0;

  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Consumer<UserProvider>(builder: (context,controller,child){
       return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            DefaultTabController(
                 length: 4,
                 child: Column(
                  children: [
              Container(
                margin:const EdgeInsets.only(top: 20),
                decoration:const BoxDecoration(
                  //color: AppColor.appThemeColorOrange
                ),
                child: Container(
                  //height: 50,
                 
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12)
                  ),
                  child: TabBar(
                    unselectedLabelColor: AppColor.appThemeColorOlive,
                    labelColor: AppColor.appThemeColorOrange,
                    labelStyle: AppTextStyles.k16TextN.copyWith(
                        fontSize: 16.0,
                        color: AppColor.appThemeColorOlive,
                        fontWeight: FontWeight.w700),
                    tabs: [
                      Tab(
                        child: Container( child: Center(child: Text("Active".tr()))),
                      ),
                    Tab(
                      child: Container( child: Center(child: Text("Hiring".tr()))),
                    ),

                    Tab(
                      child: Container( child: Center(child: Text("Not Hired".tr()))),
                    ),Tab(
                      child:Container( child: Center(child: Text("Completed".tr()))),
                    ),
                  ],indicatorColor: AppColor.appThemeColorOrange,
                    isScrollable: true,
                    automaticIndicatorColorAdjustment: true,
                    //physics: NeverScrollableScrollPhysics(),
                  onTap: (val){
                    print(val);
                    currentIndex = val;
                     skipValue = 1;
                    // getData();

                    },
                  ),
                ),
              ),
               
              Expanded(
                child: TabBarView(
                  //physics: NeverScrollableScrollPhysics(),
                children: [
                  controller.activeJobsList!=null && controller.activeJobsList.length>0?  ListView.builder(
                      itemCount: controller.activeJobsList.length,
                      shrinkWrap: true,
                      controller: scController,
                      itemBuilder: (context,index){
                        JobStatusData obj = controller.activeJobsList[index];
                        return JobItem(obj: obj,tabIndex: "0",);
                      }) : NoDataWidget(isloading: controller.isLoading),


                    
                    //current Index =1


                   // currentIndex=2
                    controller.hiringJobsList!=null && controller.hiringJobsList.length>0?  ListView.builder(
                    itemCount: controller.hiringJobsList.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                    JobStatusData obj = controller.hiringJobsList[index];
                    return JobItem(obj: obj,tabIndex: "1",);
                   }) : NoDataWidget(isloading: controller.isLoading),


                  // current index = 0
                  controller.pendingJobsList!=null && controller.pendingJobsList.length>0?  ListView.builder(
                      itemCount: controller.pendingJobsList.length,
                      shrinkWrap: true,
                      controller: scController,
                      itemBuilder: (context,index){
                        JobStatusData obj = controller.pendingJobsList[index];
                        return JobItem(obj: obj,tabIndex: "2",);
                      }) : NoDataWidget(isloading: controller.isLoading),


                   // currentIndex = 3
                    controller.completeJobsList!=null && controller.completeJobsList.length>0?  ListView.builder(
                    itemCount: controller.completeJobsList.length,
                    shrinkWrap: true,
                    controller: scController,
                    itemBuilder: (context,index){
                    JobStatusData obj = controller.completeJobsList[index];
                    return JobItem(obj: obj,tabIndex: "3",);
                   }) :NoDataWidget(isloading: controller.isLoading),

                ],
              ))

                  ],
                 )
                 ),

                  controller.isLoading!?CustomLoader(): Container(),
          ],
        )
         
      ),
    );
    });
  }
}