import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/SubscriptionModel/subscription_list_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/ProfilePage/manage_subscribe.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_paypal/flutter_paypal.dart';
import 'package:provider/provider.dart';

class SubscriberPage extends StatefulWidget {
  const SubscriberPage({super.key});

  @override
  State<SubscriberPage> createState() => _SubscriberPageState();
}

class _SubscriberPageState extends State<SubscriberPage> {

  @override
  void initState() {
    setData();
    super.initState();
  }
  setData() async{
    await Provider.of<UserProvider>(context,listen: false).selectedPlan(null);
  }
  SubscriptionListData? selectedPlan;
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return SafeArea(
      child: Consumer<UserProvider>(
        builder: (context, model, child) {
          return Scaffold(
              appBar: AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0.0,
                centerTitle: true,
                title: Text("SUBSCRIBE".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
                iconTheme: IconThemeData(color: Colors.black),
              ),
              body: Column(
                children: [
                  SizedBox(height: _size!.height*0.06),
                 Expanded(child:  ManageSubscribe(selectedPlan: selectedPlan))
                ],
              ),
              bottomNavigationBar: Wrap(
                children: [
                  InkWell(
                    onTap: (){
                      if(model.userSelectedPlan!=null){
                        showAlert(model);
                      } else {
                        showToastMsg("Please select plan first".tr());
                      }
                    },
                    child: Container(
                      padding:const EdgeInsets.symmetric(vertical: 6),
                      margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 10),
                      decoration: BoxDecoration(
                        color: AppColor.appThemeColorOlive,
                        borderRadius: BorderRadius.circular(12),

                      ),
                      child: Center(child: Text("APPLY".tr(),style: AppTextStyles.k18TextN.copyWith(color: Colors.white),),),
                    ),
                  ),
                ],
              ),
          );
        }
      ),
    );
  }

  showAlert(UserProvider model){
    showDialog(context: context,
        builder: (cntxt){
          return AlertDialog(
            title: Text("Please do payment.\n Are you sure ?".tr()),
            actions: [
              TextButton(onPressed: (){
                doPayment(model);
              }, child: Text("Proceed Payment".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive), ))
            ],
          );
        });
  }

  doPayment(UserProvider?model){
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (BuildContext context) => UsePaypal(
            sandboxMode: true,
            clientId:
            "AW1TdvpSGbIM5iP4HJNI5TyTmwpY9Gv9dYw8_8yW5lYIbCqf326vrkrp0ce9TAqjEGMHiV3OqJM_aRT0",
            secretKey:
            "EHHtTDjnmTZATYBPiGzZC_AZUfMpMAzj2VZUeqlFUrRJA_C0pQNCxDccB5qoRQSEdcOnnKQhycuOWdP9",
            returnURL: "https://samplesite.com/return",
            cancelURL: "https://samplesite.com/cancel",
            transactions: [
              {
                "amount": {
                  "total": double.parse(model!.userSelectedPlan!.price!).toString(),
                  "currency": "USD",
                  "details": {
                    "subtotal": double.parse(model.userSelectedPlan!.price!).toString(),
                    "shipping": '0',
                    "shipping_discount": 0
                  }
                },
                "description": "",
                // "payment_options": {
                //   "allowed_payment_method":
                //       "INSTANT_FUNDING_SOURCE"
                // },
                "item_list": {
/*                  "items": [
                    {
                      "name": "A demo product",
                      "quantity": 1,
                      "price": '10.12',
                      "currency": "USD"
                    }
                  ],

                  // shipping address is not required though
                  "shipping_address": {
                    "recipient_name": "Jane Foster",
                    "line1": "Travis County",
                    "line2": "",
                    "city": "Austin",
                    "country_code": "US",
                    "postal_code": "73301",
                    "phone": "+00000000",
                    "state": "Texas"
                  },*/
                }
              }
            ],
            note: "Contact us for any questions on your order.",
            onSuccess: (Map params) async {
              var data = params["paymentId"];
              print("PAYMENT ID" +data);
              model.createsubscription(data);
            },
            onError: (error) {
              print("onError: $error");
            },
            onCancel: (params) {
              print('cancelled: $params');
            }),
      ),
    );

  }

}