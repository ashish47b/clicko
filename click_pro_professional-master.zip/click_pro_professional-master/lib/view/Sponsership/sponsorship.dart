
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/Sponsership/list_sponsorship.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import 'add-sponsership.dart';

class Sponsorship extends StatefulWidget {
  const Sponsorship({super.key});

  @override
  State<Sponsorship> createState() => _SponsorshipState();
}

class _SponsorshipState extends State<Sponsorship> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
          appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          centerTitle: true,
          title: Text("SPONSORSHIP".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
          iconTheme: IconThemeData(color: Colors.black),
        ),
        body: DefaultTabController(length: 2, child: 
            Column(
              children: [
               Divider(color: Colors.grey,),
              Container(
                 height: 50,
                decoration: BoxDecoration(
               //color: primaryColor
               ),
               child: TabBar(tabs: [
                   Text("Pending".tr(), style: AppTextStyles.k14TextN,),
                  Text("Accepted".tr(), style: AppTextStyles.k14TextN,),
                   
               //  Text("DisApproved")
               ],indicatorColor: AppColor.appThemeColorOrange,
                  isScrollable: false,automaticIndicatorColorAdjustment: true,
                 unselectedLabelColor: Colors.black54,
                 labelColor: AppColor.appThemeColorOlive,
                 physics: NeverScrollableScrollPhysics(),
                 indicator: UnderlineTabIndicator(
                 borderSide: BorderSide(color: AppColor.appThemeColorOlive, width: 4.0),
                 //insets: EdgeInsets.fromLTRB(50.0, 0.0, 50.0, 40.0),
        
                ),onTap: (val){
                  print(val);
                  // tabIndex = val;
                  // skipValue = 1;
                  },
      
             ),
          ),
         Expanded(child: TabBarView(children: [
          SponsorshipList(tabIndex: "0",),
          SponsorshipList(tabIndex:"1"),
         
         ]))
          
        ],
             )),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColor.appThemeColorOlive,
        onPressed: (){
          navigateWithPageTransition(context, AddSponsership());
        },
        child: Icon(Icons.add),
      ),
    );
  }

}