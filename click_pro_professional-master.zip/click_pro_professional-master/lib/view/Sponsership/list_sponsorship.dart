
import 'package:clik_pro_professional/view/Sponsership/item_sponsorpship.dart';
import 'package:flutter/material.dart';

class SponsorshipList extends StatefulWidget {
final tabIndex;

SponsorshipList({this.tabIndex});

  @override
  State<SponsorshipList> createState() => _SponsorshipListState();
}

class _SponsorshipListState extends State<SponsorshipList> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 4,
      itemBuilder: (context,index){
        return SponsorshipItem(tabIndex: widget.tabIndex,);
      },
    );
  }
}