
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class AddSponsership extends StatefulWidget {
  const AddSponsership({super.key});

  @override
  State<AddSponsership> createState() => _AddSponsershipState();
}

class _AddSponsershipState extends State<AddSponsership> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
          appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          centerTitle: true,
          title: Text("Fill Details".tr(),style: AppTextStyles.k18TextH.copyWith(color: Colors.black),),
          iconTheme: IconThemeData(color: Colors.black),
        ),
        body: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          children: [
                     getTextFieldTextType("Enter Name".tr(),"Enter Name".tr()),
                     SizedBox(height: _size!.height*0.02),
                     getTextFieldTextType("Enter Phone".tr(),"Enter Phone".tr()),
                     SizedBox(height: _size!.height*0.02),
                     getTextFieldTextType("Business Type".tr(),"Business Type".tr()),
                    
                     SizedBox(height: _size!.height*0.02),
                     getTextFieldTextType("Amount".tr(),"Amount".tr()),
                      SizedBox(height: _size!.height*0.02),
                     Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                       children: [
                         Container(
                          
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: AppColor.appThemeColorOlive,
                            borderRadius: BorderRadius.circular(10)
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.add_box_outlined,color: Colors.white),
                              SizedBox(width: 5),
                              Text("Attach File".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                            ],
                          ),
                         ),
                       ],
                     ),
                    // getTextFieldTextType("Description".tr(),"Description".tr(),maxLines: 4),
          ],
        ),
        bottomNavigationBar:Container(
          margin: const EdgeInsets.symmetric(horizontal: 16,vertical: 12),
                      height: _size!.height*0.05,
                      decoration: BoxDecoration(
                        color: AppColor.appThemeColorOlive,
                       // border: Border.all(color: AppColor.appThemeColorOlive),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                         
                          Text("SUBMIT".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white,fontWeight: FontWeight.w600),),
                        ],
                      ),
                     ),
    );
  }
}