 import 'dart:convert';
import 'dart:io';

import 'package:clik_pro_professional/model/Appointment%20Mdel/appointment_model.dart';
import 'package:clik_pro_professional/model/CategoryModel/category_model.dart';
import 'package:clik_pro_professional/model/ChatUsers/all_messages.dart';
import 'package:clik_pro_professional/model/ChatUsers/chat_user_list.dart';
import 'package:clik_pro_professional/model/CityModel/city_model.dart';
import 'package:clik_pro_professional/model/InvoiceModel/invoice_list.dart';
import 'package:clik_pro_professional/model/InvoiceModel/view_invoice_model.dart';
import 'package:clik_pro_professional/model/JobModel/job_data_model.dart';
import 'package:clik_pro_professional/model/MaterialModel/material_Model.dart';
import 'package:clik_pro_professional/model/NegotiationList/negotation_list.dart';
import 'package:clik_pro_professional/model/ProSearchDataModel.dart';
import 'package:clik_pro_professional/model/ProfileDataModel/profile_data_model.dart';
import 'package:clik_pro_professional/model/QuoteModel/quote_model.dart';
import 'package:clik_pro_professional/model/QuoteModel/view_quote_model.dart';
import 'package:clik_pro_professional/model/SubscriptionModel/subscription_list_model.dart';
import 'package:clik_pro_professional/model/UserMOdel/user_model.dart';
import 'package:clik_pro_professional/res/api.dart';
import 'package:clik_pro_professional/res/sp_keys.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/view/AppliedJobs/negotiation_page.dart';
import 'package:clik_pro_professional/view/Auth/verify_otp.dart';
import 'package:clik_pro_professional/view/BottomNavBar/bottomNavbar.dart';
import 'package:clik_pro_professional/view/ProfilePage/personal_info.dart';
import 'package:clik_pro_professional/view/Quote/send_quote.dart';
import 'package:clik_pro_professional/widgets/Account_verify_dialog.dart';
import 'package:clik_pro_professional/widgets/verify_success.dart';
import 'package:easy_localization/easy_localization.dart';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../model/JobModel/job_status_model.dart';

class UserProvider extends ChangeNotifier{

 String? userName;
 String? userEmail;
 String? userPhone;
 String?userToken;
 String?userID;
 bool? isLoading =false;
 String?userVerify;

 UserProvider(){
  laodSPDATA();
 }

 setLoader(val){
  isLoading = val;
  notifyListeners();
 }


 void laodSPDATA()async {    
   try {
      var sharedPreference = await SharedPreferences.getInstance();
      if (!["", null].contains(sharedPreference.getString(SPData.USER_EMAIL))) {
        userEmail = sharedPreference.getString(SPData.USER_EMAIL);
      }
      if (!["", null].contains(sharedPreference.getString(SPData.USER_TOKEN))) {
        userToken = sharedPreference.getString(SPData.USER_TOKEN);
      }
      if (!["", null].contains(sharedPreference.getString(SPData.USER_PHONE))) {
        userPhone = sharedPreference.getString(SPData.USER_PHONE);
      }
      if (!["", null].contains(sharedPreference.getString(SPData.USER_NAME))) {
        userName = sharedPreference.getString(SPData.USER_NAME);
      }
      if (!["", null].contains(sharedPreference.getString(SPData.USER_ID))) {
        userID = sharedPreference.getString(SPData.USER_ID);
      }
      if (!["", null].contains(sharedPreference.getString(SPData.USER_VERIFY))) {
        userVerify = sharedPreference.getString(SPData.USER_VERIFY);
      }

    } catch (ex) {}
 //   print("USERID "+ userID!);+

     getCity();
     getCategory();
 }


 // register api
 UserData? userData;
 userRegister(BuildContext context,{String?first_name,String?last_name,String?email,String?phone,String?pass,String?confirmPass})async {
  try{
    userData = null;
    isLoading =true;
    notifyListeners();
   Map map = {
    "first_name": first_name,
    "last_name": last_name,
    "email": email,
    "password": pass,
    "conf_password": confirmPass,
    "phone": phone,
    "fcm_token": "eHV", "type": "1"
   };
   print(API.REGISTER);
   print(map);
   final response = await http.post(Uri.parse(API.REGISTER),body: jsonEncode(map));
   if(response.statusCode==200){
    print(response.body);
    var data = UserDataModel.fromJson(jsonDecode(response.body));
    if(data.status=="true"){  
      if(data.data!=null){
        userData = data.data!;
        SPData.saveStringValue(SPData.USER_NAME, userData!.name!);
        SPData.saveStringValue(SPData.USER_EMAIL, userData!.email!);
        SPData.saveStringValue(SPData.USER_PHONE, userData!.phone!);
        SPData.saveStringValue(SPData.USER_TOKEN, userData!.professionalToken!);
        SPData.saveStringValue(SPData.USER_ID, userData!.id!);
        SPData.saveStringValue(SPData.USER_VERIFY, userData!.emailVerification!);
        laodSPDATA();
        navigateWithPageTransition(context, VerifyOTP());
      }
       showToastMsg("User Register Successfully".tr());
    }else{
      showToastMsg(data.message!.toString());
    }
   }
  }catch(e){
    print(e);
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 // verify otp 
 verifyOtp(BuildContext context,{String?otp})async {
  try{
    isLoading=true;
    notifyListeners();
    print(API.VERIFY);
    Map map = {
     "user_id": userID, "type": "1","otp":otp
    };
    print(map);
    final response = await http.post(Uri.parse(API.VERIFY), body: jsonEncode(map),
    headers: {
        "content-type": "application/json",
        'Authorization': 'Bearer $userToken',
    });
    if(response.statusCode==200){
      print(response.body);
      var data = jsonDecode(response.body);
      if(data['status'] == "true"){
        navigatetoAnotherPage(context, VerifySuccessWidget());
      }
    }

  }catch(e){
    print(e.toString());
  }finally{
    isLoading= false;
    notifyListeners();
  }
 }

 List<MaterialModel> userMaterialModelList = [];
 setUserMaterialModelList(MaterialModel obj){
    userMaterialModelList.add(obj);
 }

 // login api 
  UserData? loginData;
 loginAPi(BuildContext context,{String?email,String?pass})async {
  try{
    userData = null;
    isLoading =true;
    notifyListeners();
   Map map = {
    "email": email, "password": pass, "fcm_token": "e", "type": "1"};
   print(API.LOG_IN);
   print(map);
   final response = await http.post(Uri.parse(API.LOG_IN),body: jsonEncode(map));
   if(response.statusCode==200){
    print(response.body);
    var data = UserDataModel.fromJson(jsonDecode(response.body));
    if(data.status=="true"){  
      if(data.data!=null){
        loginData = data.data!;
        SPData.saveStringValue(SPData.USER_NAME, loginData!.name!);
        SPData.saveStringValue(SPData.USER_EMAIL, loginData!.email!);
        SPData.saveStringValue(SPData.USER_PHONE, loginData!.phone!);
        SPData.saveStringValue(SPData.USER_TOKEN, loginData!.professionalToken!);
        SPData.saveStringValue(SPData.USER_ID, loginData!.id!);
        SPData.saveStringValue(SPData.USER_VERIFY, loginData!.emailVerification!);
        laodSPDATA();
        if(loginData!.emailVerification=="1"){
             navigatetoAnotherPage(context, BottomNavBar(0));
        }else{
            showDialog(context: context,
             barrierDismissible: false, builder: (val){
              
              return AccountVerifyDialog();
             });
        }
      }
       showToastMsg("User Login Successfully".tr());
    }else{
      showToastMsg(data.message!.toString());
    }
   }
  }catch(e){
    print(e);
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 // 
 logOut(BuildContext context)async{
  try{
    isLoading=false;
    notifyListeners();
    print(API.LOG_OUT);
    Map map = {
      "user_tocken": userToken,
      "u_id":userID,
      "type":"1",
      "log_time":DateTime.now().toString()
    };
    final response = await http.post(Uri.parse(API.LOG_OUT),body: jsonEncode(map));
    print(map);
    print(response.body);
    if(response.statusCode==200){
      var data = jsonDecode(response.body);
      if(data['status']=="true"){
        print("logout");
        logout(context);
      }
    }

  }catch(e){
    print(e.toString());
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 // generate otp
 generateOtp(BuildContext context)async{
  try{
    isLoading=true;
    notifyListeners();
    Map map = {"user_id": userID, "type": "1"};
    print(API.GENERATE_OTP);
    print(map);
    final response = await http.post(Uri.parse(API.GENERATE_OTP), body: jsonEncode(map), );
    if(response.statusCode==200){
      print(response.body);
      var data = jsonDecode(response.body);
      if(data['status'] == "true"){
        showToastMsg(data['message']);
       navigatetoAnotherPage(context, VerifyOTP());
      }else{
         showToastMsg(data['message']);
      }
    }
  }catch(e){
    print(e.toString());
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 // get city
 List<CityData> cityList = [];
 getCity()async {
  try{
    isLoading=true;
    cityList.clear();
    notifyListeners();
    final response = await http.post(Uri.parse(API.CITY_DATA));
    if(response.statusCode==200){
      print(response.body);
      var data = CityDataModel.fromJson(jsonDecode(response.body));
      if(data.status=="true"){
        if(data.data!=null && data.data!=null){
          cityList.addAll(data.data!);
          print("cityList >> "+ cityList.length.toString());
        }
      }
    }

  }catch(e){
    print(e.toString());
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }
  
   // get category
 List<CategoryData> categoryList = [];
 getCategory()async {
  try{
    isLoading=true;
    categoryList.clear();
    notifyListeners();
    final response = await http.post(Uri.parse(API.CATEGORY_DATA));
    if(response.statusCode==200){
      print(response.body);
      var data = CategoryDataModel.fromJson(jsonDecode(response.body));
      if(data.status=="true"){
        if(data.data!=null && data.data!=null){
          categoryList.addAll(data.data!);
          print("categoryList >> "+ cityList.length.toString());
        }
      }
    }

  }catch(e){
    print(e.toString());
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 // job api
 JobsData?jobData;
 getJObs({int?limit})async {
  try{
    isLoading =true;
    notifyListeners();
    
    print(API.JOB_API);
    var request = http.MultipartRequest("POST", Uri.parse(API.JOB_API));
    request.fields["limit"] =limit!=null?limit.toString(): "1";

    var responsedData = await request.send();
    if (responsedData.statusCode == 200) {
    } else if (responsedData.statusCode == 422 /*&& data!=null*/) {
      // showTostMsg(data["message"]);
    } else {
      showToastMsg("Something went wrong".tr());
    }

    responsedData.stream.transform(utf8.decoder).transform(LineSplitter()).listen((value) { 
    print(value);
     var data = JobsDataModel.fromJson(jsonDecode(value));
     if(responsedData.statusCode==200){
      if(data.status=="true"){
           jobData = null;
         jobData = data.data;
        notifyListeners();
      }else{
        showToastMsg("No Data");
      }
     }
    });
    
  }catch(e){
    print(e);
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 // view jobs 
 viewJobs(job_id)async {
  try{
    isLoading=true;
    notifyListeners();
    print(API.VIEW_JOB_API);
    Map map = {"id":job_id};
    final response = await http.get(Uri.parse(API.VIEW_JOB_API));

  }catch(e){
    print(e.toString());
  }finally{
    isLoading = false;
    notifyListeners();
  }
 }

 //
  saveQuotation(BuildContext context, SaveQuotationModel model,{String?edit_id})async {
  try{
    isLoading =true;
    notifyListeners();
    print(API.SAVE_QUOTATION);
    var request = http.MultipartRequest("POST", Uri.parse(API.SAVE_QUOTATION));
    request.fields["edit_id"] = edit_id!=null?edit_id:"";
    request.fields["job_id"] = model.jobId!;
    request.fields["estimate_price"] = model.estimatePrice!;
    request.fields["estimate_project_time"] = model.estimateProjectTime!;
    request.fields["cover_description"] = model.coverDescription!;
    request.fields["instalment_plan"] = model.instalmentPlan!;
    request.fields["work_start_date"] = model.workStartDate!;
    request.fields["work_end_date"] = model.workEndDate!;
    request.fields["comment"] = model.comment!;
    request.fields["material_details"] = jsonEncode(model.materialList!);
    request.fields["userId"] = userID!;
    request.fields["total"] = model.total!;
    request.fields["total_tax"] =model.totalTax!;
    request.fields["grand_total"] = model.grandTotal!;
    request.fields["grand_total_estimate_price"] = model.grandTotalEstimatePrice!;
    // request.fields["versement_amount1"] = model.versement_amount1!;
    // request.fields["versement_amount2"] = model.versement_amount2!;
    // request.fields["versement_amount3"] = model.versement_amount3!;
    // request.fields["versement_amount4"] = model.versement_amount4!;
    // request.fields["versement_amount5"] = model.versement_amount5!;
    // request.fields["versement_date1"] = model.versement_date1!;
    // request.fields["versement_date2"] = "";
    // request.fields["versement_date3"] = "";
    // request.fields["versement_date4"] = "";
    // request.fields["versement_date5"] = "";
    request.fields['versement_date_amount'] = jsonEncode(model.installPlanValueList!);
    request.fields['cust_id']= model.cust_id!;
    
    print(request.fields);
    var responsedData = await request.send();
    if (responsedData.statusCode == 200) {
    } else if (responsedData.statusCode == 422 /*&& data!=null*/) {
      // showTostMsg(data["message"]);
    } else {
      showToastMsg("Something went wrong".tr());
    }

    responsedData.stream.transform(utf8.decoder).listen((value) { 
    print(value);
     var data = jsonDecode(value);
     if(responsedData.statusCode==200){
      if(data["status"]==true){
        
        showToastMsg("Save Quotation Successfully".tr());
        Navigator.pop(context);
         getJObs();
      }else{
        showToastMsg(data['message']);
      }
     }
    });
    
  }catch(e){
    print(e);
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 // view profile
 ProfileData? profileData;
 profileList()async {
  try{
    isLoading=true;
    profileData = null;
    notifyListeners();
    print(API.PROFF_PROFILE);
    Map map = {"user_id":userID};
    final response = await http.post(Uri.parse(API.PROFF_PROFILE), body: jsonEncode(map));
    print(map);
    if(response.statusCode==200){
      print(response.body);
      var data = ProfileDataModel.fromJson(jsonDecode(response.body));
      if(data.status=="true"){
         if(data.data!=null){
           profileData=data.data;
           print("subscriptionPlanId "+profileData!.subscriptionPlanId!);
         }
      }
    }

  }catch(e){
    print(e.toString());
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 // rating 
 String? ratingBar="0";
 getRatings()async {
  try{
    isLoading=true;
    notifyListeners();
    print(API.GET_RATING);
    Map map = {
      "user_id": userID, "type": "1","prof_id":userID
    };
    final response = await http.post(Uri.parse(API.GET_RATING), body: jsonEncode(map));
    print(map);
    if(response.statusCode==200){
      print(response.body);
      var data = jsonDecode(response.body);
      if(data['status']=="true"){
        ratingBar = data["data"];
      }
    }

  }catch(e){
    print(e.toString());
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 // pending quote 
 List<QuoteData> pendingQuoteList=[];
 pendingQuote({int?limit})async {
  try{
    isLoading=true;
    notifyListeners();
    if(limit==1){
      pendingQuoteList.clear();
    }
    print(API.PENDING_QUOTE);
    Map map = {"user_id": userID,"prof_id": userID, "type": 1,"job_id":"","limit":limit!=null?limit.toString():"1"};
    final response = await http.post(Uri.parse(API.PENDING_QUOTE),body:jsonEncode(map));
    print(map);
    print(response.body);
    if(response.statusCode==200){
      print(response.body);
     var data = QuoteModelData.fromJson(jsonDecode(response.body));
     if(data.status=="true"){
      if(data.data!=null && data.data!.length>0){
         pendingQuoteList.addAll(data.data!);
      }
     }
    }
  }catch(e){
    print(e.toString());
  }finally{
    isLoading = false;
    notifyListeners();
  }
 }

 // active 
List<QuoteData> activeQuoteList=[];
 activeQuote({int?limit})async {
  try{
    isLoading=true;
    notifyListeners();
    if(limit==1){
      activeQuoteList.clear();
    }
    print(API.ACTIVE_QUOTE);
    Map map = {"user_id": userID,"prof_id": userID, "type": 1,"job_id":"","limit":limit!=null?limit.toString():"1"};
    final response = await http.post(Uri.parse(API.ACTIVE_QUOTE),body:jsonEncode(map));
    print(map);
    print(response.body);
    if(response.statusCode==200){
      print(response.body);
     var data = QuoteModelData.fromJson(jsonDecode(response.body));
     if(data.status=="true"){
      if(data.data!=null && data.data!.length>0){
         activeQuoteList.addAll(data.data!);
      }
     }
    }
  }catch(e){
    print(e.toString());
  }finally{
    isLoading = false;
    notifyListeners();
  }
 }

 // reject
  List<QuoteData> rwjetcQuoteList=[];
 rejextQuote({int?limit})async {
  try{
    isLoading=true;
    notifyListeners();
    if(limit==1){
      rwjetcQuoteList.clear();
    }
    print(API.REJECT_QUOTE);
    Map map = {"user_id": userID,"prof_id": userID, "type": 1,"job_id":"","limit":limit!=null?limit.toString():"1"};
    final response = await http.post(Uri.parse(API.REJECT_QUOTE),body:jsonEncode(map));
    print(map);
    print(response.body);
    if(response.statusCode==200){
      print(response.body);
     var data = QuoteModelData.fromJson(jsonDecode(response.body));
     if(data.status=="true"){
      if(data.data!=null && data.data!.length>0){
         rwjetcQuoteList.addAll(data.data!);
      }
     }
    }
  }catch(e){
    print(e.toString());
  }finally{
    isLoading = false;
    notifyListeners();
  }
 }


  // 
  ViewQuoteData? viewQuoteData;
  ProffUserData?prof_Data;
  viewQuote({quot_id})async {
    try{
      isLoading = true;
      notifyListeners();
      viewQuoteData=null;
      print(API.VIEW_QUOTATION);
      Map map  = {"quot_id":quot_id};
      final response = await http.post(Uri.parse(API.VIEW_QUOTATION),body: jsonEncode(map));
      print(map);
      print(response.body);
      if(response.statusCode==200){
        print(response.body);
        var data =  ViewQuoteDataModel.fromJson(jsonDecode(response.body));
        if(data.status=="true"){
          if(data.data!=null){
            viewQuoteData = data.data!;
          }
          if(data.prof_userData!=null){
            prof_Data = data.prof_userData!;
          }
        }
      }

    }catch(e){
      print(e.toString());
    }finally{
      isLoading = false;
      notifyListeners();
    }
  }


  // job status 
  List<JobStatusData> pendingJobsList = [];
  List<JobStatusData> activeJobsList = [];
  List<JobStatusData> hiringJobsList = [];
  List<JobStatusData> completeJobsList = [];
  jobStausApi({int?limit})async{
   try{
    isLoading = true;
    notifyListeners();
    if(limit==1){
      pendingJobsList.clear();
      activeJobsList.clear();
      hiringJobsList.clear();
      completeJobsList.clear();
    }
    print(API.JOB_STATUS_API);
    Map map = {"user_id":userID, "limit":limit!=null?limit:1};
    final response = await http.post(Uri.parse(API.JOB_STATUS_API), body: jsonEncode(map));
    print(map);
    if(response.statusCode==200){
      print(response.body);
      var data = JobStatusDataModel.fromJson(jsonDecode(response.body));
      if(data.status=="true"){
        if(data.data!=null){
          if(data.data!.pendingJobs!=null && data.data!.pendingJobs!.length>0){
              pendingJobsList.addAll(data.data!.pendingJobs!);
              print("LEnght of pending jobs >> " + pendingJobsList.length.toString());
          }
          if(data.data!.activeJobs!=null && data.data!.activeJobs!.length>0){
              activeJobsList.addAll(data.data!.activeJobs!);
              print("LEnght of active jobs >> " + activeJobsList.length.toString());
          }
          if(data.data!.hiringJobs!=null && data.data!.hiringJobs!.length>0){
              hiringJobsList.addAll(data.data!.hiringJobs!);
              print("LEnght of hiring jobs >> " + hiringJobsList.length.toString());
          }
          if(data.data!.completedJobs!=null && data.data!.completedJobs!.length>0){
              completeJobsList.addAll(data.data!.completedJobs!);
              print("LEnght of complete jobs >> " + completeJobsList.length.toString());
          }
        }

      }
    }

   }catch(e){
    print(e.toString());
   }finally{
    isLoading=false;
    notifyListeners();
   }
  }
  

  // 
  doCompleteJob(String?jobId)async {
    try{
      isLoading = true;
      notifyListeners();
      print(API.COMPLETE_JOB);
      Map map = {
       "job_id":jobId,"userId":userID
      };

      final response = await http.post(Uri.parse(API.COMPLETE_JOB),body: jsonEncode(map));
      print(map);
      if(response.statusCode==200){
        print(response.body);
        var data = jsonDecode(response.body);
        if(data['status'] == true){
          showToastMsg("Successfully!!".tr());
          jobStausApi(limit: 1);
          //showToastMsg(data['data'])
        }
      }

    }catch(e){
      print(e.toString());
    }finally{
      isLoading = false;
      notifyListeners();
    }
  }

  // invoice list 
  InvoiceDataListModel? invoiceDataListModel;
  List<InvoiceDataList> invoiceList = [];
  getInvocie()async {
    try{
      notifyListeners();
      isLoading=true;
      invoiceList.clear();
      invoiceDataListModel=null;
      print(API.INVOICE_LIST);
      Map map = {"job_id":"","userId":userID,"search":"","created_date":"","limit":"1"};
      final response = await http.post(Uri.parse(API.INVOICE_LIST), body: jsonEncode(map));
      print(map);
      if(response.statusCode==200){
        print(response.body);
        var data = InvoiceDataListModel.fromJson(jsonDecode(response.body));
        if(data.status=="true"){
          invoiceDataListModel = data;
          if(data.data!=null && data.data!.length>0){
            invoiceList.addAll(data.data!);
          }
        }
      }


    }catch(e){
      print(e.toString());
    }finally{
      isLoading = false;
      notifyListeners();
    }
  }
  ViewInvoiceData? viewInvoiceData;
  ViewInvoiceCusData? viewInvoiceCusData;
  ViewInvoiceProData?viewInvoiceProData;
  ViewInvoiceJobData?viewInvoiceJobData;
  viewInvoices(String?invc_id)async {
    try{
      isLoading=true;
      notifyListeners();
      print(API.VIEW_INVOICE);
      Map map = {"invc_id":invc_id};
      final response = await http.post(Uri.parse(API.VIEW_INVOICE),
      body: jsonEncode(map));
      print(map);
      print(response.body);
      if(response.statusCode==200){
        print(response.body);
        var data = ViewInvoiceDataModel.fromJson(jsonDecode(response.body));
        if(data.status=="true"){
          if(data.data!=null){
            viewInvoiceData = data.data!;
          }
          if(data.proData!=null){
            viewInvoiceProData = data.proData!;
          }
          if(data.cusData!=null){
            viewInvoiceCusData = data.cusData!;
          }
          if(data.jobData!=null){
            viewInvoiceJobData = data.jobData!;
          }
        }
        else{

        }
      }

    }catch(e){
      print(e.toString());
    }finally{
      isLoading=false;
      notifyListeners();
    }
  }

  // subscriptionList 
  List<SubscriptionListData> subscribeList = [];
    List<SubscriptionListData>? monthList=[];
  List<SubscriptionListData>? yearList=[];
  subscriptionList()async {
    try{
      isLoading=true;
      notifyListeners();
      subscribeList.clear();
      monthList!.clear();
      yearList!.clear();
      print(API.SUBSCRIPTION_LIST);
      final response = await http.post(Uri.parse(API.SUBSCRIPTION_LIST));
      if(response.statusCode==200){
        print(response.body);
        var data = SubscriptionListDataModel.fromJson(jsonDecode(response.body));
        if(data.status=="true"){
          if(data.data!=null && data.data!.length>0){
              subscribeList.addAll(data.data!);
              data.data!.forEach((v){
                if(v.subscriptionType=="monthly"){
                  monthList!.add(v);
                }
              });

              data.data!.forEach((v){
                if(v.subscriptionType=="yearly"){
                  yearList!.add(v);
                }
              });
            

    // if(json['Data'] != null){
    //   data = <SubscriptionListData>[];
    //   data!.forEach((v){
    //     if(v.subscriptionType=="yearly"){
    //       monthList!.add(v);
    //     }
    //   });
    // }
          }
        }
      }

    }catch(e){
      print(e.toString());
    }finally{
      isLoading=false;
      notifyListeners();
    }
  }
  
 // negotiation list 
 List<Negotiation> negotiationList = [];
 Quot? quote;
 negotiationListAPI({String?quote_id})async {
  try{
    isLoading=true;
    notifyListeners();
    print(API.NEGOTIATION_LIST);
    quote=null;
    negotiationList.clear();
    Map map = {"quot_id":quote_id};
    final response = await http.post(Uri.parse(API.NEGOTIATION_LIST),body: jsonEncode(map));
    print(map);
    if(response.statusCode==200){
      print(response.body);
      var data = NegotiationList.fromJson(jsonDecode(response.body));
      if(data.status=="true"){
        if(data.negotiation!=null && data.negotiation!.length>0){
         negotiationList.addAll(data.negotiation!);
        }
        if(data.quot!=null){
          quote = data.quot;
        }
      }
    }

  }catch(e){
    print(e.toString());
  }finally{
    isLoading = false;
    notifyListeners();
  }
 }


 //
  saveProfile(BuildContext context, SavePorfileData model,{String?from})async {
  try{
    isLoading =true;
    notifyListeners();
    print(API.SAVE_PROFILE);
    var request = http.MultipartRequest("POST", Uri.parse(API.SAVE_PROFILE));
    request.fields["userId"] = userID!;
    request.fields["first_name"] = model.firstName!;
    request.fields["last_name"] = model.lastName!;
    request.fields["phone"] = model.phoneNumber!;
    request.fields["gender"] = model.gender!;
    request.fields["city_id"] = model.city_id!;
    request.fields["description"] = model.description!;
    request.fields["proof_accept_travel_city"] = model.proof_accept_travel_city!;
    request.fields["website"] = model.website!;
    request.fields["work_history"] = model.work_history!;
    request.fields["siren_or_siret_no"] = model.siren_or_siret_no!;
    request.fields["rcs_no"] = model.rcs_no!;
    request.fields["category_details"] = jsonEncode(model.categoryDetailsList!);
    request.fields["company_details"] = jsonEncode(model.companYdetails!);
    // request.fields["profile_pic"] = model.profile_pic!;
    // request.fields["certificate"] = jsonEncode(model.certificateList!);
    // request.fields["previous_work_done_file"] = jsonEncode(model.previous_work_done_file!);
    print(request.fields);
    print(model.profile_pic!);
    print(jsonEncode(model.certificateList));
    print(jsonEncode(model.previous_work_done_file));
    if(model.profile_pic!=null && model.profile_pic!=""){
      print("PROFILE >>" + model.profile_pic!);
      request.files.add(await http.MultipartFile('profile_pic',
                await new http.ByteStream(File(model.profile_pic!).openRead()),
                await File(model.profile_pic!).length(),
                filename: model.profile_pic!
                    .split("/")
                    .last)
            );
    }
     if (model.certificateList!.length > 0) {
        model.certificateList!.forEach((element) async {
          request.files.add(await http.MultipartFile(
              'certificate[]',
              await new http.ByteStream(File(element).openRead()),
              await File(element).length(),
              filename: element.split("/").last));
        });
      }

      if (model.previous_work_done_file!.length > 0) {
        model.previous_work_done_file!.forEach((element) async {
          request.files.add(await http.MultipartFile(
              'previous_work_done_file[]',
              await new http.ByteStream(File(element).openRead()),
              await File(element).length(),
              filename: element.split("/").last));
        });
      }

    var responsedData = await request.send();
    if (responsedData.statusCode == 200) {
    } else if (responsedData.statusCode == 422 /*&& data!=null*/) {
      // showTostMsg(data["message"]);
    } else {
      showToastMsg("Something went wrong".tr());
    }

    responsedData.stream.transform(utf8.decoder).listen((value) { 
    print(value);
     var data = jsonDecode(value);
     if(responsedData.statusCode==200){
      if(data["status"]=="true"){
        
        showToastMsg("Save Profile Successfully".tr());
        if(![null,""].contains(from)){
          navigatetoAnotherPage(context, BottomNavBar(0));
        }else{
             Navigator.pop(context);
        }
     
         profileList();
         getJObs();
      }else{
        showToastMsg(data['message']);
      }
     }
    });
    
  }catch(e){
    print(e);
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }
 SubscriptionListData? userSelectedPlan;
 selectedPlan(SubscriptionListData? obj){
   userSelectedPlan = obj;
   notifyListeners();
 }
 // save negotation

saveNegotiation(BuildContext context, SaveNegotiationData model)async {
  try{
    isLoading=true;
    
    print(API.SAVE_NEGOTIATION);
    var request = http.MultipartRequest("POST", Uri.parse(API.SAVE_NEGOTIATION));
    request.fields["quote_id"] = model.quote_id!;
    request.fields["job_id"] = model.jobId!;
    request.fields["estimate_price"] = model.estimate_price!;
    request.fields["userId"] = model.userId!;
    request.fields["milestone"] = model.milestone!;
    request.fields["cust_id"] = model.cust_id!;
    request.fields["negotiation_data"] = jsonEncode(model.negotiationData!);

    
    print(request.fields);
    var responsedData = await request.send();
    if (responsedData.statusCode == 200) {
    } else if (responsedData.statusCode == 422 /*&& data!=null*/) {
      // showTostMsg(data["message"]);
    } else {
      showToastMsg("Something went wrong".tr());
    }

    responsedData.stream.transform(utf8.decoder).listen((value) { 
    print(value);
     var data = jsonDecode(value);
     if(responsedData.statusCode==200){
      if(data["status"]=="true"){
        showToastMsg("Save Negotiation Successfully".tr());
        navigatetoAnotherPage(context, BottomNavBar(0));
      }
     }
    });
    
  }catch(e){
    print(e);
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

   // chat users 
  List<ChatUser> chatUserList = [];
  chatUser()async {
    try{
      isLoading=false;
      chatUserList.clear();
      notifyListeners();
      print(API.CHAT_USER);
      Map map = {"user_type":"1"};
      final response = await http.post(Uri.parse(API.CHAT_USER), body: jsonEncode(map));
      print(map);
      if(response.statusCode==200){
        print(response.body);
       var data = ChatUserListDataModel.fromJson(jsonDecode(response.body));
       if(data.status=="true"){
        if(data.data!.users!=null && data.data!.users!.length>0){
           chatUserList.addAll(data.data!.users!);
        }
       }

      }

    }catch(e){
      print(e.toString());
    }finally{
      isLoading=false;
      notifyListeners();
    }
  }


 // all chat message
 List<ChatMessage> messageList = [];
 allMessage(String?custID)async {
  try{
    isLoading = true;
    notifyListeners();
    messageList.clear();
    print(API.ALL_CHAT_MESSAGE);
    Map map = {
      "user_type":"1","cust_id":custID,"userId":userID
    };
    final response = await http.post(Uri.parse(API.ALL_CHAT_MESSAGE),body: jsonEncode(map));
    print(map);
    if(response.statusCode==200){
      print(response.body);
      var data = AllMessageListDataModel.fromJson(jsonDecode(response.body));
      if(data.status=="true"){
        if(data.chatMessage!=null && data.chatMessage!.length>0){
          messageList.addAll(data.chatMessage!);
        }
      }
    }


  }catch(e){
    print(e.toString());
  }finally{
    isLoading = false;
    notifyListeners();
  }
 }

 createsubscription(data)async {
  try{
    isLoading = true;
    notifyListeners();
    messageList.clear();
    print(API.createsubscription);

    Map map =  {"plan_id":userSelectedPlan!.id!,"user_id":userID,"subscription_type": userSelectedPlan!.subscriptionType!,"payment_id":data.toString(),"amount":userSelectedPlan!.price};
    final response = await http.post(Uri.parse(API.createsubscription),body: jsonEncode(map));
    print(map);
    if(response.statusCode==200){
      print(response.body);
      var data = jsonDecode(response.body);
      if(data["status"]=="true") {
        profileList();
      }
    }
  }catch(e){
    print(e.toString());
  }finally{
    isLoading = false;
    notifyListeners();
  }
 }

 // add message
 addMessage(String?cust_id,String?message)async {
  try{
    isLoading=true;
    notifyListeners();
    print(API.ADD_CHAT_MESSAGE);
    Map map = {"user_type":"1","customer_id":cust_id,"userid":userID,"message":message};
    final response = await http.post(Uri.parse(API.ADD_CHAT_MESSAGE),body: jsonEncode(map));
    print(map);
    if(response.statusCode==200){
      print(response.body);
      var data = jsonDecode(response.body);
      if(data['status']=="true"){
        allMessage(cust_id);
      }
    }

  }catch(e){
    print(e.toString());
  }finally{
    isLoading = false;
    notifyListeners();
  }
 }


  // save appointment
saveAppointment(BuildContext context,{String?title,String?quote_id, String?appointmnet,String?date,String?time,String?desc,String?job_Id,String?attach_file})async {
  try{
    isLoading =true;
    notifyListeners();
    print(API.SAVE_APPOINTMENT);
    var request = http.MultipartRequest("POST", Uri.parse(API.SAVE_APPOINTMENT));
    request.fields["userId"] = userID!;
    request.fields["quot_id"] = quote_id!;
    request.fields["job_id"] = job_Id!;
    request.fields["title"] = title!;
    request.fields["add_apointment"] = appointmnet!;
    request.fields["date"] = date!;
    request.fields["time"] = "12:15";
    request.fields["description"] = desc!;
     if(attach_file!=null && attach_file!=""){
      print("ATTACH FILE >>" + attach_file);
      request.files.add(await http.MultipartFile('attachment',
                await  http.ByteStream(File(attach_file).openRead()),
                await File(attach_file).length(),
                filename: attach_file
                    .split("/")
                    .last)
            );
    }

    print(request.fields);
    var responsedData = await request.send();
    if (responsedData.statusCode == 200) {
    } else if (responsedData.statusCode == 422 /*&& data!=null*/) {
      // showTostMsg(data["message"]);
    } else {
      showToastMsg("Something went wrong");
    }

    responsedData.stream.transform(utf8.decoder).listen((value) { 
    print(value);
     var data = jsonDecode(value);
     if(responsedData.statusCode==200){
      if(data["status"]=="true"){
        
        showToastMsg("Save Appointmnet Successfully".tr());
        Navigator.pop(context);
        
      }else{
        showToastMsg(data['message']);
      }
     }
    });
    
  }catch(e){
    print(e);
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 // all appointmenty
 clearAppointmentList() async{
  appointmentList.clear();
  notifyListeners();
 }
 List<AppointmentListData> appointmentList = [];
 getAppointment({int?limit,String?tab})async {
  try{
    isLoading = true;
    notifyListeners();
    print(API.APPOINTMENT_List);
    Map map = {
      "userId":userID,"limit":"1","tab":tab
    };
    final response = await http.post(Uri.parse(API.APPOINTMENT_List), body: jsonEncode(map));
    print(map);
    if(response.statusCode==200){
      print(response.body);
      var data = AppointmentListDataModel.fromJson(jsonDecode(response.body));
      if(data.status=="true"){
        if(data.data!=null && data.data!.isNotEmpty){         
          appointmentList.addAll(data.data!);
          notifyListeners();
        }
      }
    }

  }catch(e){
    print(e.toString());
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }

 approveNegotiation(BuildContext context,{String?quote_id,String?status})async {
   try{
    isLoading=true;
    notifyListeners();
    print(API.APPROVE_REJ_NEGO);
    Map map = {
      "quot_id":quote_id,
      "status":status
    };
    final response = await http.post(Uri.parse(API.APPROVE_REJ_NEGO),body: jsonEncode(map));
    print(map);
    if(response.statusCode==200){
      print(response.body);
      var data = jsonDecode(response.body);
      if(data['status']=="true"){
        showToastMsg("Save Negotiation Successfully".tr());
        navigatetoAnotherPage(context, BottomNavBar(0));
      }else{
        showToastMsg("Something Wrong");
      }
    }

   }catch(e){
    print(e.toString());
   }
 }
 clearSearchData(){
   proSearchDataList.clear();
   notifyListeners();
 }
 List<ProSearchData> proSearchDataList = [];
 getProSearchData({String?cityID,String?catID})async {
  try{
    notifyListeners();
    isLoading=true;
    proSearchDataList.clear();
    print(API.PRO_SEARCH_JOB);
    Map map = {
      "locationid": cityID!=null?cityID:"",
      "cat_id":catID!=null?catID:"",
    };
    final response = await http.post(Uri.parse(API.PRO_SEARCH_JOB), body: jsonEncode(map));
    print(map);
    if(response.statusCode==200){
      print(response.body);
      var data = ProSearchDataModel.fromJson(jsonDecode(response.body));
      if(data.status=="true"){
        if(data.data!=null && data.data!.length>0){
           proSearchDataList.addAll(data.data!);
        }else if(data.data==false){
          showToastMsg("No Result".tr());
        }else{
          showToastMsg("No Result".tr());
        }
      }
    }
  }catch(e){
    print(e.toString());
  }finally{
    isLoading=false;
    notifyListeners();
  }
 }


}