

import 'package:clik_pro_professional/utils/app_color.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ShowDialogsss {
  //
  Future showDialogContainer(BuildContext context) {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[100],
        content: Row(
          children:const  [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(
                AppColor.appThemeColorOrange
              ),
            ),
            SizedBox(width: 18),
            Text(
              "Working....",
              style: TextStyle(
                color:   AppColor.appThemeColorOrange
              ),
            )
          ],
        ),
      ),
    );
  }

  // showSuccessDialog(BuildContext context) {
  //   return showDialog(
  //     context: context,
  //     builder: (context) => AlertDialog(
  //       backgroundColor: Colours.YELLOW_LIGHT,
  //       content: Row(
  //         children: [
  //           Image.asset(
  //             "images/Payment/Success.png",
  //             height: 50,
  //             width: 50,
  //           ),
  //           const SizedBox(width: 18),
  //           const Text(
  //             "Success",
  //             style: TextStyle(
  //               fontSize: 20,
  //               color: Colours.PRIMARY_BLUE,
  //             ),
  //           )
  //         ],
  //       ),
  //     ),
  //   );
  // }

  Widget exitDialog(BuildContext context, {String? text}) {
    return AlertDialog(
      title: const Text("Really ?"),
      content: const Text("Want to exit"),
      actions: [
        // text != null && text != "" && text == "Back"
        //     ? TextButton(
        //         onPressed: () {
        //           Navigator.pop(context);
        //           Navigator.pop(context);
        //         },
        //         child: const Text("Back"),
        //       )
        //     : Text(""),
        TextButton(
          onPressed: () {
            Navigator.of(context).pop(false);
          },
          child: const Text("Cancel"),
        ),
        TextButton(
          onPressed: () {
            SystemNavigator.pop();
          },
          child: const Text("Exit"),
        ),
      ],
    );
  }

  //
}