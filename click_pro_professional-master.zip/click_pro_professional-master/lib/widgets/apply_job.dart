import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/widgets/job_details_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class ApplyJobs extends StatefulWidget {
  const ApplyJobs({super.key});

  @override
  State<ApplyJobs> createState() => _ApplyJobsState();
}

class _ApplyJobsState extends State<ApplyJobs> {
  int selectedRadio=0;
  Size?_size;
  List<String> list=[
    "Small Project",
    "Service Delivery",
    "Major Project"
  ];
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.transparent,
        title: Text("Submit Proposal".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.black),),
        actions: [
          IconButton(onPressed: (){}, icon: Icon(Icons.more_vert))
        ],
       ),
       body: ListView(
        children: [
         
          Padding(
            padding:const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
             child: Text("Job Details".tr(),style: AppTextStyles.k18TextN,)
          ),
           SizedBox(height: _size!.height*0.01),
           Padding(
            padding:const EdgeInsets.symmetric(horizontal: 14,),
             child: Row(
               children: [
                 Text("You can check".tr(),style: AppTextStyles.k12TextN,),
                  SizedBox(width: 5,),
                 InkWell(
                  onTap: (){
                    navigateWithPageTransition(context, JobDetailsPage());
                  },
                  child: Text("here".tr(),style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive, decoration: TextDecoration.underline),)),
               ],
             ),
            
          ),
          SizedBox(height: _size!.height*0.02),
          Divider(color: Colors.grey),

           Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text("Total Amount".tr(),style: AppTextStyles.k18TextN,),
            
          ),
            Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text("\$60 ",style: AppTextStyles.k14TextN,),
            
          ),
          //SizedBox(height: _size!.height*0.02),
          Divider(color: Colors.grey),

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text("Select Payment".tr(),style: AppTextStyles.k18TextN,),
            
          ),
          ListView.builder(
            itemCount: list.length,
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemBuilder: (context,index){
            return Container(
              child: RadioListTile(
            title: Text(list[index].tr(), style: AppTextStyles.k14TextN,),
            value: index,
             groupValue: selectedRadio,
              onChanged: (val){
             selectedRadio = val!;
             setState(() {
               
             });

              }
            ),
            );
          }),
         
          SizedBox(height: _size!.height*0.02),
          ListView.builder(
            itemCount: selectedRadio==2?3:2,
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemBuilder: (context,index){
             return installmentBox(index+1);
          }),
           
          SizedBox(height: _size!.height*0.02),
          Divider(color: Colors.grey),
          
          Padding(
             padding:const EdgeInsets.symmetric(horizontal: 14,),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Other Details".tr(),style: AppTextStyles.k18TextN,),
                SizedBox(height: _size!.height*0.02),
                Text("Quote".tr(),style: AppTextStyles.k16TextN,),
                 SizedBox(height: _size!.height*0.01),
                getTextFieldTextType("Enter Details".tr(), "Enter Details".tr(), maxLines: 4),
                SizedBox(height: _size!.height*0.02),
                Text("Attachment".tr(),style: AppTextStyles.k16TextN,),
                 SizedBox(height: _size!.height*0.01),
                 Container(
                  padding: EdgeInsets.symmetric(vertical: 3, horizontal: 3),
                  //width: 120,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    border: Border.all(color: AppColor.appThemeColorOlive)
                  ),
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add, color: AppColor.appThemeColorOlive,),
                        Text("Attach Files".tr(),style: AppTextStyles.k14TextN,),
                      ],
                    ),
                  ),
                 )
              ],
            ),
          ),

          SizedBox(height: _size!.height*0.04,),
          
          // SizedBox(height: _size!.height*0.06,),
        ],
       ),
       bottomNavigationBar: Wrap(
        children: [
          Container(
            padding: EdgeInsets.symmetric(vertical: 5),
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: AppColor.appThemeColorOlive, 
              borderRadius: BorderRadius.circular(50)

            ),
            child: Center(
              child: Text("Submit".tr(), style: AppTextStyles.k18TextN.copyWith(color: Colors.white),),
            ),
          ),
        ],
       ),
    );
  }

  installmentBox(title){
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Amount ".tr() + title.toString(),style: AppTextStyles.k16TextN,),
          SizedBox(height: _size!.height*0.01),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10,vertical: 6),
              width: double.infinity,
              height: 35,
              decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(12),

              ),
             child: Text("\$20"),
            ),
        ],
      ),
    );
  }
  
 
}