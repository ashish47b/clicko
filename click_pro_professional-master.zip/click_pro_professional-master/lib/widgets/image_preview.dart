import 'package:flutter/material.dart';

class ImagePreviewScreen extends StatelessWidget {
  String?path;
  ImagePreviewScreen({this.path});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: InkWell(
        onTap: ()=>Navigator.pop(context),
        child: Center(
          child: Hero(
            tag: 'imageHero',
            child: InteractiveViewer(
              //panEnabled: false, // Set it to false
              boundaryMargin: EdgeInsets.all(20),
              minScale: 0.5,
              maxScale: 4,scaleEnabled: true,
              child: Image.network(
                path!,
              ),
            ),
          ),
        ),
      ),
    );
  }
}