import 'package:flutter/material.dart';

class FadeImageWithError extends StatelessWidget {
  String? imgPath;
  BoxFit? fit;
  double? height;
  FadeImageWithError({this.imgPath,this.fit,this.height});
  @override
  Widget build(BuildContext context) {
    return FadeInImage.assetNetwork(
        placeholder: 'assets/icons/no_image.png',
        image: imgPath!,
        fit: fit!=null?fit:BoxFit.cover,
        height: height!=null?height:null,
        imageErrorBuilder:
            (BuildContext? context, Object? exception, StackTrace? stackTrace) {
          return Image.asset('assets/icons/no_image.png',fit: fit!=null?fit:BoxFit.cover);
        }
    );
  }
}
