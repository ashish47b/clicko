
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

class LanguageDialogBox extends StatelessWidget {


  List<String> list = ["ENGLISH", "FRENCH(FRANÇAISE)"];
  int selectRadio = 0;

  @override
  Widget build(BuildContext context) {
    return StatefulBuilder(builder: (context,myState){
        return AlertDialog(
                    title: Text("Choose Language".tr(), style: AppTextStyles.k18TextN,),
                    content: Wrap(
                      children: [
                        for(int i=0;i<list.length;i++)
                        RadioListTile(
                                title: Text(list[i], style: AppTextStyles.k14TextN,),
                                value: i,
                                 groupValue: selectRadio,
                        onChanged: (val){
                                 selectRadio = val!;
                          myState(() {
                            
                          });
              
                        }
                                )
                      ],
                    ),
                    actions: [
                      InkWell(
                        onTap: (){
                          if(selectRadio==0){
                              context.locale =const Locale('en', 'US');
                          Navigator.pop(context);
                          }else {
                              context.locale =const Locale('fr', 'BE');
                          Navigator.pop(context);
                          }
                         
                         },
                        child: Container(
                          padding:const EdgeInsets.symmetric(vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColor.appThemeColorOlive,
                             borderRadius: BorderRadius.circular(12),
                          ),
                          child: Center(child: Text("Set".tr(), style: AppTextStyles.k18TextN,),),
                        ),
                      )
                    ],
              
                  );
    });
  }
}