import 'package:flutter/material.dart';

class LanguageSwithcer extends StatefulWidget {
  const LanguageSwithcer({super.key});

  @override
  State<LanguageSwithcer> createState() => _LanguageSwithcerState();
}

class _LanguageSwithcerState extends State<LanguageSwithcer> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      child: Dialog(
        backgroundColor: Colors.white,
        
      ),
    );
  }
}