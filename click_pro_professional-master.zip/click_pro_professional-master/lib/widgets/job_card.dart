import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/model/JobModel/job_data_model.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/view/AppliedJobs/view_quotes.dart';
import 'package:clik_pro_professional/view/Chat/chat_screen.dart';
import 'package:clik_pro_professional/view/Quote/send_quote.dart';
import 'package:clik_pro_professional/widgets/RowWithText.dart';
import 'package:clik_pro_professional/widgets/TextWithIcon.dart';
import 'package:clik_pro_professional/widgets/job_details_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';

class JobItemCard extends StatefulWidget {
 ActiveJobs? obj;
 JobItemCard({this.obj});

  @override
  State<JobItemCard> createState() => _JobItemCardState();
}

class _JobItemCardState extends State<JobItemCard> {

  bool?sendQuote=false;

  getData()async {
    print("USER ID" + myProvider!.userID!);
    if(widget.obj!=null && widget.obj!.bidProfessionalList!=null && widget.obj!.bidProfessionalList.length>0){
       widget.obj!.bidProfessionalList.forEach((element) {
        if(element.compareTo(myProvider!.userID!)==0){
             sendQuote=true;
             setState(() {});
        }
       });
    }



  }

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 100),()=> getData());
  }
  


  Size?_size;
  String?agoTIme="";
  UserProvider?myProvider;
  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context,listen: false);
    _size = MediaQuery.of(context).size;
    agoTIme = Jiffy(widget.obj!.createdDate, "yyyy-MM-dd hh:mm:ss").fromNow();
    return Consumer<UserProvider>(builder: (context,model,child){
      return Container(
                   //height: 150,
                   margin:const EdgeInsets.symmetric(horizontal: 12,vertical: 6),
                   padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                   decoration: BoxDecoration(
                       borderRadius: BorderRadius.circular(12),
                  //border: Border.all(color: Colors.black),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: AppColor.appThemeColorOlive.withOpacity(0.2),
                      
                      spreadRadius: 3,blurRadius: 3
                    )
                  ]
                   ),
                   child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(child: Text(widget.obj!.jobTitle!.toUpperCase(),style: AppTextStyles.k18TextH.copyWith(color: AppColor.appThemeColorSky))),
                            SizedBox(width: _size!.width*0.04),
                           
                             Container(
                              padding:const EdgeInsets.symmetric(horizontal: 6,vertical: 4),
                              decoration: BoxDecoration(
                              color: AppColor.appThemeColorGreen,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(("€" )+ widget.obj!.price!,style: AppTextStyles.k14TextN.copyWith(color: Colors.white)),
                            ),
                          ],
                        ),
                        SizedBox(height: _size!.height*0.005),
                        RowWtihText(title: "Location".tr(),value: widget.obj!.city_name,),
                        SizedBox(height: _size!.height*0.005),
                        RowWtihText(title: "Category".tr(),value: widget.obj!.category_name,),
                        SizedBox(height: _size!.height*0.01),
                        Text("Posted".tr() + (" ") + agoTIme!,style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),),
                        SizedBox(height: _size!.height*0.01),
                        RowWtihText(title: "Due Date".tr(),value: widget.obj!.dueDate,valueColr: AppColor.appRedColor,),
                        SizedBox(height: _size!.height*0.01),
                        Row(children: [
                                  Container(
                                    padding:const EdgeInsets.all(3),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      color: AppColor.appThemeColorOrange
                                    ),
                                    child: Text(widget.obj!.bidCount!,style: AppTextStyles.k16TextN.copyWith(color: Colors.white),),
                                  ),
                                  const SizedBox(width: 8),
                                  Text("Proposals".tr(),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),)
                                ],
                              ),
                              SizedBox(height: _size!.height*0.01),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                          
                            InkWell(
                                onTap: (){
                                  navigateWithPageTransition(context, ChatScreen(customerID: widget.obj!.custId,first_name: widget.obj!.name));
                                },
                              child: Container(
                                 padding:const EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      color: AppColor.appThemeColorOrange
                                    ),
                                    child:const Icon(Icons.chat,size:20,color: Colors.white,),
                              ),
                            ),
                              const SizedBox(width: 8),
                            InkWell(
                                onTap: (){
                                  navigateWithPageTransition(context, JobDetailsPage(obj: widget.obj,));
                                },
                              child: Container(
                                 padding:const EdgeInsets.all(3),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      color: AppColor.appThemeColorOrange
                                    ),
                                    child:const Icon(Icons.remove_red_eye,color: Colors.white,),
                              ),
                            ),
                            const SizedBox(width: 8),
                             !sendQuote!?
                             InkWell(
                              onTap: (){ 
                                     navigateWithPageTransition(context, SendQuote(job_id: widget.obj!.id,customer_budget:widget.obj!.price,cust_id: widget.obj!.custId,));
                              },
                               child: Container(
                                 padding:const EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      color: AppColor.appThemeColorOrange
                                    ),
                                    child:Text("Send a Quote".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)
                                 ),
                             ):InkWell(
                              onTap: (){
                                     navigateWithPageTransition(context, ViewQuotes(quote_id:  widget.obj!.id,));
                              },
                               child: Container(
                                 padding:const EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      color: AppColor.appThemeColorOlive
                                    ),
                                    child:Text("See the Quote".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.white),)
                                 ),
                             ),

                          ],
                        ),
                    ],
                   ),
                 );
    });
  }
}