import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:clik_pro_professional/widgets/CustomeLoader.dart';
import 'package:clik_pro_professional/widgets/fade_in_image.dart';
import 'package:clik_pro_professional/widgets/image_preview.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:jiffy/jiffy.dart';
import 'package:provider/provider.dart';

import '../model/JobModel/job_data_model.dart';

class JobDetailsPage extends StatefulWidget {
ActiveJobs?obj;

JobDetailsPage({this.obj});

  @override
  State<JobDetailsPage> createState() => _JobDetailsPageState();
}

class _JobDetailsPageState extends State<JobDetailsPage> {

  getData()async {
    await Provider.of<UserProvider>(context,listen: false).getCategory();
    await Provider.of<UserProvider>(context,listen: false).getCity();

    if(myProvider!.categoryList!=null && myProvider!.categoryList.length>0){
      if(widget.obj!=null && ![null,""].contains(widget.obj!.category)){
        myProvider!.categoryList.forEach((element) {
          if(element.id!.compareTo(widget.obj!.category!)==0){
              categoryName = element.categoryName;
          }
        });
      }
    }
     if(myProvider!.cityList!=null && myProvider!.cityList.length>0){
      if(widget.obj!=null && ![null,""].contains(widget.obj!.location)){
        myProvider!.cityList.forEach((element) {
          if(element.id!.compareTo(widget.obj!.location!)==0){
              cityName = element.cityName;
          }
        });
      }
    }
    setState(() {
      
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
  }
  String?categoryName="";
  String?cityName="";

  UserProvider?myProvider;
  String?agoTIme="";

  Size?_size;
  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context,listen: false);
     _size = MediaQuery.of(context).size;
  // agoTIme = Jiffy(widget.obj!.createdDate, "yyyy-MM-dd hh:mm:ss").fromNow();
    return Consumer<UserProvider>(builder: (context,model,child){
      return Scaffold(
       appBar: AppBar(
        elevation: 0.0,
        centerTitle: true,
        iconTheme:const IconThemeData(color: Colors.black),
        backgroundColor: Colors.transparent,
        title: Text("Job Details".tr(),style: AppTextStyles.k16TextN.copyWith(color: Colors.black),),
        
       ),
       body: Stack(
         children: [
           ListView(
            //padding:const EdgeInsets.symmetric(horizontal: 14),
            children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  child: Text(widget.obj!.jobTitle!,style: AppTextStyles.k20TextN),
                ),
                SizedBox(height: _size!.height*0.01),
                
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  child: Text(categoryName!,style: AppTextStyles.k18TextN.copyWith(color: AppColor.appThemeColorOlive)),
                ),
                // Padding(
                //   padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                //  // child: Text("Posted".tr() + (" ")+ agoTIme!,style: AppTextStyles.k14TextN),
                // ),
                 SizedBox(height: _size!.height*0.02),
                 const Divider(color: Colors.grey),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: Text(widget.obj!.description!, style: AppTextStyles.k14TextN,),
                  ),

                  /*Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: Text("https://www.betterteam.com/plumber-job-description",style: AppTextStyles.k14TextN.copyWith(color: AppColor.appThemeColorOlive),),
                  ),*/

                  SizedBox(height: _size!.height*0.02),
                  const Divider(color: Colors.grey),

                  Padding(
                       padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                       child: Row(
                         children: [
                           Text("Fixed Price".tr() + (" : "), style: AppTextStyles.k14TextN,),
                           Text(("€ ") + widget.obj!.price!, style: AppTextStyles.k16TextN,),
                         ],
                       ),
                  ),

                        SizedBox(height: _size!.height*0.02),
                  const Divider(color: Colors.grey),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: Text("Location Details".tr(),style: AppTextStyles.k16TextN,),
                  ),
                  SizedBox(height: _size!.height*0.01),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: Text(cityName!,style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive)),
                  ),

                       SizedBox(height: _size!.height*0.02),
                  const Divider(color: Colors.grey),

                Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: Text("Attachments".tr(),style: AppTextStyles.k16TextN,),
                  ),
                Container(
                  height: _size!.height*.15,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: ListView.builder(
                    itemCount: widget.obj!.attachmnetList.length,
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    itemBuilder: (context,index){
                     return InkWell(
                       onTap: (){
                         navigatetoAnotherPage(context, ImagePreviewScreen(path: widget.obj!.attachmnetList[index],));
                       },
                       child: Container(
                                     height: _size!.height*0.15,
                                     width: _size!.width*0.3,
                             
                                     margin: const EdgeInsets.only(right: 10),
                                     decoration: BoxDecoration(
                                      border: Border.all(color: AppColor.appThemeColorGreen,width: 2),
                                      borderRadius: BorderRadius.circular(10),
                                     
                      
                                     ),
                                     child: ClipRRect(
                                         borderRadius: BorderRadius.circular(10),
                                      child: FadeImageWithError(imgPath:widget.obj!.attachmnetList[index],)),
                                   ),
                     );
                  }),
                ),
            ],
           ),
           
           model.isLoading!?CustomLoader():Container(),
         ],
       ),
    );
    });
  }
}