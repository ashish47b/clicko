import 'package:flutter/material.dart';


class NoDataWidget extends StatefulWidget {
  bool?isloading;

  NoDataWidget({this.isloading});

  @override
  State<NoDataWidget> createState() => _NoDataWidgetState();
}

class _NoDataWidgetState extends State<NoDataWidget> {
  Size?_size;
  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return widget.isloading!?Container(): Column(
            children: [
              Center(child: Container(
                height: _size!.height*0.6,
                
                decoration:const BoxDecoration(
                  //color: Colors.red,
                  image: DecorationImage(image: AssetImage("assets/images/no_data1.png"),fit: BoxFit.fill,)
                ),
              )),
            // const Text("No results found.",style: TextStyle(fontSize: 22,fontWeight: FontWeight.w500)),
            // const SizedBox(height: 3),
            // const Padding(
            //   padding:  EdgeInsets.symmetric(horizontal: 0),
            //   child: Text("Currently No data is available here please\n add some data ",textAlign: TextAlign.center, style: TextStyle(fontSize: 16),),
            // ),
            // const SizedBox(height: 6),

            ],
          );
  }
}