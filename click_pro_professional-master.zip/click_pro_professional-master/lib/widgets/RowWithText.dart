
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:flutter/material.dart';

import '../utils/text_styles.dart';

class RowWtihText extends StatefulWidget {
 String?title,value;
 Color? titleColor,valueColr;
 RowWtihText({this.title,this.value,this.titleColor,this.valueColr});

  @override
  State<RowWtihText> createState() => _RowWtihTextState();
}

class _RowWtihTextState extends State<RowWtihText> {
  @override
  Widget build(BuildContext context) {
    return Row(
          children: [
            Text(widget.title! + (" : " ),style: AppTextStyles.k16TextN.copyWith(color: AppColor.appThemeColorOlive),),
            Text(widget.value!, style: AppTextStyles.k16TextN.copyWith(color:widget.valueColr!=null?widget.valueColr!: AppColor.appThemeColorOrange),)
          ],
     );
  }
}