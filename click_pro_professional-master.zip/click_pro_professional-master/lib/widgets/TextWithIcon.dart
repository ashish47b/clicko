import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:flutter/material.dart';

class TextWithIcon extends StatelessWidget {
 String?img,title;
 TextWithIcon({this.img,this.title});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration:const BoxDecoration(
       
      ),
    //  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Image.asset(img!,height: 20,),
          const SizedBox(width: 6),
          Text(title!,style: AppTextStyles.k16TextN)
        ],
      ),
    );
  }
}