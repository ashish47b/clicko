
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/utils/common.dart';
import 'package:clik_pro_professional/view/BottomNavBar/bottomNavbar.dart';
import 'package:clik_pro_professional/view/ProfilePage/personal_info.dart';
import 'package:flutter/material.dart';

import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';

class VerifySuccessWidget extends StatefulWidget {
  const VerifySuccessWidget({super.key});

  @override
  State<VerifySuccessWidget> createState() => _VerifySuccessWidgetState();
}

class _VerifySuccessWidgetState extends State<VerifySuccessWidget> {
  
  getData()async {
    await Provider.of<UserProvider>(context,listen: false).profileList();
    if(myProvider!.profileData!=null){
      Future.delayed(const Duration(seconds: 3),()=>   navigateWithPageTransition(context, AddPersonalScreen(profileData: myProvider!.profileData!,from: "start")));
    }
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 200),()=> getData());
    
  }

  UserProvider? myProvider;
  Size?_size;
  @override
  Widget build(BuildContext context) {
    myProvider = Provider.of<UserProvider>(context,listen: false);
    _size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        margin:const EdgeInsets.symmetric(horizontal: 20),
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.only(top: _size!.height*0.05),
              width: _size!.width*0.7,
              height:_size!.height*0.1,           
              child: Image.asset("assets/logos/logo1.png"),
          ),
          SizedBox(height: _size!.height*0.08),
          SizedBox(
            height: 200,
            child: Lottie.asset("assets/lottie/success.json"),
           ),
          const SizedBox(height: 40),
       
        ]),
      ),
    );
  }
}