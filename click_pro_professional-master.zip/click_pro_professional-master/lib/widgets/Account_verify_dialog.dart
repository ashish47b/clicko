
import 'package:clik_pro_professional/Provider/user_provider.dart';
import 'package:clik_pro_professional/utils/app_color.dart';
import 'package:clik_pro_professional/utils/text_styles.dart';
import 'package:easy_localization/easy_localization.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class AccountVerifyDialog extends StatelessWidget {
  const AccountVerifyDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<UserProvider>(builder: (context,model,child){
      return AlertDialog(

                title: Text("Account Verification".tr()),
                content: Text("Your Account is not Verify , First Verify your account for the further process".tr(),style: AppTextStyles.k14TextN),
                actions: [
                         InkWell(
                          onTap: (){
                            model.generateOtp(context);
                          },
                           child: Container(
                                    height: 30,
                                    decoration: BoxDecoration(
                                    color: AppColor.appThemeColorOrange,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                              child: Center(
                            child: Text("Verify Account".tr()),
                           ),
                          ),
                         )
                ],
              );
    });
  }
}