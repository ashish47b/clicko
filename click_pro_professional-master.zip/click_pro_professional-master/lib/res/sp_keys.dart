import 'package:shared_preferences/shared_preferences.dart';

class SPData{
  static String app_sp="lasting_owner_app_";

  static String BASE_URL=app_sp+"base_url";
  static String USER_ID=app_sp+"userId";
  static String USER_Data=app_sp+"user_data";
  static String USER_ROLE=app_sp+"user_role";
  static String USER_COMPANY_ID=app_sp+"user_company_id";
  static String USER_EMAIL=app_sp+"user_email";
  static String USER_NAME=app_sp+"username";
  static String USER_PHONE = app_sp + "phone";
  static String USER_VERIFY = app_sp + "verify";
 
  static String USER_TRACKING_PERMISSION=app_sp+"trackingPermission";
  static String USER_TOKEN=app_sp+"userToken";
  static String USER_DB_NAME=app_sp+"companyDbName";
  static String USER_ROUTE_PLAN_STATUS=app_sp+"route_plasn_started";
  static String USER_ROUTE_DATA=app_sp+"route_data_list";
  static String USER_Profile_img=app_sp+"profile_pic";
  static String? email_validate=r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';


  static String SHIFT_START= app_sp+"_shift_start";
  static String SHIFT_START_DATE= app_sp+"_shift_start_date";

  static String FOR_IMAGE = app_sp+"image";
  static final String Priority_task_DATA_LIST = "work_data_list";


  static saveStringValue(String key,String value) async{
    await SharedPreferences.getInstance().then((val) {
      val.setString(key, value);
    });
  }
  static saveBoolValue(String key,bool value) async{
    await SharedPreferences.getInstance().then((val) {
      val.setBool(key, value);
    });
  }
  static String map_key="AIzaSyA0J55ze_la1WANrT-oPvT5PorIrgvFyWU";
}