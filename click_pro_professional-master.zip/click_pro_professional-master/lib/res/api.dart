class API{
  //static const String BASE_URL  = "https://pro.clikopro.fr/api/";
 static const String BASE_URL  = "https://clikopro.fr/api/";
  
  
  static const String LOG_IN =BASE_URL+ "auth/login";
  static const String REGISTER = BASE_URL+ "auth/register";
  static const String GENERATE_OTP = BASE_URL +  "auth/generate_otp";
  static const String VERIFY = BASE_URL +  "auth/verify_account";
  static const String CITY_DATA = BASE_URL + "home/get_active_city";
  static const String CATEGORY_DATA = BASE_URL + "home/get_active_cat";
  static const String JOB_API = BASE_URL + "home/profess_jobList";
  static const String VIEW_JOB_API = BASE_URL + "home/view_job";
  static const String PENDING_QUOTE = BASE_URL + "quotation/pending_quote";
  static const String ACTIVE_QUOTE  = BASE_URL + "quotation/active_quote";
  static const String REJECT_QUOTE  = BASE_URL + "quotation/rejected_quote";
  static const String INVOICE_LIST = BASE_URL + "home/invoicelist";
  static const String VIEW_INVOICE = BASE_URL + "home/viewinvoice";
  static const String SAVE_QUOTATION = BASE_URL + "home/savequotation";
  static const String VIEW_QUOTATION = BASE_URL + "home/viewquot";
  static const String SAVE_APPOINTMENT = BASE_URL + "home/saveappointment";
  static const String PROFF_PROFILE = BASE_URL + "home/professionalProfile";
  static const String GET_RATING = BASE_URL + "jobs/getProfRating";
  static const String CHAT_USER = BASE_URL + "home/userlist";
  static const String JOB_STATUS_API = BASE_URL + "home/profess_appointment_jobs";
  static const String COMPLETE_JOB = BASE_URL + "home/jobcompleted";
  static const String APPOINTMENT_List = BASE_URL + "home/appointmentlist";
  static const String SUBSCRIPTION_LIST = BASE_URL + "home/listsubscription";
  static const String NEGOTIATION_LIST = BASE_URL + "home/negotiation";
  static const String SAVE_PROFILE = BASE_URL + "home/update_profess_profile";
  static const String SAVE_NEGOTIATION = BASE_URL + "home/save_milestone";
  static const String ADD_CHAT_MESSAGE = BASE_URL + "home/addmessage";
  static const String ALL_CHAT_MESSAGE = BASE_URL + "home/allmessages";
  static const String createsubscription = BASE_URL + "home/createsubscription";
  static const String APPROVE_REJ_NEGO = BASE_URL + "home/pro_nego_aprv_rej";
  static const String LOG_OUT = BASE_URL + "auth/logout";
  static const String PRO_SEARCH_JOB = BASE_URL + "home/pro_search_job";


}