//import 'package:clik_pro_professional/utils/PushNotificationsManager.dart';
import 'package:clik_pro_professional/utils/routes.dart';
import 'package:clik_pro_professional/view/Splash/splash_screen.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'Provider/user_provider.dart';

void main() async{
   WidgetsFlutterBinding.ensureInitialized();
   await EasyLocalization.ensureInitialized();
   runApp(
    EasyLocalization(
      supportedLocales:const [Locale('en', 'US'), Locale('fr', 'BE')],
      saveLocale: true,
      path: 'assets/translations', // <-- change the path of the translation files 
      fallbackLocale:const Locale('fr', 'BE'),
      startLocale:const Locale('fr',"BE"),
      child:const MyApp()
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
  //  PushNotificationsManager().init();
    return ChangeNotifierProvider<UserProvider>.value(
      value: UserProvider(),
      child: Consumer<UserProvider>(builder: (context,model,child){
        return MultiProvider(providers: [
          ChangeNotifierProvider<UserProvider>(create:(context)=> UserProvider(),lazy: false,),   //PTS
        ],
            child: MaterialApp(
                title: 'Flutter Demo',
                debugShowCheckedModeBanner: false,
                localizationsDelegates: context.localizationDelegates,
                supportedLocales: context.supportedLocales,
                locale: context.locale,
                theme: ThemeData(
                  
                  primarySwatch: Colors.blue,
                ),
              initialRoute: Routes.SPLASH,
              routes: {
                Routes.SPLASH : (context) =>const SplashScreen(),
              },
              )
        );
      },
      ),
    );
  }
}






