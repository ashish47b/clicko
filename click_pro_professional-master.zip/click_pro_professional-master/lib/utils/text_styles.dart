import 'package:flutter/cupertino.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTextStyles{

    static  TextStyle k20TextH = GoogleFonts.blackOpsOne(
       fontSize: 20, fontWeight: FontWeight.w500
  );

  static  TextStyle k18TextH = GoogleFonts.blackOpsOne(
       fontSize: 18, fontWeight: FontWeight.w500
  );

  static  TextStyle k16TextH = GoogleFonts.blackOpsOne(
       fontSize: 16, fontWeight: FontWeight.w500
  );

    static  TextStyle k14TextH = GoogleFonts.blackOpsOne(
       fontSize: 14, fontWeight: FontWeight.w500
  );

  //

      static  TextStyle k20TextN = GoogleFonts.montserrat(
       fontSize: 20, fontWeight: FontWeight.w500
  );

  static  TextStyle k18TextN = GoogleFonts.montserrat(
       fontSize: 18, fontWeight: FontWeight.w500
  );

  static  TextStyle k16TextN = GoogleFonts.montserrat(
       fontSize: 16, fontWeight: FontWeight.w500
  );

    static  TextStyle k14TextN = GoogleFonts.montserrat(
       fontSize: 14, fontWeight: FontWeight.w400
  );
      static  TextStyle k12TextN = GoogleFonts.montserrat(
       fontSize: 12, fontWeight: FontWeight.w400
  );
        static  TextStyle k13TextN = GoogleFonts.montserrat(
       fontSize: 13, fontWeight: FontWeight.w400
  );
       static  TextStyle k25TextN = GoogleFonts.montserrat(
       fontSize: 25, fontWeight: FontWeight.w400
  );
}