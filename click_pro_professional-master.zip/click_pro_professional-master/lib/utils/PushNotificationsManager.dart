// import 'dart:convert';

// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';

// class PushNotificationsManager {

//   PushNotificationsManager._();

//   factory PushNotificationsManager() => _instance;

//   static final PushNotificationsManager _instance = PushNotificationsManager._();

//   final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
//   bool _initialized = false;
//   String? tk;
//   get token => tk;
//   final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
//   Future<void> init() async {
//     if (!_initialized) {
//       // For iOS request permission first.
//       _firebaseMessaging.requestPermission();
//       _firebaseMessaging.getInitialMessage();

//       // For testing purposes print the Firebase Messaging token
//       tk = await _firebaseMessaging.getToken();
//       print("FirebaseMessaging token: $tk");

//       _initialized = true;
// /*      AndroidNotificationChannel channel = AndroidNotificationChannel(
//         'high_importance_channel', // id
//         'High Importance Notifications', // title
//         'This channel is used for important notifications.', // description
//         importance: Importance.high,
//       );*/
//       FirebaseMessaging.onMessage.listen((message) async{
//         RemoteNotification notification = message.notification!;
//         print(notification.body);
//         AndroidNotification android = message.notification!.android!;
//         if (notification != null && android != null) {
//           flutterLocalNotificationsPlugin.show(
//               notification.hashCode,
//               notification.title,
//               notification.body,
//               NotificationDetails(
//                 android: AndroidNotificationDetails(
//                   //notification..id,
//                     notification.title!,
//                     notification.body!,
//                      //      one that already exists in example app.
//                     icon: 'launch_background',importance: Importance.high,
//                     channelShowBadge: true,
//                     visibility: NotificationVisibility.public,
//                     showProgress: true,
//                     colorized: true,
//                     usesChronometer: true
//                 ),
//               ));
//           AndroidNotificationDetails? notificationAndroidSpecifics =
//           AndroidNotificationDetails(
//               "101", "aa",
//               importance: Importance.max,
//               priority: Priority.high,
//               groupKey: "101");
//           NotificationDetails notificationPlatformSpecifics =
//           NotificationDetails(android: notificationAndroidSpecifics, iOS:null);

//           await flutterLocalNotificationsPlugin.show(
//               1,
//               'Jeff Chang',
//               'Please join us to celebrate the...',
//               notificationPlatformSpecifics);
//         }});
//       FirebaseMessaging.onMessageOpenedApp.listen((message) {
//         RemoteNotification notification = message.notification!;
//         print(jsonEncode(notification));

//       });
// /*      _firebaseMessaging.configure(
//         // onBackgroundMessage: (Map<String?, dynamic> message) async {
//         //   print("onMessage: $message");
//         //   callFcm();
//         // },
//         onMessage: (Map<String?, dynamic> message) async {
//           print("onMessage: $message");
//           var androidPlatformChannelSpecifics = AndroidNotificationDetails('com.pridetruck', 'com.pridetruck', 'com.pridetruck',importance: Importance.high, priority: Priority.high, ticker: 'ticker',
//               icon: "@drawable/ic_notification",color: Colors.green);
//           var iOSPlatformChannelSpecifics = IOSNotificationDetails();
//           var platformChannelSpecifics = NotificationDetails(android:androidPlatformChannelSpecifics,iOS: iOSPlatformChannelSpecifics);
//           await new FlutterLocalNotificationsPlugin().show(0, message['notification']['title'], message['notification']['body'], platformChannelSpecifics, payload: message['data']['id']);
//           //callFcm();
//         },
//         onLaunch: (Map<String?, dynamic> message) async {
//           print("onLaunch: $message");
//         },
//         onResume: (Map<String?, dynamic> message) async  {
//           print("onResume: $message");
//           callFcm();
//         },
//       );*/
//       //callFcm();
//     }
//   }
//   callFcm() async{
//     /*FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
//     FlutterLocalNotificationsPlugin();
// // initialise the plugin. app_icon needs to be a added as a drawable resource to the Android head project
//     const AndroidInitializationSettings initializationSettingsAndroid =
//     AndroidInitializationSettings('@mipmap/ic_launcher');
//     final IOSInitializationSettings initializationSettingsIOS =
//     IOSInitializationSettings(
//         onDidReceiveLocalNotification: onDidReceiveLocalNotification);
//     final MacOSInitializationSettings initializationSettingsMacOS =
//     MacOSInitializationSettings();
//     final InitializationSettings initializationSettings = InitializationSettings(
//         android: initializationSettingsAndroid,
//         iOS: initializationSettingsIOS,
//         macOS: initializationSettingsMacOS);
//     await flutterLocalNotificationsPlugin.initialize(initializationSettings,
//         onSelectNotification: selectNotification);*/
//   }
//   Future onDidReceiveLocalNotification(a,str1,str2,str3) async{
//         //print()
//   }


//   Future selectNotification(String? payload) async {
//     if (payload != null) {
//       print('notification payload: $payload');
//     }
//     // await Navigator.push(
//     //   context,
//     //   MaterialPageRoute<void>(builder: (context) => SecondScreen(payload)),
//     // );
//   }
// }